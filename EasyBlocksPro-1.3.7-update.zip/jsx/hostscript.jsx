// hostscript.jsx -- EasyBlocks Pro entry point
// ASCII-only: AE ExtendScript reads JSX as Latin-1, not UTF-8.

#include "utils.jsx"
#include "blocks.jsx"

// Open a system folder-picker dialog and return the chosen path.
// Returns 'OK:<path>', 'CANCELLED', or 'ERROR:<msg>'.
function selectFolder() {
  try {
    var folder = Folder.selectDialog('Select folder');
    if (!folder) return 'CANCELLED';
    return 'OK:' + folder.fsName;
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// Open an AE project file dialog. Used by the AI Generate tab to resolve the
// output folder relative to the current AE project.
function getProjectFolder() {
  try {
    var proj = app.project;
    if (!proj || !proj.file) return 'NONE';
    return 'OK:' + proj.file.parent.fsName;
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// Open a file in the OS default explorer / Finder.
function openFolder(folderPath) {
  try {
    var f = new Folder(folderPath);
    if (f.exists) { f.execute(); return 'ok'; }
    return 'error: folder not found';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// Import a rendered .mov file into the current AE project.
// Returns 'ok:<compName>' or 'error:<msg>'.
function importMov(movPath, compName) {
  try {
    var f = new File(movPath);
    if (!f.exists) return 'error: file not found: ' + movPath;
    var io = new ImportOptions(f);
    io.importAs = ImportAsType.FOOTAGE;
    var item = app.project.importFile(io);
    item.name = compName || item.name;
    // Place into a "Renders" folder in the project
    var folder = null;
    for (var i = 1; i <= app.project.numItems; i++) {
      if (app.project.items[i] instanceof FolderItem &&
          app.project.items[i].name === 'EBP_Renders') {
        folder = app.project.items[i];
        break;
      }
    }
    if (!folder) folder = app.project.items.addFolder('EBP_Renders');
    item.parentFolder = folder;
    return 'ok:' + item.name;
  } catch (e) {
    return 'error: ' + e.message;
  }
}

// Set by the panel on load via cs.evalScript (see app.js).
var _ebpScriptDir = '';
var _ebpIconDir   = '';   // path to NVIDIA icon SVGs (set by panel alongside _ebpScriptDir)

// Build a clean comp name from block type + title.
function ebpMakeCompName(blockType, title) {
  var tag = {
    'slide-title':    'Title',
    'cards-1':        '1Card',
    'cards-2':        '2Cards',
    'cards-3':        '3Cards',
    'cards-4':        '4Cards',
    'cards-5':        '5Cards',
    'cards-compare':       'Compare',
    'cards-media':         'MediaCards',
    'cards-specs-a':       'SpecsA',
    'cards-specs-b':       'SpecsB',
    'cards-specs-c':       'SpecsC',
    'cards-corner':        'CornerCards',
    'cards-corner-sq':     'CornerSq',
    'cards-corner-slim':   'CornerSlim',
    'cards-top-bar':       'TopBarCards',
    'cards-circle':        'CircleCards',
    'cards-bottom-bar':    'BottomBarCards',
    'bullets':         'Bullets',
    'diagram-flow':   'FlowDiagram',
    'text-bullets':   'TextBullets',
    'text-nested':    'TextNested',
    'text-2col':      'Text2Col',
    'text-numbered':  'TextNumbered',
    'text-cli':          'TextCLI',
    'text-code-bullets': 'TextCodeBullets',
    'text-code-cli':     'TextCodeCLI',
    'text-links':        'TextLinks',
    'text-body-bullets': 'TextBodyBullets',
    'text-errors':       'TextErrors',
    'rack-callout':      'RackCallout',
    'cards-device':      'DeviceCard',
    'comp-timeline':     'CompTimeline',
    'comp-logo-strip':   'LogoStrip',
    'comp-compare':      'CompareTable',
    'comp-tags':         'TagsStrip',
    'comp-callout':      'Callout',
    'comp-icon-grid':    'IconGrid',
    'diagram-flow-4': 'Flow4Step',
    'diagram-cycle':  'FlowCycle',
    'table-1col':     'Table1Col',
    'table-2col':     'Table2Col',
    'table-3col':     'Table3Col',
    'table-4col':     'Table4Col',
    'chart-bar':          'BarChart',
    'chart-bar-v':        'BarChartV',
    'chart-bar-stacked':  'StackedChart',
    'chart-donut':        'DonutChart',
    'tree-3':         'Tree3',
    'tree-2level':    'Tree2Level',
    'tree-h3':        'TreeH3',
    'tree-h5':        'TreeH5',
    'diagram-process-2':      'Process2',
    'diagram-timeline':       'Timeline',
    'diagram-funnel':         'Funnel',
    'diagram-matrix':         'Matrix',
    'diagram-steps':          'Steps',
    'topology-gh200':         'GH200Pair',
    'topology-nvlink-switch': 'NVLinkSwitch',
    'topology-spine-leaf':    'SpineLeaf',
    'topology-gpu-node':      'GPUNode',
    'topology-multi-rack':    'MultiRack',
    'diagram-parallel-split-ol': 'ParallelSplitOL',
    'diagram-split-2-ol':        'Split2OL',
    'diagram-split-3-ol':        'Split3OL',
    'diagram-split-5-ol':        'Split5OL',
    'diagram-split-mirror-ol':   'SplitMirrorOL',
    'custom':                    'Custom',
    'comp-stat':    'StatCallout',
    'comp-kpi':     'KPIRow',
    'comp-quote':   'PullQuote',
    'comp-divider': 'SectionDiv',
    'text-agenda':      'Agenda',
    'text-acronym':     'Acronym',
    'diagram-chal-sol': 'ChalSol',
    'text-code-quad':   'CodeQuad',
    'text-code-split':        'CodeSplit',
    'diagram-flow-bullets-3': 'FlowBullets3',
    'diagram-hub-spoke':      'HubSpoke'
  }[blockType];

  // element-* types: derive tag from suffix
  if (!tag && blockType.indexOf('element-') === 0) {
    var sfx = blockType.substring(8);
    var words = sfx.split('-');
    var camel = '';
    for (var wi = 0; wi < words.length; wi++) {
      camel += words[wi].charAt(0).toUpperCase() + words[wi].slice(1);
    }
    tag = 'El_' + camel;
  }
  tag = tag || blockType;

  var t = (title || '').replace(/[^A-Za-z0-9 _-]/g, '').substring(0, 24).replace(/^\s+|\s+$/g, '');
  return 'EBP_' + tag + (t ? '_' + t : '');
}

// Returns (or creates) a project folder by name.
function ebpGetOrCreateFolder(name) {
  var proj = app.project;
  for (var i = 1; i <= proj.numItems; i++) {
    var item = proj.items[i];
    if (item instanceof FolderItem && item.name === name) return item;
  }
  return proj.items.addFolder(name);
}

function ebpFolderForBlockType(bt) {
  if (bt === 'slide-title' || bt === 'bullets' || bt.indexOf('text-') === 0) return 'Text';
  if (bt.indexOf('cards-') === 0)    return 'Cards';
  if (bt.indexOf('diagram-') === 0)  return 'Diagrams';
  if (bt.indexOf('tree-') === 0)     return 'Trees';
  if (bt.indexOf('rack-') === 0)     return 'Racks';
  if (bt.indexOf('chart-') === 0)    return 'Charts';
  if (bt.indexOf('table-') === 0)    return 'Tables';
  if (bt.indexOf('element-') === 0)   return 'Elements';
  if (bt.indexOf('topology-') === 0)  return 'Topologies';
  if (bt.indexOf('comp-') === 0)      return 'Components';
  if (bt === 'custom')                return 'Custom';
  return 'Misc';
}

// Universal post-build pre-comp grouper.
// Walks the workspace comp's layers and groups them by detected group-ID
// (first numeric token after `EB_` in the layer name). Each detected group
// becomes its own pre-comp. Layers named EB_Background/EB_Title/EB_Subtitle
// are skipped (they live at the top level). Layers that are already pre-comps
// (e.g., the block's create fn already did its own grouping) are left as-is.
//
// This makes "Pre-comp cards" universal — every block exposes its visual
// groups as standalone pre-comps regardless of whether its create function
// implemented precomping internally. The "Add to Current Comp" flow can
// then pull each pre-comp directly into the user's active comp.
function _ebpAutoPrecompGroups(comp, params) {
  if (!params || !params.precomp) return 0;
  if (!comp || !comp.numLayers) return 0;

  var skipExact = { 'EB_Background': 1, 'EB_Title': 1, 'EB_Subtitle': 1 };

  function detectGid(nm) {
    if (!nm) return null;
    var rest = String(nm).replace(/^EB_/, '');
    var m = rest.match(/(\d+)/);
    return m ? m[1] : null;
  }

  // Snapshot layers BY NAME (not index) since indices shift after each
  // precompose call.
  var groupNames = {}; // gid -> [layer names]
  for (var i = 1; i <= comp.numLayers; i++) {
    var lyr = comp.layers[i];
    var nm = '';
    try { nm = lyr.name || ''; } catch(e) {}
    if (skipExact[nm]) continue;

    // If this layer is already a pre-comp (block did it itself), leave it alone.
    var alreadyPrecomp = false;
    try { alreadyPrecomp = (lyr.source instanceof CompItem); } catch(e) {}
    if (alreadyPrecomp) continue;

    var gid = detectGid(nm);
    if (gid !== null) {
      if (!groupNames[gid]) groupNames[gid] = [];
      groupNames[gid].push(nm);
    }
  }

  // Collect group IDs and sort numerically so naming is stable.
  var gids = [];
  for (var k in groupNames) gids.push(k);
  gids.sort(function(a, b) { return (parseInt(a, 10) || 0) - (parseInt(b, 10) || 0); });

  // If only 1 group detected, the block is single-element (e.g., comp-stat) —
  // nothing meaningful to split out. Bail.
  if (gids.length < 2) return 0;

  var compTitle = String(comp.name || 'Block').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 40);
  var precompedCount = 0;

  for (var g = 0; g < gids.length; g++) {
    var gid = gids[g];
    var names = groupNames[gid];
    var indices = [];
    for (var li = 1; li <= comp.numLayers; li++) {
      var ln = '';
      try { ln = comp.layers[li].name || ''; } catch(e) {}
      // Re-resolve indices each iteration (they shift after each precompose).
      for (var n = 0; n < names.length; n++) {
        if (ln === names[n]) { indices.push(li); break; }
      }
    }
    if (indices.length > 0) {
      try {
        comp.layers.precompose(indices, compTitle + '_g' + gid, true);
        precompedCount++;
      } catch(e) {}
    }
  }
  return precompedCount;
}

// Main entry point called from the panel via CSInterface.evalScript().
function createBlock(paramsJSON) {
  try {
    if (!_ebpScriptDir) {
      return 'error: Script path not initialised -- close and reopen the EasyBlocks Pro panel, then try again.';
    }

    // Hot-reload utils + blocks so edits take effect without restarting AE.
    try {
      $.evalFile(_ebpScriptDir + '/utils.jsx');
      $.evalFile(_ebpScriptDir + '/blocks.jsx');
    } catch(eLoad) {
      var _loadWarn = 'warn:hot-reload failed (' + eLoad.message + ')';
    }

    var params = (typeof paramsJSON === 'object') ? paramsJSON : JSON.parse(paramsJSON);
    var compName = (params.compNamePrefix || '') + ebpMakeCompName(params.blockType, params.title);

    // Capture the user's currently-active comp BEFORE we create the workspace comp
    // (used when params.insertTarget === 'active' to add the new block into it).
    var _origActiveComp = null;
    try {
      if (app.project.activeItem && (app.project.activeItem instanceof CompItem)) {
        _origActiveComp = app.project.activeItem;
      }
    } catch(_oe) {}

    var comp;
    try { comp = app.project.items.addComp(compName, 1920, 1080, 1, 10, 30); }
    catch(e) { return 'error: [addComp] ' + e.message; }

    try { comp.bgColor = [1, 1, 1]; } catch(e) {}

    try { comp.parentFolder = ebpGetOrCreateFolder(ebpFolderForBlockType(params.blockType)); }
    catch(e) { return 'error: [parentFolder] ' + e.message; }

    try {
      var _bg = comp.layers.addSolid([1, 1, 1], 'EB_Background', 1920, 1080, 1);
      _bg.label = 2; // Yellow — brightest available AE label color
    }
    catch(e) { return 'error: [addSolid] ' + e.message; }

    // Only auto-open the new comp if we're NOT going to drop it into the active comp.
    // For active-comp inserts the user stays focused on their working comp.
    if (params.insertTarget !== 'active' || !_origActiveComp) {
      try { comp.openInViewer(); } catch(e) {}
    }

    app.beginUndoGroup('EasyBlocks Pro: ' + params.blockType);

    try { $.global._ebSkipPosAnim = (params.posAnim   === false); } catch(e) { $.global._ebSkipPosAnim = false; }
    try { $.global._ebSkipAnimIn  = (params.animateIn === false); } catch(e) { $.global._ebSkipAnimIn  = false; }

    if (params.blockType.indexOf('element-') === 0) {
      createElementBlock(comp, params);
    } else switch (params.blockType) {
      case 'slide-title':   createSlideTitleBlock(comp, params);      break;
      case 'cards-1':       createIconCardsBlock(comp, params, 1);    break;
      case 'cards-2':       createIconCardsBlock(comp, params, 2);    break;
      case 'cards-3':       createIconCardsBlock(comp, params, 3);    break;
      case 'cards-4':       createIconCardsBlock(comp, params, 4);    break;
      case 'cards-5':       createIconCardsBlock(comp, params, 5);    break;
      case 'cards-compare':       createComparisonBlock(comp, params);    break;
      case 'cards-media':         createMediaCardsBlock(comp, params);    break;
      case 'cards-corner':        createCornerCardsBlock(comp, params);   break;
      case 'cards-corner-sq':     createCornerSquareBlock(comp, params);  break;
      case 'cards-corner-slim':   createCornerSlimBlock(comp, params);    break;
      case 'cards-top-bar':       createTopBarCardsBlock(comp, params);   break;
      case 'cards-circle':        createCircleCardsBlock(comp, params);   break;
      case 'cards-bottom-bar':    createBottomBarCardsBlock(comp, params); break;
      case 'bullets':         createBulletListBlock(comp, params);    break;
      case 'diagram-flow':    createFlowDiagramBlock(comp, params);   break;
      case 'text-bullets':    createTextBulletsBlock(comp, params);   break;
      case 'bullet-list':     createBulletDotListBlock(comp, params);   break;
      case 'check-list':      createCheckmarksListBlock(comp, params);  break;
      case 'text-nested':     createTextNestedBlock(comp, params);    break;
      case 'text-2col':       createText2ColBlock(comp, params);      break;
      case 'text-numbered':   createTextNumberedBlock(comp, params);  break;
      case 'text-cli':          createTextCLIBlock(comp, params);          break;
      case 'text-code-bullets': createTextCodeBulletsBlock(comp, params);  break;
      case 'text-code-cli':     createTextCodeCLIBlock(comp, params);      break;
      case 'text-links':        createTextLinksBlock(comp, params);        break;
      case 'text-body-bullets': createTextBodyBulletsBlock(comp, params);  break;
      case 'text-errors':       createTextErrorsBlock(comp, params);       break;
      case 'rack-callout':      createRackBlock(comp, params);         break;
      case 'cards-device':      createDeviceCardBlock(comp, params);   break;
      case 'comp-timeline':     createCompTimelineBlock(comp, params); break;
      case 'comp-logo-strip':   createLogoStripBlock(comp, params);    break;
      case 'comp-compare':      createCompareBlock(comp, params);      break;
      case 'comp-tags':         createTagsBlock(comp, params);         break;
      case 'comp-callout':      createCalloutBlock(comp, params);          break;
      case 'comp-icon-grid':    createIconGridBlock(comp, params);         break;
      case 'diagram-flow-4':  createFlowDiagram4StepBlock(comp, params); break;
      case 'diagram-cycle':   createFlowCycleBlock(comp, params);    break;
      case 'table-1col':      createTableBlock(comp, params, 1);     break;
      case 'table-2col':      createTableBlock(comp, params, 2);     break;
      case 'table-3col':      createTableBlock(comp, params, 3);     break;
      case 'table-4col':      createTableBlock(comp, params, 4);     break;
      case 'chart-bar':         createBarGraphBlock(comp, params);          break;
      case 'chart-bar-v':       createVerticalBarGraphBlock(comp, params);  break;
      case 'chart-bar-stacked': createStackedBarChartBlock(comp, params);   break;
      case 'chart-donut':       createDonutChartBlock(comp, params);        break;
      case 'chart-line':        createLineChartBlock(comp, params);         break;
      case 'chart-bar-grouped': createGroupedBarChartBlock(comp, params);   break;
      case 'chart-area':        createAreaChartBlock(comp, params);         break;
      case 'chart-progress':    createProgressChartBlock(comp, params);     break;
      case 'chart-scatter':     createScatterPlotBlock(comp, params);       break;
      case 'chart-pie':         createPieChartBlock(comp, params);          break;
      case 'chart-waterfall':   createWaterfallChartBlock(comp, params);    break;
      case 'chart-radar':       createRadarChartBlock(comp, params);        break;
      case 'chart-bubble':      createBubbleChartBlock(comp, params);       break;
      case 'tree-3':          createTree3Block(comp, params);        break;
      case 'tree-2level':     createTree2LevelBlock(comp, params);   break;
      case 'tree-h3':         createTreeH3Block(comp, params);       break;
      case 'tree-h5':         createTreeH5Block(comp, params);       break;
      case 'diagram-process-2':      createDiagramProcess2Block(comp, params);  break;
      case 'diagram-timeline':       createTimelineBlock(comp, params);         break;
      case 'diagram-funnel':         createFunnelBlock(comp, params);           break;
      case 'diagram-matrix':         createMatrixBlock(comp, params);           break;
      case 'diagram-steps':          createStepsBlock(comp, params);            break;
      case 'topology-gh200':         createGH200PairBlock(comp, params);        break;
      case 'topology-nvlink-switch': createNVLinkSwitchBlock(comp, params);     break;
      case 'topology-spine-leaf':    createSpineLeafBlock(comp, params);        break;
      case 'topology-gpu-node':      createGPUNodeBlock(comp, params);          break;
      case 'topology-multi-rack':    createMultiRackBlock(comp, params);        break;
      case 'diagram-parallel-split-ol': params.strokeOnly = true; createParallelSplitBlock(comp, params); break;
      case 'diagram-split-2-ol':        params.strokeOnly = true; createSplitBlock(comp, params, 2);      break;
      case 'diagram-split-3-ol':        params.strokeOnly = true; createSplitBlock(comp, params, 3);      break;
      case 'diagram-split-5-ol':        params.strokeOnly = true; createSplitBlock(comp, params, 5);      break;
      case 'diagram-split-mirror-ol':   params.strokeOnly = true; createSplitMirrorBlock(comp, params);   break;
      case 'diagram-flow-bullets-3':    createFlowBulletsBlock(comp, params);    break;
      case 'diagram-hub-spoke':         createHubSpokeBlock(comp, params);       break;
      case 'cards-icon-3':              createCardsIconBlock(comp, params, 3);   break;
      case 'cards-specs-a':             createSpecsCardA(comp, params);          break;
      case 'cards-specs-b':             createSpecsCardB(comp, params);          break;
      case 'cards-specs-c':             createSpecsCardC(comp, params);          break;
      case 'custom':                    createCustomBlock(comp, params);          break;
      case 'comp-stat':    createStatCalloutBlock(comp, params);    break;
      case 'comp-kpi':     createKPIRowBlock(comp, params);         break;
      case 'comp-quote':   createPullQuoteBlock(comp, params);      break;
      case 'comp-divider':    createSectionDividerBlock(comp, params); break;
      case 'text-agenda':     createTextAgendaBlock(comp, params);    break;
      case 'text-acronym':    createTextAcronymBlock(comp, params);   break;
      case 'diagram-chal-sol':createChalSolBlock(comp, params);       break;
      case 'text-code-quad':  createCodeQuadBlock(comp, params);      break;
      case 'text-code-split': createCodeSplitBlock(comp, params);     break;
      case 'multi-split-h':
      case 'multi-split-v':
      case 'multi-left-1-right-2':
      case 'multi-left-2-right-1':
      case 'multi-three-col':
      case 'multi-2x2':
        createMultiBlockLayout(comp, params); break;
      default:
        app.endUndoGroup();
        return 'error: Unknown block type: ' + params.blockType;
    }

    // If fill is OFF, clear fills from every shape layer except:
    //   - EB_Background (the white comp solid)
    //   - card/node background layers (comment='ebp-cardbg') -- they keep a white
    //     base fill so the Drop Shadow effect has card-shaped alpha to render from.
    if (params.shapeFill === false) {
      for (var _fli = 1; _fli <= comp.numLayers; _fli++) {
        try {
          var _flyr = comp.layers[_fli];
          if (_flyr.name === 'EB_Background') continue;
          try { if (_flyr.comment === 'ebp-cardbg') continue; } catch(e) {}
          if (!(_flyr instanceof ShapeLayer)) continue;
          try { ebClearGroupFills(_flyr.property('Contents')); } catch(e) {}
        } catch(e) {}
      }
    }

    // Enforce layer stack order: BG bottom, Title above BG, Subtitle above Title.
    try {
      var bgL = null, titL = null, subL = null;
      for (var li = 1; li <= comp.numLayers; li++) {
        var ln = comp.layers[li].name;
        if (ln === 'EB_Background') bgL  = comp.layers[li];
        if (ln === 'EB_Title')      titL = comp.layers[li];
        if (ln === 'EB_Subtitle')   subL = comp.layers[li];
      }
      if (bgL)          bgL.moveToEnd();
      if (titL && bgL)  titL.moveBefore(bgL);
      if (subL && titL) subL.moveBefore(titL);
    } catch(e) {}

    // ─── Universal auto-precomp ─────────────────────────────────────────
    // When the user enabled "Pre-comp cards", make sure EVERY block exposes
    // its visual groups as separate pre-comps — not just the ones whose
    // create function does it internally. Detection is layer-name based:
    //   - The first numeric token after "EB_" is the group ID.
    //   - EB_Background / EB_Title / EB_Subtitle are excluded from grouping.
    //   - Layers whose source is already a CompItem are left alone (the
    //     block already pre-comp'd them).
    // This is the foundation for "Add to Current Comp": each pre-comp can
    // then be placed directly into the user's active comp.
    try { _ebpAutoPrecompGroups(comp, params); } catch(_apc) {}

    app.endUndoGroup();

    var _easeResult = '';
    try { _easeResult = ebApplyEaseToComp(comp); } catch(_ex) { _easeResult = 'err:' + _ex.message; }

    // Insert into active comp (if requested and we have a valid pre-existing active comp).
    var _activeNote = '';
    if (params.insertTarget === 'active') {
      if (_origActiveComp) {
        try {
          app.beginUndoGroup('EasyBlocks Pro: add to active comp');

          // Apply include-filter: strip out layers the user doesn't want.
          // Universal categories — Title/Subtitle/Background by exact name,
          // Body = "everything else". If only Body is selected (the default),
          // we just remove Title/Subtitle/Background layers and keep the rest.
          var inc = params.includeElements || { body: true, title: true, subtitle: true, background: true };
          var _removed = 0;
          // Iterate top-down so indices stay stable as we remove.
          for (var _li = comp.numLayers; _li >= 1; _li--) {
            var _lyr = comp.layers[_li];
            var _nm = '';
            try { _nm = _lyr.name; } catch(_ne) {}
            var keep = true;
            if (_nm === 'EB_Background')      keep = !!inc.background;
            else if (_nm === 'EB_Title')      keep = !!inc.title;
            else if (_nm === 'EB_Subtitle')   keep = !!inc.subtitle;
            else                              keep = !!inc.body;
            if (!keep) {
              try { _lyr.remove(); _removed++; } catch(_re) {}
            }
          }

          // If everything got stripped, abort gracefully — nothing to insert.
          if (comp.numLayers === 0) {
            app.endUndoGroup();
            _activeNote = '|empty';
            try { comp.remove(); } catch(_x) {} // clean up the empty workspace comp
          } else {
            // ─── Killer feature: extract each pre-comp directly into the active comp ───
            // When auto-precomp ran (params.precomp === true), the workspace
            // contains one pre-comp per visual group. Pull each one out as a
            // standalone layer in the user's active comp — they get individual
            // groups they can manipulate, not a single wrapper they have to
            // dive into. When precomp is off, fall back to wrapper-as-layer.
            var _atTime = _origActiveComp.time || 0;
            var _activeCx = _origActiveComp.width / 2;
            var _activeCy = _origActiveComp.height / 2;
            var _splitCount = 0;

            if (params.precomp) {
              // Collect pre-comp source items from workspace layers (top-down so
              // first-built groups end up as bottom-most layers in active comp,
              // matching natural Z-order).
              var _sources = [];
              for (var _eli = 1; _eli <= comp.numLayers; _eli++) {
                try {
                  var _esrc = comp.layers[_eli].source;
                  if (_esrc && (_esrc instanceof CompItem)) _sources.push(_esrc);
                } catch(_se2) {}
              }
              if (_sources.length > 0) {
                for (var _si = 0; _si < _sources.length; _si++) {
                  try {
                    var _newLyr = _origActiveComp.layers.add(_sources[_si]);
                    _newLyr.position.setValue([_activeCx, _activeCy]);
                    _newLyr.startTime = _atTime;
                    _splitCount++;
                  } catch(_addOne) {}
                }
                // Workspace wrapper is no longer needed — remove from project.
                try { comp.remove(); } catch(_rmw) {}
              }
            }

            // Fallback (or precomp=off): add the whole workspace as one layer.
            if (_splitCount === 0) {
              var _wrapLyr = _origActiveComp.layers.add(comp);
              try { _wrapLyr.position.setValue([_activeCx, _activeCy]); } catch(_wpe) {}
              try { _wrapLyr.startTime = _atTime; } catch(_wse) {}
            }

            try { _origActiveComp.openInViewer(); } catch(_oe) {}
            app.endUndoGroup();
            _activeNote = '|active:' + _origActiveComp.name +
                          (_splitCount  ? ':split' + _splitCount : '') +
                          (_removed     ? ':strip' + _removed   : '');
          }
        } catch(_addErr) {
          try { app.endUndoGroup(); } catch(_x) {}
          _activeNote = '|activeErr:' + _addErr.message;
          // Fall back to opening the new comp so the user still sees their work
          try { comp.openInViewer(); } catch(_e) {}
        }
      } else {
        // No valid active comp; behave like a normal insert
        _activeNote = '|noActive';
        try { comp.openInViewer(); } catch(_e) {}
      }
    }

    return 'ok|' + compName + '|' + _easeResult + _activeNote + (_loadWarn ? '|' + _loadWarn : '');

  } catch (e) {
    try { app.endUndoGroup(); } catch(x) {}
    var _ver = (typeof _EB_UTILS_VERSION !== 'undefined') ? _EB_UTILS_VERSION : 'CACHED_OLD';
    var _diag = ' [ver:' + _ver + ' dir:' + _ebpScriptDir + (_loadWarn ? ' ' + _loadWarn : '') + ']';
    return 'error: ' + e.message + ' (line ' + e.line + ')' + _diag;
  }
}

// Apply injectable components to an existing comp (called after createBlock in deck mode).
// compName: the AE comp name; injectsJSON: JSON array of inject objects.
function applyInjectables(compName, injectsJSON) {
  try {
    if (!_ebpScriptDir) return 'error: Script path not initialised';
    try {
      $.evalFile(_ebpScriptDir + '/utils.jsx');
      $.evalFile(_ebpScriptDir + '/blocks.jsx');
    } catch(eLoad) {}

    var comp = null;
    for (var i = 1; i <= app.project.numItems; i++) {
      var item = app.project.items[i];
      if ((item instanceof CompItem) && item.name === compName) {
        comp = item; break;
      }
    }
    if (!comp) return 'error: comp not found: ' + compName;
    return ebpApplyInjectables(comp, injectsJSON);
  } catch(e) {
    return 'error: ' + e.message;
  }
}

// Create a master comp that sequences all deck slide comps end-to-end.
// slideDataJSON: JSON array of {name, duration} objects.
function createDeckMasterComp(slideDataJSON) {
  try {
    var slideData = JSON.parse(slideDataJSON);
    var fps = 30;
    var totalDur = 0;
    for (var i = 0; i < slideData.length; i++) {
      totalDur += (slideData[i].duration || 7);
    }

    var masterName = 'EBP_DECK_' + (new Date().getTime() % 1000000);
    var masterComp = app.project.items.addComp(masterName, 1920, 1080, 1, totalDur, fps);

    var currentTime = 0;
    for (var j = 0; j < slideData.length; j++) {
      var sd  = slideData[j];
      var dur = sd.duration || 7;
      var slideComp = null;
      for (var k = 1; k <= app.project.numItems; k++) {
        var it = app.project.items[k];
        if ((it instanceof CompItem) && it.name === sd.name) {
          slideComp = it; break;
        }
      }
      if (slideComp) {
        var layer = masterComp.layers.add(slideComp, dur);
        layer.startTime = currentTime;
      }
      currentTime += dur;
    }

    masterComp.parentFolder = ebpGetOrCreateFolder('Decks');
    masterComp.openInViewer();
    return 'ok|' + masterName;
  } catch(e) {
    return 'error: ' + e.message;
  }
}
