/* ─── EasyBlocks Pro — Panel Logic ───────────────────────────────────────── */
'use strict';

var cs = new CSInterface();

// ── Node modules (available via --enable-nodejs) ──────────────────────────
var os            = require('os');
var path          = require('path');
var fs            = require('fs');
var childProcess  = require('child_process');
var spawnFn       = childProcess.spawn;
var execFn        = childProcess.exec;

// ── Node binary (for bridge scripts) ──────────────────────────────────────
var NODE_BIN = (function() {
  var candidates = [
    '/usr/local/bin/node', '/opt/homebrew/bin/node', '/usr/bin/node',
    process.env.NODE || ''
  ];
  for (var i = 0; i < candidates.length; i++) {
    var p = candidates[i];
    if (p) { try { if (fs.existsSync(p)) return p; } catch(e) {} }
  }
  return 'node';
}());

// ── Claude CLI path detection ──────────────────────────────────────────────
var CLAUDE_BIN = (function() {
  var candidates = [
    path.join(os.homedir(), '.local', 'bin', 'claude'),
    '/usr/local/bin/claude',
    '/opt/homebrew/bin/claude',
    '/usr/bin/claude',
    'claude' // fallback: rely on PATH
  ];
  for (var i = 0; i < candidates.length; i++) {
    try {
      if (candidates[i] !== 'claude' && fs.existsSync(candidates[i])) return candidates[i];
    } catch(e) {}
  }
  return 'claude';
}());

// Extra PATH entries so child processes can find node, claude, system tools
var CHILD_PATH = [
  path.join(os.homedir(), '.local', 'bin'),
  '/usr/local/bin', '/opt/homebrew/bin',
  '/opt/homebrew/opt/poppler/bin',
  '/usr/bin', '/bin', '/sbin'
].join(':') + (process.env.PATH ? ':' + process.env.PATH : '');

// LibreOffice binary (for PPTX → PDF conversion)
var IS_WIN = (process.platform === 'win32');
var SOFFICE = (function() {
  var candidates = IS_WIN ? [
    'C:\\Program Files\\LibreOffice\\program\\soffice.exe',
    'C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe',
    'soffice.exe'
  ] : [
    '/Applications/LibreOffice.app/Contents/MacOS/soffice',
    '/usr/bin/soffice',
    '/usr/local/bin/soffice',
    'soffice'
  ];
  var fallback = IS_WIN ? 'soffice.exe' : 'soffice';
  for (var i = 0; i < candidates.length; i++) {
    if (candidates[i] === fallback) return fallback;
    try { if (fs.existsSync(candidates[i])) return candidates[i]; } catch(e) {}
  }
  return fallback;
}());

// Build a file:// URL for the LibreOffice -env:UserInstallation arg.
// LibreOffice exit -4058 on Windows = "user profile already in use" — happens
// when LibreOffice is already running as a GUI OR a prior CLI run left a lock
// file. Forcing a unique private profile per invocation bypasses both.
function _libreUserInstallUrl(tmpDir) {
  var p = path.join(tmpDir, 'li_profile');
  try { fs.mkdirSync(p, { recursive: true }); } catch(e) {}
  // file:// URL: Windows needs forward slashes after the drive, e.g.
  //   file:///C:/Users/.../profile
  // POSIX uses three slashes too:  file:///tmp/...
  var norm = p.replace(/\\/g, '/');
  if (IS_WIN && norm.charAt(0) !== '/') norm = '/' + norm;
  return 'file://' + norm;
}

// ── Script dir (for ExtendScript hot-reload) ──────────────────────────────
var _scriptDir = (function() {
  var ext = cs.getSystemPath(SystemPath.EXTENSION);
  return path.join(ext, 'jsx').replace(/\\/g, '/');
}());

cs.evalScript('_ebpScriptDir = "' + _scriptDir + '"');

// ── Icon dir (NVIDIA SVG library) ─────────────────────────────────────────
// Prefer a bundled copy inside the extension; fall back to the Abstractor project icons.
var _iconDir = (function() {
  var candidates = [
    path.join(cs.getSystemPath(SystemPath.EXTENSION), 'icons'),
    path.join(os.homedir(), 'Desktop', '_Projects', 'AI Video Lab',
              'Abstractor', 'remotion', 'public', 'assets', 'icons')
  ];
  for (var i = 0; i < candidates.length; i++) {
    try {
      if (fs.existsSync(candidates[i]) &&
          fs.readdirSync(candidates[i]).some(function(f){ return f.endsWith('.svg'); })) {
        return candidates[i].replace(/\\/g, '/');
      }
    } catch(e) {}
  }
  return '';
}());
if (_iconDir) cs.evalScript('_ebpIconDir = "' + _iconDir + '"');

// ── SVG → PNG conversion (Chromium canvas) ────────────────────────────────
// Renders an SVG file to a PNG of the given square size using the browser's
// native canvas API. Writes the PNG to the OS temp directory and returns the
// path. This avoids relying on AE's SVG import (which may fail silently).
// callback(err, pngPath)
function ebpConvertSvgToPng(svgPath, size, callback) {
  try {
    var svgContent = fs.readFileSync(svgPath, 'utf8');
    var b64svg = Buffer.from(svgContent).toString('base64');
    var img = new Image();
    var canvas = document.createElement('canvas');
    canvas.width  = size;
    canvas.height = size;
    var ctx = canvas.getContext('2d');
    img.onload = function() {
      try {
        ctx.clearRect(0, 0, size, size);
        ctx.drawImage(img, 0, 0, size, size);
        canvas.toBlob(function(blob) {
          if (!blob) { callback(new Error('toBlob failed')); return; }
          var reader = new FileReader();
          reader.onload = function(e) {
            try {
              var b64 = (e.target.result || '').split(',')[1] || '';
              var pngPath = path.join(os.tmpdir(),
                path.basename(svgPath, '.svg') + '_' + size + '.png');
              fs.writeFileSync(pngPath, b64, 'base64');
              callback(null, pngPath.replace(/\\/g, '/'));
            } catch(err) { callback(err); }
          };
          reader.onerror = function() { callback(new Error('FileReader error')); };
          reader.readAsDataURL(blob);
        }, 'image/png');
      } catch(err) { callback(err); }
    };
    img.onerror = function() { callback(new Error('SVG load failed: ' + svgPath)); };
    img.src = 'data:image/svg+xml;base64,' + b64svg;
  } catch(e) { callback(e); }
}

// Recursively scan a payload object/array for any icon fields (icon, iconTop,
// iconBottom) and resolve each SVG to a PNG, patching _iconPng / _iconTopPng /
// _iconBottomPng fields in-place. Always calls callback(payload) even if some
// conversions fail, so the insert proceeds with whatever succeeded.
function ebpResolveIconsInPayload(payload, callback) {
  if (!_iconDir) { callback(payload); return; }
  var tasks = [];
  function scanObj(obj) {
    if (!obj || typeof obj !== 'object') return;
    if (Array.isArray(obj)) { for (var ai = 0; ai < obj.length; ai++) scanObj(obj[ai]); return; }
    if (obj.icon        && typeof obj.icon        === 'string') tasks.push({ obj: obj, src: 'icon',        dst: '_iconPng'       });
    if (obj.iconTop     && typeof obj.iconTop     === 'string') tasks.push({ obj: obj, src: 'iconTop',     dst: '_iconTopPng'    });
    if (obj.iconBottom  && typeof obj.iconBottom  === 'string') tasks.push({ obj: obj, src: 'iconBottom',  dst: '_iconBottomPng' });
    var keys = Object.keys(obj);
    for (var ki = 0; ki < keys.length; ki++) {
      var v = obj[keys[ki]];
      if (v && typeof v === 'object') scanObj(v);
    }
  }
  scanObj(payload);
  if (!tasks.length) { callback(payload); return; }
  var pending = tasks.length;
  for (var ti = 0; ti < tasks.length; ti++) {
    (function(t) {
      var svgPath = _iconDir + '/' + t.obj[t.src] + '.svg';
      ebpConvertSvgToPng(svgPath, 64, function(err, pngPath) {
        if (!err && pngPath) t.obj[t.dst] = pngPath;
        if (--pending === 0) callback(payload);
      });
    }(tasks[ti]));
  }
}

// ── State ─────────────────────────────────────────────────────────────────
var state = {
  // Blocks tab
  selectedBlock:  null,
  insertTarget:   'new',     // 'new' = create new comp; 'active' = add to current comp
  titleAlign:     'left',    // title (and body) alignment in card blocks: 'left'|'center'|'right'
  tableNumCols:   3,         // 1-8
  tableNumRows:   3,         // 2-10
  // Element-level filter when adding to active comp. "body" = everything that
  // isn't title/subtitle/background. Sensible defaults: body only.
  includeBody:        true,
  includeTitle:       false,
  includeSubtitle:    false,
  includeBackground:  false,
  accentColor:    '76B900',
  leftColor:      '5D1682',
  rightColor:     '76B900',
  chartCount:     5,
  cardBodyStyle:  'text',
  lastChartType:  null,
  cardCount:      3,
  cornerRows:     1,
  precompCards:   true,
  pipeCount:      3,
  colCount:       3,
  acronymCount:   4,
  bulletCount:    4,
  nestedMainCount: 3,
  nestedSubCount:  2,
  cardLineCount:  3,
  slotBlock1:     'cards-3',
  slotBlock2:     'diagram-flow',
  slotBlock3:     'chart-bar',
  slotBlock4:     'diagram-cycle',
  // Combine queue (new design):
  //   - Each entry is a frozen snapshot of a block + its full params at the
  //     moment the user pressed "+ Combine".
  //   - When 2-4 entries are queued, the tray shows layout choices.
  //   - Picking a layout enables INSERT COMBINED in place of INSERT BLOCK.
  combineQueue:        [],
  combineLayoutPicked: null,
  // Per-slot config snapshots. Each entry is a full options snapshot built by
  // `_snapshotToSlotConfig(idx)`; populated as the user configures each slot
  // inside the slot picker overlay, then read by `_buildSlotParams` at insert.
  slotConfigs:    [null, null, null, null],
  // True while the slot-picker overlay is open. `_comboLayoutBlock` keeps the
  // multi-* layout type alive while `state.selectedBlock` is temporarily
  // swapped to a slot block (so the regular options-panel logic can react).
  _slotPickerOpen:    false,
  _comboLayoutBlock:  null,
  seriesCount:    1,
  pointCount:     5,
  stepCount:      10,
  stepsPerRow:    5,
  timelineCount:  4,
  timelineStyle:  'straight',
  compTimelineCount: 4,
  logoCount:      5,
  deviceCount:    2,
  calloutType:    'dark',
  calloutStroke:  'solid',
  compareCount:   5,
  compareTheme:   'dark',
  tagsCount:      6,
  iconGridCount:  4,
  pointStyle:     'diamond',
  // AI Generate tab
  aiGenerateMode: 'deck',    // 'deck' | 'media' (prompt removed)
  aiImagePath:    null,
  aiFramePath:    null,   // temp extracted frame path (GIF/video)
  aiVoScript:     '',
  aiOutput:       null,   // { mode:'block'|'motion', payload:... }
  aiRefineTurns:  0,      // conversational-refinement turn count (resets on new generation)
  aiRunning:      false,
  aiChild:        null,
  aiPollInterval: null,
  lastGenParams:  null,
  aiStartTime:    0,
  aiProgressLabel: '',
  aiDeckSlides:   [],      // PNG paths from PPTX/PDF conversion
  aiSlideNotes:   {},      // {slideIndex: "notes text"} from PPTX
  // My Blocks
  myBlocks:       [],
  myBlocksDir:    path.join(os.homedir(), '.ebp_my_blocks'),
  selectedMyBlock: null,
  // AI Generate settings
  forceBlockType:  '',           // '' = AI decides
  autoSaveMyBlocks: false,
  // Deck extras
  deckPreviewTypes: {},   // { slideIndex: blockType }
  deckSkipped:      {},   // { slideIndex: bool }
  deckCompNames:    {}    // { slideIndex: compName } — for per-slide re-run
};

// ── DOM refs ──────────────────────────────────────────────────────────────
var $ = function(id) { return document.getElementById(id); };

// Tabs
var tabBtns     = document.querySelectorAll('.tab');
var tabBlocks   = $('tab-blocks');
var tabAi       = $('tab-ai');

// Blocks tab
var blockBtns   = document.querySelectorAll('.block-btn');
var blockSearch = $('blockSearch');
var titleInput  = $('titleInput');
var subtitleInput = $('subtitleInput');
var colorPicker = $('colorPicker');
var perCardRow  = $('perCardRow');
var leftPicker  = $('leftCardPicker');
var rightPicker = $('rightCardPicker');
var colorName   = $('colorName');
var catHeaders  = document.querySelectorAll('.cat-header');
var animateIn   = $('animateIn');
var posAnim     = $('posAnim');
var cardBg      = $('cardBg');
var cardBorder  = $('cardBorder');
var dropShadow  = $('dropShadow');
var cardStyleRow = $('cardStyleRow');
var cardStyleBtns = document.querySelectorAll('#cardStyleBtns .style-btn');
var bulletCountBtns = document.querySelectorAll('#bulletCountBtns .style-btn');
var nestedMainBtns  = document.querySelectorAll('#nestedMainBtns .style-btn');
var nestedSubBtns   = document.querySelectorAll('#nestedSubBtns .style-btn');
var precompCards    = $('precompCards');
var cardCountBtns   = document.querySelectorAll('#cardCountBtns .style-btn');
var tableColsBtns   = document.querySelectorAll('#tableColsBtns .style-btn');
var tableRowsBtns   = document.querySelectorAll('#tableRowsBtns .style-btn');
var cardLinesBtns   = document.querySelectorAll('#cardLinesBtns .style-btn');
var pipeCountBtns   = document.querySelectorAll('#pipeCountBtns .style-btn');
var colCountBtns    = document.querySelectorAll('#colCountBtns .style-btn');
var acronymCountBtns    = document.querySelectorAll('#acronymCountBtns .style-btn');
var slotOverlay    = $('slotOverlay');
var slotThumbGrid  = $('slotThumbGrid');
var slotTabs       = $('slotTabs').querySelectorAll('.slot-tab');
var slotCloseBtn   = $('slotCloseBtn');
var slotOverlayLayout = $('slotOverlayLayout');
var layoutStripBtns = document.querySelectorAll('.layout-btn');
var stepCountBtns       = document.querySelectorAll('#stepCountBtns .style-btn');
var stepsPerRowBtns     = document.querySelectorAll('#stepsPerRowBtns .style-btn');
var timelineCountBtns      = document.querySelectorAll('#timelineCountBtns .style-btn');
var compTimelineCountBtns  = document.querySelectorAll('#compTimelineCountBtns .style-btn');
var logoCountBtns          = document.querySelectorAll('#logoCountBtns .style-btn');
var deviceCountBtns        = document.querySelectorAll('#deviceCountBtns .style-btn');
var calloutTypeBtns        = document.querySelectorAll('#calloutTypeBtns .style-btn');
var calloutStrokeBtns      = document.querySelectorAll('#calloutStrokeBtns .style-btn');
var compareCountBtns       = document.querySelectorAll('#compareCountBtns .style-btn');
var compareThemeBtns       = document.querySelectorAll('#compareThemeBtns .style-btn');
var tagsCountBtns          = document.querySelectorAll('#tagsCountBtns .style-btn');
var iconGridCountBtns      = document.querySelectorAll('#iconGridCountBtns .style-btn');
var timelineStyleBtns   = document.querySelectorAll('#timelineStyleBtns .style-btn');
var pointStyleBtns      = document.querySelectorAll('#pointStyleBtns .style-btn');
var insertBtn   = $('insertBtn');
var statusEl    = $('status');
var graphDataSection = $('graphDataSection');

// AI tab
var aiDropzone  = $('aiDropzone');
var aiFileInput = $('aiFileInput');
var aiPreviewImg      = $('aiPreviewImg');
var aiFilePlaceholder = $('aiFilePlaceholder');
var aiFileNameLabel   = $('aiFileNameLabel');
var aiClearBtn        = $('aiClearBtn');
var aiSlideGridWrap    = $('aiSlideGridWrap');
var aiSlideGrid        = $('aiSlideGrid');
var aiImportProgress   = $('aiImportProgress');
var aiImportBar        = $('aiImportBar');
var aiImportMsg        = $('aiImportMsg');
var voAutoTag          = $('voAutoTag');
var voScript    = $('voScript');
var extraInstr  = $('extraInstr');
var promptText  = $('promptText');
var aiMediaMode = $('aiMediaMode');
var aiPromptMode = $('aiPromptMode');
var generateBtn = $('generateBtn');
var aiProgress  = $('aiProgress');
var aiProgressBar = $('aiProgressBar');
var aiProgressMsg = $('aiProgressMsg');
var aiOutput    = $('aiOutput');
var aiModeBadge = $('aiModeBadge');
var aiOutputLabel = $('aiOutputLabel');
var toggleJsonBtn = $('toggleJsonBtn');
var aiJsonEditor = $('aiJsonEditor');
var saveBlockBtn = $('saveBlockBtn');
var aiFix       = $('aiFix');
var fixText             = $('fixText');
var fixBtn              = $('fixBtn');
var refineTurnCounter   = $('refineTurnCounter');
var refineResetBtn      = $('refineResetBtn');
var aiInsertBtn  = $('aiInsertBtn');
var aiActionRow  = $('aiActionRow');
var recreateBtn  = $('recreateBtn');
var resetBtn     = $('resetBtn');
var autoSaveToggle    = $('autoSaveToggle');
var promptHistorySelect = $('promptHistorySelect');
var forceBlockSelect  = $('forceBlockSelect');
var deckPreviewBtn    = $('deckPreviewBtn');
var aiStatus    = $('aiStatus');
var aiLogWrap   = $('aiLogWrap');
var aiLog       = $('aiLog');

// ── Force block type select — populate options ────────────────────────────
(function() {
  var cats = [
    { label: 'Cards',      types: ['slide-title','cards-1','cards-2','cards-3','cards-4','cards-5','cards-compare','cards-media','cards-corner','cards-corner-sq','cards-corner-slim','cards-specs-a','cards-specs-b','cards-specs-c','cards-device','cards-top-bar','cards-bottom-bar'] },
    { label: 'Text',       types: ['bullets','text-bullets','bullet-list','text-nested','text-2col','text-numbered','text-code-cli','text-body-bullets','text-errors','text-links','text-agenda','text-acronym','text-code-quad','text-code-split'] },
    { label: 'Diagrams',   types: ['diagram-flow','diagram-flow-4','diagram-cycle','diagram-process-2','diagram-timeline','diagram-funnel','diagram-matrix','diagram-steps','diagram-chal-sol','diagram-flow-bullets-3','diagram-parallel-split-ol','diagram-split-2-ol','diagram-split-3-ol','diagram-split-5-ol','diagram-split-mirror-ol'] },
    { label: 'Trees',      types: ['tree-3','tree-2level','tree-h3','tree-h5'] },
    { label: 'Charts',     types: ['chart-bar','chart-bar-v','chart-bar-stacked','chart-donut'] },
    { label: 'Tables',     types: ['table-bar','table-minimal','table-outlined'] },
    { label: 'Lower Thirds', types: ['comp-callout'] },
    { label: 'Components', types: ['rack-callout','comp-timeline','comp-logo-strip','comp-compare','comp-tags','comp-icon-grid','comp-stat','comp-kpi','comp-quote','comp-divider'] }
  ];
  cats.forEach(function(cat) {
    var grp = document.createElement('optgroup');
    grp.label = cat.label;
    cat.types.forEach(function(t) {
      var opt = document.createElement('option');
      opt.value = t; opt.textContent = t;
      grp.appendChild(opt);
    });
    forceBlockSelect.appendChild(grp);
  });
})();

// ── Prompt history ────────────────────────────────────────────────────────
var PROMPT_HIST_KEY = 'ebp_prompt_history';
function savePromptToHistory(prompt) {
  try {
    var hist = JSON.parse(localStorage.getItem(PROMPT_HIST_KEY) || '[]');
    hist = hist.filter(function(p) { return p !== prompt; });
    hist.unshift(prompt);
    localStorage.setItem(PROMPT_HIST_KEY, JSON.stringify(hist.slice(0, 15)));
    renderPromptHistory();
  } catch(e) {}
}
function renderPromptHistory() {
  try {
    var hist = JSON.parse(localStorage.getItem(PROMPT_HIST_KEY) || '[]');
    promptHistorySelect.innerHTML = '<option value="">↑ Recent</option>';
    hist.forEach(function(p) {
      var opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p.length > 55 ? p.slice(0, 55) + '…' : p;
      promptHistorySelect.appendChild(opt);
    });
    promptHistorySelect.style.display = hist.length ? 'inline-block' : 'none';
  } catch(e) {}
}
renderPromptHistory();
promptHistorySelect.addEventListener('change', function() {
  if (this.value) { promptText.value = this.value; this.value = ''; updateGenerateBtn(); }
});
forceBlockSelect.addEventListener('change', function() { state.forceBlockType = this.value; });
autoSaveToggle.addEventListener('change', function() { state.autoSaveMyBlocks = this.checked; });

// Help
var helpBtn     = $('helpBtn');
var helpPanel   = $('helpPanel');
var helpCloseBtn = $('helpCloseBtn');

// Settings / Update
var settingsBtn      = $('settingsBtn');
var settingsPanel    = $('settingsPanel');
var settingsCloseBtn = $('settingsCloseBtn');
var updateBanner          = $('updateBanner');
var updateBannerVersion   = $('updateBannerVersion');
var updateBannerBtn       = $('updateBannerBtn');
var updateBannerDismiss   = $('updateBannerDismiss');
var updAutoBox       = $('updAutoBox');
var updAutoVersion   = $('updAutoVersion');
var updAutoBtn       = $('updAutoBtn');
var updCheckBtn      = $('updCheckBtn');
var updDropZone      = $('updDropZone');
var updFileInput     = $('updFileInput');
var updDropLabel     = $('updDropLabel');
var updStatus        = $('updStatus');
var installUpdateBtn = $('installUpdateBtn');
var reloadPanelBtn   = $('reloadPanelBtn');
var _updZipPath      = null;

// Add Blocks
var blocksDropZone   = $('blocksDropZone');
var blocksFileInput  = $('blocksFileInput');
var blocksDropLabel  = $('blocksDropLabel');
var blocksStatus     = $('blocksStatus');
var installBlocksBtn = $('installBlocksBtn');
var reloadBlocksBtn  = $('reloadBlocksBtn');
var _blocksZipPath   = null;

// ══════════════════════════════════════════════════════════════════════════
// TAB SWITCHING
// ══════════════════════════════════════════════════════════════════════════
tabBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    var tab = this.dataset.tab;
    tabBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    if (tab === 'blocks') {
      tabBlocks.style.display = 'flex';
      tabAi.style.display = 'none';
      collapseAllCats();
    } else {
      tabBlocks.style.display = 'none';
      tabAi.style.display = 'flex';
    }
  });
});

// ══════════════════════════════════════════════════════════════════════════
// HELP
// ══════════════════════════════════════════════════════════════════════════
helpBtn.addEventListener('click', function() { helpPanel.style.display = 'flex'; });
helpCloseBtn.addEventListener('click', function() { helpPanel.style.display = 'none'; });

// ══════════════════════════════════════════════════════════════════════════
// SETTINGS / UPDATE
// ══════════════════════════════════════════════════════════════════════════
settingsBtn.addEventListener('click', function() { settingsPanel.style.display = 'flex'; });
settingsCloseBtn.addEventListener('click', function() { settingsPanel.style.display = 'none'; });

// ── Version checker — fetches latest.json from public GitHub manifest ────
// Public repo, no auth needed; works for every user with internet.
// Repo: https://github.com/amitnvda/easyblocks-releases
//
// Multi-host fallback chain — corporate networks (especially Windows) sometimes
// block one CDN via SmartScreen / proxy / AV. We try each in order; first one
// that returns valid JSON wins. Order:
//   1. raw.githubusercontent.com — canonical, always fresh
//   2. cdn.jsdelivr.net          — widely allowlisted CDN (may briefly cache)
//   3. api.github.com/contents   — REST API; always fresh, no CDN cache,
//                                  returns base64-encoded content (we decode)
var EBP_LATEST_URLS = [
  'https://raw.githubusercontent.com/amitnvda/easyblocks-releases/main/latest.json',
  'https://cdn.jsdelivr.net/gh/amitnvda/easyblocks-releases@main/latest.json',
  'https://api.github.com/repos/amitnvda/easyblocks-releases/contents/latest.json?ref=main'
];
var EBP_DOWNLOAD_URL  = 'https://nvidia.sharepoint.com/:f:/r/sites/NBU-AcademyDM/R%20%20D/AE%20Plugins%20and%20Scripts/EasyBlocks?csf=1&web=1&e=3Kw415';
var EBP_VERSION = (function() {
  // Read from manifest header badge (single source of truth)
  var el = document.querySelector('.header-version');
  return el ? el.textContent.replace(/^v/, '').trim() : '0.0.0';
}());
var EBP_DISMISS_KEY = 'ebp_update_dismissed';

function _verCmp(a, b) {
  var pa = String(a).split('.').map(function(n) { return parseInt(n, 10) || 0; });
  var pb = String(b).split('.').map(function(n) { return parseInt(n, 10) || 0; });
  for (var i = 0; i < 3; i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return  1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

// Tries each manifest URL in order; resolves with { data, host } on first success
// or { error } if every host fails. Logs every attempt to console for diagnostics.
// The GitHub Contents API URL is special-cased: response is base64-encoded inside
// a JSON envelope, so we decode it before returning.
function _fetchLatestJson() {
  var cacheBust = '?t=' + Date.now() + '-' + Math.random().toString(36).slice(2);
  return EBP_LATEST_URLS.reduce(function(promise, baseUrl) {
    return promise.then(function(prev) {
      if (prev && prev.data) return prev; // already succeeded — short-circuit
      var isGitHubApi = /^https:\/\/api\.github\.com\//.test(baseUrl);
      var url = isGitHubApi ? baseUrl : (baseUrl + (baseUrl.indexOf('?') >= 0 ? '&' : '?') + cacheBust.slice(1));
      var hostMatch = baseUrl.match(/^https?:\/\/([^/]+)/);
      var host = hostMatch ? hostMatch[1] : baseUrl;
      var headers = { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache' };
      if (isGitHubApi) headers['Accept'] = 'application/vnd.github.v3+json';
      return fetch(url, { cache: 'no-store', headers: headers }).then(function(res) {
        if (!res.ok) {
          var err = host + ' → HTTP ' + res.status;
          console.warn('[EasyBlocks] manifest fetch failed:', err);
          return { error: err };
        }
        if (isGitHubApi) {
          return res.json().then(function(envelope) {
            if (!envelope || envelope.encoding !== 'base64' || !envelope.content) {
              var err = host + ' → unexpected API response shape';
              console.warn('[EasyBlocks] manifest fetch failed:', err);
              return { error: err };
            }
            try {
              var json = atob(envelope.content.replace(/\s/g, ''));
              var data = JSON.parse(json);
              console.log('[EasyBlocks] manifest fetched from ' + host + ' → v' + (data && data.version));
              return { data: data, host: host };
            } catch(e) {
              var err2 = host + ' → ' + (e && e.message ? e.message : String(e));
              console.warn('[EasyBlocks] manifest fetch failed:', err2);
              return { error: err2 };
            }
          });
        }
        return res.json().then(function(data) {
          console.log('[EasyBlocks] manifest fetched from ' + host + ' → v' + (data && data.version));
          return { data: data, host: host };
        }, function(e) {
          var err = host + ' → ' + (e && e.message ? e.message : 'invalid JSON');
          console.warn('[EasyBlocks] manifest fetch failed:', err);
          return { error: err };
        });
      }, function(e) {
        var err = host + ' → ' + (e && e.message ? e.message : String(e));
        console.warn('[EasyBlocks] manifest fetch failed:', err);
        return { error: err };
      });
    });
  }, Promise.resolve(null)).then(function(final) {
    return final && final.data ? final : { error: (final && final.error) || 'all manifest hosts unreachable' };
  });
}

// Paint the "Update Now" auto-update button to match current state. Skips
// the paint while an install is in flight (data-installing flag set) so the
// state machine never clobbers the "Installing v…" label.
function _setAutoBtnState(state, version) {
  if (!updAutoBtn) return;
  if (updAutoBtn.dataset.installing === '1') return;
  switch (state) {
    case 'available':
      updAutoBtn.disabled = false;
      updAutoBtn.textContent = 'Update to v' + version;
      if (updAutoBox) updAutoBox.style.display = 'flex';
      break;
    case 'uptodate':
      updAutoBtn.disabled = true;
      updAutoBtn.textContent = 'Up to date (v' + version + ')';
      if (updAutoBox) updAutoBox.style.display = 'flex';
      break;
    case 'unreachable':
      updAutoBtn.disabled = true;
      updAutoBtn.textContent = 'Update server unreachable';
      if (updAutoBox) updAutoBox.style.display = 'flex';
      break;
    case 'checking':
      updAutoBtn.disabled = true;
      updAutoBtn.textContent = 'Checking…';
      if (updAutoBox) updAutoBox.style.display = 'flex';
      break;
  }
}

// checkForUpdate(opts) — set opts.manual=true for user-triggered checks so a
// visible result is surfaced (success / no-update / error) rather than silently
// failing.
function checkForUpdate(opts) {
  var manual = !!(opts && opts.manual);
  return _fetchLatestJson().then(function(result) {
    if (!result || result.error || !result.data || !result.data.version) {
      var msg = (result && result.error) || 'manifest missing version field';
      console.warn('[EasyBlocks] update check failed:', msg);
      if (manual && updStatus) {
        updStatus.textContent = "Couldn't reach update server (" + msg + "). Use manual install below.";
        updStatus.style.color = '#f55';
      }
      _setAutoBtnState('unreachable');
      return;
    }
    var data = result.data;
    var remote = String(data.version).trim();
    if (_verCmp(remote, EBP_VERSION) <= 0) {
      if (manual && updStatus) {
        updStatus.textContent = "You're up to date — running v" + EBP_VERSION + ".";
        updStatus.style.color = 'var(--text-muted)';
      }
      _setAutoBtnState('uptodate', EBP_VERSION);
      return;
    }
    // Manual checks override the dismiss flag — the user explicitly asked.
    if (!manual && localStorage.getItem(EBP_DISMISS_KEY) === remote) {
      // Reflect the available update on the install button anyway, so it stays
      // actionable from the gear icon even when the top banner is dismissed.
      _setAutoBtnState('available', remote);
      if (updateBanner) {
        updateBanner.dataset.version  = remote;
        updateBanner.dataset.update   = data.update || '';
        updateBanner.dataset.updateUrl = data.updateUrl || '';
      }
      return;
    }
    if (!updateBanner) return;
    updateBannerVersion.textContent = 'v' + remote;
    updateBanner.dataset.version  = remote;
    updateBanner.dataset.update   = data.update || '';
    updateBanner.dataset.updateUrl = data.updateUrl || '';
    updateBanner.style.display = 'flex';
    _setAutoBtnState('available', remote);
    console.log('[EasyBlocks] Update available: v' + remote + ' (installed v' + EBP_VERSION + ')');
    if (manual && updStatus) {
      updStatus.textContent = 'Update v' + remote + ' available — banner shown at top.';
      updStatus.style.color = 'var(--accent)';
    }
  });
}

// Diagnostic helpers — callable from DevTools console
window.ebpDiag = {
  check: function() { return checkForUpdate({ manual: true }); },
  clear: function() { localStorage.removeItem(EBP_DISMISS_KEY); },
  state: function() {
    return {
      installed: EBP_VERSION,
      dismissed: localStorage.getItem(EBP_DISMISS_KEY),
      banner:    updateBanner ? (updateBanner.style.display !== 'none') : 'missing'
    };
  }
};

function openSharePointFolder() {
  try {
    if (typeof cep !== 'undefined' && cep.util && cep.util.openURLInDefaultBrowser) {
      cep.util.openURLInDefaultBrowser(EBP_DOWNLOAD_URL);
      return true;
    }
  } catch(e) {}
  // Fallback: shell out via Node (covers older CEP versions)
  try {
    var cmd = process.platform === 'darwin' ? 'open "' + EBP_DOWNLOAD_URL + '"' :
              process.platform === 'win32'  ? 'start "" "' + EBP_DOWNLOAD_URL + '"' :
                                              'xdg-open "' + EBP_DOWNLOAD_URL + '"';
    execFn(cmd, function() {});
    return true;
  } catch(e) {}
  return false;
}

// If the user has the SharePoint folder OneDrive-synced, the new -update.zip is
// already on disk. Find it across the common Mac/Windows OneDrive paths.
function findLocalUpdateZip(updateFilename) {
  if (!updateFilename) return null;
  var rel = path.join('NVIDIA Academy CMS - AE Plugins', 'EasyBlocks', updateFilename);
  var candidates = [
    path.join(os.homedir(), 'Library', 'CloudStorage', 'OneDrive-NVIDIACorporation', rel),
    path.join(os.homedir(), 'OneDrive - NVIDIA Corporation', rel),
    path.join(os.homedir(), 'OneDrive - NVIDIA', rel)
  ];
  for (var i = 0; i < candidates.length; i++) {
    try { if (fs.existsSync(candidates[i])) return candidates[i]; } catch(e) {}
  }
  return null;
}

updateBannerBtn.addEventListener('click', function() {
  // Open the settings/install panel — the auto-update box inside it is the
  // single canonical install entry point now. Settings panel open also kicks
  // off a fresh check via the settingsBtn handler chain (mirrored below).
  if (typeof updAutoVersion !== 'undefined' && updAutoVersion && updateBanner.dataset.version) {
    updAutoVersion.textContent = 'v' + updateBanner.dataset.version;
  }
  // If the user has SharePoint OneDrive-synced, pre-fill the manual drop zone
  // with the local copy as a convenience — they can still hit "Update to vX"
  // for the GitHub-hosted one-click path, or "Install Update" for the local
  // copy. Either works.
  var localZip = findLocalUpdateZip(updateBanner.dataset.update);
  if (localZip && typeof updSetFile === 'function') updSetFile(localZip);
  settingsPanel.style.display = 'flex';
  updateBanner.style.display  = 'none';
});

// "Open SharePoint folder" button inside Settings — same handler, accessible
// any time (not just when the banner is showing).
var updOpenSharePointBtn = $('updOpenSharePoint');
if (updOpenSharePointBtn) {
  updOpenSharePointBtn.addEventListener('click', openSharePointFolder);
}

updateBannerDismiss.addEventListener('click', function() {
  var v = updateBanner.dataset.version;
  if (v) localStorage.setItem(EBP_DISMISS_KEY, v);
  updateBanner.style.display = 'none';
});

// Run once on boot, then every 30 minutes while panel is open.
setTimeout(function() { checkForUpdate(); }, 1500);
setInterval(function() { checkForUpdate(); }, 30 * 60 * 1000);

// Settings panel open → trigger a fresh check so the auto-update box shows
// current state immediately (Up to date / Update to vX / unreachable).
settingsBtn.addEventListener('click', function() {
  if (typeof updAutoBtn !== 'undefined' && updAutoBtn) {
    _setAutoBtnState('checking');
  }
  if (updStatus) {
    updStatus.textContent = 'Checking for updates…';
    updStatus.style.color = 'var(--text-muted)';
  }
  checkForUpdate({ manual: true });
});

// Manual "Check for updates" link in the settings panel — surfaces visible
// status (success / up-to-date / network error) so users can self-diagnose.
if (updCheckBtn) {
  updCheckBtn.addEventListener('click', function() {
    updCheckBtn.disabled = true;
    var oldLabel = updCheckBtn.textContent;
    updCheckBtn.textContent = 'Checking…';
    if (updStatus) {
      updStatus.textContent = 'Checking for updates…';
      updStatus.style.color = 'var(--text-muted)';
    }
    _setAutoBtnState('checking');
    checkForUpdate({ manual: true }).then(function() {
      updCheckBtn.disabled = false;
      updCheckBtn.textContent = oldLabel;
    });
  });
}

// "Update to vX.Y.Z" auto-install button — fetches the update zip directly
// from GitHub and runs the same shell-exec install path as the manual drop
// zone. Multi-host fallback so a blocked CDN doesn't break the install.
if (updAutoBtn) {
  updAutoBtn.addEventListener('click', function() {
    if (updAutoBtn.disabled) return;
    var url = (updateBanner && updateBanner.dataset.updateUrl) || '';
    var ver = (updateBanner && updateBanner.dataset.version)   || '';
    if (!url) {
      // No URL means we never detected an update OR the manifest pre-dates the
      // updateUrl field — fall back to opening SharePoint.
      if (updStatus) {
        updStatus.textContent = "You're already on the latest version (v" + EBP_VERSION + ").";
        updStatus.style.color = 'var(--text-muted)';
      }
      return;
    }
    updAutoBtn.dataset.installing = '1';
    updAutoBtn.disabled = true;
    updAutoBtn.textContent = ver ? 'Installing v' + ver + '…' : 'Installing…';
    fetchAndInstallUpdate(url, ver).then(function() {
      delete updAutoBtn.dataset.installing;
    });
  });
}

// Multi-host zip fetch — same idea as the manifest. If the manifest's
// updateUrl points at raw.githubusercontent.com we try jsDelivr as a backup
// (zip files are versioned, so jsDelivr's cache is fine for them).
function _zipUrlCandidates(updateUrl) {
  if (!updateUrl) return [];
  var m = updateUrl.match(/^https?:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/);
  if (!m) return [updateUrl];
  return [
    updateUrl,
    'https://cdn.jsdelivr.net/gh/' + m[1] + '/' + m[2] + '@' + m[3] + '/' + m[4]
  ];
}

// Downloads the zip, writes it to a temp path, then hands it to the existing
// install pipeline. Returns a Promise that resolves when the install
// (success or failure) is fully reported.
function fetchAndInstallUpdate(updateUrl, version) {
  var tmpZip = path.join(os.tmpdir(), 'ebp_update_' + Date.now() + '.zip');
  var candidates = _zipUrlCandidates(updateUrl);
  var verLabel = version ? 'v' + version : 'update';
  if (updStatus) {
    updStatus.textContent = 'Downloading ' + verLabel + '…';
    updStatus.style.color = 'var(--text-muted)';
  }
  var lastErr = '';
  var chain = Promise.resolve(null);
  candidates.forEach(function(url) {
    chain = chain.then(function(buf) {
      if (buf) return buf;
      var hostMatch = url.match(/^https?:\/\/([^/]+)/);
      var host = hostMatch ? hostMatch[1] : url;
      return fetch(url, { cache: 'no-store' }).then(function(res) {
        if (!res.ok) {
          lastErr = host + ' → HTTP ' + res.status;
          console.warn('[EasyBlocks] zip fetch failed:', lastErr);
          return null;
        }
        return res.arrayBuffer().then(function(ab) {
          var b = Buffer.from(ab);
          console.log('[EasyBlocks] zip downloaded from ' + host + ' (' + b.length + ' bytes)');
          return b;
        });
      }, function(e) {
        lastErr = host + ' → ' + (e && e.message ? e.message : String(e));
        console.warn('[EasyBlocks] zip fetch failed:', lastErr);
        return null;
      });
    });
  });
  return chain.then(function(buf) {
    if (!buf) throw new Error(lastErr || 'all mirrors unreachable');
    if (updStatus) {
      updStatus.textContent = 'Installing ' + verLabel + '…';
      updStatus.style.color = 'var(--text-muted)';
    }
    fs.writeFileSync(tmpZip, buf);
    return _runInstall(tmpZip, version);
  }).catch(function(e) {
    if (updStatus) {
      updStatus.textContent = 'Update to ' + verLabel + ' failed: ' + e.message;
      updStatus.style.color = '#f55';
    }
    if (updAutoBtn) {
      updAutoBtn.disabled = false;
      updAutoBtn.textContent = version ? 'Update to v' + version : 'Try again';
    }
  }).then(function() {
    try { fs.unlinkSync(tmpZip); } catch(_) {}
  });
}

// Shared install pipeline used by both the auto-install and the manual drop
// zone. Returns a Promise that resolves when the unzip command finishes.
function _runInstall(zipPath, version) {
  return new Promise(function(resolve) {
    var extRoot = cs.getSystemPath(SystemPath.EXTENSION);
    var cmd;
    if (process.platform === 'win32') {
      var zipPS = zipPath.replace(/'/g, "''");
      var extPS = extRoot.replace(/'/g, "''");
      cmd = "powershell -NoProfile -Command \"Expand-Archive -Force -Path '" + zipPS + "' -DestinationPath '" + extPS + "'\"";
    } else {
      cmd = 'unzip -o ' + JSON.stringify(zipPath) + ' -d ' + JSON.stringify(extRoot);
    }
    execFn(cmd, { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) }, function(err, stdout, stderr) {
      if (err) {
        if (updStatus) {
          updStatus.textContent = 'Error: ' + (stderr || err.message || String(err));
          updStatus.style.color = '#f55';
        }
        if (installUpdateBtn) installUpdateBtn.disabled = false;
        if (updAutoBtn) {
          updAutoBtn.disabled = false;
          updAutoBtn.textContent = version ? 'Update to v' + version : 'Try again';
        }
      } else {
        // Successful install — surface the big celebratory success card.
        if (updStatus) updStatus.textContent = '';
        if (reloadPanelBtn) reloadPanelBtn.style.display = 'none';
        if (updAutoBtn) {
          updAutoBtn.disabled = true;
          updAutoBtn.textContent = version ? 'Installed v' + version : 'Installed';
        }
        showUpdateSuccess(version);
      }
      resolve();
    });
  });
}


function updSetFile(filePath) {
  _updZipPath = filePath;
  var name = filePath ? path.basename(filePath) : '';
  updDropLabel.textContent = name || 'Drop .zip here or click to browse';
  updDropZone.classList.toggle('has-file', !!filePath);
  updStatus.textContent = '';
  updStatus.style.color = 'var(--text-muted)';
  installUpdateBtn.disabled = !filePath;
  if (reloadPanelBtn) reloadPanelBtn.style.display = 'none';
}

// Click to browse
updDropZone.addEventListener('click', function() { updFileInput.click(); });
updFileInput.addEventListener('change', function() {
  var f = this.files && this.files[0];
  if (f && f.name.toLowerCase().endsWith('.zip')) updSetFile(f.path);
});

// Drag & drop
updDropZone.addEventListener('dragover', function(e) {
  e.preventDefault();
  updDropZone.classList.add('drag-over');
});
updDropZone.addEventListener('dragleave', function() {
  updDropZone.classList.remove('drag-over');
});
updDropZone.addEventListener('drop', function(e) {
  e.preventDefault();
  updDropZone.classList.remove('drag-over');
  var f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f && f.name.toLowerCase().endsWith('.zip')) {
    updSetFile(f.path);
  } else {
    updStatus.textContent = 'Please drop a .zip file.';
    updStatus.style.color = '#f55';
  }
});

// Install (manual drop-zone path) — delegates to the shared _runInstall pipeline
// so success/failure messaging stays consistent across the auto and manual paths.
installUpdateBtn.addEventListener('click', function() {
  if (!_updZipPath) return;
  updStatus.textContent = 'Installing…';
  updStatus.style.color = 'var(--text-muted)';
  installUpdateBtn.disabled = true;
  // Best-effort version detection from the dropped zip filename
  var verMatch = (_updZipPath.match(/EasyBlocksPro-([0-9][0-9.]*)-update\.zip$/i)) || [];
  _runInstall(_updZipPath, verMatch[1] || null);
});

// Reload — element was removed from HTML when the success card was added,
// so guard against null so the rest of the script (success card + listeners)
// continues to load.
if (reloadPanelBtn) {
  reloadPanelBtn.addEventListener('click', function() { window.location.reload(); });
}

// ── Install success card ─────────────────────────────────────────────────
var updSuccessCard       = $('updSuccessCard');
var updSuccessVersion    = $('updSuccessVersion');
var updSuccessReloadBtn  = $('updSuccessReloadBtn');
var updSuccessDismiss    = $('updSuccessDismiss');

function showUpdateSuccess(version) {
  if (!updSuccessCard) return;
  if (updSuccessVersion) {
    updSuccessVersion.textContent = version ? 'v' + version : 'Installed';
  }
  // Reset animation by toggling display so the keyframes restart
  updSuccessCard.style.display = 'none';
  // Force reflow then show
  void updSuccessCard.offsetWidth;
  updSuccessCard.style.display = 'block';
  // Smooth-scroll the card into view in the Settings overlay
  try { updSuccessCard.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e) {}
}
function hideUpdateSuccess() {
  if (updSuccessCard) updSuccessCard.style.display = 'none';
}
if (updSuccessReloadBtn) {
  updSuccessReloadBtn.addEventListener('click', function() {
    window.location.reload();
  });
}
if (updSuccessDismiss) {
  updSuccessDismiss.addEventListener('click', hideUpdateSuccess);
}

// ── Add Blocks (blocks.jsx only) ─────────────────────────────────────────
function blocksSetFile(filePath) {
  _blocksZipPath = filePath;
  var name = filePath ? path.basename(filePath) : '';
  blocksDropLabel.textContent = name || 'Drop .zip here or click to browse';
  blocksDropZone.classList.toggle('has-file', !!filePath);
  blocksStatus.textContent = '';
  blocksStatus.style.color = 'var(--text-muted)';
  installBlocksBtn.disabled = !filePath;
  reloadBlocksBtn.style.display = 'none';
}

blocksDropZone.addEventListener('click', function() { blocksFileInput.click(); });
blocksFileInput.addEventListener('change', function() {
  var f = this.files && this.files[0];
  if (f && f.name.toLowerCase().endsWith('.zip')) blocksSetFile(f.path);
});
blocksDropZone.addEventListener('dragover', function(e) {
  e.preventDefault();
  blocksDropZone.classList.add('drag-over');
});
blocksDropZone.addEventListener('dragleave', function() {
  blocksDropZone.classList.remove('drag-over');
});
blocksDropZone.addEventListener('drop', function(e) {
  e.preventDefault();
  blocksDropZone.classList.remove('drag-over');
  var f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f && f.name.toLowerCase().endsWith('.zip')) {
    blocksSetFile(f.path);
  } else {
    blocksStatus.textContent = 'Please drop a .zip file.';
    blocksStatus.style.color = '#f55';
  }
});

installBlocksBtn.addEventListener('click', function() {
  if (!_blocksZipPath) return;
  var extRoot = cs.getSystemPath(SystemPath.EXTENSION);
  var jsxDest = path.join(extRoot, 'jsx');
  blocksStatus.textContent = 'Installing…';
  blocksStatus.style.color = 'var(--text-muted)';
  installBlocksBtn.disabled = true;
  var cmd;
  if (process.platform === 'win32') {
    var zipPS  = _blocksZipPath.replace(/'/g, "''");
    var destPS = jsxDest.replace(/'/g, "''");
    // Extract only jsx/blocks.jsx from the zip
    cmd = "powershell -NoProfile -Command \"" +
      "Add-Type -Assembly System.IO.Compression.FileSystem;" +
      "$z=[System.IO.Compression.ZipFile]::OpenRead('" + zipPS + "');" +
      "$e=$z.Entries|Where-Object{$_.FullName -match 'blocks\\.jsx$'};" +
      "if($e){[System.IO.Compression.ZipFileExtensions]::ExtractToFile($e,'" + destPS.replace(/\\/g,'\\\\') + "\\\\blocks.jsx',$true)};" +
      "$z.Dispose()\"";
  } else {
    // Extract only jsx/blocks.jsx (handles both flat and nested zip structures)
    cmd = 'cd ' + JSON.stringify(extRoot) + ' && ' +
      'unzip -o ' + JSON.stringify(_blocksZipPath) + ' "*/blocks.jsx" "blocks.jsx" -d ' + JSON.stringify(extRoot) + ' 2>/dev/null; ' +
      'find ' + JSON.stringify(extRoot) + ' -name "blocks.jsx" ! -path "*/jsx/blocks.jsx" -exec mv {} ' + JSON.stringify(jsxDest) + '/blocks.jsx \\;';
  }
  execFn(cmd, { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) }, function(err, stdout, stderr) {
    if (err) {
      blocksStatus.textContent = 'Error: ' + (stderr || err.message || String(err));
      blocksStatus.style.color = '#f55';
      installBlocksBtn.disabled = false;
    } else {
      blocksStatus.textContent = 'Blocks installed. Reload to apply.';
      blocksStatus.style.color = 'var(--accent)';
      reloadBlocksBtn.style.display = 'block';
    }
  });
});

reloadBlocksBtn.addEventListener('click', function() { window.location.reload(); });

// ══════════════════════════════════════════════════════════════════════════
// COLOR PICKER (shared)
// ══════════════════════════════════════════════════════════════════════════
colorPicker.addEventListener('click', function(e) {
  var sw = e.target.closest('.swatch[data-color]');
  if (!sw || sw.dataset.target) return;
  var c = sw.dataset.color;
  document.querySelectorAll('#colorPicker .swatch').forEach(function(s) { s.classList.remove('active'); });
  sw.classList.add('active');
  var oldColor = state.accentColor;
  state.accentColor = c;
  if (colorName) colorName.textContent = sw.dataset.name || c;
  updateBlockThumbColors(oldColor, c);
});

leftPicker.addEventListener('click', function(e) {
  var sw = e.target.closest('.swatch');
  if (!sw) return;
  document.querySelectorAll('#leftCardPicker .swatch').forEach(function(s) { s.classList.remove('active'); });
  sw.classList.add('active');
  state.leftColor = sw.dataset.color;
});

rightPicker.addEventListener('click', function(e) {
  var sw = e.target.closest('.swatch');
  if (!sw) return;
  document.querySelectorAll('#rightCardPicker .swatch').forEach(function(s) { s.classList.remove('active'); });
  sw.classList.add('active');
  state.rightColor = sw.dataset.color;
});

function updateBlockThumbColors(oldHex, newHex) {
  var oldVal = ('#' + oldHex).toUpperCase();
  var newVal = '#' + newHex;
  document.querySelectorAll('.block-thumb svg *').forEach(function(el) {
    var fill   = el.getAttribute('fill');
    var stroke = el.getAttribute('stroke');
    if (fill   && fill.toUpperCase()   === oldVal) el.setAttribute('fill',   newVal);
    if (stroke && stroke.toUpperCase() === oldVal) el.setAttribute('stroke', newVal);
  });
}

// ══════════════════════════════════════════════════════════════════════════
// CATEGORY ACCORDION
// ══════════════════════════════════════════════════════════════════════════
function collapseAllCats() {
  document.querySelectorAll('.cat-body').forEach(function(b) { b.classList.add('hidden'); });
  document.querySelectorAll('.cat-header').forEach(function(h) { h.classList.add('collapsed'); });
}
collapseAllCats(); // collapsed on load

catHeaders.forEach(function(hdr) {
  hdr.addEventListener('click', function() {
    var cat = this.dataset.cat;
    var body = document.getElementById('cat-' + cat);
    if (!body) return;
    var isOpen = !body.classList.contains('hidden');
    // Close all categories
    document.querySelectorAll('.cat-body').forEach(function(b) { b.classList.add('hidden'); });
    document.querySelectorAll('.cat-header').forEach(function(h) { h.classList.add('collapsed'); });
    // If it was closed, open it; if it was open, leave everything closed (toggle off)
    if (isOpen) return;
    body.classList.remove('hidden');
    this.classList.remove('collapsed');
  });
});

// ══════════════════════════════════════════════════════════════════════════
// BLOCK SEARCH
// ══════════════════════════════════════════════════════════════════════════
blockSearch.addEventListener('input', function() {
  var q = this.value.trim().toLowerCase();
  blockBtns.forEach(function(btn) {
    var label = btn.querySelector('.block-label').textContent.toLowerCase();
    var blockType = (btn.dataset.block || '').toLowerCase();
    btn.style.display = (!q || label.includes(q) || blockType.includes(q)) ? '' : 'none';
  });
  // Show/hide category bodies based on whether they have visible children
  document.querySelectorAll('.cat-body').forEach(function(body) {
    var visible = Array.from(body.querySelectorAll('.block-btn')).some(function(b) {
      return b.style.display !== 'none';
    });
    body.classList.toggle('hidden', !visible && !!q);
    var hdr = body.previousElementSibling;
    if (hdr && hdr.classList.contains('cat-header')) {
      hdr.style.display = (!visible && q) ? 'none' : '';
      if (!q) hdr.classList.remove('collapsed');
    }
  });
});

// ══════════════════════════════════════════════════════════════════════════
// BLOCK SELECTION
// ══════════════════════════════════════════════════════════════════════════
var CHART_TYPES   = ['chart-bar','chart-bar-v','chart-donut','chart-bar-stacked',
                     'chart-pie','chart-progress','chart-waterfall',
                     'chart-line','chart-area','chart-bar-grouped','chart-radar',
                     'chart-scatter','chart-bubble'];
var SIMPLE_CHART_TYPES  = ['chart-bar','chart-bar-v','chart-donut','chart-bar-stacked','chart-pie','chart-progress','chart-waterfall'];
var SERIES_CHART_TYPES  = ['chart-line','chart-area','chart-bar-grouped','chart-radar'];
var POINT_CHART_TYPES   = ['chart-scatter','chart-bubble'];
var COMPARE_TYPES = ['cards-compare'];
// Only blocks whose createX function actually reads params.bodyStyle:
//   createIconCardsBlock (cards-1..5) defaults to 'text'
//   createComparisonBlock (cards-compare) defaults to 'bullets'
var CARD_BODY_TYPES     = ['cards-1','cards-2','cards-3','cards-4','cards-5','cards-compare','cards-media','diagram-flow','cards-top-bar','cards-bottom-bar','cards-corner','cards-corner-sq','cards-corner-slim'];
var CARD_BODY_DEFAULT   = { 'cards-compare': 'bullets' }; // override default per block
var CORNER_CARD_TYPES  = ['cards-corner', 'cards-corner-sq', 'cards-corner-slim'];
var TREE_BLOCK_TYPES   = ['tree-3', 'tree-2level', 'tree-h3', 'tree-h5'];
var FLAT_BULLET_TYPES  = ['bullets', 'text-bullets', 'bullet-list', 'check-list'];
var NESTED_BULLET_TYPE = 'text-nested';

blockBtns.forEach(function(btn) {
  btn.addEventListener('click', function() { selectBlock(this); });
  btn.addEventListener('dblclick', function() { selectBlock(this); doInsert(); });
});

// ── Layout Combiner Strip + Slot Picker Overlay ───────────────────────────
var _activeSlot = 0;
var _filledSlots = [];  // tracks which slot indices the user has explicitly picked
var LAYOUT_NAMES = {
  'multi-split-h':'Split H','multi-split-v':'Split V',
  'multi-left-1-right-2':'1 + 2','multi-left-2-right-1':'2 + 1',
  'multi-three-col':'3 Col','multi-2x2':'2×2'
};
var LAYOUT_SLOT_COUNT = {
  'multi-split-h':2,'multi-split-v':2,
  'multi-left-1-right-2':3,'multi-left-2-right-1':3,'multi-three-col':3,
  'multi-2x2':4
};

function _slotBlockState(idx) { return [state.slotBlock1, state.slotBlock2, state.slotBlock3, state.slotBlock4][idx]; }

// ── Slot-picker config snapshot helpers ─────────────────────────────────────
// Capture every per-block option from global state into the slot's config so
// each slot can carry its own setup (table dimensions, card count, body style,
// etc.). Mirror of _buildSlotParams' source list, kept identical so nothing is
// silently dropped when params are read back at insert time.
function _snapshotToSlotConfig(idx) {
  if (idx < 0 || idx > 3) return;
  var bt = _slotBlockState(idx);
  if (!bt) return;
  state.slotConfigs[idx] = {
    blockType:        bt,
    cardCount:        state.cardCount,
    cornerRows:       state.cornerRows,
    bulletCount:      state.bulletCount,
    cardBodyStyle:    state.cardBodyStyle,
    titleAlign:       state.titleAlign,
    tableNumCols:     state.tableNumCols,
    tableNumRows:     state.tableNumRows,
    stepCount:        state.stepCount,
    stepsPerRow:      state.stepsPerRow,
    timelineCount:    state.timelineCount,
    timelineStyle:    state.timelineStyle,
    pointStyle:       state.pointStyle,
    iconGridCount:    state.iconGridCount,
    tagsCount:        state.tagsCount,
    logoCount:        state.logoCount,
    compTimelineCount:state.compTimelineCount,
    compareCount:     state.compareCount,
    compareTheme:     state.compareTheme,
    calloutType:      state.calloutType,
    calloutStroke:    state.calloutStroke,
    nestedMain:       state.nestedMain,
    nestedSub:        state.nestedSub,
    acronymCount:     state.acronymCount,
    cardBorder:       !!(cardBorder && cardBorder.checked),
    cardBg:           !!(cardBg     && cardBg.checked),
    dropShadow:       !!(dropShadow && dropShadow.checked),
    animateIn:        !!(animateIn  && animateIn.checked),
    posAnim:          !!(document.getElementById('posAnim') && document.getElementById('posAnim').checked),
    precompCards:     !!(precompCards && precompCards.checked)
  };
}

// Restore a slot's saved config back into global state so the options panel
// reflects what the user previously set for that slot. Falls back to a clean
// default state when slot has no saved config yet.
function _restoreSlotConfig(idx) {
  var cfg = state.slotConfigs[idx];
  if (!cfg) return false;
  // Copy primitive fields back to global state
  state.cardCount        = cfg.cardCount;
  state.cornerRows       = cfg.cornerRows;
  state.bulletCount      = cfg.bulletCount;
  state.cardBodyStyle    = cfg.cardBodyStyle;
  state.titleAlign       = cfg.titleAlign;
  state.tableNumCols     = cfg.tableNumCols;
  state.tableNumRows     = cfg.tableNumRows;
  state.stepCount        = cfg.stepCount;
  state.stepsPerRow      = cfg.stepsPerRow;
  state.timelineCount    = cfg.timelineCount;
  state.timelineStyle    = cfg.timelineStyle;
  state.pointStyle       = cfg.pointStyle;
  state.iconGridCount    = cfg.iconGridCount;
  state.tagsCount        = cfg.tagsCount;
  state.logoCount        = cfg.logoCount;
  state.compTimelineCount= cfg.compTimelineCount;
  state.compareCount     = cfg.compareCount;
  state.compareTheme     = cfg.compareTheme;
  state.calloutType      = cfg.calloutType;
  state.calloutStroke    = cfg.calloutStroke;
  state.nestedMain       = cfg.nestedMain;
  state.nestedSub        = cfg.nestedSub;
  state.acronymCount     = cfg.acronymCount;
  // Reflect checkbox state
  if (cardBorder)   cardBorder.checked   = !!cfg.cardBorder;
  if (cardBg)       cardBg.checked       = !!cfg.cardBg;
  if (dropShadow)   dropShadow.checked   = !!cfg.dropShadow;
  if (animateIn)    animateIn.checked    = !!cfg.animateIn;
  if (precompCards) precompCards.checked = !!cfg.precompCards;
  var posAnimEl = document.getElementById('posAnim');
  if (posAnimEl)    posAnimEl.checked    = !!cfg.posAnim;
  return true;
}

// Find a regular block-btn for a given block type. Used to drive `selectBlock`
// from the slot picker so all the existing options-panel setup runs naturally.
function _findBlockBtn(bt) {
  return document.querySelector('#blocks-scroll .block-btn[data-block="' + bt + '"]');
}

// ── Combine queue helpers (new design) ────────────────────────────────────
// The Combine feature works inside-out: the user picks + configures any block
// normally, then taps "+ Combine" to push a frozen snapshot to the queue.
// Once the queue has ≥ 2 items, a layout picker appears in the tray. Picking
// a layout swaps INSERT BLOCK → INSERT COMBINED.

// Layouts available for each queue size — matches createMultiBlockLayout's
// recognised IDs.  Inline SVG icons mirror the previous slot-picker thumbs.
var COMBINE_LAYOUTS = [
  { id: 'split-h',        slots: 2, label: 'Side by side',
    svg: '<svg viewBox="0 0 40 28"><rect x="2"  y="3" width="16" height="22" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="22" y="3" width="16" height="22" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id: 'split-v',        slots: 2, label: 'Stacked',
    svg: '<svg viewBox="0 0 40 28"><rect x="3" y="2"  width="34" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="3" y="15" width="34" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id: 'left-1-right-2', slots: 3, label: '1 + 2',
    svg: '<svg viewBox="0 0 40 28"><rect x="2"  y="2"  width="16" height="24" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="22" y="2"  width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="22" y="15" width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id: 'left-2-right-1', slots: 3, label: '2 + 1',
    svg: '<svg viewBox="0 0 40 28"><rect x="2"  y="2"  width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="2"  y="15" width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="22" y="2"  width="16" height="24" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id: 'three-col',      slots: 3, label: '3 columns',
    svg: '<svg viewBox="0 0 40 28"><rect x="2"  y="3" width="10" height="22" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="15" y="3" width="10" height="22" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="28" y="3" width="10" height="22" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id: '2x2',            slots: 4, label: '2 × 2',
    svg: '<svg viewBox="0 0 40 28"><rect x="2"  y="2"  width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="22" y="2"  width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="2"  y="15" width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="22" y="15" width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' }
];
var COMBINE_MAX = 4;

function _labelForBlock(bt) {
  var btn = _findBlockBtn(bt);
  if (btn) {
    var lbl = btn.querySelector('.block-label');
    if (lbl && lbl.textContent) return lbl.textContent.trim();
  }
  return bt;
}

function _addCurrentBlockToCombineQueue() {
  if (!state.selectedBlock) return;
  if (state.selectedBlock.indexOf('multi-') === 0) return; // can't queue layouts
  if (state.combineQueue.length >= COMBINE_MAX) return;
  // Snapshot the block's full configured params at THIS moment.
  var snapshot;
  try { snapshot = buildParams(state.selectedBlock); } catch(e) { snapshot = { blockType: state.selectedBlock }; }
  state.combineQueue.push({
    blockType: state.selectedBlock,
    label:     _labelForBlock(state.selectedBlock),
    params:    snapshot
  });
  // If the picked layout no longer matches the queue size, clear it.
  if (state.combineLayoutPicked) {
    var match = false;
    for (var li = 0; li < COMBINE_LAYOUTS.length; li++) {
      if (COMBINE_LAYOUTS[li].id === state.combineLayoutPicked &&
          COMBINE_LAYOUTS[li].slots === state.combineQueue.length) { match = true; break; }
    }
    if (!match) state.combineLayoutPicked = null;
  }
  renderCombineTray();
  _updateInsertButtonForCombine();
}

function _removeFromCombineQueue(idx) {
  state.combineQueue.splice(idx, 1);
  if (state.combineQueue.length < 2) state.combineLayoutPicked = null;
  // Same auto-clear as above when queue size changes
  if (state.combineLayoutPicked) {
    var match = false;
    for (var li2 = 0; li2 < COMBINE_LAYOUTS.length; li2++) {
      if (COMBINE_LAYOUTS[li2].id === state.combineLayoutPicked &&
          COMBINE_LAYOUTS[li2].slots === state.combineQueue.length) { match = true; break; }
    }
    if (!match) state.combineLayoutPicked = null;
  }
  renderCombineTray();
  _updateInsertButtonForCombine();
}

function _clearCombineQueue() {
  state.combineQueue = [];
  state.combineLayoutPicked = null;
  renderCombineTray();
  _updateInsertButtonForCombine();
}

function renderCombineTray() {
  var tray = document.getElementById('combineTray');
  if (!tray) return;
  if (!state.combineQueue.length) {
    tray.style.display = 'none';
    return;
  }
  tray.style.display = '';

  var countEl = document.getElementById('combineQueueCount');
  if (countEl) countEl.textContent = '(' + state.combineQueue.length + ')';

  var chipsHost = document.getElementById('combineChips');
  if (chipsHost) {
    chipsHost.innerHTML = '';
    state.combineQueue.forEach(function(entry, idx) {
      var chip = document.createElement('div');
      chip.className = 'combine-chip';
      var idxEl = document.createElement('span');
      idxEl.className = 'combine-chip-idx';
      idxEl.textContent = String(idx + 1);
      var lblEl = document.createElement('span');
      lblEl.textContent = entry.label || entry.blockType;
      var xEl = document.createElement('span');
      xEl.className = 'combine-chip-x';
      xEl.textContent = '×';
      xEl.title = 'Remove from queue';
      xEl.addEventListener('click', function(e) {
        e.stopPropagation();
        _removeFromCombineQueue(idx);
      });
      chip.appendChild(idxEl);
      chip.appendChild(lblEl);
      chip.appendChild(xEl);
      chipsHost.appendChild(chip);
    });
  }

  // Layout picker — only when 2+ blocks queued
  var layoutsHost = document.getElementById('combineTrayLayouts');
  var layoutGrid  = document.getElementById('combineLayoutGrid');
  if (layoutsHost && layoutGrid) {
    if (state.combineQueue.length < 2) {
      layoutsHost.style.display = 'none';
    } else {
      layoutsHost.style.display = '';
      layoutGrid.innerHTML = '';
      var n = state.combineQueue.length;
      COMBINE_LAYOUTS.forEach(function(layout) {
        if (layout.slots !== n) return;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'combine-layout-btn' + (state.combineLayoutPicked === layout.id ? ' active' : '');
        btn.dataset.layout = layout.id;
        btn.title = layout.label;
        btn.innerHTML = layout.svg;
        btn.addEventListener('click', function() {
          state.combineLayoutPicked = layout.id;
          renderCombineTray();
          _updateInsertButtonForCombine();
        });
        layoutGrid.appendChild(btn);
      });
    }
  }
}

// Swap INSERT BLOCK ↔ INSERT COMBINED based on queue + layout selection state.
function _updateInsertButtonForCombine() {
  if (!insertBtn) return;
  var combinedReady = state.combineQueue.length >= 2 && state.combineLayoutPicked;
  if (combinedReady) {
    insertBtn.textContent = 'INSERT COMBINED (' + state.combineQueue.length + ')';
    insertBtn.disabled = false;
    insertBtn.classList.add('insert-btn-combined');
  } else {
    insertBtn.textContent = 'INSERT BLOCK';
    insertBtn.classList.remove('insert-btn-combined');
    // Re-evaluate normal disabled state — selectedBlock + not running
    insertBtn.disabled = !state.selectedBlock || state.aiRunning;
  }
  // Combine add button — enabled when a block is selected, queue not full,
  // and the block isn't a multi-* layout (we removed those, but guard).
  var addBtn = document.getElementById('combineAddBtn');
  if (addBtn) {
    var canQueue = !!state.selectedBlock
                && state.selectedBlock.indexOf('multi-') !== 0
                && state.combineQueue.length < COMBINE_MAX;
    addBtn.disabled = !canQueue;
    addBtn.textContent = state.combineQueue.length >= COMBINE_MAX
      ? '+ Queue full'
      : '+ Combine';
  }
}
function _setSlotBlock(idx, bt) {
  if (idx === 0) state.slotBlock1 = bt;
  else if (idx === 1) state.slotBlock2 = bt;
  else if (idx === 2) state.slotBlock3 = bt;
  else state.slotBlock4 = bt;
}

function openSlotOverlay(layoutId) {
  state.selectedBlock     = layoutId;
  state._comboLayoutBlock = layoutId;
  state._slotPickerOpen   = true;
  // Fresh slot configs for this overlay session — each slot starts un-configured.
  state.slotConfigs = [null, null, null, null];
  insertBtn.disabled = false;
  _activeSlot = 0;
  _filledSlots = [];

  // Highlight active layout btn
  layoutStripBtns.forEach(function(b) { b.classList.toggle('active', b.dataset.layout === layoutId); });

  // Set layout icon in header
  var activeBtn = document.querySelector('.layout-btn[data-layout="' + layoutId + '"]');
  if (activeBtn) {
    var thumbSvg = activeBtn.querySelector('.layout-btn-thumb');
    slotOverlayLayout.innerHTML = thumbSvg ? thumbSvg.innerHTML : '';
  }

  // Show/hide slot tabs — no pre-filling
  var nSlots = LAYOUT_SLOT_COUNT[layoutId] || 2;
  slotTabs.forEach(function(tab, i) {
    tab.style.display = i < nSlots ? '' : 'none';
    tab.classList.remove('filled');
  });

  // NOTE: do NOT clear slotOptionsHost.innerHTML here — the previous session
  // may have left #blockOptionsPanel inside it, and clearing innerHTML
  // destroys the panel entirely. _applySlotBlockToOptions() below will move
  // the panel into the host (or leave it there if it's already in place).

  activateSlotTab(0);

  $('blocks-scroll').style.display = 'none';
  var _ls = $('layoutStrip'); if (_ls) _ls.style.display = 'none';
  slotOverlay.style.display = 'flex';
}

function closeSlotOverlay() {
  // Capture whatever the user just configured for the active slot before closing.
  if (state._slotPickerOpen) {
    try { _snapshotToSlotConfig(_activeSlot); } catch(e) {}
    // Restore state.selectedBlock to the multi-* layout type so Insert acts on it.
    if (state._comboLayoutBlock) state.selectedBlock = state._comboLayoutBlock;
  }
  state._slotPickerOpen = false;
  slotOverlay.style.display = 'none';
  $('blocks-scroll').style.display = '';
  var _ls = $('layoutStrip'); if (_ls) _ls.style.display = '';
}

function activateSlotTab(idx) {
  // Snapshot the previously-active slot's config so its options stick when
  // the user switches back to it later.
  if (state._slotPickerOpen && _activeSlot !== idx) {
    try { _snapshotToSlotConfig(_activeSlot); } catch(e) {}
  }
  _activeSlot = idx;
  slotTabs.forEach(function(t, i) { t.classList.toggle('active', i === idx); });
  renderSlotThumbGrid(idx);
  // If this slot already has a block + saved config, restore it so the options
  // panel reflects what was set last. We do it via the regular selectBlock()
  // flow so option-row visibility logic matches exactly. selectBlock() will
  // overwrite state.selectedBlock to the slot's block; we restore back to the
  // multi-* layout at close/insert time.
  var slotBt = _slotBlockState(idx);
  if (slotBt) {
    _applySlotBlockToOptions(slotBt, idx);
  } else {
    // No block yet for this slot — hide any leftover options panel
    var _host = document.getElementById('slotOptionsHost');
    if (_host) _host.innerHTML = '';
  }
}

// Drive the regular options-panel flow for a slot's block.  Order is:
//   1. selectBlock() — runs the full option-row visibility logic + block-type
//      defaults (e.g. cardCount = 3 for cards-3, default bodyStyle, etc.)
//   2. _restoreSlotConfig() — if the slot has a saved config, overlay the
//      user's customised values back over selectBlock's defaults
//   3. _syncOptionUIToState() — repaint the option buttons to match restored state
//   4. Move the options panel into the slot picker host so user sees inline
//   5. Snapshot back to slot config (captures any defaults applied in step 1)
function _applySlotBlockToOptions(slotBt, slotIdx) {
  var origBtn = _findBlockBtn(slotBt);
  if (!origBtn) return;

  try { selectBlock(origBtn); } catch(e) {}

  var hadConfig = _restoreSlotConfig(slotIdx);
  if (hadConfig) {
    // Prevent _refreshCornerRowsRow from auto-flipping our restored cornerRows.
    state._cornerRowsTouched = true;
    _syncOptionUIToState();
  }

  var panel = document.getElementById('blockOptionsPanel');
  var host  = document.getElementById('slotOptionsHost');
  if (panel && host) {
    host.appendChild(panel);
    panel.classList.add('is-active');
  }

  if (slotTabs[slotIdx]) slotTabs[slotIdx].classList.add('filled');

  try { _snapshotToSlotConfig(slotIdx); } catch(e) {}
}

// Paint the option panel's active states to match current global `state`
// values.  Used after `_restoreSlotConfig` to overlay saved slot settings on
// top of the defaults selectBlock just applied.  Only handles the most-used
// controls — rare ones (timeline style, chart point shape, etc.) fall back to
// selectBlock's defaults, which is acceptable.
function _syncOptionUIToState() {
  function paint(btns, key, parser) {
    if (!btns) return;
    var want = parser ? parser(state[key]) : state[key];
    btns.forEach(function(b) {
      var v = parser ? parser(b.dataset[key === 'cardBodyStyle' ? 'style' : 'count']) : b.dataset.style;
      // No-op fallback — explicit handling below per control
    });
  }
  // Card body style
  if (typeof cardStyleBtns !== 'undefined' && cardStyleBtns) {
    cardStyleBtns.forEach(function(b) {
      b.classList.toggle('active', b.dataset.style === state.cardBodyStyle);
    });
  }
  // Card count
  if (typeof cardCountBtns !== 'undefined' && cardCountBtns) {
    cardCountBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.cardCount);
    });
  }
  // Corner rows
  if (typeof cornerRowsBtns !== 'undefined' && cornerRowsBtns) {
    cornerRowsBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.rows, 10) === (state.cornerRows || 1));
    });
  }
  // Table cols/rows
  if (typeof tableColsBtns !== 'undefined' && tableColsBtns) {
    tableColsBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.tableNumCols);
    });
  }
  if (typeof tableRowsBtns !== 'undefined' && tableRowsBtns) {
    tableRowsBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.tableNumRows);
    });
  }
  // Title alignment
  document.querySelectorAll('#titleAlignBtns .style-btn').forEach(function(b) {
    b.classList.toggle('active', b.dataset.align === state.titleAlign);
  });
  // Step count + per-row
  document.querySelectorAll('#stepCountBtns .style-btn').forEach(function(b) {
    b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.stepCount);
  });
  document.querySelectorAll('#stepsPerRowBtns .style-btn').forEach(function(b) {
    b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.stepsPerRow);
  });
}

function renderSlotThumbGrid(slotIdx) {
  slotThumbGrid.innerHTML = '';
  var current = _slotBlockState(slotIdx);
  var nSlots = state.selectedBlock ? (LAYOUT_SLOT_COUNT[state.selectedBlock] || 2) : 2;

  // Clone all block-btn thumbnails — skip multi-* (layout controls, not blocks);
  // nesting Combine layouts isn't supported.
  document.querySelectorAll('#blocks-scroll .block-btn[data-block]').forEach(function(btn) {
    var bt = btn.dataset.block;
    if (bt && bt.indexOf('multi-') === 0) return;
    var item = document.createElement('div');
    item.className = 'slot-thumb-item' + (bt === current ? ' active' : '');
    item.dataset.block = bt;

    var origThumb = btn.querySelector('.block-thumb');
    if (origThumb) {
      var thumbDiv = document.createElement('div');
      thumbDiv.className = 'block-thumb';
      thumbDiv.innerHTML = origThumb.innerHTML;
      item.appendChild(thumbDiv);
    }
    var origLabel = btn.querySelector('.block-label');
    if (origLabel) {
      var labelDiv = document.createElement('div');
      labelDiv.className = 'block-label';
      labelDiv.textContent = origLabel.textContent;
      item.appendChild(labelDiv);
    }

    item.addEventListener('click', function() {
      // If the slot's block changed, drop its saved config so we don't apply
      // table-only options to a card block (or vice versa).
      var prev = _slotBlockState(slotIdx);
      if (prev !== bt) state.slotConfigs[slotIdx] = null;
      _setSlotBlock(slotIdx, bt);
      if (_filledSlots.indexOf(slotIdx) === -1) _filledSlots.push(slotIdx);
      // Repaint highlights in this slot's grid
      slotThumbGrid.querySelectorAll('.slot-thumb-item').forEach(function(el) {
        el.classList.toggle('active', el.dataset.block === bt);
      });
      // Run the regular options-panel setup for this block type and move the
      // panel into the slot picker so user can configure inline. Stays on the
      // active slot — no more auto-advance — so the user can finish setup
      // before switching slots.
      _applySlotBlockToOptions(bt, slotIdx);
    });

    slotThumbGrid.appendChild(item);
  });
}

// Layout strip button clicks
layoutStripBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    // Deselect any regular block
    blockBtns.forEach(function(b) { b.classList.remove('active'); });
    state.selectedMyBlock = null;
    openSlotOverlay(btn.dataset.layout);
  });
});

// Slot tab clicks
slotTabs.forEach(function(tab) {
  tab.addEventListener('click', function() {
    activateSlotTab(parseInt(tab.dataset.slot, 10));
  });
});

// Close button
slotCloseBtn.addEventListener('click', closeSlotOverlay);
var slotBackBtn = $('slotBackBtn');
if (slotBackBtn) slotBackBtn.addEventListener('click', closeSlotOverlay);

function selectBlock(btn) {
  // Combine layouts (multi-*) go through the slot picker overlay — not the
  // normal select flow. Detect and route early.
  var bt = btn.dataset.block;
  if (bt && bt.indexOf('multi-') === 0) {
    openSlotOverlay(bt);
    return;
  }
  blockBtns.forEach(function(b) { b.classList.remove('active'); });
  btn.classList.add('active');
  state.selectedBlock = bt;
  state.selectedMyBlock = null;
  insertBtn.disabled = false;
  // Refresh the Combine button label/enabled state for the new selection.
  try { _updateInsertButtonForCombine(); } catch(_uic) {}
  // The active-class highlight on the thumbnail already shows what's selected
  // — repeating the block label in the status row reads like a stray glitch.
  // Clear the status here; setStatus() calls for real messages still work.
  statusEl.textContent = '';
  statusEl.className = 'status';
  // Reveal the configuration rows now that we have a block to configure.
  try { document.querySelector('.fixed-bottom').classList.add('has-block'); } catch(e) {}
  // Move the per-block options panel into the parent category so the user
  // sees configuration in context with the catalog.
  try { _moveOptionsPanelToCategory(btn); } catch(e) {}

  // Per-card color row
  var isCompare = COMPARE_TYPES.indexOf(state.selectedBlock) !== -1;
  perCardRow.classList.toggle('visible', isCompare);

  // Card BG checkbox — hidden for corner types and tree blocks; Border defaults ON for corner types
  var isCornerCard = CORNER_CARD_TYPES.indexOf(state.selectedBlock) !== -1;
  var isTreeBlock  = TREE_BLOCK_TYPES.indexOf(state.selectedBlock) !== -1;
  $('cardBgLabel').style.display = (isCornerCard || isTreeBlock) ? 'none' : '';
  if (isCornerCard) { cardBorder.checked = false; dropShadow.checked = true; }

  // Pre-comp / null-parent / animation rig — show for every MULTI-element block.
  // Single-element blocks (one card, one stat, one quote, etc.) get no value
  // from grouping or staggered animation; the rig silently does nothing.
  var SINGLE_ELEMENT_BLOCKS = [
    'slide-title','comp-stat','comp-quote','comp-divider','comp-callout','rack-callout',
    'cards-specs-a','cards-specs-b','cards-specs-c',
    'topology-gh200','topology-nvlink-switch','topology-spine-leaf','topology-gpu-node','topology-multi-rack'
  ];
  var isBarCard     = state.selectedBlock === 'cards-top-bar' || state.selectedBlock === 'cards-bottom-bar';
  var isMultiBlock  = state.selectedBlock && SINGLE_ELEMENT_BLOCKS.indexOf(state.selectedBlock) === -1
                      && state.selectedBlock.indexOf('multi-') !== 0;  // exclude combine layouts
  var isPrecompable = isMultiBlock;
  $('precompRow').style.display = isPrecompable ? 'flex' : 'none';

  // Card count row — shown for cards-1..5, corner types, media cards, and code-quad
  var isNCard      = /^cards-[1-5]$/.test(state.selectedBlock);
  var isMediaCard  = state.selectedBlock === 'cards-media';
  var isCodeQuad   = state.selectedBlock === 'text-code-quad';
  var isFlowSteps  = state.selectedBlock === 'diagram-flow';
  $('cardCountRow').style.display = (isNCard || isCornerCard || isMediaCard || isCodeQuad || isFlowSteps || isBarCard) ? 'flex' : 'none';
  if (isBarCard) {
    state.cardCount = 3;
    cardCountBtns.forEach(function(b) {
      b.style.display = '';
      b.classList.toggle('active', b.dataset.count === '3');
    });
  } else if (isNCard) {
    var n = parseInt(state.selectedBlock.replace('cards-', ''), 10);
    state.cardCount = n;
    cardCountBtns.forEach(function(b) {
      b.style.display = '';
      if (parseInt(b.dataset.count, 10) === n) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
  } else if (isCornerCard) {
    // Allow 1-6 cards for corner types; keep whatever count is already on
    // state (clamped to [1, 6]), default to 4.
    if (!state.cardCount || state.cardCount < 1 || state.cardCount > 6) state.cardCount = 4;
    cardCountBtns.forEach(function(b) {
      var v = parseInt(b.dataset.count, 10);
      b.style.display = ''; // the 6 button is corner-only — always show here
      if (v === state.cardCount) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
    // Match the pre-toggle default: 3+ cards used to render as 2 rows (2x2,
    // 3+2, etc.). Only set when the user hasn't explicitly chosen rows this
    // session so a deliberate "Rows 1" click sticks.
    if (!state._cornerRowsTouched) {
      state.cornerRows = (state.cardCount >= 3) ? 2 : 1;
    }
  } else if (isMediaCard) {
    state.cardCount = Math.min(state.cardCount, 4);
    cardCountBtns.forEach(function(b) {
      var v = parseInt(b.dataset.count, 10);
      if (v === state.cardCount) { b.classList.add('active'); } else { b.classList.remove('active'); }
      b.style.display = v <= 4 ? '' : 'none'; // hide the 5 button for media cards
    });
  } else if (isCodeQuad) {
    if (state.cardCount !== 2 && state.cardCount !== 4) state.cardCount = 4;
    cardCountBtns.forEach(function(b) {
      var v = parseInt(b.dataset.count, 10);
      b.style.display = (v === 2 || v === 4) ? '' : 'none';
      if (v === state.cardCount) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
  } else if (isFlowSteps) {
    if (state.cardCount < 2 || state.cardCount > 5) state.cardCount = 3;
    cardCountBtns.forEach(function(b) {
      var v = parseInt(b.dataset.count, 10);
      b.style.display = v >= 2 ? '' : 'none';
      if (v === state.cardCount) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
  }
  // Post-step: the 6-button is corner-only. Hide it whenever we're NOT on a
  // corner block, regardless of which branch set display above.
  cardCountBtns.forEach(function(b) {
    if (b.dataset.cornerOnly === '1' && !isCornerCard) b.style.display = 'none';
  });
  // Refresh the corner-rows row whenever a block changes (handles both showing
  // and hiding the row + reflecting the active state).
  try { _refreshCornerRowsRow(); } catch(e) {}

  // Card body style row — only shown for blocks that actually use bodyStyle
  var showStyle = CARD_BODY_TYPES.indexOf(state.selectedBlock) !== -1;
  cardStyleRow.style.display = showStyle ? 'flex' : 'none';
  if (showStyle) {
    var def = CARD_BODY_DEFAULT[state.selectedBlock] || 'text';
    cardStyleBtns.forEach(function(b) {
      if (b.dataset.style === def) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
    state.cardBodyStyle = def;
  }

  // Card lines row — show for card types (not pipe style) and corner card types
  var isCardType   = CARD_BODY_TYPES.indexOf(state.selectedBlock) !== -1;
  var isCornerType = CORNER_CARD_TYPES.indexOf(state.selectedBlock) !== -1;
  var isPipe = state.cardBodyStyle === 'pipe';
  $('cardLinesRow').style.display  = (isCornerType || (isCardType && !isPipe)) ? 'flex' : 'none';
  $('pipeCountRow').style.display  = (isCardType || isCornerType) && isPipe ? 'flex' : 'none';

  // Table columns / rows pickers — shown INSIDE the Tables category, right
  // below the style thumbs, when a table style is selected.
  var sb = state.selectedBlock || '';
  var isTable = (sb === 'table-bar' || sb === 'table-minimal' || sb === 'table-outlined' ||
                 sb === 'table-1col' || sb === 'table-2col' || sb === 'table-3col' || sb === 'table-4col');
  $('tableInlineOpts').style.display = isTable ? 'block' : 'none';

  // Legacy table-Ncol IDs: lock the cols picker to N and disable changes,
  // so saved My Blocks remain intact but the user picking from the library
  // gets the new flexible flow.
  if (sb === 'table-1col' || sb === 'table-2col' || sb === 'table-3col' || sb === 'table-4col') {
    var legacyN = parseInt(sb.replace('table-', '').replace('col', ''), 10);
    state.tableNumCols = legacyN;
    tableColsBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === legacyN);
    });
  } else if (isTable) {
    // Reflect current state into the buttons (in case user just toggled blocks).
    tableColsBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.tableNumCols);
    });
    tableRowsBtns.forEach(function(b) {
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === state.tableNumRows);
    });
  }
  // Title alignment row — shown for every card type whose block honors params.titleAlign:
  // corner cards, cards-1..5, cards-compare, cards-media, top-bar, bottom-bar.
  var isTitleAlignable =
    isCornerType ||
    isNCard ||
    state.selectedBlock === 'cards-compare' ||
    state.selectedBlock === 'cards-media' ||
    state.selectedBlock === 'cards-top-bar' ||
    state.selectedBlock === 'cards-bottom-bar';
  $('titleAlignRow').style.display = isTitleAlignable ? 'flex' : 'none';

  // Top-bar / bottom-bar default to 'center' (their natural design); other card
  // types default to 'left'. Repaint the alignment buttons to match.
  var defaultAlign = (state.selectedBlock === 'cards-top-bar' ||
                      state.selectedBlock === 'cards-bottom-bar') ? 'center' : 'left';
  if (isTitleAlignable) {
    // Preserve user choice if they've already picked something for THIS block;
    // otherwise reset to the natural default whenever the selected block changes.
    if (state._titleAlignFor !== state.selectedBlock) {
      state.titleAlign = defaultAlign;
      state._titleAlignFor = state.selectedBlock;
      document.querySelectorAll('#titleAlignBtns .style-btn').forEach(function(b) {
        b.classList.toggle('active', b.dataset.align === defaultAlign);
      });
    }
  }

  // Bullet count rows
  var isFlatBullet = FLAT_BULLET_TYPES.indexOf(state.selectedBlock) !== -1;
  var isNested     = state.selectedBlock === NESTED_BULLET_TYPE;
  $('bulletCountRow').style.display = isFlatBullet ? 'flex' : 'none';
  $('nestedCountRow').style.display = isNested     ? 'flex' : 'none';

  // Graph data section
  var isSimpleChart  = SIMPLE_CHART_TYPES.indexOf(state.selectedBlock) !== -1;
  var isSeriesChart  = SERIES_CHART_TYPES.indexOf(state.selectedBlock) !== -1;
  var isPointChart   = POINT_CHART_TYPES.indexOf(state.selectedBlock) !== -1;
  graphDataSection.style.display        = isSimpleChart  ? 'block' : 'none';
  $('seriesDataSection').style.display  = isSeriesChart  ? 'block' : 'none';
  $('pointDataSection').style.display   = isPointChart   ? 'block' : 'none';
  if (isSimpleChart) {
    var isStacked  = state.selectedBlock === 'chart-bar-stacked';
    var isPct      = ['chart-donut','chart-pie','chart-progress'].indexOf(state.selectedBlock) !== -1;
    var isWF       = state.selectedBlock === 'chart-waterfall';
    $('stackedYMaxRow').style.display = isStacked ? 'flex' : 'none';
    $('graphHint').textContent = isStacked
      ? 'Base: normal bar value (0-100). Overflow: stacked portion above base.'
      : isPct ? 'Values: % of total (0-100)'
      : isWF  ? 'Values: positive or negative'
      : 'Bars: value = % of max width (0-100)';
    updateOverflowCols(isStacked);
    var maxItems = state.selectedBlock === 'chart-progress' ? 5 : 8;
    document.querySelectorAll('#graphCountBtns .count-btn').forEach(function(b) {
      b.style.display = parseInt(b.dataset.count, 10) <= maxItems ? '' : 'none';
    });
    if (isPct) { $('graphTotal').textContent = ''; updateDonutTotal(); }
    state.lastChartType = state.selectedBlock;
  }
  if (isSeriesChart) {
    var isRadar = state.selectedBlock === 'chart-radar';
    var isArea  = state.selectedBlock === 'chart-area';
    $('xLabelsLabel').textContent = isRadar ? 'AXES' : 'X LABELS';
    if (isRadar) $('xLabelsInput').value = 'Perf,Efficiency,Reliability,Scalability,Security,Cost';
    var maxSer = isArea ? 1 : (isRadar ? 2 : 3);
    document.querySelectorAll('#seriesCountBtns .count-btn').forEach(function(b) {
      var n = parseInt(b.dataset.count, 10);
      b.style.display = n <= maxSer ? '' : 'none';
    });
    if (state.seriesCount > maxSer) {
      state.seriesCount = 1;
      document.querySelectorAll('#seriesCountBtns .count-btn').forEach(function(b) {
        b.classList.toggle('active', b.dataset.count === '1');
      });
      document.querySelectorAll('.series-row').forEach(function(r, i) {
        r.style.display = i === 0 ? '' : 'none';
      });
    }
    $('seriesHint').textContent = isRadar ? 'Values per axis, comma-separated' : 'Values: comma-separated numbers (0–100)';
  }
  if (isPointChart) {
    var isBubble = state.selectedBlock === 'chart-bubble';
    $('pointHint').textContent = isBubble ? 'Label, X, Y, Size (0–100)' : 'Label, X, Y (0–100)';
    document.querySelectorAll('.point-s-input').forEach(function(el) {
      el.style.display = isBubble ? '' : 'none';
    });
  }

  // 2 Columns row count
  $('colCountRow').style.display = state.selectedBlock === 'text-2col' ? 'flex' : 'none';

  // Acronym count row — only shown when pre-comp is enabled (count = number of precomped letters)
  $('acronymCountRow').style.display = (state.selectedBlock === 'text-acronym' && precompCards.checked) ? 'flex' : 'none';

  // Steps animation rows
  var isStepsAnim = state.selectedBlock === 'diagram-steps';
  $('stepCountRow').style.display    = isStepsAnim ? 'flex' : 'none';
  $('stepsPerRowRow').style.display  = isStepsAnim ? 'flex' : 'none';

  // Timeline rows — shown only for diagram-timeline
  var isTL = state.selectedBlock === 'diagram-timeline';
  $('timelineCountRow').style.display = isTL ? 'flex' : 'none';
  $('timelineStyleRow').style.display = isTL ? 'flex' : 'none';
  $('pointStyleRow').style.display    = isTL ? 'flex' : 'none';

  // comp-timeline count row
  $('compTimelineCountRow').style.display = (state.selectedBlock === 'comp-timeline') ? 'flex' : 'none';
  // comp-logo-strip count row
  $('logoCountRow').style.display = (state.selectedBlock === 'comp-logo-strip') ? 'flex' : 'none';
  // comp-compare count + theme rows
  $('compareCountRow').style.display  = (state.selectedBlock === 'comp-compare') ? 'flex' : 'none';
  $('compareThemeRow').style.display  = (state.selectedBlock === 'comp-compare') ? 'flex' : 'none';
  // comp-tags count row
  $('tagsCountRow').style.display = (state.selectedBlock === 'comp-tags') ? 'flex' : 'none';
  // comp-icon-grid count row
  $('iconGridCountRow').style.display = (state.selectedBlock === 'comp-icon-grid') ? 'flex' : 'none';
  // cards-device count row
  $('deviceCountRow').style.display = (state.selectedBlock === 'cards-device') ? 'flex' : 'none';
  // comp-callout type + stroke rows
  var isCallout = state.selectedBlock === 'comp-callout';
  $('calloutTypeRow').style.display   = isCallout ? 'flex' : 'none';
  $('calloutStrokeRow').style.display = (isCallout && state.calloutType !== 'dark') ? 'flex' : 'none';
  if (isCallout) {
    calloutTypeBtns.forEach(function(b) {
      if (b.dataset.type === state.calloutType) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
    calloutStrokeBtns.forEach(function(b) {
      if (b.dataset.stroke === state.calloutStroke) { b.classList.add('active'); } else { b.classList.remove('active'); }
    });
  }


  // Close slot overlay if user picks a regular block
  if (slotOverlay.style.display !== 'none') { closeSlotOverlay(); }
  layoutStripBtns.forEach(function(b) { b.classList.remove('active'); });

  // Blocks where Border/Shadow/BG are irrelevant — hide the row
  var NO_STYLE_BLOCKS = [
    // Text
    'text-code-split',
    // Diagrams — no card backgrounds
    'diagram-split-2-ol','diagram-split-3-ol','diagram-split-5-ol',
    'diagram-split-mirror-ol','diagram-parallel-split-ol',
    'diagram-timeline','diagram-funnel','diagram-matrix','diagram-steps',
    'diagram-hub-spoke',
    // Charts — all purely graphical
    'chart-bar','chart-bar-v','chart-bar-stacked','chart-donut',
    'chart-pie','chart-progress','chart-waterfall',
    'chart-line','chart-area','chart-bar-grouped','chart-radar',
    'chart-scatter','chart-bubble',
    // Infrastructure — fixed hardcoded visuals
    'topology-gh200','topology-nvlink-switch',
    'topology-spine-leaf','topology-gpu-node','topology-multi-rack',
    // Components — no card bg/border/shadow
    'rack-callout','comp-timeline','comp-logo-strip','comp-compare','comp-tags','comp-callout','comp-icon-grid',
    'comp-stat','comp-kpi','comp-quote','comp-divider',
    // Cards with own styling
    'cards-device',
    // Tables — use addSolid internally, no card style params
    'table-bar','table-minimal','table-outlined',
    'table-1col','table-2col','table-3col','table-4col',
    // Multi-block layouts — style applied per-slot, not to master
    'multi-split-h','multi-split-v','multi-left-1-right-2','multi-left-2-right-1','multi-three-col','multi-2x2'
  ];
  var hideStyle = NO_STYLE_BLOCKS.indexOf(state.selectedBlock) !== -1;
  $('styleCheckRow').style.display = hideStyle ? 'none' : '';
  if (hideStyle) { $('precompRow').style.display = 'none'; }
}

function updateOverflowCols(show) {
  document.querySelectorAll('.graph-ovf-input, .graph-ovf-lbl').forEach(function(el) {
    el.style.display = show ? '' : 'none';
  });
}

// ══════════════════════════════════════════════════════════════════════════
// CARD BODY STYLE
// ══════════════════════════════════════════════════════════════════════════
cardStyleBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    cardStyleBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.cardBodyStyle = this.dataset.style;
    var isCardType   = CARD_BODY_TYPES.indexOf(state.selectedBlock) !== -1;
    var isCornerType = CORNER_CARD_TYPES.indexOf(state.selectedBlock) !== -1;
    var isPipe = state.cardBodyStyle === 'pipe';
    $('cardLinesRow').style.display  = (isCornerType || (isCardType && !isPipe)) ? 'flex' : 'none';
    $('pipeCountRow').style.display  = (isCardType || isCornerType) && isPipe ? 'flex' : 'none';
  });
});

// ══════════════════════════════════════════════════════════════════════════
// CARD COUNT
// ══════════════════════════════════════════════════════════════════════════
cardCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    cardCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.cardCount = parseInt(this.dataset.count, 10);
    // If we're on a corner-card block, refresh the rows toggle visibility
    // (rows toggle only makes sense when card count > 1).
    try { _refreshCornerRowsRow(); } catch(e) {}
  });
});

// ── Corner cards: 1-row vs 2-row layout ────────────────────────────────────
var cornerRowsBtns = document.querySelectorAll('#cornerRowsBtns .style-btn');
cornerRowsBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    cornerRowsBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.cornerRows = parseInt(this.dataset.rows, 10);
    state._cornerRowsTouched = true; // user opted in — don't auto-flip on count change
  });
});
function _refreshCornerRowsRow() {
  var CORNER = (typeof CORNER_CARD_TYPES !== 'undefined') ? CORNER_CARD_TYPES : [];
  var isCorner = CORNER.indexOf(state.selectedBlock) !== -1;
  // Toggle the rows row visibility: only corner blocks AND count >= 2 (one card
  // doesn't need a row layout choice).
  var show = isCorner && (state.cardCount || 4) >= 2;
  var row  = document.getElementById('cornerRowsRow');
  if (row) row.style.display = show ? 'flex' : 'none';
  // If user hasn't manually toggled rows this session, follow the count:
  // ≥3 cards default to 2 rows (matches the pre-toggle behaviour), else 1 row.
  if (isCorner && !state._cornerRowsTouched) {
    state.cornerRows = (state.cardCount >= 3) ? 2 : 1;
  }
  cornerRowsBtns.forEach(function(b) {
    b.classList.toggle('active', parseInt(b.dataset.rows, 10) === (state.cornerRows || 1));
  });
}

// ── Move the block options panel into the active category's body so options
// appear inline with the catalog (not stranded at the bottom of the panel). ──
function _moveOptionsPanelToCategory(originBtn) {
  var panel = document.getElementById('blockOptionsPanel');
  if (!panel) return;
  var catBody = originBtn && originBtn.closest ? originBtn.closest('.cat-body') : null;
  if (catBody) {
    catBody.appendChild(panel);
    panel.classList.add('is-active');
  } else {
    panel.classList.remove('is-active');
  }
}

// ══════════════════════════════════════════════════════════════════════════
// TABLE COLUMNS / ROWS
// ══════════════════════════════════════════════════════════════════════════
tableColsBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    tableColsBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.tableNumCols = parseInt(this.dataset.count, 10);
  });
});
tableRowsBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    tableRowsBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.tableNumRows = parseInt(this.dataset.count, 10);
  });
});

// ══════════════════════════════════════════════════════════════════════════
// CARD LINES COUNT
// ══════════════════════════════════════════════════════════════════════════
cardLinesBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    cardLinesBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.cardLineCount = parseInt(this.dataset.count, 10);
  });
});

// ══════════════════════════════════════════════════════════════════════════
// PIPE COUNT
// ══════════════════════════════════════════════════════════════════════════
pipeCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    pipeCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.pipeCount = parseInt(this.dataset.count, 10);
  });
});

colCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    colCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.colCount = parseInt(this.dataset.count, 10);
  });
});

precompCards.addEventListener('change', function() {
  if (state.selectedBlock === 'text-acronym') {
    $('acronymCountRow').style.display = this.checked ? 'flex' : 'none';
  }
});

acronymCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    acronymCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.acronymCount = parseInt(this.dataset.count, 10);
  });
});

// ══════════════════════════════════════════════════════════════════════════
// STEPS ANIMATION CONTROLS
// ══════════════════════════════════════════════════════════════════════════
stepCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    stepCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.stepCount = parseInt(this.dataset.count, 10);
  });
});

stepsPerRowBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    stepsPerRowBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.stepsPerRow = parseInt(this.dataset.count, 10);
  });
});

compTimelineCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    compTimelineCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.compTimelineCount = parseInt(this.dataset.count, 10);
  });
});
logoCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    logoCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.logoCount = parseInt(this.dataset.count, 10);
  });
});
compareCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    compareCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.compareCount = parseInt(this.dataset.count, 10);
  });
});
compareThemeBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    compareThemeBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.compareTheme = this.dataset.theme;
  });
});
tagsCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    tagsCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.tagsCount = parseInt(this.dataset.count, 10);
  });
});
iconGridCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    iconGridCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.iconGridCount = parseInt(this.dataset.count, 10);
  });
});
deviceCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    deviceCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.deviceCount = parseInt(this.dataset.count, 10);
  });
});
calloutTypeBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    calloutTypeBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.calloutType = this.dataset.type;
    $('calloutStrokeRow').style.display = (state.calloutType !== 'dark') ? 'flex' : 'none';
  });
});
calloutStrokeBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    calloutStrokeBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.calloutStroke = this.dataset.stroke;
  });
});


// ══════════════════════════════════════════════════════════════════════════
// TIMELINE CONTROLS
// ══════════════════════════════════════════════════════════════════════════
timelineCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    timelineCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.timelineCount = parseInt(this.dataset.count, 10);
  });
});

timelineStyleBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    timelineStyleBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.timelineStyle = this.dataset.style;
  });
});

pointStyleBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    pointStyleBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.pointStyle = this.dataset.style;
  });
});


// ══════════════════════════════════════════════════════════════════════════
// BULLET COUNT
// ══════════════════════════════════════════════════════════════════════════
bulletCountBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    bulletCountBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.bulletCount = parseInt(this.dataset.count, 10);
  });
});
nestedMainBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    nestedMainBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.nestedMainCount = parseInt(this.dataset.count, 10);
  });
});
nestedSubBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    nestedSubBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.nestedSubCount = parseInt(this.dataset.count, 10);
  });
});

// ══════════════════════════════════════════════════════════════════════════
// GRAPH DATA (chart blocks)
// ══════════════════════════════════════════════════════════════════════════
$('graphCountBtns').addEventListener('click', function(e) {
  var btn = e.target.closest('.count-btn');
  if (!btn) return;
  var n = parseInt(btn.dataset.count, 10);
  state.chartCount = n;
  document.querySelectorAll('#graphCountBtns .count-btn').forEach(function(b) { b.classList.remove('active'); });
  btn.classList.add('active');
  var rows = document.querySelectorAll('.graph-row');
  rows.forEach(function(row, i) { row.style.display = (i < n) ? '' : 'none'; });
  updateDonutTotal();
});

// Donut / pie normalization
$('graphRows').addEventListener('input', function(e) {
  if (['chart-donut','chart-pie'].indexOf(state.selectedBlock) !== -1 && e.target.classList.contains('graph-val-input')) {
    updateDonutTotal();
  }
});

// Series count buttons
$('seriesCountBtns').addEventListener('click', function(e) {
  var btn = e.target.closest('.count-btn');
  if (!btn) return;
  var n = parseInt(btn.dataset.count, 10);
  state.seriesCount = n;
  document.querySelectorAll('#seriesCountBtns .count-btn').forEach(function(b) { b.classList.remove('active'); });
  btn.classList.add('active');
  document.querySelectorAll('.series-row').forEach(function(row, i) {
    row.style.display = (i < n) ? '' : 'none';
  });
});

// Point count buttons
$('pointCountBtns').addEventListener('click', function(e) {
  var btn = e.target.closest('.count-btn');
  if (!btn) return;
  var n = parseInt(btn.dataset.count, 10);
  state.pointCount = n;
  document.querySelectorAll('#pointCountBtns .count-btn').forEach(function(b) { b.classList.remove('active'); });
  btn.classList.add('active');
  document.querySelectorAll('.point-row').forEach(function(row, i) {
    row.style.display = (i < n) ? '' : 'none';
  });
});

function updateDonutTotal() {
  if (['chart-donut','chart-pie','chart-progress'].indexOf(state.selectedBlock) === -1) return;
  var rows = document.querySelectorAll('.graph-row');
  var total = 0;
  rows.forEach(function(row, i) {
    if (i < state.chartCount) {
      total += parseFloat(row.querySelector('.graph-val-input').value) || 0;
    }
  });
  var totalEl = $('graphTotal');
  totalEl.textContent = 'Total: ' + Math.round(total) + '%';
  totalEl.className = 'graph-total' + (Math.abs(total - 100) > 1 ? ' warn' : '');
}

function getGraphData() {
  var data = [];
  var rows = document.querySelectorAll('.graph-row');
  rows.forEach(function(row, i) {
    if (i >= state.chartCount) return;
    var label = row.querySelector('.graph-label-input').value;
    var val   = parseFloat(row.querySelector('.graph-val-input').value) || 0;
    var item  = { label: label, value: val };
    var ovfEl = row.querySelector('.graph-ovf-input');
    if (ovfEl && ovfEl.style.display !== 'none') {
      item.overflow = parseFloat(ovfEl.value) || 0;
    }
    data.push(item);
  });
  return data;
}

// ══════════════════════════════════════════════════════════════════════════
// KEYBOARD SHORTCUTS (Blocks tab)
// ══════════════════════════════════════════════════════════════════════════
document.addEventListener('keydown', function(e) {
  if (settingsPanel.style.display !== 'none') { if (e.key === 'Escape') settingsPanel.style.display = 'none'; return; }
  if (helpPanel.style.display !== 'none') { if (e.key === 'Escape') helpPanel.style.display = 'none'; return; }
  if (tabBlocks.style.display === 'none') return;
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  if (e.key === 'Enter' && state.selectedBlock) doInsert();
});

// ══════════════════════════════════════════════════════════════════════════
// INSERT TARGET (New Comp vs Current Comp) + ELEMENT INCLUDE FILTERS
// ══════════════════════════════════════════════════════════════════════════
var targetBtns       = document.querySelectorAll('#targetBtns .style-btn');
var includeRow       = $('includeRow');
var incBody          = $('incBody');
var incTitle         = $('incTitle');
var incSubtitle      = $('incSubtitle');
var incBackground    = $('incBackground');

targetBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    targetBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.insertTarget = this.dataset.target;
    _updateInsertUi();
  });
});

// Title alignment toggle (corner blocks only)
var titleAlignBtns = document.querySelectorAll('#titleAlignBtns .style-btn');
titleAlignBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    titleAlignBtns.forEach(function(b) { b.classList.remove('active'); });
    this.classList.add('active');
    state.titleAlign = this.dataset.align;
  });
});

function _updateInsertUi() {
  var isActive = state.insertTarget === 'active';
  insertBtn.textContent = isActive ? 'INSERT INTO CURRENT COMP' : 'INSERT BLOCK';
  insertBtn.setAttribute('data-tip', isActive
    ? 'Build the block and drop the body elements as layers into your currently open comp'
    : 'Build the block in a new composition');
  // Current-comp inserts always bring only the body layers — title / subtitle
  // / background stay behind (title lives at the slide level, not per element).
  // The INCLUDE row is hidden permanently; state is pinned to body-only.
  if (includeRow) includeRow.style.display = 'none';
  if (isActive) {
    state.includeBody       = true;
    state.includeTitle      = false;
    state.includeSubtitle   = false;
    state.includeBackground = false;
    if (incBody)       incBody.checked       = true;
    if (incTitle)      incTitle.checked      = false;
    if (incSubtitle)   incSubtitle.checked   = false;
    if (incBackground) incBackground.checked = false;
  }
}

// Repaint state from current checkbox values + update chip "checked" highlight.
function _onIncChange() {
  state.includeBody       = incBody.checked;
  state.includeTitle      = incTitle.checked;
  state.includeSubtitle   = incSubtitle.checked;
  state.includeBackground = incBackground.checked;
  [incBody, incTitle, incSubtitle, incBackground].forEach(function(cb) {
    var chip = cb.parentElement;
    chip.classList.toggle('checked', cb.checked);
  });
  _updateInsertUi();
}

// Handle clicks on each chip directly — don't rely on the implicit label→input
// click chain (some CEP webview versions don't fire `change` reliably when the
// underlying input is visually hidden, which makes the chip never re-paint).
[incBody, incTitle, incSubtitle, incBackground].forEach(function(cb) {
  var chip = cb.parentElement;
  chip.addEventListener('click', function(e) {
    // Prevent the default label behavior (which would fire a click on the
    // input AGAIN and double-toggle), then toggle the state ourselves.
    e.preventDefault();
    cb.checked = !cb.checked;
    _onIncChange();
  });
});

// Paint initial chip states
_onIncChange();

// ══════════════════════════════════════════════════════════════════════════
// INSERT BLOCK
// ══════════════════════════════════════════════════════════════════════════
insertBtn.addEventListener('click', doInsert);

// Combine queue: + Combine button (snapshot current block + push to queue)
var combineAddBtn = document.getElementById('combineAddBtn');
if (combineAddBtn) {
  combineAddBtn.addEventListener('click', function() {
    _addCurrentBlockToCombineQueue();
  });
}
// Clear queue
var combineClearBtn = document.getElementById('combineClear');
if (combineClearBtn) {
  combineClearBtn.addEventListener('click', _clearCombineQueue);
}

function doInsert() {
  // ── Combined insert path: queue has ≥ 2 entries + a layout has been picked.
  //    Bundle the queued block params as slots and dispatch as multi-*.
  if (state.combineQueue.length >= 2 && state.combineLayoutPicked) {
    var combinedBlockType = 'multi-' + state.combineLayoutPicked;
    // Build the master params using the CURRENT global state (header text,
    // accent color, animation flags). Each slot brings its own params
    // captured at queue time.
    var masterParams = buildParams(state.selectedBlock || combinedBlockType);
    masterParams.blockType   = combinedBlockType;
    masterParams.multiLayout = state.combineLayoutPicked;
    masterParams.slots       = state.combineQueue.map(function(entry) {
      // Each slot must carry its own blockType — buildParams snapshots already
      // include it. Strip the outer header/target fields since the master
      // comp owns those.
      var sp = {};
      for (var k in entry.params) { sp[k] = entry.params[k]; }
      sp.blockType = entry.blockType;
      delete sp.insertTarget;
      delete sp.includeElements;
      return sp;
    });
    setStatus('Inserting combined block (' + state.combineQueue.length + ' slots)...', '');
    cs.evalScript('createBlock(' + JSON.stringify(masterParams) + ')', function(result) {
      if (!result || result.indexOf('error') === 0) {
        setStatus(result || 'Unknown error', 'err');
      } else {
        setStatus('Inserted combined: ' + state.combineLayoutPicked, 'ok');
        _clearCombineQueue();
      }
    });
    return;
  }

  // Legacy slot-picker overlay path (kept for safety while we phase it out).
  if (state._slotPickerOpen) {
    try { _snapshotToSlotConfig(_activeSlot); } catch(e) {}
    if (state._comboLayoutBlock) state.selectedBlock = state._comboLayoutBlock;
    state._slotPickerOpen = false;
    try { slotOverlay.style.display = 'none'; } catch(e) {}
    try { $('blocks-scroll').style.display = ''; } catch(e) {}
  }
  if (state.selectedMyBlock) {
    insertMyBlock(state.selectedMyBlock);
    return;
  }
  if (!state.selectedBlock) return;
  var params = buildParams(state.selectedBlock);
  setStatus('Inserting...', '');
  cs.evalScript('createBlock(' + JSON.stringify(params) + ')', function(result) {
    if (!result || result.indexOf('error') === 0) {
      setStatus(result || 'Unknown error', 'err');
    } else {
      // Surface the active-comp routing so users know whether the drop landed.
      var msg = 'Inserted: ' + (state.selectedBlock || '');
      if (result.indexOf('|noActive') !== -1) {
        msg = 'No active comp — inserted as new comp instead';
      } else if (result.indexOf('|empty') !== -1) {
        msg = 'Nothing selected to include — pick at least one element';
      } else if (result.indexOf('|active:') !== -1) {
        // Match: |active:<compName>[:splitN][:stripN]
        var m = result.match(/\|active:([^:|]+)(?::split(\d+))?(?::strip(\d+))?/);
        msg = 'Added to ' + (m ? m[1] : 'active comp');
        var bits = [];
        if (m && m[2]) bits.push(m[2] + ' pre-comp' + (m[2] === '1' ? '' : 's'));
        if (m && m[3]) bits.push(m[3] + ' layer' + (m[3] === '1' ? '' : 's') + ' filtered');
        if (bits.length) msg += ' (' + bits.join(', ') + ')';
      } else if (result.indexOf('|activeErr:') !== -1) {
        msg = 'Active comp insert failed — opened new comp instead';
      }
      setStatus(msg, 'ok');
    }
  });
}

function buildParams(blockType) {
  // Override card count when user has changed the picker
  if (/^cards-[1-5]$/.test(blockType)) {
    blockType = 'cards-' + state.cardCount;
  }
  var p = {
    blockType:    blockType,
    // Both optional — empty = skip header text layer (see ebCreateHeader).
    title:        titleInput.value.trim(),
    subtitle:     subtitleInput.value.trim(),
    accentColor:  state.accentColor,
    animateIn:    animateIn.checked,
    posAnim:      posAnim.checked,
    shapeFill:    false,
    cardBg:       cardBg.checked,
    cardBorder:   cardBorder.checked,
    dropShadow:   dropShadow.checked,
    bodyStyle:     state.cardBodyStyle,
    calloutStyle:       state.calloutType === 'dark' ? 'dark' : state.calloutType + '-' + state.calloutStroke,
    precomp:            precompCards.checked,
    titleAlign:         state.titleAlign,
    cornerRows:         state.cornerRows,
    numCols:            state.tableNumCols,
    numRows:            state.tableNumRows,
    tableStyle:         (state.selectedBlock === 'table-minimal' ? 'minimal'
                       : state.selectedBlock === 'table-outlined' ? 'outlined'
                       : state.selectedBlock === 'table-bar'      ? 'bar'
                       : undefined),
    insertTarget:       state.insertTarget,
    includeElements:    {
      body:       state.includeBody,
      title:      state.includeTitle,
      subtitle:   state.includeSubtitle,
      background: state.includeBackground
    }
  };
  if (FLAT_BULLET_TYPES.indexOf(blockType) !== -1) {
    var _flatDefs = [
      'First key point \u2014 a strong, memorable statement',
      'Second point that supports the core message clearly',
      'Third bullet with specific data or evidence here',
      'Fourth point adding depth or supporting context',
      'Fifth item with concrete example or measurement',
      'Final takeaway that drives the audience to action'
    ];
    p.bullets = _flatDefs.slice(0, state.bulletCount);
  }
  if (blockType === NESTED_BULLET_TYPE) {
    var _nestedMainDefs = [
      'First primary point with key message here',
      'Second main point carries equal visual weight',
      'Third key point that drives the message home'
    ];
    var _nestedSubDefs = [
      ['Supporting detail that expands on the main point',
       'Additional context or evidence to reinforce it',
       'Third clarifying detail for completeness'],
      ['Sub-bullet with specific data or example here',
       'Further clarification to help the audience',
       'Third point adding supporting context'],
      ['Supporting sub-bullet with actionable insight',
       'Final detail that closes the argument clearly',
       'Additional evidence to strengthen the point']
    ];
    p.bullets = [];
    for (var _ni = 0; _ni < state.nestedMainCount; _ni++) {
      p.bullets.push({
        main: _nestedMainDefs[_ni] || ('Point ' + (_ni + 1)),
        subs: _nestedSubDefs[_ni % _nestedSubDefs.length].slice(0, state.nestedSubCount)
      });
    }
  }
  if (CORNER_CARD_TYPES.indexOf(blockType) !== -1) {
    p.cardCount = state.cardCount;
    var _crnrLineDefs = [
      'First line of content here',
      'Second supporting point',
      'Third key item or detail',
      'Fourth point with context'
    ];
    var _crnrBody = _crnrLineDefs.slice(0, state.cardLineCount).join('\r');
    p.cards = [];
    for (var _cci = 0; _cci < state.cardCount; _cci++) {
      p.cards.push({ label: 'Title ' + (_cci + 1), body: _crnrBody });
    }
  }
  if (CARD_BODY_TYPES.indexOf(blockType) !== -1) {
    var _textLineDefs = [
      'First line of content here',
      'Second supporting point or detail',
      'Third key item with context',
      'Fourth point adding depth',
      'Fifth item with specifics'
    ];
    var _bulLineDefs = [
      'First key point here',
      'Second supporting point',
      'Third item with detail',
      'Fourth point with context',
      'Fifth item here'
    ];
    var _pipeDefs = [
      'First item here',
      'Second item here',
      'Third item here',
      'Fourth item here',
      'Fifth item here'
    ];
    var _lineDefs = state.cardBodyStyle === 'bullets' ? _bulLineDefs : (state.cardBodyStyle === 'pipe' ? _pipeDefs : _textLineDefs);
    var _lineCount = state.cardBodyStyle === 'pipe' ? state.pipeCount : state.cardLineCount;
    var _body = _lineDefs.slice(0, _lineCount).join('\r');
    var _cardN = blockType === 'cards-compare' ? 2 :
                 (blockType === 'cards-media' || blockType === 'diagram-flow') ? state.cardCount :
                 (blockType === 'cards-top-bar' || blockType === 'cards-bottom-bar') ? 3 :
                 (parseInt(blockType.replace('cards-', ''), 10) || 1);
    p.cards = [];
    for (var _ci = 0; _ci < _cardN; _ci++) {
      p.cards.push({ label: 'Card ' + (_ci + 1), body: _body });
    }
  }
  if (COMPARE_TYPES.indexOf(blockType) !== -1) {
    p.leftColor  = state.leftColor;
    p.rightColor = state.rightColor;
  }
  if (SIMPLE_CHART_TYPES.indexOf(blockType) !== -1) {
    var _gd = getGraphData();
    if (blockType === 'chart-bar-stacked') {
      p.items = _gd.map(function(d) { return {label:d.label, base:d.value, overflow:d.overflow||0}; });
      p.stackedYMax = parseFloat($('stackedYMax').value) || 100;
    } else if (blockType === 'chart-waterfall') {
      p.chartData = _gd.map(function(d) { return {label:d.label, value:d.value}; });
    } else {
      // chart-bar, chart-bar-v, chart-donut, chart-pie, chart-progress
      p.chartData = _gd.map(function(d) { return {label:d.label, pct:d.value}; });
    }
  }
  if (SERIES_CHART_TYPES.indexOf(blockType) !== -1) {
    var _xRaw = $('xLabelsInput').value;
    var _xArr = _xRaw.split(',').map(function(s){return s.trim();}).filter(Boolean);
    p.xLabels = _xArr;
    p.axes    = _xArr;
    var _serData = [];
    document.querySelectorAll('.series-row').forEach(function(row, i) {
      if (i >= state.seriesCount) return;
      var _lbl = row.querySelector('.series-label-input').value.trim() || ('Series '+(i+1));
      var _vRaw = row.querySelector('.series-vals-input').value;
      var _vals = _vRaw.split(',').map(function(s){return parseFloat(s.trim())||0;});
      _serData.push({label:_lbl, values:_vals});
    });
    p.series = _serData;
  }
  if (POINT_CHART_TYPES.indexOf(blockType) !== -1) {
    p.xLabel = $('pointXLabel').value.trim();
    p.yLabel = $('pointYLabel').value.trim();
    var _isBubble = blockType === 'chart-bubble';
    var _ptData = [];
    document.querySelectorAll('.point-row').forEach(function(row, i) {
      if (i >= state.pointCount) return;
      var _lbl2 = row.querySelector('.point-label-input').value.trim();
      var _px = parseFloat(row.querySelector('.point-x-input').value) || 0;
      var _py = parseFloat(row.querySelector('.point-y-input').value) || 0;
      if (_isBubble) {
        var _ps = parseFloat(row.querySelector('.point-s-input').value) || 50;
        _ptData.push({label:_lbl2, x:_px, y:_py, size:_ps});
      } else {
        _ptData.push({label:_lbl2, x:_px, y:_py});
      }
    });
    if (_isBubble) {
      p.chartData = _ptData;
    } else {
      p.series = [{label:'Data', data:_ptData}];
    }
  }
  p.colCount      = state.colCount;
  p.acronymCount  = state.acronymCount;
  if (blockType === 'diagram-flow') p.cardCount = state.cardCount;
  p.cardCount     = p.cardCount !== undefined ? p.cardCount : state.cardCount;
  if (blockType === 'comp-timeline')   { p.count = state.compTimelineCount; }
  if (blockType === 'comp-logo-strip') { p.count = state.logoCount; }
  if (blockType === 'comp-compare')    { p.count = state.compareCount; p.compareTheme = state.compareTheme; }
  if (blockType === 'comp-tags')       { p.count = state.tagsCount; }
  if (blockType === 'comp-icon-grid')  { p.count = state.iconGridCount; }
  if (blockType === 'cards-device')    { p.count = state.deviceCount; }
  if (blockType === 'diagram-timeline') {
    p.timelineCount = state.timelineCount;
    p.timelineStyle = state.timelineStyle;
    p.pointStyle    = state.pointStyle;
  }
  if (blockType === 'diagram-steps') {
    p.stepCount   = state.stepCount;
    p.stepsPerRow = state.stepsPerRow;
  }
  if (blockType.indexOf('multi-') === 0) {
    p.multiLayout = blockType.replace('multi-', '');
    var nSlots = LAYOUT_SLOT_COUNT[blockType] || 2;
    p.slots = [];
    var slotBlocks = [state.slotBlock1, state.slotBlock2, state.slotBlock3, state.slotBlock4];
    for (var _si = 0; _si < nSlots; _si++) {
      p.slots.push(_buildSlotParams(slotBlocks[_si], _si));
    }
  }
  return p;
}

// Build a slot's full param set. Prefers each slot's own saved config (from
// `state.slotConfigs[idx]` — captured as the user configures inside the slot
// picker overlay). Falls back to current global state for any field the slot
// didn't customise (e.g., when slotConfigs hasn't been built yet).
function _buildSlotParams(slotBt, slotIdx) {
  var sp = { blockType: slotBt };
  if (!slotBt) return sp;
  var cfg = (slotIdx !== undefined && state.slotConfigs[slotIdx]) || null;
  function pick(key, fallback) {
    if (cfg && cfg[key] !== undefined && cfg[key] !== null) return cfg[key];
    return (fallback !== undefined) ? fallback : state[key];
  }
  // Count + style options
  sp.cardCount    = pick('cardCount');
  sp.cornerRows   = pick('cornerRows');
  sp.bulletCount  = pick('bulletCount');
  sp.bodyStyle    = pick('cardBodyStyle');
  sp.titleAlign   = pick('titleAlign');
  // Table dimensions + style (style derived from blockType so the slot's
  // chosen table variant always wins, even if config was missed).
  sp.numCols      = pick('tableNumCols');
  sp.numRows      = pick('tableNumRows');
  if (slotBt === 'table-bar')           sp.tableStyle = 'bar';
  else if (slotBt === 'table-minimal')  sp.tableStyle = 'minimal';
  else if (slotBt === 'table-outlined') sp.tableStyle = 'outlined';
  // Diagram dimensions
  sp.stepCount        = pick('stepCount');
  sp.stepsPerRow      = pick('stepsPerRow');
  sp.timelineCount    = pick('timelineCount');
  sp.timelineStyle    = pick('timelineStyle');
  sp.pointStyle       = pick('pointStyle');
  // Component dimensions
  sp.iconGridCount    = pick('iconGridCount');
  sp.tagsCount        = pick('tagsCount');
  sp.logoCount        = pick('logoCount');
  sp.compTimelineCount= pick('compTimelineCount');
  // Compare / callout
  sp.compareCount     = pick('compareCount');
  sp.compareTheme     = pick('compareTheme');
  sp.calloutType      = pick('calloutType');
  sp.calloutStroke    = pick('calloutStroke');
  // Nested + acronym
  sp.nestedMain       = pick('nestedMain');
  sp.nestedSub        = pick('nestedSub');
  sp.acronymCount     = pick('acronymCount');
  // Chip toggles
  if (cfg) {
    if (cfg.cardBorder   !== undefined) sp.cardBorder  = cfg.cardBorder;
    if (cfg.cardBg       !== undefined) sp.cardBg      = cfg.cardBg;
    if (cfg.dropShadow   !== undefined) sp.dropShadow  = cfg.dropShadow;
    if (cfg.animateIn    !== undefined) sp.animateIn   = cfg.animateIn;
    if (cfg.posAnim      !== undefined) sp.posAnim     = cfg.posAnim;
    if (cfg.precompCards !== undefined) sp.precomp     = cfg.precompCards;
  }
  return sp;
}

function setStatus(msg, cls) {
  statusEl.textContent = msg;
  statusEl.className = 'status' + (cls ? ' ' + cls : '');
}

// ══════════════════════════════════════════════════════════════════════════
// AI GENERATE TAB
// ══════════════════════════════════════════════════════════════════════════

// Extract the first frame of a GIF or video to a temp PNG.
// Calls callback(tmpPngPath) on success, callback(null) on failure.
function extractFrame(filePath, callback) {
  var tmpPath = path.join(os.tmpdir(), 'ebp_frame_' + Date.now() + '.png');

  function saveCanvasToPng(canvas, cb) {
    canvas.toBlob(function(blob) {
      if (!blob) { cb(null); return; }
      var reader = new FileReader();
      reader.onload = function(e) {
        try {
          var b64 = e.target.result.split(',')[1] || '';
          fs.writeFileSync(tmpPath, b64, 'base64');
          cb(tmpPath);
        } catch(err) { cb(null); }
      };
      reader.onerror = function() { cb(null); };
      reader.readAsDataURL(blob);
    }, 'image/png');
  }

  var isVideo = /\.(mp4|mov|avi|webm)$/i.test(filePath);
  if (isVideo) {
    var vid = document.createElement('video');
    vid.crossOrigin = 'anonymous';
    vid.addEventListener('seeked', function() {
      var canvas = document.createElement('canvas');
      canvas.width  = vid.videoWidth  || 1280;
      canvas.height = vid.videoHeight || 720;
      canvas.getContext('2d').drawImage(vid, 0, 0, canvas.width, canvas.height);
      saveCanvasToPng(canvas, callback);
    });
    vid.addEventListener('error', function() { callback(null); });
    vid.src = 'file://' + filePath;
    vid.load();
  } else {
    // GIF or other image: render first frame via <img>
    var img = document.createElement('img');
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width  = img.naturalWidth;
      canvas.height = img.naturalHeight;
      canvas.getContext('2d').drawImage(img, 0, 0);
      saveCanvasToPng(canvas, callback);
    };
    img.onerror = function() { callback(null); };
    img.src = 'file://' + filePath;
  }
}

// --- Drop zone ---
// aiDropzone is a <label for="aiFileInput"> — clicking it natively opens the file picker.
// Block the label action when a file is already loaded or when clicking the × button.
aiDropzone.addEventListener('click', function(e) {
  if (e.target === aiClearBtn || e.target.closest && e.target.closest('#aiClearBtn')) {
    e.preventDefault();
    return;
  }
  if (state.aiImagePath) {
    e.preventDefault();
  }
});
aiDropzone.addEventListener('dragover', function(e) {
  e.preventDefault();
  this.classList.add('drag-over');
});
aiDropzone.addEventListener('dragleave', function() { this.classList.remove('drag-over'); });
aiDropzone.addEventListener('drop', function(e) {
  e.preventDefault();
  this.classList.remove('drag-over');
  var file = e.dataTransfer.files[0];
  if (file) handleAiFile(file.path || file.name, file);
});
aiFileInput.addEventListener('change', function() {
  if (this.files[0]) handleAiFile(null, this.files[0]);
});
aiClearBtn.addEventListener('click', function(e) {
  e.stopPropagation();
  e.preventDefault(); // prevent <label> from opening file picker when clicking ×
  clearAiImage();
});

// ── Import progress helpers ───────────────────────────────────────────────

function showImportProgress(frac, msg) {
  aiImportProgress.style.display = 'flex';
  aiImportBar.style.width = Math.round((frac || 0) * 100) + '%';
  if (msg) aiImportMsg.textContent = msg;
}

function hideImportProgress() {
  aiImportProgress.style.display = 'none';
  aiImportBar.style.width = '0%';
}

// ── PPTX / PDF → slide PNGs ───────────────────────────────────────────────

// Detect the python binary available on this machine (python3 → python → py)
var _pythonBin = (function() {
  var candidates = ['/usr/bin/python3', '/usr/local/bin/python3', '/opt/homebrew/bin/python3'];
  for (var i = 0; i < candidates.length; i++) {
    try { if (fs.existsSync(candidates[i])) return candidates[i]; } catch(e) {}
  }
  return process.platform === 'win32' ? 'python' : 'python3';
}());

function _runPdfConvert(pyBin, pyScript, pdfPath, tmpDir, cb) {
  var stderr = '';
  var pyProc = spawnFn(pyBin, ['-c', pyScript, pdfPath, tmpDir],
    { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) });
  pyProc.stderr.on('data', function(d) { stderr += d.toString(); });
  pyProc.on('error', function(e) { cb(new Error(pyBin + ' not found: ' + e.message)); });
  pyProc.on('close', function(code) {
    if (code !== 0) { cb(new Error(stderr.trim()), true); return; }
    try {
      var pngs = fs.readdirSync(tmpDir)
        .filter(function(f) { return /^slide-\d+\.png$/.test(f); })
        .sort(function(a, b) { return parseInt(a.match(/\d+/)[0], 10) - parseInt(b.match(/\d+/)[0], 10); })
        .map(function(f) { return path.join(tmpDir, f); });
      if (pngs.length === 0) { cb(new Error('No pages extracted from PDF')); return; }
      cb(null, false, pngs);
    } catch(e) { cb(e); }
  });
}

function pdfToPngs(pdfPath, tmpDir, cb) {
  var pyScript = [
    'import sys, os, fitz',
    'doc = fitz.open(sys.argv[1])',
    'outDir = sys.argv[2]',
    'for i, page in enumerate(doc):',
    '    mat = fitz.Matrix(2, 2)',
    '    pix = page.get_pixmap(matrix=mat, alpha=False)',
    '    pix.save(os.path.join(outDir, "slide-%d.png" % (i + 1)))'
  ].join('\n');

  var pyBin = _pythonBin;

  _runPdfConvert(pyBin, pyScript, pdfPath, tmpDir, function(err, isFitzMissing, pngs) {
    if (!err) { cb(null, pngs); return; }

    // Auto-install PyMuPDF if fitz is missing, then retry once
    var isMissing = isFitzMissing && /No module named.*fitz|ModuleNotFoundError/i.test(err.message);
    if (!isMissing) { cb(err); return; }

    appendLog('PyMuPDF not found — installing automatically…', '');
    var installProc = spawnFn(pyBin, ['-m', 'pip', 'install', 'pymupdf', '--quiet'],
      { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) });
    var installErr = '';
    installProc.stderr.on('data', function(d) { installErr += d.toString(); });
    installProc.on('error', function(e) {
      cb(new Error('Auto-install failed: ' + e.message + '. Run: ' + pyBin + ' -m pip install pymupdf'));
    });
    installProc.on('close', function(code) {
      if (code !== 0) {
        cb(new Error('Auto-install failed. Run manually: ' + pyBin + ' -m pip install pymupdf\n' + installErr.trim()));
        return;
      }
      appendLog('PyMuPDF installed — retrying PDF import…', '');
      _runPdfConvert(pyBin, pyScript, pdfPath, tmpDir, function(err2, _, pngs2) {
        if (err2) { cb(err2); return; }
        cb(null, pngs2);
      });
    });
  });
}

function convertPptxToSlides(pptxPath, cb) {
  var tmpDir = path.join(os.tmpdir(), 'ebp_slides_' + Date.now());
  try { fs.mkdirSync(tmpDir, { recursive: true }); } catch(e) {}
  var env = Object.assign({}, process.env, { PATH: CHILD_PATH });
  var liArgs = [
    '-env:UserInstallation=' + _libreUserInstallUrl(tmpDir),
    '--headless', '--norestore', '--nologo', '--nofirststartwizard',
    '--convert-to', 'pdf', '--outdir', tmpDir, pptxPath
  ];
  var libreProc = spawnFn(SOFFICE, liArgs, { env: env });
  libreProc.on('error', function(e) {
    cb(new Error('LibreOffice not found. Install from libreoffice.org (' + e.message + ')'));
  });
  libreProc.on('close', function(code) {
    if (code !== 0) {
      var hint = (code === -4058 || code === 4058)
        ? ' — close any open LibreOffice window and retry'
        : '';
      cb(new Error('LibreOffice failed (exit ' + code + ')' + hint));
      return;
    }
    var baseName = path.basename(pptxPath, path.extname(pptxPath));
    var pdfPath  = path.join(tmpDir, baseName + '.pdf');
    if (!fs.existsSync(pdfPath)) { cb(new Error('PDF not found after LibreOffice')); return; }
    pdfToPngs(pdfPath, tmpDir, cb);
  });
}

function convertPdfToSlides(pdfPath, cb) {
  var tmpDir = path.join(os.tmpdir(), 'ebp_slides_' + Date.now());
  try { fs.mkdirSync(tmpDir, { recursive: true }); } catch(e) {}
  pdfToPngs(pdfPath, tmpDir, cb);
}

function extractPptxNotes(pptxPath, cb) {
  var pyScript = [
    'import sys, zipfile, json, re',
    'import xml.etree.ElementTree as ET',
    'pptx = sys.argv[1]',
    'A = "http://schemas.openxmlformats.org/drawingml/2006/main"',
    'P = "http://schemas.openxmlformats.org/presentationml/2006/main"',
    '# Placeholder strings that should be ignored (empty notes)',
    'PLACEHOLDERS = {"click to add notes", "click to edit master title style"}',
    '',
    'def extract_notes_text(tree):',
    '    texts = []',
    '    for sp in tree.findall(".//{%s}sp" % P):',
    '        ph = sp.find(".//{%s}ph" % P)',
    '        if ph is None: continue',
    '        idx = ph.get("idx", "0")',
    '        tp  = ph.get("type", "")',
    '        if idx == "1" or tp == "body":',
    '            for t in sp.iter("{%s}t" % A):',
    '                if t.text and t.text.strip(): texts.append(t.text.strip())',
    '    joined = " ".join(texts).strip()',
    '    return joined if joined.lower() not in PLACEHOLDERS else ""',
    '',
    'result = {}',
    'try:',
    '    with zipfile.ZipFile(pptx) as z:',
    '        names = z.namelist()',
    '        slides = sorted([n for n in names if re.match(r"ppt/slides/slide\\d+\\.xml$", n)],',
    '                        key=lambda x: int(re.search(r"\\d+", x).group()))',
    '        for i, sf in enumerate(slides, 1):',
    '            sn = sf.split("/")[-1]',
    '            nt = None',
    '            # Primary: look up via relationship file',
    '            rp = "ppt/slides/_rels/" + sn + ".rels"',
    '            if rp in names:',
    '                for r in ET.fromstring(z.read(rp)):',
    '                    tg = r.get("Target", "")',
    '                    if "notesSlide" in tg:',
    '                        candidate = "ppt/" + tg.replace("../", "").lstrip("/")',
    '                        if candidate in names: nt = candidate',
    '                        break',
    '            # Fallback: try direct path ppt/notesSlides/notesSlide{i}.xml',
    '            if not nt:',
    '                direct = "ppt/notesSlides/notesSlide%d.xml" % i',
    '                if direct in names: nt = direct',
    '            if not nt: continue',
    '            txt = extract_notes_text(ET.fromstring(z.read(nt)))',
    '            if txt: result[str(i)] = txt',
    'except Exception as e:',
    '    pass',
    'print(json.dumps(result))'
  ].join('\n');
  var out = '';
  var proc = spawnFn('python3', ['-c', pyScript, pptxPath],
    { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) });
  proc.stdout.on('data', function(d) { out += d.toString(); });
  proc.on('close', function() {
    try { cb(JSON.parse(out.trim())); } catch(e) { cb({}); }
  });
  proc.on('error', function() { cb({}); });
}

function renderSlideGrid(slidePaths, notes) {
  state.aiDeckSlides = slidePaths;
  aiSlideGrid.innerHTML = '';
  slidePaths.forEach(function(slidePath, idx) {
    var slideNum = idx + 1;
    var slideNotes = (notes && notes[String(slideNum)]) || '';

    var thumb = document.createElement('div');
    thumb.className = 'slide-thumb';
    thumb.dataset.path = slidePath;

    var img = document.createElement('img');
    img.src = 'file://' + slidePath;
    thumb.appendChild(img);

    var num = document.createElement('div');
    num.className = 'slide-thumb-num';
    num.textContent = slideNum;
    thumb.appendChild(num);

    if (slideNotes) {
      var dot = document.createElement('div');
      dot.className = 'slide-thumb-notes-dot';
      dot.title = 'Has VO notes';
      thumb.appendChild(dot);
    }

    thumb.addEventListener('click', function() {
      var prev = aiSlideGrid.querySelector('.slide-thumb.active');
      if (prev) prev.classList.remove('active');
      thumb.classList.add('active');
      state.aiImagePath = slidePath;
      state.aiFramePath = null;
      // Show selected slide in the dropzone preview
      aiPreviewImg.src = 'file://' + slidePath;
      aiPreviewImg.style.display = 'block';
      aiFilePlaceholder.style.display = 'none';
      // Auto-populate VO textarea with notes
      if (slideNotes) {
        voScript.value = slideNotes;
        voAutoTag.style.display = '';
      } else {
        voAutoTag.style.display = 'none';
      }
      updateGenerateBtn();
      setAiStatus('Slide ' + slideNum + ' selected.' + (slideNotes ? ' VO notes loaded.' : ''), 'info');
    });
    aiSlideGrid.appendChild(thumb);
  });
  aiSlideGridWrap.style.display = 'block';
}

// ── File handling ─────────────────────────────────────────────────────────

function handleAiFile(filePath, file) {
  var fileName     = filePath ? path.basename(filePath) : (file ? file.name : '');
  var resolvedPath = filePath || (file && file.path) || null;
  var isDeck       = /\.(pptx?|pdf)$/i.test(fileName);
  var isMedia      = /\.(gif|mp4|mov|avi|webm)$/i.test(fileName);
  var isImg        = /\.(png|jpe?g|webp|bmp|svg)$/i.test(fileName);

  // For PPTX/PDF: convert → slide grid (works from both drag-drop and file picker)
  if (isDeck) {
    var deckPath = resolvedPath;
    if (!deckPath && file) {
      // Write to temp so LibreOffice / PyMuPDF can read it
      var ext2 = (fileName.match(/\.(\w+)$/) || ['', 'pptx'])[1].toLowerCase();
      deckPath = path.join(os.tmpdir(), 'ebp_deck_' + Date.now() + '.' + ext2);
      try {
        var buf = fs.readFileSync ? null : null; // no-op placeholder
        // Use FileReader to get bytes, write to disk
        var fr = new FileReader();
        fr.onload = function(ev) {
          var b64 = ev.target.result.split(',')[1] || '';
          try { fs.writeFileSync(deckPath, b64, 'base64'); } catch(e) {}
          loadDeck(deckPath, fileName);
        };
        fr.onerror = function() { setAiStatus('Could not read file.', 'err'); };
        fr.readAsDataURL(file);
        return;
      } catch(e) {}
    }
    if (deckPath) loadDeck(deckPath, fileName);
    return;
  }

  // For images / GIF / video: show single preview
  state.aiDeckSlides = [];
  aiSlideGridWrap.style.display = 'none';
  state.aiImagePath = null;
  state.aiFramePath = null;

  if (resolvedPath) {
    // Drag-drop with real path
    state.aiImagePath = resolvedPath;
    if (isMedia) {
      showAiPreview(resolvedPath);
      showImportProgress(0, 'Extracting frame…');
      extractFrame(resolvedPath, function(framePath) {
        state.aiFramePath = framePath;
        hideImportProgress();
        updateGenerateBtn();
      });
    } else {
      showAiPreview(resolvedPath);
    }
  } else if (file) {
    // File-picker without path: read via FileReader
    var reader = new FileReader();
    reader.onload = function(ev) {
      var dataUrl = ev.target.result;
      if (isImg || isMedia) {
        aiPreviewImg.src = dataUrl;
        aiPreviewImg.style.display = 'block';
        aiFilePlaceholder.style.display = 'none';
      } else {
        aiPreviewImg.src = '';
        aiPreviewImg.style.display = 'none';
        aiFileNameLabel.textContent = fileName;
        aiFilePlaceholder.style.display = 'flex';
      }
      aiDropzone.classList.add('has-file');
      aiClearBtn.style.display = 'flex';
      var lbl = aiDropzone.querySelector('.drop-label');
      var sub = aiDropzone.querySelector('.drop-sub');
      var ico = aiDropzone.querySelector('.drop-icon');
      if (lbl) lbl.style.display = 'none';
      if (sub) sub.style.display = 'none';
      if (ico) ico.style.display = 'none';
      if (file.path) {
        state.aiImagePath = file.path;
        if (isMedia) {
          showImportProgress(0, 'Extracting frame…');
          extractFrame(file.path, function(framePath) {
            state.aiFramePath = framePath;
            hideImportProgress();
            updateGenerateBtn();
          });
        } else { updateGenerateBtn(); }
      } else {
        var ext = (fileName.match(/\.(\w+)$/) || ['', 'png'])[1].toLowerCase();
        var tmpPath = path.join(os.tmpdir(), 'ebp_img_' + Date.now() + '.' + ext);
        try {
          fs.writeFileSync(tmpPath, dataUrl.split(',')[1] || '', 'base64');
          state.aiImagePath = tmpPath;
        } catch(e) { state.aiImagePath = null; }
        updateGenerateBtn();
      }
    };
    reader.onerror = function() { setAiStatus('Could not read file.', 'err'); };
    reader.readAsDataURL(file);
  }
  updateGenerateBtn();
}

function loadDeck(deckPath, displayName) {
  // Show filename in dropzone
  aiPreviewImg.src = '';
  aiPreviewImg.style.display = 'none';
  aiFileNameLabel.textContent = displayName || path.basename(deckPath);
  aiFilePlaceholder.style.display = 'flex';
  aiDropzone.classList.add('has-file');
  aiClearBtn.style.display = 'flex';
  var lbl = aiDropzone.querySelector('.drop-label');
  var sub = aiDropzone.querySelector('.drop-sub');
  var ico = aiDropzone.querySelector('.drop-icon');
  if (lbl) lbl.style.display = 'none';
  if (sub) sub.style.display = 'none';
  if (ico) ico.style.display = 'none';

  state.aiImagePath = null;
  state.aiFramePath = null;
  state.aiDeckSlides = [];
  state.aiSlideNotes = {};
  aiSlideGridWrap.style.display = 'none';
  updateGenerateBtn();

  var isPdf = /\.pdf$/i.test(deckPath);

  // Extract PPTX notes in parallel
  if (!isPdf) {
    extractPptxNotes(deckPath, function(notes) {
      state.aiSlideNotes = notes || {};
    });
  }

  showImportProgress(isPdf ? 0.1 : 0.05, isPdf ? 'Extracting PDF slides…' : 'Converting PPTX…');

  var convert = isPdf ? convertPdfToSlides : convertPptxToSlides;
  convert(deckPath, function(err, slidePaths) {
    hideImportProgress();
    if (err) {
      setAiStatus(err.message, 'err');
      return;
    }
    showImportProgress(0.95, 'Loading slides…');
    setTimeout(function() {
      hideImportProgress();
      renderSlideGrid(slidePaths, state.aiSlideNotes);
      setAiStatus(slidePaths.length + ' slides loaded — click one to select it.', 'info');
      updateGenerateBtn();
    }, 200);
  });
}

function showAiPreview(filePath) {
  if (!filePath) return;
  var isImg = /\.(png|jpe?g|gif|webp|bmp|svg|mp4|mov|avi|webm)$/i.test(filePath);
  if (isImg) {
    aiPreviewImg.src = 'file://' + filePath;
    aiPreviewImg.style.display = 'block';
    aiFilePlaceholder.style.display = 'none';
  } else {
    aiPreviewImg.src = '';
    aiPreviewImg.style.display = 'none';
    aiFileNameLabel.textContent = filePath.split('/').pop();
    aiFilePlaceholder.style.display = 'flex';
  }
  aiDropzone.classList.add('has-file');
  aiClearBtn.style.display = 'flex';
  var lbl = aiDropzone.querySelector('.drop-label');
  var sub = aiDropzone.querySelector('.drop-sub');
  var ico = aiDropzone.querySelector('.drop-icon');
  if (lbl) lbl.style.display = 'none';
  if (sub) sub.style.display = 'none';
  if (ico) ico.style.display = 'none';
}

function clearAiImage() {
  state.aiImagePath = null;
  state.aiFramePath = null;
  state.aiDeckSlides = [];
  state.aiSlideNotes = {};
  if (voAutoTag) voAutoTag.style.display = 'none';
  aiPreviewImg.src = '';
  aiPreviewImg.style.display = 'none';
  aiFilePlaceholder.style.display = 'none';
  aiFileNameLabel.textContent = '';
  aiSlideGridWrap.style.display = 'none';
  aiSlideGrid.innerHTML = '';
  aiDropzone.classList.remove('has-file');
  aiClearBtn.style.display = 'none';
  var lbl = aiDropzone.querySelector('.drop-label');
  var sub = aiDropzone.querySelector('.drop-sub');
  var ico = aiDropzone.querySelector('.drop-icon');
  if (lbl) lbl.style.display = '';
  if (sub) sub.style.display = '';
  if (ico) ico.style.display = '';
  aiFileInput.value = '';
  updateGenerateBtn();
}

function updateGenerateBtn() {
  var hasInput = state.aiGenerateMode === 'prompt'
    ? !!promptText.value.trim()
    : (!state.aiImagePath && !voScript.value.trim()) === false;
  generateBtn.disabled = state.aiRunning || !hasInput;
}

voScript.addEventListener('input', updateGenerateBtn);
promptText.addEventListener('input', updateGenerateBtn);

// Mode toggle handled below (deck-aware version)

// --- Generate ---
generateBtn.addEventListener('click', function() {
  state.aiRefineTurns = 0;  // fresh generation resets the conversation lifecycle
  runGenerate(false);
});
fixBtn.addEventListener('click', function() {
  state.aiRefineTurns = (state.aiRefineTurns || 0) + 1;
  runGenerate(true);
});
fixText.addEventListener('input', function() { fixBtn.disabled = !this.value.trim(); });

recreateBtn.addEventListener('click', function() {
  state.aiRefineTurns = 0;  // Recreate also restarts the conversation
  runGenerate(false);
});

// Refine "Start over" — clears the textarea but keeps the current output so
// the user can decide to re-run from scratch or insert what they have.
if (refineResetBtn) {
  refineResetBtn.addEventListener('click', function() {
    state.aiRefineTurns = 0;
    if (fixText) fixText.value = '';
    if (fixBtn)  fixBtn.disabled = true;
    _updateRefineTurnLabel();
  });
}

function _updateRefineTurnLabel() {
  if (!refineTurnCounter) return;
  var n = state.aiRefineTurns || 0;
  refineTurnCounter.textContent = n > 0 ? (n + ' refinement' + (n === 1 ? '' : 's')) : '';
}

resetBtn.addEventListener('click', function() {
  state.aiOutput = null;
  state.aiRefineTurns = 0;
  if (fixText) fixText.value = '';
  if (fixBtn)  fixBtn.disabled = true;
  _updateRefineTurnLabel();
  aiOutput.style.display   = 'none';
  aiFix.style.display      = 'none';
  aiInsertBtn.style.display = 'none';
  aiActionRow.style.display = 'none';
  aiLogWrap.style.display   = 'none';
  setAiStatus('', '');
  clearAiImage();
});

// Spawn the bridge for a single AI call.
// configObj: { systemPrompt, userMessage, imagePath } — outputPath/model added internally.
// onProgress(label, pct): called for bridge progress events.
// onDone(err, rawText): called when bridge exits.
// Returns the child process (assigned to state.aiChild by caller).
function spawnBridge(configObj, onProgress, onDone) {
  var extPath   = cs.getSystemPath(SystemPath.EXTENSION);
  var bridge    = path.join(extPath, 'scripts', 'ai-generate.js');
  var configPath = path.join(os.tmpdir(), 'ebp_config_' + Date.now() + '.json');
  var outputPath = path.join(os.tmpdir(), 'ebp_output_' + Date.now() + '.txt');

  try {
    fs.writeFileSync(configPath, JSON.stringify({
      systemPrompt: configObj.systemPrompt,
      userMessage:  configObj.userMessage,
      imagePath:    configObj.imagePath || null,
      outputPath:   outputPath,
      model:        'claude-opus-5'
    }), 'utf8');
  } catch(e) {
    onDone('Setup error: ' + e.message, null);
    return null;
  }

  var env = Object.assign({}, process.env, { PATH: CHILD_PATH });
  delete env.CLAUDECODE;

  appendLog('node: ' + NODE_BIN, '');
  appendLog('bridge: ' + bridge, '');
  appendLog('pid-test: spawning…', '');

  var child;
  try {
    child = spawnFn(NODE_BIN, [bridge, '--config', configPath], {
      env: env,
      cwd: os.tmpdir()
    });
  } catch(spawnErr) {
    onDone('Spawn error: ' + spawnErr.message, null);
    return null;
  }
  appendLog('pid: ' + (child && child.pid), '');

  if (!child || !child.stderr || !child.stdout) {
    onDone('Spawn failed — child.pid=' + (child && child.pid), null);
    return null;
  }

  child.stderr.on('data', function(d) {
    d.toString().split('\n').forEach(function(l) {
      l = l.trim();
      if (!l) return;
      if (l === 'STREAMING') {
        onProgress('Receiving response…', null);
      } else if (l.indexOf('Prompt sent') === 0) {
        onProgress('Analyzing…', null);
      } else {
        appendLog(l, l.indexOf('ERROR') !== -1 ? 'err' : '');
      }
    });
  });

  child.stdout.on('data', function(d) {
    var t = d.toString().trim();
    if (t) appendLog(t, '');
  });

  child.on('error', function(e) {
    try { fs.unlinkSync(configPath); } catch(e2) {}
    try { fs.unlinkSync(outputPath); } catch(e2) {}
    onDone('Spawn error: ' + e.message, null);
  });

  child.on('close', function(code) {
    try { fs.unlinkSync(configPath); } catch(e) {}
    if (code !== 0) {
      try { fs.unlinkSync(outputPath); } catch(e) {}
      onDone('Bridge failed (exit ' + code + ') — check log', null);
      return;
    }
    try {
      var raw = fs.readFileSync(outputPath, 'utf8').trim();
      try { fs.unlinkSync(outputPath); } catch(e) {}
      onDone(null, raw);
    } catch(e) {
      onDone('Could not read result: ' + e.message, null);
    }
  });

  return child;
}

// Known valid block IDs for two-pass plan validation — must match full block inventory
var KNOWN_BLOCK_IDS = [
  // Title
  'slide-title',
  // Cards
  'cards-1','cards-2','cards-3','cards-4','cards-5',
  'cards-compare','cards-media','cards-corner','cards-corner-sq','cards-corner-slim',
  'cards-specs-a','cards-specs-b','cards-specs-c',
  'cards-top-bar','cards-bottom-bar',
  // Text
  'bullets','text-bullets','bullet-list','check-list','text-nested','text-2col','text-numbered',
  'text-code-cli','text-cli','text-code-bullets','text-body-bullets','text-errors','text-links',
  'text-agenda','text-acronym','text-code-quad','text-code-split',
  // Diagrams
  'diagram-flow','diagram-flow-4','diagram-flow-bullets-3','diagram-cycle',
  'diagram-process-2','diagram-chal-sol',
  'diagram-timeline','diagram-steps','diagram-funnel','diagram-matrix','diagram-hub-spoke',
  'diagram-parallel-split-ol',
  'diagram-split-2-ol','diagram-split-3-ol','diagram-split-5-ol','diagram-split-mirror-ol',
  // Trees
  'tree-3','tree-2level','tree-h3','tree-h5',
  // Charts
  'chart-bar','chart-bar-v','chart-bar-stacked','chart-donut',
  'chart-line','chart-area','chart-bar-grouped','chart-pie',
  'chart-progress','chart-radar','chart-scatter','chart-bubble','chart-waterfall',
  // Tables
  'table-bar','table-minimal','table-outlined',
  'table-1col','table-2col','table-3col','table-4col',
  // Components
  'rack-callout','comp-timeline','comp-logo-strip','comp-compare','comp-tags','comp-callout','comp-icon-grid',
  'comp-stat','comp-kpi','comp-quote','comp-divider',
  // Cards — device/hardware
  'cards-device',
  // Infrastructure
  'topology-gh200','topology-nvlink-switch','topology-spine-leaf','topology-gpu-node','topology-multi-rack'
];

function runGenerate(isFix) {
  if (state.aiRunning) return;
  state.aiRunning = true;
  state.aiStartTime = Date.now();
  generateBtn.disabled = true;
  aiInsertBtn.style.display = 'none';
  aiActionRow.style.display = 'none';
  aiOutput.style.display = 'none';
  aiProgress.style.display = 'block';
  aiProgressMsg.textContent = isFix ? 'Applying tweak…' : state.aiGenerateMode === 'prompt' ? 'Generating block…' : 'Sending to Claude…';
  aiProgressBar.style.width = '15%';
  setAiStatus('', '');
  clearLog();
  aiLogWrap.style.display = 'block';
  aiLog.style.display = 'block'; // ensure body visible even if user previously toggled it

  // Live elapsed timer — counts from original start across both passes
  var timerInterval = setInterval(function() {
    if (!state.aiRunning) { clearInterval(timerInterval); return; }
    var totalSec = Math.floor((Date.now() - state.aiStartTime) / 1000);
    var mm = String(Math.floor(totalSec / 60)).padStart(2, '0');
    var ss = String(totalSec % 60).padStart(2, '0');
    aiProgressMsg.textContent = (state.aiProgressLabel || 'Sending to Claude…') + ' (' + mm + ':' + ss + ')';
  }, 1000);
  state.aiProgressLabel = isFix ? 'Applying tweak…' : state.aiGenerateMode === 'prompt' ? 'Generating block…' : 'Sending to Claude…';

  var msgs, imgPath;
  try {
    msgs    = buildAiMessages(isFix);
    imgPath = (state.aiGenerateMode === 'prompt') ? null : (state.aiFramePath || state.aiImagePath);
  } catch(e) {
    clearInterval(timerInterval);
    finishGenerate(false, null, 'Setup error: ' + e.message);
    return;
  }

  // Determine if two-pass eligible
  var twoPass = !isFix && !state.forceBlockType;

  if (twoPass) {
    // ── Pass 1: Planning ──────────────────────────────────────────────────
    appendLog('Pass 1: Planning…', '');
    state.aiProgressLabel = 'Planning layout…';
    aiProgressBar.style.width = '15%';

    state.aiChild = spawnBridge(
      { systemPrompt: AI_PLAN_PROMPT, userMessage: msgs.userMessage, imagePath: imgPath },
      function onProgress1(label) {
        // map generic progress events to pass-1 range (15%→45%)
        if (label === 'Receiving response…') {
          state.aiProgressLabel = 'Planning layout…';
          aiProgressBar.style.width = '35%';
        } else if (label === 'Analyzing…') {
          state.aiProgressLabel = 'Planning layout…';
          aiProgressBar.style.width = '25%';
        }
      },
      function onDone1(err, raw1) {
        if (err || !raw1) {
          // Pass 1 failed — fall back to single pass
          appendLog('Pass 1 failed (' + (err || 'no output') + '), falling back to single pass.', '');
          _runSinglePass(msgs, imgPath, timerInterval);
          return;
        }

        // Parse plan JSON
        var plan = null;
        try {
          var clean1 = raw1.replace(/^```[a-z]*\n?/,'').replace(/```$/,'').trim();
          plan = JSON.parse(clean1);
        } catch(e) {
          appendLog('Pass 1 JSON parse failed, falling back to single pass.', '');
          _runSinglePass(msgs, imgPath, timerInterval);
          return;
        }

        // Validate plan has a known blockType
        if (!plan || !plan.blockType || KNOWN_BLOCK_IDS.indexOf(plan.blockType) === -1) {
          appendLog('Pass 1 returned unknown blockType "' + (plan && plan.blockType) + '", falling back to single pass.', '');
          _runSinglePass(msgs, imgPath, timerInterval);
          return;
        }

        appendLog('Pass 1 plan: ' + plan.blockType + ' / #' + plan.accentColor + ' / ' + plan.reasoning, 'ok');
        aiProgressBar.style.width = '45%';

        // ── Pass 2: Content generation ────────────────────────────────────
        appendLog('Pass 2: Generating…', '');
        state.aiProgressLabel = 'Writing content…';

        var planContext = '\n\n## Design Plan (follow exactly):\n' +
          'Block: ' + plan.blockType + '\n' +
          'Accent color: ' + plan.accentColor + '\n' +
          (plan.bodyStyle ? 'Body style: ' + plan.bodyStyle + '\n' : '') +
          'Items: ' + plan.itemCount + '\n' +
          'Strategy: ' + plan.contentStrategy + '\n\n' +
          'MANDATORY: Use blockType "' + plan.blockType + '". Use accentColor "' + plan.accentColor + '". Generate exactly ' + plan.itemCount + ' items.';

        state.aiChild = spawnBridge(
          { systemPrompt: msgs.systemPrompt, userMessage: msgs.userMessage + planContext, imagePath: imgPath },
          function onProgress2(label) {
            if (label === 'Receiving response…') {
              state.aiProgressLabel = 'Writing content…';
              aiProgressBar.style.width = '75%';
            } else if (label === 'Analyzing…') {
              state.aiProgressLabel = 'Writing content…';
              aiProgressBar.style.width = '55%';
            }
          },
          function onDone2(err2, raw2) {
            clearInterval(timerInterval);
            if (err2 || !raw2) {
              finishGenerate(false, null, err2 || 'Pass 2 returned no output.');
              return;
            }
            var parsed = parseAiOutput(raw2);
            if (!parsed) {
              appendLog(raw2.slice(0, 300), '');
              finishGenerate(false, null, 'Could not parse AI output (pass 2).');
            } else {
              finishGenerate(true, parsed, null);
            }
          }
        );
      }
    );
  } else {
    // ── Single pass (fix / forceBlockType / prompt mode) ─────────────────
    _runSinglePass(msgs, imgPath, timerInterval);
  }
}

function _runSinglePass(msgs, imgPath, timerInterval) {
  state.aiChild = spawnBridge(
    { systemPrompt: msgs.systemPrompt, userMessage: msgs.userMessage, imagePath: imgPath },
    function onProgress(label) {
      if (label === 'Receiving response…') {
        state.aiProgressLabel = 'Receiving response…';
        aiProgressBar.style.width = '60%';
      } else if (label === 'Analyzing…') {
        state.aiProgressLabel = 'Analyzing…';
        aiProgressBar.style.width = '30%';
      }
    },
    function onDone(err, raw) {
      clearInterval(timerInterval);
      if (err || !raw) {
        finishGenerate(false, null, err || 'No output from bridge.');
        return;
      }
      var parsed = parseAiOutput(raw);
      if (!parsed) {
        appendLog(raw.slice(0, 300), '');
        finishGenerate(false, null, 'Could not parse AI output.');
      } else {
        finishGenerate(true, parsed, null);
      }
    }
  );
}

function finishGenerate(ok, parsed, errMsg) {
  state.aiRunning = false;
  state.aiChild   = null;
  if (state.aiPollInterval) { clearInterval(state.aiPollInterval); state.aiPollInterval = null; }
  aiProgress.style.display = 'none';
  generateBtn.disabled = false;

  var elapsedSec = Math.floor((Date.now() - (state.aiStartTime || Date.now())) / 1000);
  var elMm = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
  var elSs = String(elapsedSec % 60).padStart(2, '0');
  var elapsed = elMm + ':' + elSs;

  if (!ok) {
    setAiStatus(errMsg, 'err');
    return;
  }

  aiProgressBar.style.width = '100%';
  state.aiOutput = parsed;
  showAiOutput(parsed);
  aiFix.style.display = 'block';
  aiInsertBtn.style.display = 'block';
  aiActionRow.style.display = 'flex';
  setAiStatus('\u23F1 ' + elapsed + ' — ready to insert', 'ok');
  appendLog('Done in ' + elapsed + '.', 'ok');

  // Conversational refinement bookkeeping. Clear the textarea so the user can
  // type the next instruction fresh, and update the turn counter so it''s
  // obvious this is a back-and-forth, not a one-shot.
  try {
    if (fixText) fixText.value = '';
    if (fixBtn)  fixBtn.disabled = true;
    _updateRefineTurnLabel();
  } catch(e) {}

  if (state.autoSaveMyBlocks && parsed && parsed.mode === 'block') {
    var autoName = (parsed.payload.title || parsed.payload.blockType || 'Block');
    saveMyBlock(autoName, parsed.payload);
  }
}

// ── Pass-1 design planner prompt ──────────────────────────────────────────
var AI_PLAN_PROMPT = [
  'You are a slide design planner for NVIDIA EasyBlocks Pro.',
  'Given slide content, output ONLY a compact JSON design plan. No content yet.',
  '',
  '## Full block list — pick the FIRST strong match working down:',
  '',
  '### High-impact standalone',
  'comp-stat      — ONE dominant number/metric',
  'comp-kpi       — 2-5 KPI metrics side by side',
  'comp-quote     — impactful quote/statement with attribution',
  'comp-divider   — section break / chapter title',
  'rack-callout      — server rack diagram with callout labels',
  'comp-timeline     — horizontal timeline/roadmap (3–5 milestones with date, title, desc)',
  'comp-logo-strip   — row of logo placeholder boxes (3–6), for partner/customer logos',
  'comp-compare      — 2-column VS comparison table Traditional vs NVIDIA, 4–6 feature rows with check/cross',
  'comp-tags         — technology chip/badge strip (4/6/8 tags), CUDA TensorRT cuDNN etc.',
  'comp-callout      — insight card / lower third: accent left bar + KEY INSIGHT label + headline + body',
  'comp-icon-grid    — row of icon placeholder squares (3–6) with label + description below each',
  'cards-device      — hardware/product spec card (1–2 cards) with accent title, rule, image placeholder, and bullet spec list',
  'cards-top-bar     — 3 feature cards with accent green top bar + circle icon + title + body lines',
  'cards-bottom-bar  — 3 feature cards with accent green bottom bar + circle icon + title + body lines',
  '',
  '### Charts (use whenever numbers/percentages are present)',
  'chart-bar         — horizontal bar chart (up to 8 items)',
  'chart-bar-v       — vertical bar chart (up to 8 items)',
  'chart-bar-stacked — stacked bars (2–4 series, up to 8 groups)',
  'chart-bar-grouped — grouped bars side-by-side (2–4 series, up to 8 groups)',
  'chart-donut       — donut/ring chart (up to 8 segments)',
  'chart-pie         — pie chart (up to 8 segments)',
  'chart-line        — line chart, trends over time (2–4 series)',
  'chart-area        — area/filled line chart (2–4 series)',
  'chart-progress    — horizontal progress bars, up to 5 items, ideal for percentages',
  'chart-radar       — radar/spider chart, 2-series capability comparison',
  'chart-scatter     — scatter plot, x/y data points',
  'chart-bubble      — bubble chart, 3-dimensional data (x/y/size)',
  'chart-waterfall   — waterfall chart, cumulative gains and losses',
  '',
  '### Diagrams (use for any process, structure, or relationship)',
  'diagram-steps          — numbered sequential steps, 3-8 items',
  'diagram-flow           — linear pipeline A→B→C, 2-5 stages',
  'diagram-flow-4         — fixed 4-step flow with large visuals',
  'diagram-flow-bullets-3 — 3 columns each with numbered badge + bullet list',
  'diagram-cycle          — circular/repeating lifecycle (loop back to start — NOT for linear phase sequences)',
  'diagram-process-2      — 2-row process matrix with sub-steps',
  'diagram-chal-sol       — challenge on left, solution on right',
  'diagram-timeline       — horizontal milestone roadmap, 2-10 events; use for Phase 1/2/3... sequences, lifecycle phases on a horizontal axis, or any multi-phase progression with alternating labels above/below',
  'diagram-hub-spoke      — one central concept + 3-12 satellite nodes',
  'diagram-funnel         — narrowing stages / conversion funnel',
  'diagram-matrix         — 2×2 priority/effort quadrant',
  'diagram-parallel-split-ol — one input → 2 parallel paths',
  'diagram-split-2-ol     — 1 source → 2 results',
  'diagram-split-3-ol     — 1 source → 3 results',
  'diagram-split-5-ol     — 1 source → 5 results',
  'diagram-split-mirror-ol— two parallel 4-item columns (use for "X vs Y", side-by-side stacks)',
  '',
  '### Checklists',
  'check-list     — verification items, requirements, criteria, pre-flight checks',
  '',
  '### Hierarchy',
  'tree-h3        — horizontal org chart: root → 3 branches',
  'tree-h5        — horizontal org chart: root → 5 branches',
  'tree-3         — vertical tree: root + 3 children',
  'tree-2level    — two-level tree: root + 2 L1 + 4 L2',
  '',
  '### Tables (choose style, then set numCols 1-8 and numRows 2-10)',
  'table-bar       — accent-color header bar with white text, alternating row stripes (default — high-contrast)',
  'table-minimal   — clean. accent-green header text + thick accent underline, light row dividers only (best for dense data)',
  'table-outlined  — full accent-color borders on every cell, no fills (best for spec sheets)',
  '',
  '### Cards (parallel independent items — last resort)',
  'cards-1        — 1 large feature card',
  'cards-2        — 2 cards side by side',
  'cards-3        — 3 feature cards',
  'cards-4        — 4 narrow cards',
  'cards-5        — 5 very compact cards',
  'cards-compare  — left vs right comparison',
  'cards-corner   — 2×2 corner-accent feature cards',
  'cards-media    — 2 cards with image placeholder',
  'cards-specs-a/b/c — GPU/hardware spec cards',
  '',
  '### Text (list or prose heavy content)',
  'bullets        — up to 4 bullet items in a card',
  'bullet-list    — dot bullet list',
  'check-list     — checkmark list',
  'text-bullets   — flat standalone bullets (up to 6)',
  'text-nested    — 2-3 main points each with sub-bullets',
  'text-numbered  — numbered steps, up to 4',
  'text-2col      — two-column list (6 items)',
  'text-agenda    — numbered agenda/TOC (up to 5)',
  'text-acronym   — large letter + word + description (2-6 letters)',
  'text-body-bullets — body paragraph + side bullets',
  'text-cli       — terminal command + explanation',
  'text-code-bullets — code snippets with labels',
  'text-code-cli  — terminal output log + cards',
  'text-code-quad — 2×2 code cards (exactly 4)',
  'text-code-split— bullets left + code block right',
  'text-links     — URL/resource list',
  'text-errors    — error codes with cause/fix',
  '',
  '### Infrastructure (NVIDIA-specific topology diagrams)',
  'topology-gh200 / topology-nvlink-switch / topology-spine-leaf / topology-gpu-node / topology-multi-rack',
  '',
  '### Title only',
  'slide-title    — full-slide title + subtitle, no content',
  '',
  '## Color — pick based on content mood:',
  '"76B900"=performance/green  "0071C5"=infrastructure/blue',
  '"5D1682"=AI/ML/software     "008564"=efficiency/sustainability',
  '"890C58"=security/risk      "FAC200"=warning/highlight  "5E5E5E"=neutral',
  '',
  '## Output this JSON and nothing else:',
  '{',
  '  "blockType": "exact-block-id",',
  '  "accentColor": "76B900",',
  '  "bodyStyle": "text",',
  '  "itemCount": 3,',
  '  "reasoning": "one sentence explaining why this block fits",',
  '  "contentStrategy": "preserve|adapt — preserve=copy text verbatim (text blocks), adapt=restructure to fit layout (cards/diagrams)"',
  '}',
  'bodyStyle: "text"|"bullets"|"pipe" for card blocks; null for everything else.',
  'itemCount: exact number of cards/steps/items/nodes to generate.',
  'Return ONLY the JSON. No markdown. No explanation.'
].join('\n');

// ── Full EasyBlocks Pro system prompt ─────────────────────────────────────
var AI_SYSTEM_PROMPT = [
  'You are a senior motion graphics designer and content strategist for NVIDIA.',
  'You create After Effects slides using EasyBlocks Pro. Your output is a single JSON object.',
  'You think like a designer: you choose the most visually compelling block for the content,',
  'rewrite source text to fit the layout precisely, and make intentional visual decisions.',
  '',
  '━━━ STEP 1: READ THE CONTENT DEEPLY ━━━',
  'Before choosing anything, ask yourself:',
  '  • What is the CORE MESSAGE of this slide in one sentence?',
  '  • What TYPE of relationship exists between the items?',
  '    - Sequential (A then B then C) → flow/steps/timeline',
  '    - Hierarchical (parent-child) → tree',
  '    - Convergent (many → one) → funnel',
  '    - Divergent (one → many) → hub-spoke or split',
  '    - Comparative (A vs B) → compare or table',
  '    - Additive (independent parallel items) → cards (last resort)',
  '    - Verificational (checklist, requirements, criteria) → check-list',
  '    - Quantitative (numbers, metrics) → chart or comp-stat/kpi',
  '  • How DENSE is the content? Long text → fewer items or text block. Short labels → cards or diagram.',
  '  • Is there a VISUAL STRUCTURE already implied (timeline, funnel, org chart)?',
  '',
  '━━━ STEP 2: CHOOSE THE BLOCK ━━━',
  'Priority order — work DOWN this list and stop at the first strong match:',
  '',
  '1. ONE dominant metric/number → comp-stat',
  '2. 2-5 KPI metrics → comp-kpi',
  '3. Impactful quote/statement → comp-quote',
  '4. Section break → comp-divider',
  '5. Numbers/percentages (bars/comparisons) → chart-bar / chart-bar-v / chart-bar-stacked / chart-bar-grouped',
  '   Proportions/shares → chart-donut / chart-pie',
  '   Trends over time → chart-line / chart-area',
  '   % completion / progress → chart-progress',
  '   Multi-axis comparison → chart-radar',
  '   Distribution/correlation → chart-scatter / chart-bubble',
  '   Cumulative gain/loss → chart-waterfall',
  '6. Sequential numbered steps (3-8) → diagram-steps',
  '7. Linear pipeline (2-5 stages) → diagram-flow',
  '8. Circular/repeating lifecycle (loops back to beginning) → diagram-cycle. IMPORTANT: "lifecycle" in the title does NOT mean cycle — if phases are numbered sequentially (Phase 1, 2, 3...) or progress along a time axis, use diagram-timeline instead.',
  '9. Timeline / roadmap / phase sequence / lifecycle phases on a horizontal axis → diagram-timeline',
  '10. One concept + many satellites → diagram-hub-spoke',
  '11. Narrowing stages → diagram-funnel',
  '12. 2×2 prioritization → diagram-matrix',
  '13. Checklist / verification / requirements / criteria → check-list',
  '14. Hierarchy / org chart → tree-h3 / tree-h5 / tree-3 / tree-2level',
  '15. Structured rows + columns → table-bar / table-minimal / table-outlined (set numCols + numRows)',
  '16. Split/fork flow → diagram-split-* / diagram-parallel-split-ol',
  '17. Process with sub-steps → diagram-flow-bullets-3 / diagram-process-2',
  '18. Code / CLI / links → text-code-* / text-cli / text-links',
  '19. Parallel independent features (NO better fit above) → cards-1..5',
  '20. Long prose with supporting points → text-body-bullets / text-nested',
  '',
  'NEVER jump to cards-* or text-* without checking options 1-18 first.',
  '',
  '━━━ STEP 3: FIT CONTENT TO LAYOUT ━━━',
  'CONTENT FIDELITY RULE: Your job is visual redesign, NOT content editing.',
  'Preserve the original text as faithfully as possible. Only adapt where layout physically requires it.',
  '',
  'For TEXT-DOMINANT blocks (check-list, bullet-list, text-bullets, text-numbered, text-2col, text-body-bullets):',
  '  • Preserve the original intent, structure, and most of the wording.',
  '  • Light edits are allowed: tighten phrasing, trim excess words, improve flow — but the result must still clearly resemble the source.',
  '  • Never fully replace or rewrite an item. If the original says "Hardware Mapping: Fabric components match NCP Device List" it must still say something like "Hardware Mapping: Fabric components match NCP Device List (DR vs NDR)".',
  '  • Preserve the original title as closely as possible. Shorten only if it exceeds 6 words, keeping the key nouns.',
  '  • check-list items: max 90 chars. Trim or tighten from the end — never change the core meaning.',
  '',
  'For CARD blocks (cards-1..5, cards-compare, cards-corner, cards-media):',
  '  • Card labels: 1-4 words, title case, no verbs ("GPU Memory" not "The GPU has memory")',
  '  • Card body lines: max 45 chars per line, plain declarative statements',
  '  • Density by card count:',
  '    - cards-1/2: up to 5 body lines each',
  '    - cards-3: exactly 3 body lines each',
  '    - cards-4: exactly 3 short body lines each (cards are narrow)',
  '    - cards-5: exactly 2 body lines each (cards are very narrow)',
  '',
  'For DIAGRAM / STRUCTURAL blocks:',
  '  • Diagram labels: ultra-short (1-3 words). Put details in body/text field.',
  '  • Timeline dates: real format ("Q1 2024", "Jan 2025", "2026")',
  '  • Steps: action verbs ("Configure", "Deploy", "Validate")',
  '  • Hub nodes: noun phrases only ("NVLink", "InfiniBand", "Storage")',
  '  • Chart labels: short category names. pct = realistic 0-100 value.',
  '  • Table cells: single value or short phrase, never a sentence',
  '',
  '━━━ STEP 4: VISUAL DESIGN DECISIONS ━━━',
  'Make intentional choices — do not just use defaults:',
  '',
  'accentColor: Pick from palette based on content mood:',
  '  "76B900" NVIDIA Green — performance, capability, positive outcomes (DEFAULT)',
  '  "0071C5" CPU Blue     — infrastructure, networking, compute',
  '  "5D1682" Amethyst     — AI, ML, software, intelligence',
  '  "008564" Emerald      — sustainability, efficiency, optimization',
  '  "890C58" Garnet       — security, risk, critical systems',
  '  "FAC200" Fluorite     — warning, highlight, caution',
  '  "5E5E5E" Dark Gray    — neutral, supporting, background info',
  '',
  'bodyStyle for cards:',
  '  "text"    — prose descriptions, explanations (default)',
  '  "bullets" — feature lists, capabilities, advantages',
  '  "pipe"    — specs, parameters, key=value pairs',
  '',
  'cardBorder: outline-first design — set true to draw 2px accent border around cards.',
  'dropShadow: false by default (Foundations design system bans decorative shadows). Only set true if a card NEEDS depth separation from another card right next to it.',
  'animateIn: true always',
  '',
  'cards-corner: ALL cards use the SAME accent color (the chosen accentColor). The old rainbow rule is removed — Foundations design system requires parallel cards to share their border color.',
  'cards-compare: MUST use contrasting colors (e.g. "76B900" vs "890C58") — this is the one exception (left vs right are NOT parallel; they oppose).',
  '',
  '━━━ STEP 5: COMPOSITIONAL THINKING (multi-block layouts) ━━━',
  'Canvas is 1920x1080. You are NOT limited to one block per slide. When the source',
  'content has two or three DISTINCT ideas that deserve equal visual weight, compose',
  'them on the same canvas using a multi-block layout. Single-block output is still',
  'the right answer for ~70% of slides — but reach for compositions when:',
  '  • The slide has BOTH a metric/quote/stat AND a list/diagram',
  '  • There are 2-3 parallel sections each rich enough to be their own block',
  '  • A timeline / chart is paired with explanatory bullets',
  '  • A diagram (left) deserves a callout/quote/stat alongside (right)',
  '  • A summary KPI row sits above a detail table or chart',
  '',
  'Available multi-block layouts:',
  '  split-h          : 2 slots, side-by-side (50/50 horizontal)',
  '  split-v          : 2 slots, stacked (50/50 vertical)',
  '  left-1-right-2   : 1 tall left (50%) + 2 stacked right',
  '  left-2-right-1   : 2 stacked left + 1 tall right (50%)',
  '  three-col        : 3 columns, equal width',
  '  2x2              : 4 slots in a 2x2 grid',
  '  custom           : free positioning — you supply `regions:[{l,t,w,h}, ...]` in pixels (canvas 1920x1080, 8px gap recommended between slots)',
  '',
  'Multi-block output shape (use INSTEAD of single-block when composing):',
  '{',
  '  "multiLayout": "split-h",            // one of the layouts above',
  '  "regions": [{...}],                  // OMIT unless multiLayout="custom"',
  '  "title": "Slide title",',
  '  "subtitle": "subtitle",',
  '  "accentColor": "76B900",',
  '  "slots": [',
  '    { "blockType": "comp-stat",  "statNumber":"94%", "statLabel":"Accuracy", "statDesc":"on benchmarks" },',
  '    { "blockType": "check-list", "bullets":["Hardware verified","Cable map confirmed","Power budget met"] }',
  '  ]',
  '}',
  '',
  'Multi-block rules:',
  '  • Each slot is a complete block with its own blockType + schema fields',
  '  • Slots inherit accentColor unless they override it',
  '  • Each slot is rendered into its region and scaled to fit',
  '  • Use multi-block sparingly — only when content is GENUINELY composed of distinct parts',
  '  • A slot can be ANY single block from the schemas below — including charts, diagrams, lists',
  '  • Number of slots must match the layout (split-h=2, three-col=3, 2x2=4, etc.)',
  '  • For "custom": regions are in pixels, total canvas is 1920x1080, leave 60px at top for title',
  '',
  '━━━ BLOCK SCHEMAS ━━━',
  'CRITICAL: Use EXACT field names below. Wrong field names = block renders with placeholder text.',
  'Body text in diagram/card blocks: use \\r to separate lines ("Line one\\rLine two\\rLine three")',
  '',
  '⚠️  ALL VALUES IN THESE SCHEMAS ARE STRUCTURAL EXAMPLES ONLY.',
  '    You MUST replace every label, body, text, title, stat, and bullet with REAL content extracted from the slide.',
  '    Copying or paraphrasing any example value ("First challenge", "Category A", "Node 1", "Detail", etc.) is FORBIDDEN.',
  '',
  '## STANDALONE',
  'slide-title:  (title + subtitle only — no extra fields)',
  'comp-stat:    "statNumber":"94%","statLabel":"Model Accuracy","statDesc":"on standard benchmarks"',
  'comp-kpi:     "kpis":[{"number":"2.4x","label":"Throughput","desc":"vs prev gen"}]  // 2-5 kpis',
  'comp-quote:   "quote":"The GPU is the engine of AI.","author":"Jensen Huang, CEO NVIDIA"',
  'comp-divider: "sectionNum":2,"sectionTitle":"Architecture Deep Dive","sectionDesc":"How Spectrum-X connects it all"',
  '',
  '## CHARTS',
  'chart-bar / chart-bar-v / chart-donut:',
  '  "chartData":[{"label":"Category A","pct":75},{"label":"Category B","pct":52}]',
  'chart-bar-stacked:',
  '  "items":[{"label":"Series","base":60,"overflow":20}],"yMax":100,"legend":{"baseLabel":"Actual","overflowLabel":"Target"}',
  '',
  '## DIAGRAMS',
  'diagram-flow:',
  '  "cardCount":4,"bodyStyle":"text","cards":[{"label":"Phase 1","body":"Validate NCP Device List\\rConfirm DR vs NDR specs"},{"label":"Phase 2","body":"Rack leveling\\rAirflow direction"},{"label":"Phase 3","body":"Transceiver profile match\\rPort orientation"},{"label":"Phase 4","body":"Fiber type match\\rMPO-12 APC only"}]',
  '  cardCount: 2-5. cards array MUST have exactly cardCount entries. body uses \\r as line separator.',
  '',
  'diagram-chal-sol:',
  '  "leftColor":"890C58","rightColor":"76B900","cards":[{"label":"Challenges","body":"Manual cable routing causes errors\\rNo real-time visibility into faults\\rScaling requires full re-cabling"},{"label":"Solutions","body":"Automated cable management layer\\rLive dashboard with alert thresholds\\rHot-swap modular cable trays"}]',
  '  *** THE BODY VALUES ABOVE ARE STRUCTURAL EXAMPLES ONLY — replace EVERY word with actual content from the slide. ***',
  '  EXACTLY 2 cards. cards[0]=left panel, cards[1]=right panel. body uses \\r as separator. label = panel header.',
  '  Use for: problem/solution, before/after, risk/mitigation, constraint/approach.',
  '',
  'diagram-flow-bullets-3:',
  '  "steps":[{"label":"Ingest","bullets":["Connect sources","Validate schema","Buffer streams"]},{"label":"Process","bullets":["Normalize data","Apply rules","Flag errors"]},{"label":"Output","bullets":["Write results","Generate report","Send notification"]}]',
  '  EXACTLY 3 steps. Each step has label + bullets array.',
  '',
  'diagram-cycle:',
  '  "cards":[{"label":"Plan","body":"Define scope"},{"label":"Build","body":"Implement"},{"label":"Test","body":"Validate"},{"label":"Deploy","body":"Release"}]  // exactly 4',
  '',
  'diagram-hub-spoke:',
  '  "hub":"NVIDIA AI Platform","nodes":["NVLink","InfiniBand","CUDA","TensorRT","Triton"]  // 3-8 nodes',
  '',
  'diagram-timeline:',
  '  "timelineCount":4,"timelineStyle":"alternate","pointStyle":"diamond",',
  '  "milestones":[{"date":"Q1 2024","label":"Launch","text":"Initial release"},{"date":"Q2 2024","label":"Expand","text":"Full rollout"}]',
  '  milestones array MUST have exactly timelineCount entries. timelineStyle: "straight"|"alternate". pointStyle: "diamond"|"circle"|"square".',
  '',
  'diagram-steps:',
  '  "stepCount":5,"stepsPerRow":5,"steps":[{"title":"Configure"},{"title":"Deploy"},{"title":"Monitor"},{"title":"Scale"},{"title":"Optimize"}]',
  '  steps array MUST have exactly stepCount entries. stepsPerRow: 3-5.',
  '',
  'diagram-funnel:',
  '  "stages":[{"label":"All Candidates","text":"Full hardware list"},{"label":"NCP Verified","text":"Device list match"},{"label":"Inspected","text":"Physical check passed"},{"label":"Cleared","text":"Ready to install"}]',
  '',
  'diagram-matrix:',
  '  "quadrants":[{"title":"Quick Wins","text":"High value, low effort"},{"title":"Major Projects","text":"High value, high effort"},{"title":"Fill-Ins","text":"Low value, low effort"},{"title":"Avoid","text":"Low value, high effort"}],"xLabel":"EFFORT","yLabel":"VALUE"',
  '  EXACTLY 4 quadrants: [top-left, top-right, bottom-left, bottom-right].',
  '',
  'diagram-process-2:',
  '  "rows":[{"label":"Row A","nodes":[{"text":"Node 1","sub":"Detail"},{"text":"Node 2","sub":"Detail"},{"text":"Node 3","sub":"Detail"}]},{"label":"Row B","nodes":[{"text":"Node 4","sub":"Detail"},{"text":"Node 5","sub":"Detail"},{"text":"Node 6","sub":"Detail"}]}]',
  '  EXACTLY 2 rows, 3 nodes each.',
  '',
  'diagram-parallel-split-ol: "cards":[{"label":"Input","body":"Source detail"},{"label":"Path A","body":"First route"},{"label":"Path B","body":"Second route"}]',
  'diagram-split-2-ol:  "cards":[{"label":"Source","body":"Origin detail"},{"label":"Result A","body":"First outcome"},{"label":"Result B","body":"Second outcome"}]',
  'diagram-split-3-ol:  4 cards (source + 3 results) — same pattern',
  'diagram-split-5-ol:  6 cards (source + 5 results) — same pattern',
  'diagram-split-mirror-ol: EXACTLY 10 cards in this order: cards[0]=LEFT column header (label + short body caption <=40 chars), cards[1]=RIGHT column header (label + short body caption <=40 chars), cards[2..5]=LEFT column 4 row labels (label only, <=24 chars), cards[6..9]=RIGHT column 4 row labels (label only, <=24 chars). NEVER dump bullet content into a header body — distribute items across cards[2..5] (left) and cards[6..9] (right). Example for "AI Factory vs Hardware Layer": "cards":[{"label":"AI Factory","body":"Full-stack solution"},{"label":"Hardware Layer","body":"Physical infrastructure"},{"label":"Software & Services"},{"label":"Orchestration"},{"label":"Models"},{"label":"Data"},{"label":"Data Center"},{"label":"Compute"},{"label":"Network"},{"label":"Storage"}]',
  '',
  '## CHECKLIST & LISTS',
  'check-list / text-bullets / bullet-list:',
  '  "bullets":["Hardware Mapping: fabric components match NCP Device List (DR vs NDR)","Mechanical: racks are true and level before rail install","Thermal: airflow direction (C2P/P2C) matches aisle design","Optical: fibers segregated by mode, connectors MPO-12 APC"]',
  '  bullets = array of plain strings. 3-6 items. Max 90 chars each.',
  '',
  'text-nested:',
  '  "bullets":[{"main":"Main Topic One","subs":["Supporting detail A","Supporting detail B"]},{"main":"Main Topic Two","subs":["Detail A","Detail B"]},{"main":"Main Topic Three","subs":["Detail A","Detail B"]}]',
  '  EXACTLY 3 main items, 2 subs each.',
  '',
  'text-numbered:',
  '  "bullets":["Step one: what to do and why it matters","Step two: follow-up action","Step three: validation check","Step four: confirm completion"]',
  '  bullets = array of strings (numbered automatically). 3-6 items.',
  '',
  'text-agenda:',
  '  "cards":[{"label":"Topic One","text":"Brief description of this section"},{"label":"Topic Two","text":"What will be covered"},{"label":"Topic Three","text":"Summary and next steps"}]',
  '  cards = [{label, text}]. label = agenda item, text = short description.',
  '',
  'text-acronym:',
  '  "cards":[{"label":"NCP","text":"NVIDIA Certified Professional — hardware validation standard"},{"label":"XDR","text":"Extreme Data Rate — 800 Gb/s fabric generation"},{"label":"NDR","text":"Non-blocking Data Rate — 400 Gb/s InfiniBand interconnect"}]',
  '  cards = [{label (the acronym/term), text (full meaning + brief context)}]. 2-6 items.',
  '',
  'text-2col:',
  '  "cards":[{"label":"Item 1"},{"label":"Item 2"},{"label":"Item 3"},{"label":"Item 4"},{"label":"Item 5"},{"label":"Item 6"}]',
  '  cards = [{label}] only. Items split evenly across 2 columns.',
  '',
  'text-body-bullets: "bodyText":["Paragraph 1","Paragraph 2"],"cards":[{"label":"Feature","text":"Supporting detail"}]',
  'text-cli:          "cliLabel":"Example:","cliCommand":"docker run --gpus all nvidia/cuda","cards":[{"label":"--gpus","body":"Enable GPU access"}]',
  'text-code-bullets: "cards":[{"code":"kubectl apply -f deploy.yaml","label":"Deploy workload","body":"Applies manifest to cluster"}]',
  'text-code-cli:     "cliLabel":"Output:","cliLines":["[INFO] Starting...","[OK] Done"],"cards":[{"code":"field","label":"Meaning"}]',
  'text-links:        "cards":[{"label":"Resource Title","url":"https://docs.nvidia.com"}]',
  'text-errors:       "cards":[{"code":"CUDA_ERROR_OUT_OF_MEMORY","items":[{"label":"Cause","text":"Batch too large"},{"label":"Fix","text":"Reduce batch size"}]}]',
  '',
  '## TABLES — field is "colTitles" (NOT "headers")',
  '   Required: blockType (table-bar | table-minimal | table-outlined), numCols (1-8), numRows (2-10), colTitles[], rows[][]',
  'table-bar:      "numCols":3,"numRows":3,"colTitles":["Model","Speed","Use Case"],"rows":[["Quantum-X800","800 Gb/s","XDR fabric"],["MQM3400-RA","400 Gb/s","NDR fabric"],["..."],["..."]]',
  'table-minimal:  "numCols":2,"numRows":4,"colTitles":["Device","Cable Type"],"rows":[["Switches","C13-C14"],["DGX Servers","C19-C20"],["PDUs","Site-specific"],["KVM","DB-9"]]',
  'table-outlined: "numCols":4,"numRows":3,"colTitles":["Feature","A","B","C"],"rows":[["Speed","800G","400G","200G"],["Power","750W","400W","200W"],["Port count","32","16","8"]]',
  '   numRows MUST match rows.length. Pick numCols 1-8, numRows 2-10 based on the actual data.',
  '',
  '## CARDS',
  'cards-1:  "cards":[{"label":"Header","body":"Full paragraph or 5 lines of detail\\rLine two\\rLine three\\rLine four\\rLine five"}],"bodyStyle":"text"',
  'cards-2:  "cards":[{"label":"Left Title","body":"Line 1\\rLine 2\\rLine 3\\rLine 4"},{"label":"Right Title","body":"Line 1\\rLine 2\\rLine 3\\rLine 4"}],"bodyStyle":"bullets"',
  'cards-3:  "cards":[{"label":"Card A","body":"Line 1\\rLine 2\\rLine 3"},{"label":"Card B","body":"Line 1\\rLine 2\\rLine 3"},{"label":"Card C","body":"Line 1\\rLine 2\\rLine 3"}],"bodyStyle":"text"',
  'cards-4:  "cards":[{"label":"Card A","body":"Short 1\\rShort 2\\rShort 3"},{"label":"Card B","body":"..."},{"label":"Card C","body":"..."},{"label":"Card D","body":"..."}],"bodyStyle":"text"',
  'cards-5:  "cards":[{"label":"Card A","body":"Line 1\\rLine 2"},...],"bodyStyle":"text"  // exactly 2 lines each',
  'cards-compare: "leftColor":"0071C5","rightColor":"5D1682","cards":[{"label":"XDR Fabric","body":"800 Gb/s\\rQuantum-X800\\rOSFP cages"},{"label":"NDR Fabric","body":"400 Gb/s\\rMQM3400-RA\\rInfiniBand"}],"bodyStyle":"bullets"',
  'cards-corner: "cards":[{"label":"Title 1","body":"Description","accentColor":"76B900"},{"label":"Title 2","body":"Description","accentColor":"5D1682"},{"label":"Title 3","body":"Description","accentColor":"0071C5"},{"label":"Title 4","body":"Description","accentColor":"890C58"}]',
  '  cards-corner: EACH card MUST have a different accentColor.',
  'cards-top-bar:    "cards":[{"label":"Feature A","body":"Line 1\\rLine 2\\rLine 3"},{"label":"Feature B","body":"Line 1\\rLine 2\\rLine 3"},{"label":"Feature C","body":"Line 1\\rLine 2\\rLine 3"}]',
  '  cards-top-bar: exactly 3 cards. label = card title, body = \\r-separated lines (3-4 lines).',
  'cards-bottom-bar: "cards":[{"label":"Feature A","body":"Line 1\\rLine 2\\rLine 3"},{"label":"Feature B","body":"Line 1\\rLine 2\\rLine 3"},{"label":"Feature C","body":"Line 1\\rLine 2\\rLine 3"}]',
  '  cards-bottom-bar: exactly 3 cards. Same schema as cards-top-bar.',
  '',
  '## HIERARCHY',
  'tree-h3: "cards":[{"label":"Root","body":"Top level context"},{"label":"Branch A","body":"First category"},{"label":"Branch B","body":"Second category"},{"label":"Branch C","body":"Third category"}]',
  'tree-h5: same pattern, 6 cards (root + 5 branches)',
  'tree-3:  "cards":[{"label":"Root","body":""},{"label":"Child 1","body":""},{"label":"Child 2","body":""},{"label":"Child 3","body":""}]',
  '',
  '## GPU SPEC CARDS',
  'cards-specs-a: "configLabel":"H100","configCode":"NVL","modelName":"NVIDIA H100 NVL","modelAlt":"Tensor Core GPU","badge":"New","bullets":["540 TFLOPS FP8","3.35 TB/s HBM3"],"tags":["LLM","Inference"]',
  'cards-specs-b: "configLabel":"H100","configCode":"SXM5","kvRows":[{"key":"Memory","value":"80 GB HBM3"},{"key":"Bandwidth","value":"3.35 TB/s"}],"tags":["Training"]',
  'cards-specs-c: "configLabel":"A100","configCode":"PCIe","rows":[{"label":"Memory","value":"80 GB HBM2e"},{"label":"TDP","value":"300W"}]',
  'cards-device: "deviceName":"DGX H100","deviceType":"AI Supercomputer","bullets":["8x H100 GPUs","640 GB GPU memory","3.6 TB/s NVLink"]',
  '',
  '## CARD VARIANTS',
  'cards-media:        "cards":[{"label":"Left Title","body":"Description text"},{"label":"Right Title","body":"Description text"}]  // 2 cards each with image placeholder',
  'cards-corner-sq:    "cards":[{"label":"A","body":"Detail","accentColor":"76B900"},{"label":"B","body":"Detail","accentColor":"5D1682"},{"label":"C","body":"Detail","accentColor":"0071C5"},{"label":"D","body":"Detail","accentColor":"890C58"}]  // square corner cards, 4 cards, each diff accentColor',
  'cards-corner-slim:  same shape as cards-corner-sq but slimmer cards',
  'cards-icon-3:       "cards":[{"label":"Item A","body":"Detail"},{"label":"Item B","body":"Detail"},{"label":"Item C","body":"Detail"}]  // 3 cards with icon emphasis',
  '',
  '## TEXT VARIANTS',
  'bullets:            "bullets":["First item","Second item","Third item"]  // simple text bullet card (Pipe List style — vertical bars)',
  'text-code-quad:     "cards":[{"label":"Snippet A","code":"kubectl get pods"},{"label":"Snippet B","code":"kubectl get nodes"},{"label":"Snippet C","code":"kubectl describe pod x"},{"label":"Snippet D","code":"kubectl logs -f x"}]  // exactly 4 code snippets in 2x2',
  'text-code-split:    "cliCommand":"docker run nvidia/cuda:latest","bullets":["Pulls latest CUDA image","Mounts GPU","Runs interactively"]  // bullets left, code right',
  '',
  '## HIERARCHY VARIANTS',
  'tree-2level:        "root":"NVIDIA","l1":[{"label":"Data Center"},{"label":"Edge"}],"l2":[[{"label":"DGX"},{"label":"HGX"}],[{"label":"Jetson"},{"label":"IGX"}]]  // root + 2 mid + 4 leaves',
  '',
  '## TOPOLOGY (infrastructure diagrams — labels are pre-positioned, you fill ONLY the strings)',
  'topology-gh200:        "label1":"GH200","label2":"Grace CPU","label3":"H200 GPU","label4":"NVLink-C2C 900GB/s"  // GH200 superchip diagram',
  'topology-nvlink-switch:"label1":"NVLink Switch","label2":"7.2 TB/s","label3":"576 GPUs","label4":"Fully connected"  // NVLink switch fabric',
  'topology-spine-leaf:   "label1":"Spine","label2":"Leaf","label3":"800 Gb/s","label4":"Non-blocking"  // spine-leaf network',
  'topology-gpu-node:     "label1":"DGX H200","label2":"8 GPUs","label3":"640 GB","label4":"NVLink"  // GPU node internals',
  'topology-multi-rack:   "label1":"32 racks","label2":"DGX H200","label3":"InfiniBand","label4":"NVL576"  // multi-rack cluster',
  '',
  '## COMPONENTS (overlay-style — best inside multi-block layouts or as standalone moments)',
  'comp-callout:      "calloutType":"insight","calloutTitle":"Key Insight","calloutText":"This is the takeaway message"  // callout card / lower third',
  'comp-tags:         "tagsLabel":"Tech Stack","tags":["CUDA","TensorRT","Triton","NCCL"]  // tag chips with label',
  'comp-icon-grid:    "iconItems":[{"label":"Compute"},{"label":"Network"},{"label":"Storage"},{"label":"Software"}]  // 3-8 icon tiles',
  'comp-logo-strip:   "logos":[{"label":"Partner A"},{"label":"Partner B"},{"label":"Partner C"},{"label":"Partner D"}]  // partner/ecosystem strip',
  'comp-compare:      "leftLabel":"Traditional","rightLabel":"NVIDIA","items":[{"trad":"Manual config","nvda":"Automated provisioning"},{"trad":"Hours to scale","nvda":"Minutes to scale"}]  // before/after comparison',
  'comp-timeline:     "milestones":[{"date":"Q1","label":"Plan"},{"date":"Q2","label":"Build"},{"date":"Q3","label":"Test"},{"date":"Q4","label":"Launch"}]  // compact 3-5 milestone strip',
  'rack-callout:      "rackName":"DGX SuperPOD","unitCount":42,"callouts":[{"u":40,"label":"Mgmt Switch"},{"u":36,"label":"Storage"},{"u":24,"label":"DGX H100"},{"u":4,"label":"PDU"}]  // server-rack diagram with U-position callouts',
  '',
  '━━━ BASE FIELDS (every block must include these) ━━━',
  '{',
  '  "blockType": "...",',
  '  "title": "Slide Title",        // max 6 words, sentence case',
  '  "subtitle": "Category label",  // product / version / topic — or ""',
  '  "accentColor": "76B900",       // choose intentionally per STEP 4',
  '  "animateIn": true,',
  '  "cardBorder": false,',
  '  "dropShadow": false            // Foundations: flat surfaces, no shadows',
  '}',
  '',
  '━━━ HARD RULES ━━━',
  '- VARIETY THROUGH INTENT: Each slide deserves the block that best fits its content. Repeating a blockType is fine when the content shape genuinely repeats — but if every slide in your deck is the same type, you are not thinking hard enough.',
  '- SPECIFICITY: If content has a clear structure (timeline, funnel, cycle, steps, matrix, table, checklist), use that specific block — not cards-*.',
  '- COMPOSE WHEN APPROPRIATE: If a slide has two genuinely distinct ideas, use a multi-block layout (split-h / split-v / 2x2 etc.) rather than cramming both into one block.',
  '- FILL ALL FIELDS: Every field in the schema must contain REAL content from the slide. Schema examples ("First challenge", "Category A", "Node 1", "Detail") are templates — NEVER copy or paraphrase them.',
  '- USE THE FULL LIBRARY: There are ~80 blocks total. If you find yourself reaching for cards-3 for the fifth time in a deck, step back — consider diagram-hub-spoke, diagram-funnel, tree-h3, comp-icon-grid, comp-tags, topology-*, comp-compare, or a multi-block composition.',
  '- diagram-chal-sol requires EXACTLY 2 cards. cards[0].body and cards[1].body MUST be filled with \\r-separated real content. Each line must be a COMPLETE, self-contained phrase (5-10 words). Never split one sentence across two lines.',
  '- diagram-flow: cards array MUST have exactly cardCount entries, each with a filled body field.',
  '- BULLET/BODY LINES: Every bullet or body line must be a COMPLETE, standalone phrase. NEVER start a line with a conjunction or continuation word ("and", "but", "or", "before", "after", "so", "while"). If content is too long: COMPRESS the meaning into one shorter phrase — do NOT split one sentence across two bullets.',
  '- For text-dominant blocks: preserve intent and most wording — light edits OK, full rewrites never OK',
  '- For card/diagram blocks: restructure to fit label/body format constraints',
  '- Never invent URLs — use "https://docs.nvidia.com" as placeholder',
  '- title: max 8 words. subtitle: max 5 words or empty.',
  '- pct values in charts must be realistic and not all similar',
  '- steps array must have exactly stepCount entries',
  '- cards-corner must give each card a different accentColor',
  '- table field is "colTitles" (NOT "headers"). text-agenda and text-acronym use "cards" (NOT "bullets" or "letters").',
  '',
  '━━━ OUTPUT ━━━',
  'Return ONLY a JSON object. No markdown fences. No explanation. No trailing text.',
  '',
  'TWO POSSIBLE SHAPES:',
  '  (1) Single block:   { "blockType": "...", ...schema fields..., "title", "subtitle", "accentColor", "animateIn", "dropShadow" }',
  '  (2) Multi block:    { "multiLayout": "split-h"|"split-v"|"left-1-right-2"|"left-2-right-1"|"three-col"|"2x2"|"custom",',
  '                        "slots": [ { "blockType": "...", ...schema fields... }, ... ],',
  '                        "regions": [{l,t,w,h}, ...]  // only if multiLayout="custom"',
  '                        "title", "subtitle", "accentColor", "animateIn", "dropShadow" }',
  '',
  'Choose (1) for ~70% of slides. Choose (2) when content genuinely splits into distinct ideas.'
].join('\n');


function buildAiMessages(isFix) {
  var vo    = voScript.value.trim();
  var extra = extraInstr.value.trim();
  var fix   = isFix ? fixText.value.trim() : '';

  var userMsg;
  if (isFix && fix && state.aiOutput) {
    userMsg = 'You previously generated this EasyBlocks JSON:\n' +
      JSON.stringify(state.aiOutput.payload, null, 2) +
      '\n\nThe user wants to change: ' + fix +
      '\n\nReturn ONLY the updated JSON object. No markdown, no explanation.';
  } else if (state.aiGenerateMode === 'prompt') {
    userMsg = promptText.value.trim();
    if (state.forceBlockType) {
      userMsg += '\n\nMANDATORY: You MUST use blockType "' + state.forceBlockType + '". Fill all required schema fields for that block type.';
    }
    userMsg += '\n\nReturn ONLY the JSON object. No markdown, no explanation.';
    savePromptToHistory(promptText.value.trim());
  } else {
    userMsg = 'Analyze the provided slide' + (vo ? ' and voiceover script' : '') +
      ' and return the best JSON block.' +
      (vo    ? '\n\nVO Script:\n' + vo       : '') +
      (extra ? '\n\nExtra instructions: ' + extra : '');
    if (state.forceBlockType) {
      userMsg += '\n\nMANDATORY: You MUST use blockType "' + state.forceBlockType + '".';
    }
  }
  return { systemPrompt: AI_SYSTEM_PROMPT, userMessage: userMsg };
}

// Map AI's `multiLayout` value to the actual block type the hostscript dispatches.
function _multiLayoutToBlockType(layout) {
  var MAP = {
    'split-h':        'multi-split-h',
    'split-v':        'multi-split-v',
    'left-1-right-2': 'multi-left-1-right-2',
    'left-2-right-1': 'multi-left-2-right-1',
    'three-col':      'multi-three-col',
    '2x2':            'multi-2x2',
    'custom':         'multi-split-h' // custom uses regions array directly; pick any preset as base
  };
  return MAP[layout] || null;
}

// Normalise an AI multi-block payload into the params the createMultiBlockLayout
// renderer expects. Each slot's content is also run through _sanitizeAiContent so
// per-slot field name typos / array bodies / etc. are corrected.
function _sanitizeMultiBlockPayload(obj) {
  var blockType = _multiLayoutToBlockType(obj.multiLayout);
  if (!blockType) return null;
  var slots = Array.isArray(obj.slots) ? obj.slots.slice(0) : [];
  // Sanitize each slot independently — they're complete sub-blocks
  slots = slots.map(function(s) {
    if (!s || !s.blockType) return s;
    s.shapeFill = false; s.cardBg = false;
    return _sanitizeAiContent(s);
  });
  var p = {
    blockType:    blockType,
    multiLayout:  obj.multiLayout,
    slots:        slots,
    title:        obj.title       || '',
    subtitle:     obj.subtitle    || '',
    accentColor:  obj.accentColor || '76B900',
    animateIn:    obj.animateIn   !== false,
    dropShadow:   obj.dropShadow  !== false,
    cardBorder:   obj.cardBorder  === true,
    shapeFill:    false,
    cardBg:       false
  };
  // Custom regions: pass through if the AI provided them and the layout is custom.
  if (obj.multiLayout === 'custom' && Array.isArray(obj.regions)) {
    p.customRegions = obj.regions;
  }
  // Clamp accent color to known palette
  var PALETTE = ['76B900','008564','5D1682','0071C5','890C58','FAC200','000000','5E5E5E','8C8C8C','CDCDCD'];
  if (!p.accentColor || PALETTE.indexOf(p.accentColor.toUpperCase().replace('#','')) === -1) {
    p.accentColor = '76B900';
  }
  return p;
}

function parseAiOutput(raw) {
  // Strip markdown fences if present
  var clean = raw.replace(/^```[a-z]*\n?/i, '').replace(/\n?```$/i, '').trim();
  function _tryParse(s) { try { return JSON.parse(s); } catch(e) { return null; } }
  var obj = _tryParse(clean);
  if (!obj) {
    var m = clean.match(/\{[\s\S]*\}/);
    if (m) obj = _tryParse(m[0]);
  }
  if (obj) {
    // Multi-block composition takes priority — recognise either layout naming.
    if (obj.multiLayout && Array.isArray(obj.slots)) {
      var multi = _sanitizeMultiBlockPayload(obj);
      if (multi) return { mode: 'block', payload: multi };
    }
    if (obj.blockType) return { mode: 'block', payload: _sanitizeAiPayload(obj) };
  }
  // Fallback: treat as motion code (rare — AI sometimes returns TSX)
  return { mode: 'motion', payload: clean };
}

// Enforce safe defaults on every AI-generated payload — never let the LLM
// accidentally set fill colors, bad booleans, or missing required fields.
function _sanitizeAiPayload(p) {
  // Never fill card backgrounds with accent color — always white/transparent
  p.shapeFill   = false;
  p.cardBg      = false;
  // Ensure booleans are correct types (JSON might return strings)
  p.animateIn   = p.animateIn !== false;
  p.dropShadow  = p.dropShadow !== false;
  p.cardBorder  = p.cardBorder === true;
  p.precomp     = p.precomp   === true;
  // Clamp accent color to known palette, default to NVIDIA Green
  var PALETTE = ['76B900','008564','5D1682','0071C5','890C58','FAC200','000000','5E5E5E','8C8C8C','CDCDCD'];
  if (!p.accentColor || PALETTE.indexOf(p.accentColor.toUpperCase().replace('#','')) === -1) {
    p.accentColor = '76B900';
  }
  return _sanitizeAiContent(p);
}

function _sanitizeAiContent(p) {
  var bt = p.blockType || '';

  // Helper: truncate string to maxChars — cuts at word boundary to avoid mid-word clips
  function cap(s, n) {
    if (typeof s !== 'string' || s.length <= n) return s;
    var cut = s.slice(0, n);
    var lastSpace = cut.lastIndexOf(' ');
    return (lastSpace > n * 0.5) ? cut.slice(0, lastSpace) : cut;
  }

  // Conjunction/preposition words that should NEVER start a standalone bullet line
  var FRAGMENT_STARTERS = /^(and|but|or|so|yet|before|after|while|since|because|when|if|as|nor|although|however|therefore|thus|hence|whereas|unless|until|though)\b/i;

  // Helper: truncate body string (\r separated) to maxLines lines, each capped at maxChars
  // Also removes fragment lines (starting with conjunctions) — AI sometimes splits sentences
  function capBody(body, maxLines, maxChars) {
    if (typeof body !== 'string') return body;
    var lines = body.split('\r')
      .map(function(l) { return l.trim(); })
      .filter(function(l) { return l && !FRAGMENT_STARTERS.test(l); })
      .slice(0, maxLines)
      .map(function(l) { return cap(l, maxChars); });
    return lines.join('\r');
  }

  // Helper: normalize an AI card/item object's body field.
  // AI often generates arrays, empty strings, wrong field names, or \n separators.
  function normalizeBody(c) {
    // If body is an array, join immediately
    if (Array.isArray(c.body)) { c.body = c.body.join('\r'); }
    // If body is a non-empty string, fix separators and return
    if (typeof c.body === 'string' && c.body.trim()) {
      c.body = c.body.replace(/\\r/g, '\r').replace(/\n/g, '\r'); // literal \r or \n → CR
      return;
    }
    // body missing or empty — try every alternate field name AI might use
    var alt = c.items || c.bullets || c.lines || c.points
            || c.text || c.description || c.details || c.content
            || c.summary || c.notes;
    if (Array.isArray(alt)) { c.body = alt.join('\r'); return; }
    if (typeof alt === 'string' && alt.trim()) {
      c.body = alt.replace(/\\r/g, '\r').replace(/\n/g, '\r');
    }
  }

  // Card body density — chars based on actual card width / font size at each count
  // cards-N textW: 1696 / 801 / 502 / 363 / 286 px. fontSize: 26/26/26/23/20.
  // Avg char width ≈ 0.58×fontSize. Limit at ~85% of textW/charW.
  var cardLimits = {
    'cards-1': { lines: 5, chars: 90 },
    'cards-2': { lines: 4, chars: 44 },
    'cards-3': { lines: 3, chars: 28 },
    'cards-4': { lines: 3, chars: 22 },
    'cards-5': { lines: 2, chars: 18 }
  };
  if (cardLimits[bt] && Array.isArray(p.cards)) {
    var lim = cardLimits[bt];
    p.cards = p.cards.slice(0, parseInt(bt.replace('cards-',''), 10)).map(function(c) {
      normalizeBody(c);
      if (c.body) c.body = capBody(c.body, lim.lines, lim.chars);
      if (c.label) c.label = cap(c.label, 28);
      return c;
    });
  }

  // diagram-chal-sol: normalize cards body AND recover from leftItems/rightItems pattern
  if (bt === 'diagram-chal-sol') {
    // AI sometimes generates leftItems/rightItems instead of cards array
    if ((!Array.isArray(p.cards) || p.cards.length < 2) &&
        (Array.isArray(p.leftItems) || Array.isArray(p.rightItems))) {
      var leftLabel  = p.leftLabel  || (p.cards && p.cards[0] && p.cards[0].label) || 'Challenges';
      var rightLabel = p.rightLabel || (p.cards && p.cards[1] && p.cards[1].label) || 'Solutions';
      p.cards = [
        { label: leftLabel,  body: (p.leftItems  || []).join('\r') },
        { label: rightLabel, body: (p.rightItems || []).join('\r') }
      ];
    }
    // Normalize body on each card regardless
    if (Array.isArray(p.cards)) {
      p.cards = p.cards.slice(0, 2).map(function(c) {
        normalizeBody(c);
        if (c.label) c.label = cap(c.label, 30);
        if (c.body)  c.body  = capBody(c.body, 5, 55);
        return c;
      });
    }
  }

  // diagram-flow / diagram-flow-4: normalize cards body with width-aware char limits
  // nodeW by cardCount: N=2→840, N=3→533, N=4→407, N=5→307. fontSize=30 (~17px/char).
  // diagram-flow-4 fixed: nodeW=350, fontSize=28 (~16px/char).
  if ((bt === 'diagram-flow' || bt === 'diagram-flow-4') && Array.isArray(p.cards)) {
    var dfN = bt === 'diagram-flow-4' ? 4 : (parseInt(p.cardCount) || p.cards.length || 3);
    var dfChars = bt === 'diagram-flow-4' ? 16
                : dfN <= 2 ? 40 : dfN === 3 ? 24 : dfN === 4 ? 18 : 14;
    var dfLabel = bt === 'diagram-flow-4' ? 20
                : dfN <= 2 ? 28 : dfN === 3 ? 20 : 16;
    p.cards = p.cards.map(function(c) {
      normalizeBody(c);
      if (c.label) c.label = cap(c.label, dfLabel);
      if (c.body)  c.body  = capBody(c.body, 4, dfChars);
      return c;
    });
    if (bt === 'diagram-flow-4') {
      while (p.cards.length < 4) p.cards.push({ label: 'Step ' + (p.cards.length + 1), body: '' });
      p.cards = p.cards.slice(0, 4);
    }
  }

  // text-agenda / text-acronym: normalize cards (label+text)
  if ((bt === 'text-agenda' || bt === 'text-acronym') && Array.isArray(p.cards)) {
    p.cards = p.cards.map(function(c) {
      // AI sometimes uses 'description' or 'definition' instead of 'text'
      if (!c.text && c.description) c.text = c.description;
      if (!c.text && c.definition)  c.text = c.definition;
      if (!c.text && c.body)        c.text = typeof c.body === 'string' ? c.body : c.body.join(' ');
      if (c.label) c.label = cap(c.label, 30);
      if (c.text)  c.text  = cap(c.text, 80);
      return c;
    });
  }

  // check-list
  if (bt === 'check-list' && Array.isArray(p.bullets)) {
    p.bullets = p.bullets.slice(0, 6).map(function(b) { return cap(b, 90); });
  }

  // text-bullets / bullets
  if ((bt === 'text-bullets' || bt === 'bullets') && Array.isArray(p.bullets)) {
    p.bullets = p.bullets.slice(0, 6).map(function(b) { return cap(b, 80); });
  }

  // diagram-steps: enforce stepCount matches steps array
  if (bt === 'diagram-steps' && Array.isArray(p.steps)) {
    var sc = Math.min(Math.max(parseInt(p.stepCount) || p.steps.length, 1), 10);
    p.steps = p.steps.slice(0, sc).map(function(s) {
      if (s.title) s.title = cap(s.title, 22);
      return s;
    });
    p.stepCount = p.steps.length;
  }

  // diagram-timeline: enforce timelineCount matches milestones
  if (bt === 'diagram-timeline' && Array.isArray(p.milestones)) {
    var tc = Math.min(Math.max(parseInt(p.timelineCount) || p.milestones.length, 2), 10);
    p.milestones = p.milestones.slice(0, tc).map(function(m) {
      if (m.label) m.label = cap(m.label, 20);
      if (m.text)  m.text  = cap(m.text, 50);
      return m;
    });
    p.timelineCount = p.milestones.length;
  }

  // comp-stat
  if (bt === 'comp-stat') {
    if (p.statLabel) p.statLabel = cap(p.statLabel, 30);
    if (p.statDesc)  p.statDesc  = cap(p.statDesc,  60);
  }

  // title / subtitle always capped
  if (p.title)    p.title    = cap(p.title,    60);
  if (p.subtitle) p.subtitle = cap(p.subtitle, 50);

  return p;
}

function showAiOutput(parsed) {
  aiOutput.style.display = 'block';
  if (parsed.mode === 'block') {
    aiModeBadge.textContent = 'BLOCK';
    aiModeBadge.className = 'mode-badge mode-block';
    aiOutputLabel.textContent = parsed.payload.blockType || 'Block ready';
    aiJsonEditor.value = JSON.stringify(parsed.payload, null, 2);
  } else {
    aiModeBadge.textContent = 'MOTION';
    aiModeBadge.className = 'mode-badge mode-motion';
    aiOutputLabel.textContent = 'Custom motion graphic';
    aiJsonEditor.value = parsed.payload;
  }
}

// Toggle JSON editor
toggleJsonBtn.addEventListener('click', function() {
  var visible = aiJsonEditor.style.display !== 'none';
  aiJsonEditor.style.display = visible ? 'none' : 'block';
  this.textContent = visible ? 'Edit JSON' : 'Hide JSON';
});

// AI Insert
aiInsertBtn.addEventListener('click', function() {
  if (!state.aiOutput) return;
  var payload = state.aiOutput.payload;
  // If JSON was edited, re-parse
  if (aiJsonEditor.style.display !== 'none') {
    try { payload = JSON.parse(aiJsonEditor.value); } catch(e) {
      setAiStatus('Invalid JSON', 'err'); return;
    }
  }
  if (state.aiOutput.mode === 'block') {
    setAiStatus('Inserting block...', '');
    ebpResolveIconsInPayload(payload, function(resolvedPayload) {
      cs.evalScript('createBlock(' + JSON.stringify(resolvedPayload) + ')', function(result) {
        if (!result || result.indexOf('error') === 0) {
          setAiStatus(result || 'Unknown error', 'err');
        } else {
          setAiStatus('Block inserted.', 'ok');
        }
      });
    });
  } else {
    setAiStatus('Motion render not yet implemented.', 'err');
  }
});

// Save to My Blocks
saveBlockBtn.addEventListener('click', function() {
  if (!state.aiOutput || state.aiOutput.mode !== 'block') return;
  var payload = state.aiOutput.payload;
  if (aiJsonEditor.style.display !== 'none') {
    try { payload = JSON.parse(aiJsonEditor.value); } catch(e) {
      setAiStatus('Invalid JSON', 'err'); return;
    }
  }
  var name = prompt('Block name:', payload.title || payload.blockType || 'My Block');
  if (!name) return;
  saveMyBlock(name, payload);
});

// ══════════════════════════════════════════════════════════════════════════
// MY BLOCKS
// ══════════════════════════════════════════════════════════════════════════
function loadMyBlocks() {
  try {
    if (!fs.existsSync(state.myBlocksDir)) fs.mkdirSync(state.myBlocksDir, { recursive: true });
    var files = fs.readdirSync(state.myBlocksDir).filter(function(f) { return f.endsWith('.json'); });
    state.myBlocks = files.map(function(f) {
      try {
        var data = JSON.parse(fs.readFileSync(path.join(state.myBlocksDir, f), 'utf8'));
        return { name: f.replace('.json',''), data: data, file: f };
      } catch(e) { return null; }
    }).filter(Boolean);
    renderMyBlocks();
  } catch(e) {
    console.error('loadMyBlocks:', e.message);
  }
}

function saveMyBlock(name, payload) {
  try {
    if (!fs.existsSync(state.myBlocksDir)) fs.mkdirSync(state.myBlocksDir, { recursive: true });
    var safe = name.replace(/[^a-zA-Z0-9_-]/g, '_');
    var file = safe + '.json';
    fs.writeFileSync(path.join(state.myBlocksDir, file), JSON.stringify({ name: name, payload: payload }, null, 2));
    loadMyBlocks();
    setAiStatus('Saved to My Blocks.', 'ok');
  } catch(e) {
    setAiStatus('Save failed: ' + e.message, 'err');
  }
}

function renderMyBlocks() {
  var grid = $('myBlocksGrid');
  var empty = $('myBlocksEmpty');
  grid.innerHTML = '';
  state.selectedMyBlock = null;

  var countEl = $('myBlocksCount');
  if (countEl) countEl.textContent = state.myBlocks.length;

  if (!state.myBlocks.length) {
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';

  state.myBlocks.forEach(function(block) {
    var btn = document.createElement('div');
    btn.className = 'block-btn';
    btn.innerHTML =
      '<div class="block-thumb">' +
        '<svg viewBox="0 0 100 56"><rect width="100" height="56" fill="#141414"/>' +
        '<rect x="10" y="20" width="80" height="5" rx="1" fill="#76B900" opacity="0.8"/>' +
        '<rect x="15" y="30" width="70" height="3" rx="0.8" fill="#555"/>' +
        '<rect x="15" y="36" width="55" height="3" rx="0.8" fill="#444"/>' +
        '</svg>' +
        '<div class="mb-actions">' +
          '<button class="mb-action mb-rename" title="Rename">&#9998;</button>' +
          '<button class="mb-action mb-delete" title="Delete">&#215;</button>' +
        '</div>' +
      '</div>' +
      '<div class="block-label" title="' + block.name + '">' + block.name + '</div>';

    // Single click: select
    btn.addEventListener('click', function(e) {
      if (e.target.closest('.mb-actions')) return;
      document.querySelectorAll('#myBlocksGrid .block-btn').forEach(function(b) { b.classList.remove('active'); });
      blockBtns.forEach(function(b) { b.classList.remove('active'); });
      state.selectedBlock = null;
      btn.classList.add('active');
      state.selectedMyBlock = block;
      insertBtn.disabled = false;
      try { document.querySelector('.fixed-bottom').classList.add('has-block'); } catch(e) {}
      setStatus(block.name + ' — dbl-click or INSERT to add', '');
    });

    // Double click: insert immediately
    btn.addEventListener('dblclick', function(e) {
      if (e.target.closest('.mb-actions')) return;
      insertMyBlock(block);
    });

    // Rename
    btn.querySelector('.mb-rename').addEventListener('click', function(e) {
      e.stopPropagation();
      var newName = prompt('Rename block:', block.name);
      if (newName) {
        newName = newName.replace(/^\s+|\s+$/g, '');
        if (newName && newName !== block.name) renameMyBlock(block, newName);
      }
    });

    // Delete
    btn.querySelector('.mb-delete').addEventListener('click', function(e) {
      e.stopPropagation();
      if (confirm('Delete "' + block.name + '"?')) deleteMyBlock(block);
    });

    grid.appendChild(btn);
  });
}

function insertMyBlock(block) {
  if (block.data && block.data.payload) {
    setStatus('Inserting...', '');
    cs.evalScript('createBlock(' + JSON.stringify(block.data.payload) + ')', function(result) {
      setStatus(result && result.indexOf('error') === 0 ? result : 'Inserted: ' + block.name,
                result && result.indexOf('error') === 0 ? 'err' : 'ok');
    });
  }
}

function deleteMyBlock(block) {
  try {
    fs.unlinkSync(path.join(state.myBlocksDir, block.file));
    loadMyBlocks();
    setStatus('Deleted: ' + block.name, 'ok');
  } catch(e) {
    setStatus('Delete failed: ' + e.message, 'err');
  }
}

function renameMyBlock(block, newName) {
  try {
    var safe = newName.replace(/[^a-zA-Z0-9_-]/g, '_');
    var newFile = safe + '.json';
    var oldPath = path.join(state.myBlocksDir, block.file);
    var newPath = path.join(state.myBlocksDir, newFile);
    var data = JSON.parse(fs.readFileSync(oldPath, 'utf8'));
    data.name = newName;
    fs.writeFileSync(newPath, JSON.stringify(data, null, 2));
    if (block.file !== newFile) fs.unlinkSync(oldPath);
    loadMyBlocks();
  } catch(e) {
    setStatus('Rename failed: ' + e.message, 'err');
  }
}

// ══════════════════════════════════════════════════════════════════════════
// LOG HELPERS
// ══════════════════════════════════════════════════════════════════════════
function appendLog(msg, cls) {
  if (!msg) return;
  var line = document.createElement('div');
  line.textContent = msg;
  if (cls) line.className = cls;
  aiLog.appendChild(line);
  aiLog.scrollTop = aiLog.scrollHeight;
}
function clearLog() { aiLog.innerHTML = ''; }

$('aiLogToggle').addEventListener('click', function() {
  var body = aiLog;
  body.style.display = body.style.display === 'none' ? 'block' : 'none';
});

var copyLogBtn = $('copyLogBtn');
copyLogBtn.addEventListener('click', function(e) {
  e.stopPropagation();
  var txt = aiLog.textContent;
  var ta = document.createElement('textarea');
  ta.value = txt;
  document.body.appendChild(ta);
  ta.select(); document.execCommand('copy');
  document.body.removeChild(ta);
  copyLogBtn.textContent = 'Copied!';
  setTimeout(function() { copyLogBtn.textContent = 'Copy'; }, 1500);
});

function setAiStatus(msg, cls) {
  aiStatus.textContent = msg;
  aiStatus.className = 'ai-status-msg' + (cls ? ' ' + cls : '');
}

// ══════════════════════════════════════════════════════════════════════════
// AI SERVICE STATUS CHECK
// ══════════════════════════════════════════════════════════════════════════
var dotClaude     = document.getElementById('dotClaude');
var dotNode       = document.getElementById('dotNode');
var aiServiceBar  = document.getElementById('aiServiceBar');

function checkAIStatus() {
  var env = Object.assign({}, process.env, { PATH: CHILD_PATH });

  // Reset to checking state
  dotClaude.className = 'ai-service-dot checking';
  dotNode.className   = 'ai-service-dot checking';

  // Check Claude CLI
  execFn(JSON.stringify(CLAUDE_BIN) + ' --version', { env: env, timeout: 6000 }, function(err, stdout) {
    dotClaude.className = err ? 'ai-service-dot err' : 'ai-service-dot ok';
    dotClaude.title     = err ? 'Claude CLI not found' : (stdout || '').trim().split('\n')[0];
  });

  // Check Node.js
  execFn('node --version', { env: env, timeout: 4000 }, function(err, stdout) {
    dotNode.className = err ? 'ai-service-dot err' : 'ai-service-dot ok';
    dotNode.title     = err ? 'Node.js not found on PATH' : (stdout || '').trim();
  });
}

aiServiceBar.addEventListener('click', checkAIStatus);

// ══════════════════════════════════════════════════════════════════════════
// DECK MODE
// ══════════════════════════════════════════════════════════════════════════

// ── DOM refs ──────────────────────────────────────────────────────────────
var aiDeckMode        = $('aiDeckMode');
var deckDropZone      = $('deckDropZone');
var deckFileInput     = $('deckFileInput');
var deckDropLabel     = $('deckDropLabel');
var deckClearBtn      = $('deckClearBtn');
var deckImportProgress = $('deckImportProgress');
var deckImportBar     = $('deckImportBar');
var deckImportMsg     = $('deckImportMsg');
var deckSlideListWrap = $('deckSlideListWrap');
var deckSlideList     = $('deckSlideList');
var deckSlideCountLabel = $('deckSlideCountLabel');
var deckOptionsRow    = $('deckOptionsRow');
var deckDuration      = $('deckDuration');

var deckGenRow        = $('deckGenRow');
var deckGenBtn        = $('deckGenBtn');
var deckProgress      = $('deckProgress');
var deckProgressBar   = $('deckProgressBar');
var deckProgressMsg   = $('deckProgressMsg');
var deckStatus        = $('deckStatus');

// ── Deck state ────────────────────────────────────────────────────────────
state.deckContent  = [];   // [{index, total, pngPath, text, notes}]
state.deckResults  = [];   // [{name, duration}]
state.deckRunning  = false;
state.deckPptxPath = null;

// ── Mode toggle: add 'deck' to existing handler ───────────────────────────
// Patch the existing toggle to also handle deck
document.querySelectorAll('.ai-gen-mode-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var mode = this.dataset.aimode;
    state.aiGenerateMode = mode;
    document.querySelectorAll('.ai-gen-mode-btn').forEach(function(b) {
      b.classList.toggle('active', b.dataset.aimode === mode);
    });
    aiMediaMode.style.display  = mode === 'media'  ? 'block' : 'none';
    aiPromptMode.style.display = mode === 'prompt' ? 'block' : 'none';
    aiDeckMode.style.display   = mode === 'deck'   ? 'block' : 'none';
    updateGenerateBtn();
  });
});


// ── updateGenerateBtn: account for deck mode ──────────────────────────────
function updateGenerateBtn() {
  var hasInput;
  if (state.aiGenerateMode === 'deck') {
    hasInput = state.deckContent.length > 0;
    generateBtn.style.display = 'none';   // deck has its own button
  } else {
    generateBtn.style.display = '';
    hasInput = state.aiGenerateMode === 'prompt'
      ? !!promptText.value.trim()
      : (!state.aiImagePath && !voScript.value.trim()) === false;
  }
  generateBtn.disabled = state.aiRunning || !hasInput;
}

// ── PPTX text extraction (Python — extracts visible slide text) ───────────
function extractPptxSlideTexts(pptxPath, cb) {
  var pyScript = [
    'import sys, zipfile, json, re',
    'import xml.etree.ElementTree as ET',
    'pptx = sys.argv[1]',
    'A = "http://schemas.openxmlformats.org/drawingml/2006/main"',
    'result = {"texts": {}, "hidden": []}',
    'try:',
    '    with zipfile.ZipFile(pptx) as z:',
    '        slides = sorted([n for n in z.namelist()',
    '                         if re.match(r"ppt/slides/slide\\d+\\.xml$", n)],',
    '                        key=lambda x: int(re.search(r"\\d+", x).group()))',
    '        for i, sf in enumerate(slides, 1):',
    '            root = ET.fromstring(z.read(sf))',
    '            txts = [t.text.strip()',
    '                    for t in root.iter("{%s}t" % A)',
    '                    if t.text and t.text.strip()]',
    '            if txts: result["texts"][str(i)] = " | ".join(txts)',
    '            # show="0" on the slide root marks a slide as hidden in PowerPoint.',
    '            if root.get("show") == "0":',
    '                result["hidden"].append(i)',
    'except Exception: pass',
    'print(json.dumps(result))'
  ].join('\n');
  var out = '';
  var proc = spawnFn('python3', ['-c', pyScript, pptxPath],
    { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) });
  proc.stdout.on('data', function(d) { out += d.toString(); });
  proc.on('close', function() {
    try {
      var parsed = JSON.parse(out.trim());
      // Backwards-compat shim: callers expect the old {num: text} map plus
      // an optional .hidden array attached. Normalise both old + new shapes.
      if (parsed && parsed.texts && Array.isArray(parsed.hidden)) {
        var flat = parsed.texts;
        flat.__hidden = parsed.hidden;
        cb(flat);
      } else {
        cb(parsed || {});
      }
    } catch(e) { cb({}); }
  });
  proc.on('error', function() { cb({}); });
}

// ── Load deck file (PPTX or PDF) ─────────────────────────────────────────
function deckSetImportProgress(pct, msg) {
  deckImportProgress.style.display = 'block';
  deckImportBar.style.width = Math.round(pct * 100) + '%';
  deckImportMsg.textContent = msg || '';
}

function handleDeckFile(filePath) {
  if (!filePath) return;
  state.deckPptxPath = filePath;
  var fname = path.basename(filePath);
  deckDropLabel.textContent = fname;
  deckDropZone.classList.add('has-file');
  deckClearBtn.style.display = 'block';
  deckSlideListWrap.style.display = 'none';
  deckOptionsRow.style.display = 'none';
  deckGenRow.style.display = 'none';
  deckStatus.textContent = '';
  state.deckContent = [];
  state.deckPreviewTypes = {};
  state.deckSkipped = {};
  state.deckCompNames = {};
  deckGenBtn.disabled = true;
  deckPreviewBtn.disabled = true;
  deckSetImportProgress(0.05, 'Loading…');

  var ext = path.extname(filePath).toLowerCase();
  var isPptx = (ext === '.pptx' || ext === '.ppt');

  function onSlides(err, pngs) {
    if (err) {
      deckImportProgress.style.display = 'none';
      deckStatus.textContent = 'Error: ' + err.message;
      deckStatus.style.color = '#f55';
      return;
    }
    deckSetImportProgress(0.7, 'Extracting text…');

    // Extract slide texts (PPTX only; PDF gets empty text)
    function onTexts(texts) {
      // Extract notes (PPTX only)
      function onNotes(notes) {
        deckImportProgress.style.display = 'none';

        var hiddenSet = {};
        if (texts && texts.__hidden) {
          texts.__hidden.forEach(function(i) { hiddenSet[i] = true; });
        }
        state.deckContent = pngs.map(function(pngPath, idx) {
          var num = String(idx + 1);
          var slideIdx = idx + 1;
          var isHidden = !!hiddenSet[slideIdx];
          // Hidden slides default to skipped so they don't get generated unless
          // the user explicitly opts in (they remain visible in the list).
          if (isHidden) state.deckSkipped[slideIdx] = true;
          return {
            index:   slideIdx,
            total:   pngs.length,
            pngPath: pngPath,
            text:    texts[num]  || '',
            notes:   notes[num]  || '',
            hidden:  isHidden
          };
        });

        renderDeckSlideList(state.deckContent);
        deckSlideListWrap.style.display = 'block';
        deckOptionsRow.style.display = 'flex';
        deckGenRow.style.display = 'block';
        deckGenBtn.disabled = false;
        deckPreviewBtn.disabled = false;
        deckSlideCountLabel.textContent = pngs.length + ' slide' + (pngs.length !== 1 ? 's' : '') + ' detected';
        updateGenerateBtn();
      }

      if (isPptx) {
        deckSetImportProgress(0.85, 'Extracting notes…');
        extractPptxNotes(filePath, onNotes);
      } else {
        onNotes({});
      }
    }

    if (isPptx) {
      extractPptxSlideTexts(filePath, onTexts);
    } else {
      onTexts({});
    }
  }

  if (isPptx) {
    deckSetImportProgress(0.1, 'Converting with LibreOffice…');
    convertPptxToSlides(filePath, onSlides);
  } else {
    deckSetImportProgress(0.2, 'Extracting slides…');
    convertPdfToSlides(filePath, onSlides);
  }
}

function clearDeckFile() {
  state.deckPptxPath = null;
  state.deckContent  = [];
  deckDropLabel.textContent = 'Drop PPTX or PDF';
  deckDropZone.classList.remove('has-file');
  deckClearBtn.style.display = 'none';
  deckImportProgress.style.display = 'none';
  deckSlideListWrap.style.display = 'none';
  deckOptionsRow.style.display = 'none';
  deckGenRow.style.display = 'none';
  deckStatus.textContent = '';
  deckFileInput.value = '';
  deckGenBtn.disabled = true;
  updateGenerateBtn();
}

// ── Render slide list ─────────────────────────────────────────────────────
var DECK_SLIDE_BLOCK_TYPES = [
  'slide-title','cards-1','cards-2','cards-3','cards-4','cards-5','cards-compare',
  'cards-media','cards-corner','cards-corner-sq','cards-corner-slim',
  'cards-specs-a','cards-specs-b','cards-specs-c',
  'cards-top-bar','cards-bottom-bar',
  'bullets','text-bullets','bullet-list','text-nested','text-2col','text-numbered',
  'text-code-cli','text-body-bullets','text-errors','text-links',
  'text-agenda','text-acronym','text-code-quad','text-code-split',
  'diagram-flow','diagram-flow-4','diagram-cycle','diagram-process-2',
  'diagram-timeline','diagram-funnel','diagram-matrix','diagram-steps',
  'diagram-chal-sol','diagram-flow-bullets-3',
  'diagram-parallel-split-ol','diagram-split-2-ol','diagram-split-3-ol',
  'diagram-split-5-ol','diagram-split-mirror-ol',
  'tree-3','tree-2level','tree-h3','tree-h5',
  'chart-bar','chart-bar-v','chart-bar-stacked','chart-donut',
  'table-bar','table-minimal','table-outlined',
  'rack-callout','comp-stat','comp-kpi','comp-quote','comp-divider'
];

function updateDeckSelectedCount() {
  // Hidden slides are excluded from the denominator — they're never selectable
  // (PowerPoint flagged them hidden) so "5 / 5 selected" is the correct read
  // even when the deck has 2 extra hidden rows shown in the list.
  var eligible = state.deckContent.filter(function(s) { return !s.hidden; });
  var selected = eligible.filter(function(s) { return !state.deckSkipped[s.index]; }).length;
  var el = $('deckSelectedCount');
  if (el) el.textContent = selected + ' / ' + eligible.length + ' selected';
}

function renderDeckSlideList(content) {
  deckSlideList.innerHTML = '';
  content.forEach(function(slide) {
    var item = document.createElement('div');
    item.className = 'deck-slide-item' + (slide.hidden ? ' deck-slide-hidden' : '');
    item.id = 'deckSlide_' + slide.index;
    if (slide.hidden) item.title = 'This slide is hidden in PowerPoint and won\'t be generated.';

    // Include toggle (checked = include, unchecked = skip)
    var toggleLabel = document.createElement('label');
    toggleLabel.className = 'deck-slide-toggle';
    toggleLabel.title = slide.hidden ? 'Slide is hidden in PowerPoint' : 'Include this slide';
    var toggleCb = document.createElement('input');
    toggleCb.type = 'checkbox';
    toggleCb.id = 'deckInclude_' + slide.index;
    toggleCb.checked = !state.deckSkipped[slide.index];
    if (slide.hidden) toggleCb.disabled = true;
    var toggleVis = document.createElement('span');
    toggleVis.className = 'deck-toggle-vis';
    toggleLabel.appendChild(toggleCb);
    toggleLabel.appendChild(toggleVis);
    (function(idx, el) {
      toggleCb.addEventListener('change', function() {
        state.deckSkipped[idx] = !this.checked;
        el.classList.toggle('deck-slide-skipped', !this.checked);
        updateDeckSelectedCount();
      });
    })(slide.index, item);

    var thumb = document.createElement('img');
    thumb.className = 'deck-slide-thumb';
    thumb.src = 'file://' + slide.pngPath;

    var info = document.createElement('div');
    info.className = 'deck-slide-info';

    var numRow = document.createElement('div');
    numRow.className = 'deck-slide-num-row';
    var num = document.createElement('span');
    num.className = 'deck-slide-num';
    num.textContent = 'Slide ' + slide.index;
    numRow.appendChild(num);
    if (slide.hidden) {
      var hiddenBadge = document.createElement('span');
      hiddenBadge.className = 'deck-slide-hidden-badge';
      hiddenBadge.textContent = 'Hidden';
      hiddenBadge.title = 'Marked hidden in PowerPoint';
      numRow.appendChild(hiddenBadge);
    }

    var txt = document.createElement('div');
    txt.className = 'deck-slide-text';
    txt.textContent = slide.text
      ? slide.text.substring(0, 70) + (slide.text.length > 70 ? '…' : '')
      : '(no text extracted)';

    info.appendChild(numRow);
    info.appendChild(txt);
    if (slide.notes) {
      var notes = document.createElement('div');
      notes.className = 'deck-slide-notes';
      notes.textContent = '● ' + slide.notes.substring(0, 55) + (slide.notes.length > 55 ? '…' : '');
      info.appendChild(notes);
    }

    // Right-side controls: type select + state + rerun
    var right = document.createElement('div');
    right.className = 'deck-slide-right';

    var typeSel = document.createElement('select');
    typeSel.className = 'deck-type-select';
    typeSel.id = 'deckTypeSelect_' + slide.index;
    if (slide.hidden) typeSel.disabled = true;
    var defOpt = document.createElement('option');
    defOpt.value = ''; defOpt.textContent = '— AI decides —';
    typeSel.appendChild(defOpt);
    DECK_SLIDE_BLOCK_TYPES.forEach(function(t) {
      var o = document.createElement('option'); o.value = t; o.textContent = t;
      typeSel.appendChild(o);
    });
    (function(idx, sel) {
      sel.addEventListener('change', function() {
        state.deckPreviewTypes[idx] = this.value;
        sel.classList.toggle('has-value', !!this.value);
      });
    })(slide.index, typeSel);

    var stateEl = document.createElement('div');
    stateEl.className = 'deck-slide-state';
    stateEl.id = 'deckState_' + slide.index;

    var rerunBtn = document.createElement('button');
    rerunBtn.className = 'deck-slide-rerun';
    rerunBtn.id = 'deckRerun_' + slide.index;
    rerunBtn.textContent = '↻';
    rerunBtn.title = 'Regenerate this slide';
    rerunBtn.style.display = 'none';
    (function(idx) {
      rerunBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        rerunDeckSlide(idx);
      });
    })(slide.index);

    right.appendChild(typeSel);
    right.appendChild(stateEl);
    right.appendChild(rerunBtn);

    item.appendChild(toggleLabel);
    item.appendChild(thumb);
    item.appendChild(info);
    item.appendChild(right);
    deckSlideList.appendChild(item);
  });

  updateDeckSelectedCount();
}

function setDeckSlideState(index, st) {
  var el = $('deckState_' + index);
  if (!el) return;
  el.className = 'deck-slide-state ' + st;
  el.textContent = st === 'done' ? '\u2713' : st === 'error' ? '\u2717' : st === 'skipped' ? '\u2014' : '\u29D7';
  var item = $('deckSlide_' + index);
  if (item) item.classList.toggle('generating', st === 'busy');
}

function showDeckSlideRerunBtn(index) {
  var btn = $('deckRerun_' + index);
  if (btn) btn.style.display = 'block';
}

// ── Drop zone handlers ────────────────────────────────────────────────────
deckDropZone.addEventListener('dragover', function(e) {
  e.preventDefault();
  deckDropZone.classList.add('drag-over');
});
deckDropZone.addEventListener('dragleave', function() {
  deckDropZone.classList.remove('drag-over');
});
deckDropZone.addEventListener('drop', function(e) {
  e.preventDefault();
  deckDropZone.classList.remove('drag-over');
  var f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) handleDeckFile(f.path);
});
deckFileInput.addEventListener('change', function() {
  var f = this.files && this.files[0];
  if (f) handleDeckFile(f.path);
});
deckClearBtn.addEventListener('click', function(e) {
  e.preventDefault();
  clearDeckFile();
});

// ── AI Deck System Prompt ─────────────────────────────────────────────────

var AI_DECK_BLOCK_INTELLIGENCE = [
  '## BLOCK SELECTION INTELLIGENCE',
  '',
  'You are a visual storytelling AI. Each slide must feel distinct. Match content TYPE to the',
  'most expressive block — never default to bullets or cards unless they are truly the best fit.',
  '',
  '### Content-to-Block mapping (use this as your primary decision guide)',
  '',
  'TITLE / SECTION',
  '  Opening title slide, deck name          → slide-title',
  '  Section break, chapter transition       → comp-divider',
  '',
  'FEATURES / BENEFITS (parallel items)',
  '  1 dominant feature or product           → cards-1',
  '  2 options side by side                  → cards-compare',
  '  3 features (default for most content)   → cards-3',
  '  4-5 compact features                    → cards-4, cards-5',
  '  Product spec sheet / GPU config         → cards-specs-a, cards-specs-b, cards-specs-c',
  '  2 cards each with image placeholder     → cards-media',
  '  Visual corner-accent cards              → cards-corner, cards-corner-sq',
  '  3 cards with top accent bar + circle    → cards-top-bar',
  '  3 cards with bottom accent bar + circle → cards-bottom-bar',
  '',
  'TEXT / LISTS',
  '  Numbered steps (how-to, instructions)   → text-numbered',
  '  Nested hierarchy (main + sub-points)    → text-nested',
  '  Flat standalone bullets (no card)       → text-bullets',
  '  Simple bullet card                      → bullets',
  '  Two-column list                         → text-2col',
  '  CLI commands / flags explained          → text-cli',
  '  Code snippets with labels              → text-code-bullets',
  '  Terminal output + context              → text-code-cli',
  '  Error codes, causes, fixes             → text-errors',
  '  URLs / resource links                  → text-links',
  '  Paragraph + side features             → text-body-bullets',
  '  Agenda / table of contents (TOC)       → text-agenda',
  '  Acronym breakdown (letter + word)      → text-acronym',
  '  4 code snippets in a 2x2 grid          → text-code-quad',
  '  Bullets on left, code block right      → text-code-split',
  '',
  'PROCESS / FLOW',
  '  Linear 2-5 step pipeline (with body)   → diagram-flow',
  '  Circular process / lifecycle           → diagram-cycle',
  '  3 parallel flows with bullets          → diagram-flow-bullets-3',
  '  One input splits to 2 outputs          → diagram-parallel-split-ol',
  '  One input → 2 result cards             → diagram-split-2-ol',
  '  One input → 3 result cards             → diagram-split-3-ol',
  '  One input → 5 result cards             → diagram-split-5-ol',
  '  Funnel / narrowing stages              → diagram-funnel',
  '  2×N process matrix                     → diagram-process-2',
  '  Timeline / milestone sequence / Phase 1-N progression → diagram-timeline',
  '  Numbered steps in chevron cascade      → diagram-steps',
  '  Central hub with radial nodes          → diagram-hub-spoke',
  '  Priority/effort matrix                 → diagram-matrix',
  '',
  'HIERARCHY / TREE',
  '  Vertical: root + 3 children            → tree-3',
  '  Vertical: root + 2 levels (1+2+4)      → tree-2level',
  '  Horizontal: root → 3 branches          → tree-h3',
  '  Horizontal: root → 5 branches          → tree-h5',
  '',
  'DATA / METRICS',
  '  Horizontal bar chart (up to 8 bars)    → chart-bar',
  '  Vertical bar chart                     → chart-bar-v',
  '  Stacked / grouped bars                 → chart-bar-stacked',
  '  Proportions / distribution             → chart-donut',
  '  ONE dominant number or %              → comp-stat',
  '  2-5 KPI metrics side by side          → comp-kpi',
  '',
  'TABLES',
  '  Structured comparison, 1-4 columns     → table-1col, table-2col, table-3col, table-4col',
  '',
  'COMPONENTS',
  '  Server rack diagram                    → rack-callout',
  '  Compact roadmap component (3-5 items, used as overlay/section element) → comp-timeline',
  '  Partner / ecosystem logos              → comp-logo-strip',
  '  Traditional vs NVIDIA comparison       → comp-compare',
  '  Technology stack / stack chips         → comp-tags',
  '  Insight card / lower third             → comp-callout',
  '  Icon category grid                     → comp-icon-grid',
  '  Hardware / product spec card           → cards-device',
  '',
  'INFRASTRUCTURE / TECHNICAL',
  '  GH200 node pair                        → topology-gh200',
  '  NVLink switch fabric                   → topology-nvlink-switch',
  '  Spine-leaf network                     → topology-spine-leaf',
  '  GPU node internals                     → topology-gpu-node',
  '  Multi-rack cluster                     → topology-multi-rack',
  '',
  'STANDALONE MOMENTS',
  '  Impactful quote / testimonial          → comp-quote',
  '  Section divider with number + title   → comp-divider',
  '  Single dominant KPI                    → comp-stat',
  '',
  '### VARIETY AND STORYTELLING RULES',
  '',
  '1. INTENTIONAL VARIETY: Different content shapes deserve different blocks. If two adjacent slides',
  '   both genuinely call for the same block, that\'s fine — but if you find yourself reaching for',
  '   cards-3 a third time in five slides, stop and look harder at the content.',
  '2. VISUAL OVER TEXT: When content could be rendered as either a list OR a diagram/chart,',
  '   always choose the diagram or chart. Lists are last resort.',
  '3. NUMBERS AND PERCENTAGES always trigger chart-bar, chart-donut, comp-stat, or comp-kpi.',
  '4. SLIDE POSITION awareness:',
  '   - First slide of deck → slide-title',
  '   - "Section X" or chapter header → comp-divider',
  '   - Last slide of deck → comp-quote or slide-title',
  '   - Metric/data slide → chart or comp-kpi/comp-stat',
  '   - Process/workflow slide → diagram-flow or diagram-cycle',
  '   - Closing/summary slide → cards-3 with benefits or comp-quote',
  '   - Agenda/overview slide → text-agenda',
  '   - Problem + solution pairing → cards-compare (leftColor:"890C58", rightColor:"76B900")',
  '5. USE THE FULL RANGE: Across a 10-slide deck, aim for at least 6 different block types.',
  '   Available but often underused: diagram-hub-spoke, diagram-steps, tree-h3, tree-h5, diagram-timeline, comp-quote, comp-divider.',
  '6. SCALE TO ITEM COUNT:',
  '   - 1 key item → comp-stat, cards-1, or slide-title',
  '   - 2 things compared → cards-compare',
  '   - 3 items → diagram-flow, cards-3, or tree-3',
  '   - 4-5 items → cards-4/5, diagram-flow (cardCount:5), diagram-cycle',
  '   - 5-12 connected items radiating from one center → diagram-hub-spoke',
  '   - 5-10 sequential numbered steps → diagram-steps',
  '   - 4+ items in a hierarchy → tree-3, tree-h3, or tree-h5',
  '   - 7+ rows of structured data → table-*',
  '7. THINK LIKE A DESIGNER: What is the most impactful way to present this specific content?',
  '   A process should be a flow. Metrics should be a chart. A comparison should use compare.',
  '   Only use bullets/cards when no more specific block fits.',
  '',
  '### MULTI-BLOCK COMPOSITION (deck mode is the BIGGEST WIN for this)',
  '',
  'Across a full deck, aim for at least 20-30% of slides to use multi-block compositions',
  '(multiLayout). Slides that BEG for composition:',
  '  • A stat/KPI + supporting bullets    → split-h: comp-stat | check-list',
  '  • Concept (left) + benefits (right)  → split-h: cards-1 | text-bullets',
  '  • Diagram + explanation               → split-h: diagram-flow | text-body-bullets',
  '  • Timeline (top) + details (bottom)   → split-v: diagram-timeline | cards-3',
  '  • Quote + author KPIs                 → split-h: comp-quote | comp-kpi',
  '  • Section header + agenda preview     → split-v: comp-divider | text-agenda',
  '  • Hub-spoke + tag stack               → split-h: diagram-hub-spoke | comp-tags',
  '',
  'Compositions make the deck feel intentional and edited, not templated. Reach for them.'
].join('\n');

var AI_DECK_SYSTEM_PROMPT = AI_SYSTEM_PROMPT
  // Deck mode prefers visible cards (better at video distance). cardBorder ON,
  // dropShadow stays OFF (Foundations rule), cardBg explicitly off.
  .replace('- cardBorder: false\n- dropShadow: true',
           '- cardBorder: true\n- dropShadow: false\n- cardBg: false')
  // Inject the deck block intelligence right before the output section so the
  // deck prompt actually carries the deck-specific rules. (The old replacement
  // target "## Output\\nReturn ONLY the JSON object." no longer exists in the
  // prompt, so for years this injection silently no-op'd — fixed now.)
  .replace('━━━ OUTPUT ━━━',
           AI_DECK_BLOCK_INTELLIGENCE + '\n\n━━━ OUTPUT ━━━');

// ── Variety enforcement: specific ID banning + category guidance ───────────
function buildVarietyInstruction(previousPicks) {
  if (!previousPicks || !previousPicks.length) return '';
  var types = previousPicks.map(function(p) { return typeof p === 'string' ? p : p.blockType; });

  // Count per specific ID across the entire deck so far
  var idCounts = {};
  types.forEach(function(t) { idCounts[t] = (idCounts[t] || 0) + 1; });

  // Any ID used 2+ times is forbidden for the rest of the deck
  var forbidden = Object.keys(idCounts).filter(function(t) { return idCounts[t] >= 2; });
  // Also always forbid the immediately previous block ID (no back-to-back repeats)
  var last = types[types.length - 1];
  if (last && forbidden.indexOf(last) === -1) forbidden.push(last);

  var recent = types.slice(-3);
  var isText    = function(t) { return t.indexOf('text-') === 0 || t === 'bullets' || t === 'bullet-list' || t === 'text-bullets'; };
  var isDiagram = function(t) { return t.indexOf('diagram-') === 0; };
  var isCard    = function(t) { return t.indexOf('cards-') === 0; };
  var textCount    = recent.filter(isText).length;
  var diagramCount = recent.filter(isDiagram).length;
  var cardCount    = recent.filter(isCard).length;

  var msg = '\nPREVIOUS SLIDES: ' + types.join(', ') + '\n';

  // Specific ID bans — highest priority
  if (forbidden.length) {
    msg += 'FORBIDDEN — do NOT use these exact blockType IDs: ' + forbidden.join(', ') + '\n';
  }

  // Category-level guidance — secondary
  if (isCard(last) && cardCount >= 2) {
    msg += 'MANDATORY: Cards used repeatedly. Pick a NON-CARDS block: diagram-*, chart-*, comp-*, tree-*, table-*.\n';
  } else if (isText(last) && textCount >= 2) {
    msg += 'MANDATORY: Text blocks used repeatedly. Pick a VISUAL block: diagram-*, chart-*, comp-*, cards-*, tree-*, table-*.\n';
  } else if (isDiagram(last) && diagramCount >= 2) {
    msg += 'MANDATORY: Diagrams used repeatedly. Pick NON-DIAGRAM: cards-*, text-*, chart-*, comp-*, table-*.\n';
  } else {
    msg += 'Maximize visual variety. Prefer the category least used so far in this deck.\n';
  }

  return msg;
}

// ── Build per-slide messages ──────────────────────────────────────────────
function buildDeckSlideMessages(slideData, previousPicks) {
  var isFirst  = slideData.index === 1;
  var isLast   = slideData.index === slideData.total;
  var position = isFirst ? 'FIRST slide — consider slide-title or comp-divider.'
               : isLast  ? 'LAST slide — consider a summary (cards-3) or impactful close (comp-quote, comp-stat).'
               : 'Slide ' + slideData.index + ' of ' + slideData.total + ' — pick the most VISUALLY EXPRESSIVE block.';

  var msg = 'SLIDE ' + slideData.index + ' OF ' + slideData.total + '\n';
  msg += 'Position: ' + position + '\n\n';
  if (slideData.text)  { msg += 'Slide text:\n'      + slideData.text  + '\n\n'; }
  if (slideData.notes) { msg += 'Voiceover notes:\n' + slideData.notes + '\n\n'; }

  var forcedType = state.deckPreviewTypes[slideData.index] || '';
  if (forcedType) {
    msg += 'MANDATORY: You MUST use blockType "' + forcedType + '". Fill all required schema fields for that block type.\n';
  } else {
    var varietyNote = buildVarietyInstruction(previousPicks || []);
    if (varietyNote) msg += varietyNote;
    msg += 'Choose the single best EasyBlocks block using the Block Selection Intelligence guide.\n';
    msg += 'Think: What content TYPE is this? What block makes it most VISUAL and IMPACTFUL?\n';
  }
  msg += 'Return ONLY the JSON.';
  return { systemPrompt: AI_DECK_SYSTEM_PROMPT, userMessage: msg };
}

// ── Parse deck slide AI output (same as parseAiOutput but inject-aware) ───
function parseDeckSlideOutput(raw) {
  var clean = raw.replace(/^```[a-z]*\n?/i, '').replace(/\n?```$/i, '').trim();
  try {
    var obj = JSON.parse(clean);
    if (obj && obj.blockType) return obj;
  } catch(e) {}
  var m = clean.match(/\{[\s\S]*\}/);
  if (m) { try { var o2 = JSON.parse(m[0]); if (o2 && o2.blockType) return o2; } catch(e) {} }
  return null;
}

// ── Process one slide: spawn bridge → create block → apply injectables ────
function _spawnDeckBridge(systemPrompt, userMessage, imagePath, onDone) {
  var extPath    = cs.getSystemPath(SystemPath.EXTENSION);
  var bridge     = path.join(extPath, 'scripts', 'ai-generate.js');
  var configPath = path.join(os.tmpdir(), 'ebp_deck_' + Date.now() + '_' + Math.random().toString(36).slice(2) + '.json');
  var outputPath = configPath.replace('.json', '_out.txt');

  try {
    fs.writeFileSync(configPath, JSON.stringify({
      systemPrompt: systemPrompt,
      userMessage:  userMessage,
      imagePath:    imagePath || null,
      outputPath:   outputPath,
      model:        'claude-opus-5'
    }), 'utf8');
  } catch(e) { onDone(null); return; }

  var env = Object.assign({}, process.env, { PATH: CHILD_PATH });
  delete env.CLAUDECODE;

  var child;
  try { child = spawnFn(NODE_BIN, [bridge, '--config', configPath], { env: env, cwd: os.tmpdir() }); }
  catch(e) { onDone(null); return; }

  child.stderr.on('data', function() {});
  child.stdout.on('data', function() {});

  child.on('close', function(code) {
    try { fs.unlinkSync(configPath); } catch(e) {}
    if (code !== 0) { onDone(null); return; }
    var raw;
    try { raw = fs.readFileSync(outputPath, 'utf8').trim(); } catch(e) { onDone(null); return; }
    try { fs.unlinkSync(outputPath); } catch(e) {}
    onDone(raw || null);
  });
}

function processOneDeckSlide(slideData, previousPicks, cb) {
  var msgs    = buildDeckSlideMessages(slideData, previousPicks);
  var imgPath = slideData.pngPath || null;

  // ── Pass 1: Planning ──────────────────────────────────────────────────────
  _spawnDeckBridge(AI_PLAN_PROMPT, msgs.userMessage, imgPath, function(raw1) {
    if (!raw1) {
      _runDeckSinglePass(msgs, imgPath, slideData, cb);
      return;
    }

    var plan = null;
    try {
      var clean1 = raw1.replace(/^```[a-z]*\n?/, '').replace(/```$/, '').trim();
      plan = JSON.parse(clean1);
    } catch(e) {}

    if (!plan || !plan.blockType || KNOWN_BLOCK_IDS.indexOf(plan.blockType) === -1) {
      _runDeckSinglePass(msgs, imgPath, slideData, cb);
      return;
    }

    // ── Pass 2: Content generation with plan injected ─────────────────────
    var planContext = '\n\n## Design Plan (follow exactly):\n' +
      'Block: ' + plan.blockType + '\n' +
      'Accent color: ' + plan.accentColor + '\n' +
      (plan.bodyStyle ? 'Body style: ' + plan.bodyStyle + '\n' : '') +
      'Items: ' + plan.itemCount + '\n' +
      'Strategy: ' + plan.contentStrategy + '\n\n' +
      'MANDATORY: Use blockType "' + plan.blockType + '". Use accentColor "' + plan.accentColor + '". Generate exactly ' + plan.itemCount + ' items.';

    _spawnDeckBridge(msgs.systemPrompt, msgs.userMessage + planContext, null, function(raw2) {
      if (!raw2) { cb(false, null, null); return; }
      _finishDeckSlide(raw2, slideData, cb);
    });
  });
}

function _runDeckSinglePass(msgs, imgPath, slideData, cb) {
  _spawnDeckBridge(msgs.systemPrompt, msgs.userMessage, imgPath, function(raw) {
    if (!raw) { cb(false, null, null); return; }
    _finishDeckSlide(raw, slideData, cb);
  });
}

function _finishDeckSlide(raw, slideData, cb) {
  var parsed = parseDeckSlideOutput(raw);
  if (!parsed) { cb(false, null, null); return; }

  var chosenBlockType = parsed.blockType;
  delete parsed.inject;

  // Deck-specific overrides
  var slideNum = slideData.index;
  parsed.compNamePrefix = 'Slide_' + (slideNum < 10 ? '0' : '') + slideNum + '_';
  parsed.cardBorder = true;
  parsed.dropShadow = true;
  parsed.cardBg = false;

  // Create the block comp
  cs.evalScript('createBlock(' + JSON.stringify(JSON.stringify(parsed)) + ')', function(result) {
    if (!result || result.indexOf('ok|') !== 0) { cb(false, null, null); return; }
    var compName = result.split('|')[1];
    cb(true, compName, chosenBlockType);
  });
}

// ── Shared: update slide type select (badge removed) ─────────────────────
function updateSlideBadge(index, blockType, dimmed) {
  var sel = $('deckTypeSelect_' + index);
  if (!sel || !blockType) return;
  if (!sel.value) {
    sel.value = blockType;
    sel.classList.toggle('has-value', !!sel.value);
  }
  if (dimmed) sel.style.opacity = '0.6';
}

// ── Batch process all slides (two-pass: Plan → Generate) ──────────────────
function runDeckGenerate() {
  if (state.deckRunning || !state.deckContent.length) return;
  state.deckRunning   = true;
  state.deckResults   = [];
  deckGenBtn.disabled    = true;
  deckPreviewBtn.disabled = true;
  deckProgress.style.display = 'block';
  deckStatus.textContent = '';
  var deckRetryBtn = $('deckRetryBtn');
  if (deckRetryBtn) deckRetryBtn.style.display = 'none';

  var dur       = parseInt(deckDuration.value, 10) || 7;
  var genPicks  = [];
  var queue     = state.deckContent.filter(function(s) { return !state.deckSkipped[s.index]; });
  var totalActive = queue.length;
  var genStartTime = null;
  var genDone      = 0;

  // ── Pass 0: Plan block types for every slide ─────────────────────────────
  // Fast lightweight calls (returns only {"blockType":"..."}) run sequentially
  // so variety enforcement works. Sets state.deckPreviewTypes before generation.
  var planPicks = [];
  deckProgressMsg.textContent = 'Step 1 of 2: Planning deck structure…';
  deckProgressBar.style.width = '3%';

  function planNext(idx) {
    if (idx >= queue.length) { startGeneration(); return; }
    var slide = queue[idx];
    var pct = 3 + Math.round((idx / queue.length) * 30);
    deckProgressBar.style.width = pct + '%';
    deckProgressMsg.textContent = 'Planning ' + (idx + 1) + ' of ' + totalActive + '…';

    previewOneSlideType(slide, planPicks, function(bt) {
      if (bt) {
        planPicks.push({ index: slide.index, blockType: bt });
        // Only set if user hasn't manually chosen a type
        if (!state.deckPreviewTypes[slide.index]) {
          state.deckPreviewTypes[slide.index] = bt;
        }
        updateSlideBadge(slide.index, state.deckPreviewTypes[slide.index], true);
      }
      planNext(idx + 1);
    });
  }

  // ── Pass 1: Generate content for each slide ───────────────────────────────
  function startGeneration() {
    genStartTime = Date.now();
    deckProgressMsg.textContent = 'Step 2 of 2: Generating slides…';
    deckProgressBar.style.width = '33%';
    processNext(0);
  }

  function processNext(idx) {
    if (idx >= state.deckContent.length) { finishDeckGenerate(); return; }
    var slide = state.deckContent[idx];

    if (state.deckSkipped[slide.index]) {
      setDeckSlideState(slide.index, 'skipped');
      processNext(idx + 1);
      return;
    }

    // Progress: 33–93%
    var pct = 33 + Math.round((genDone / totalActive) * 60);
    deckProgressBar.style.width = pct + '%';

    // ETA
    if (genStartTime && genDone > 0) {
      var elapsed   = Date.now() - genStartTime;
      var perSlide  = elapsed / genDone;
      var secLeft   = Math.round(((totalActive - genDone) * perSlide) / 1000);
      var etaStr    = secLeft > 90 ? Math.ceil(secLeft / 60) + ' min' : secLeft + 's';
      deckProgressMsg.textContent = 'Slide ' + slide.index + ' of ' + slide.total + ' — ~' + etaStr + ' left';
    } else {
      deckProgressMsg.textContent = 'Generating slide ' + slide.index + ' of ' + slide.total + '…';
    }

    setDeckSlideState(slide.index, 'busy');
    processOneDeckSlide(slide, genPicks, function(ok, compName, blockType) {
      if (ok && compName) {
        if (blockType) genPicks.push(blockType);
        setDeckSlideState(slide.index, 'done');
        updateSlideBadge(slide.index, blockType, false);
        state.deckResults.push({ name: compName, duration: dur, _slideIndex: slide.index });
        state.deckCompNames[slide.index] = compName;
        showDeckSlideRerunBtn(slide.index);
      } else {
        setDeckSlideState(slide.index, 'error');
      }
      genDone++;
      var el = $('deckSlide_' + slide.index);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      processNext(idx + 1);
    });
  }

  planNext(0);
}

function finishDeckGenerate() {
  var valid   = state.deckResults.filter(function(r) { return r && r.name; });
  var errored = state.deckContent.filter(function(s) {
    var st = $('deckState_' + s.index);
    return st && st.className.indexOf('error') !== -1;
  });
  var deckRetryBtn = $('deckRetryBtn');
  deckProgressBar.style.width = '95%';
  deckProgressMsg.textContent = 'Assembling master comp…';

  if (!valid.length) {
    state.deckRunning = false;
    deckGenBtn.disabled = false;
    deckPreviewBtn.disabled = false;
    deckProgress.style.display = 'none';
    deckStatus.textContent = 'No slides were generated successfully.';
    deckStatus.style.color = '#f55';
    if (deckRetryBtn) deckRetryBtn.style.display = 'inline-block';
    return;
  }

  var slideDataJSON = JSON.stringify(valid);
  cs.evalScript('createDeckMasterComp(' + JSON.stringify(slideDataJSON) + ')', function(result) {
    state.deckRunning = false;
    deckGenBtn.disabled = false;
    deckPreviewBtn.disabled = false;
    deckProgress.style.display = 'none';
    deckProgressBar.style.width = '0%';

    if (result && result.indexOf('ok|') === 0) {
      var masterName = result.split('|')[1];
      deckStatus.textContent = '\u2713 Deck ready: ' + masterName
        + ' (' + valid.length + ' of ' + state.deckContent.length + ' slides)';
      deckStatus.style.color = 'var(--accent)';
    } else {
      deckStatus.textContent = 'Master comp failed: ' + result;
      deckStatus.style.color = '#f55';
    }
    // Show retry button if any slides errored
    if (deckRetryBtn && errored.length) deckRetryBtn.style.display = 'inline-block';
  });
}

function retryFailedSlides() {
  if (state.deckRunning) return;
  var failed = state.deckContent.filter(function(s) {
    var st = $('deckState_' + s.index);
    return st && st.className.indexOf('error') !== -1;
  });
  if (!failed.length) return;

  state.deckRunning = true;
  deckGenBtn.disabled = true;
  var deckRetryBtn = $('deckRetryBtn');
  if (deckRetryBtn) deckRetryBtn.style.display = 'none';
  deckProgress.style.display = 'block';
  deckStatus.textContent = '';
  var dur = parseInt(deckDuration.value, 10) || 7;
  var done = 0;

  function retryNext(idx) {
    if (idx >= failed.length) {
      state.deckRunning = false;
      deckGenBtn.disabled = false;
      deckProgress.style.display = 'none';
      var stillFailed = failed.filter(function(s) {
        var st = $('deckState_' + s.index);
        return st && st.className.indexOf('error') !== -1;
      });
      deckStatus.textContent = (failed.length - stillFailed.length) + ' recovered'
        + (stillFailed.length ? ', ' + stillFailed.length + ' still failed' : '') + '.';
      deckStatus.style.color = stillFailed.length ? '#f55' : 'var(--accent)';
      return;
    }
    var slide = failed[idx];
    done++;
    deckProgressBar.style.width = Math.round((done / failed.length) * 100) + '%';
    deckProgressMsg.textContent = 'Retrying slide ' + slide.index + ' (' + done + ' of ' + failed.length + ')…';
    setDeckSlideState(slide.index, 'busy');
    processOneDeckSlide(slide, [], function(ok, compName, blockType) {
      if (ok && compName) {
        setDeckSlideState(slide.index, 'done');
        updateSlideBadge(slide.index, blockType, false);
        state.deckCompNames[slide.index] = compName;
        var found = false;
        for (var j = 0; j < state.deckResults.length; j++) {
          if (state.deckResults[j]._slideIndex === slide.index) {
            state.deckResults[j].name = compName; found = true; break;
          }
        }
        if (!found) state.deckResults.push({ name: compName, duration: dur, _slideIndex: slide.index });
        showDeckSlideRerunBtn(slide.index);
      } else {
        setDeckSlideState(slide.index, 'error');
      }
      retryNext(idx + 1);
    });
  }
  retryNext(0);
}

deckGenBtn.addEventListener('click', runDeckGenerate);
deckPreviewBtn.addEventListener('click', runDeckPreview);

// ── Select All / None ─────────────────────────────────────────────────────
var deckSelectAllBtn  = $('deckSelectAll');
var deckSelectNoneBtn = $('deckSelectNone');
if (deckSelectAllBtn) {
  deckSelectAllBtn.addEventListener('click', function() {
    state.deckContent.forEach(function(s) {
      if (s.hidden) return; // hidden slides are locked-skipped — leave untouched
      state.deckSkipped[s.index] = false;
      var cb = $('deckInclude_' + s.index);
      if (cb) cb.checked = true;
      var row = $('deckSlide_' + s.index);
      if (row) row.classList.remove('deck-slide-skipped');
    });
    updateDeckSelectedCount();
  });
}
if (deckSelectNoneBtn) {
  deckSelectNoneBtn.addEventListener('click', function() {
    state.deckContent.forEach(function(s) {
      if (s.hidden) return;
      state.deckSkipped[s.index] = true;
      var cb = $('deckInclude_' + s.index);
      if (cb) cb.checked = false;
      var row = $('deckSlide_' + s.index);
      if (row) row.classList.add('deck-slide-skipped');
    });
    updateDeckSelectedCount();
  });
}

// ── Per-slide re-run ──────────────────────────────────────────────────────
function rerunDeckSlide(slideIndex) {
  if (state.deckRunning) return;
  var slide = null;
  for (var i = 0; i < state.deckContent.length; i++) {
    if (state.deckContent[i].index === slideIndex) { slide = state.deckContent[i]; break; }
  }
  if (!slide) return;
  setDeckSlideState(slideIndex, 'busy');
  var dur = parseInt(deckDuration.value, 10) || 7;
  processOneDeckSlide(slide, [], function(ok, compName) {
    if (ok && compName) {
      setDeckSlideState(slideIndex, 'done');
      state.deckCompNames[slideIndex] = compName;
      // Update existing result or push new
      var found = false;
      for (var j = 0; j < state.deckResults.length; j++) {
        if (state.deckResults[j]._slideIndex === slideIndex) {
          state.deckResults[j].name = compName; found = true; break;
        }
      }
      if (!found) state.deckResults.push({ name: compName, duration: dur, _slideIndex: slideIndex });
    } else {
      setDeckSlideState(slideIndex, 'error');
    }
  });
}

// ── Deck block type preview pass ──────────────────────────────────────────
// Sequential so each slide knows previous picks — enforces variety.
// Uses full AI_DECK_SYSTEM_PROMPT + sonnet; output is tiny so still fast.
function runDeckPreview() {
  if (state.deckRunning || !state.deckContent.length) return;
  deckPreviewBtn.disabled = true;

  var queue  = state.deckContent.filter(function(s) { return !state.deckSkipped[s.index]; });
  var total  = queue.length;
  var done   = 0;
  var picks  = [];   // [{index, blockType}] — passed forward for variety

  // Mark all as pending
  queue.forEach(function(s) {
    var sel = $('deckTypeSelect_' + s.index);
    if (sel) sel.style.opacity = '0.5';
  });

  function next(idx) {
    if (idx >= queue.length) {
      deckPreviewBtn.disabled = false;
      deckPreviewBtn.textContent = 'Preview Types';
      return;
    }
    var slide = queue[idx];
    deckPreviewBtn.textContent = 'Previewing ' + (idx + 1) + '/' + total + '…';

    previewOneSlideType(slide, picks, function(bt) {
      done++;
      var sel = $('deckTypeSelect_' + slide.index);
      if (bt) {
        picks.push({ index: slide.index, blockType: bt });
        state.deckPreviewTypes[slide.index] = bt;
        updateSlideBadge(slide.index, bt, false);
      } else {
        if (sel) sel.style.opacity = '1';
      }
      next(idx + 1);
    });
  }

  next(0);
}

function previewOneSlideType(slideData, previousPicks, cb) {
  var extPath    = cs.getSystemPath(SystemPath.EXTENSION);
  var bridge     = path.join(extPath, 'scripts', 'ai-generate.js');
  var ts         = Date.now() + '_' + slideData.index;
  var configPath = path.join(os.tmpdir(), 'ebp_prev_' + ts + '.json');
  var outputPath = path.join(os.tmpdir(), 'ebp_prev_out_' + ts + '.txt');

  // Build user message — same structure as full generation but asks for blockType only
  var isFirst = slideData.index === 1;
  var isLast  = slideData.index === slideData.total;
  var position = isFirst ? 'FIRST slide — slide-title is likely correct.'
               : isLast  ? 'LAST slide — consider comp-quote, comp-stat, or cards-3 summary.'
               : 'Slide ' + slideData.index + ' of ' + slideData.total;

  var userMsg = 'SLIDE ' + slideData.index + ' OF ' + slideData.total + '\n';
  userMsg += 'Position: ' + position + '\n';
  if (slideData.text)  userMsg += '\nSlide text:\n'      + slideData.text.slice(0, 500) + '\n';
  if (slideData.notes) userMsg += '\nNotes:\n' + slideData.notes.slice(0, 200) + '\n';

  var varietyNote = buildVarietyInstruction(previousPicks);
  if (varietyNote) userMsg += varietyNote;

  userMsg += '\nUsing the Block Selection Intelligence guide, pick the BEST block for this specific content.';
  userMsg += '\nReturn ONLY {"blockType":"<type>"}. No other fields, no markdown.';

  try {
    fs.writeFileSync(configPath, JSON.stringify({
      systemPrompt: AI_DECK_SYSTEM_PROMPT,
      userMessage:  userMsg,
      imagePath:    slideData.pngPath || null,
      outputPath:   outputPath,
      model:        'claude-opus-5'
    }), 'utf8');
  } catch(e) { cb(null); return; }

  var env = Object.assign({}, process.env, { PATH: CHILD_PATH });
  delete env.CLAUDECODE;
  var child;
  try { child = spawnFn(NODE_BIN, [bridge, '--config', configPath], { env: env, cwd: os.tmpdir() }); }
  catch(e) { cb(null); return; }
  child.stderr.on('data', function() {});
  child.stdout.on('data', function() {});
  child.on('close', function(code) {
    try { fs.unlinkSync(configPath); } catch(e) {}
    if (code !== 0) { cb(null); return; }
    try {
      var raw = fs.readFileSync(outputPath, 'utf8').trim();
      try { fs.unlinkSync(outputPath); } catch(e) {}
      var m = raw.match(/"blockType"\s*:\s*"([^"]+)"/);
      cb(m ? m[1] : null);
    } catch(e) { cb(null); }
  });
}

// ══════════════════════════════════════════════════════════════════════════
// INIT
// ══════════════════════════════════════════════════════════════════════════
loadMyBlocks();
updateGenerateBtn();
checkAIStatus();
