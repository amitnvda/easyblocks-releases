// utils.jsx -- Shared utilities for EasyBlocks
// ASCII-only: AE's ExtendScript engine reads JSX as Latin-1, not UTF-8.
var _EB_UTILS_VERSION = '1.2.1-fix';

// Set to true to skip ALL animation keyframes (opacity + position). Controlled by
// params.posAnim -- hostscript.jsx sets this before calling any block function.
// Use $.global to guarantee a single shared variable across all $.evalFile scopes.
$.global._ebSkipPosAnim = false;

// --- Brand colors (AE normalized 0-1 RGBA) ---
// All colors include alpha=1 for shape Fill/Stroke properties.
// TextDocument.fillColor uses only the first 3 elements (RGB).
var EB_COLORS = {
  '76B900': [118/255, 185/255,   0/255, 1],
  '008564': [  0/255, 133/255, 100/255, 1],
  '5D1682': [ 93/255,  22/255, 130/255, 1],
  '0071C5': [  0/255, 113/255, 197/255, 1],
  '890C58': [137/255,  12/255,  88/255, 1],
  'FAC200': [250/255, 194/255,   0/255, 1],
  '000000': [0, 0, 0, 1],
  '5E5E5E': [ 94/255,  94/255,  94/255, 1],
  '8C8C8C': [140/255, 140/255, 140/255, 1],
  'CDCDCD': [205/255, 205/255, 205/255, 1]
};

// Font PostScript names — must match fonts installed in AE (or bundled in /fonts/).
// Available weights: Bold, Medium, Regular, Light (no SemiBold in the NVIDIA Sans pack).
// To verify a PostScript name: Font Book > select font > Cmd+I > PostScript name field.
var EB_FONTS = {
  bold:     'NVIDIASans-Bold',
  semibold: 'NVIDIASans-Medium',   // no SemiBold in pack — Medium is closest
  medium:   'NVIDIASans-Medium',
  regular:  'NVIDIASans-Regular',
  light:    'NVIDIASans-Light',
  mono:     'CourierNewPSMT'
};

// Layout constants (1920x1080 base)
// EasyBlocks layout tokens — aligned with the NVIDIA Academy Foundations
// design system (talexand88.github.io/Nvidia-academy-foundations). Type scale
// uses Foundations sizes (cover 76, title 55, subtitle 38, card title 34,
// body 30, caption 22). Spacing follows the Academy 6-tier scale.
// Surface treatment: outline-first cards, max 4px radius, no shadows by default.
var EB_LAYOUT = {
  compW:         1920,
  compH:         1080,
  marginX:         80,
  titleCenterX:   960,
  titleY:         108,
  subtitleY:      165,
  cardTop:        230,
  cardBottom:     980,
  cardGap:         30,
  bracketArm:      48,
  bracketStroke:    3,
  cardPadX:        24,    // was 32 — Foundations 'medium' card padding
  cardPadTop:      36,
  headerFontSize:  34,    // was 26 — Foundations 'card title'
  bodyFontSize:    30,    // Foundations 'body'
  captionFontSize: 22,    // Foundations 'caption' (min readable size for video)
  bulletBarW:       3,
  bulletBarH:      56,
  // Foundations surface treatment
  cardBorderW:      2,    // standard border width
  cardEmphasisW:    4,    // emphasis stripe
  cardRadiusMax:    4     // never exceed 4px radius (Foundations rule)
};

// --- Color helpers ---

// Returns [r, g, b, a] -- for shape Fill/Stroke (RGBA required by AE).
function ebColor(hex) {
  hex = hex.toUpperCase();
  if (EB_COLORS[hex]) return EB_COLORS[hex];
  return [
    parseInt(hex.substr(0,2), 16) / 255,
    parseInt(hex.substr(2,2), 16) / 255,
    parseInt(hex.substr(4,2), 16) / 255,
    1
  ];
}

// Returns [r, g, b] -- for TextDocument.fillColor (RGB only, no alpha).
function ebColorRGB(hex) {
  var c = ebColor(hex);
  return [c[0], c[1], c[2]];
}

// --- Easing helpers ---

// Dimension-aware ease setter.
// AE requires one KeyframeEase per value dimension:
//   opacity (1D) -> [ease]
//   position (2D) -> [ease, ease]
//
// NOTE: In AE ExtendScript, `prop.value instanceof Array` is unreliable — position
// values are returned as an AE-native vector type that may not pass instanceof.
// We use `typeof v.length === 'number'` instead, which works on any array-like.
// If PropertyValueType is available, that's used as the primary dimension source.
function setEase(prop, keyIdx, outInf, inInf) {
  var e_in  = new KeyframeEase(0, inInf  || 33);
  var e_out = new KeyframeEase(0, outInf || 66);

  // --- Determine property dimensionality ---
  var dims = 1;
  // Primary: PropertyValueType enum (most reliable, version-independent)
  try {
    var pvt = prop.propertyValueType;
    if (pvt === PropertyValueType.ThreeD || pvt === PropertyValueType.ThreeD_SPATIAL) {
      dims = 3;
    } else if (pvt === PropertyValueType.TwoD || pvt === PropertyValueType.TwoD_SPATIAL) {
      dims = 2;
    }
    // else: COLOR (4D), OneD, etc. — use dims=1 for ease (AE treats COLOR as 1D for ease)
  } catch(e) {
    // Fallback: check .length on the value (works for both Array and AE vector types)
    try {
      var v = prop.value;
      if (v !== null && v !== undefined && typeof v.length === 'number' && v.length > 1) {
        dims = v.length;
      }
    } catch(e2) {}
  }

  var arrIn = [], arrOut = [];
  for (var d = 0; d < dims; d++) {
    arrIn.push(e_in);
    arrOut.push(e_out);
  }

  // --- Set temporal interpolation to BEZIER ---
  // Makes handles visible/editable in the graph editor.
  try {
    prop.setInterpolationTypeAtKey(keyIdx,
      KeyframeInterpolationType.BEZIER,
      KeyframeInterpolationType.BEZIER);
  } catch(e) {}

  // --- Apply temporal ease ---
  // Per AE docs, setTemporalEaseAtKey also sets type to BEZIER (belt-and-suspenders).
  // If the full-dimensional call fails (can happen in some AE versions for compound
  // properties), fall back to a single-element array which AE may accept for linked
  // 2D/3D position properties that share one speed curve.
  var easeOk = false;
  try {
    prop.setTemporalEaseAtKey(keyIdx, arrIn, arrOut);
    easeOk = true;
  } catch(e) {}

  if (!easeOk && dims > 1) {
    try { prop.setTemporalEaseAtKey(keyIdx, [e_in], [e_out]); } catch(e) {}
  }
}

// --- Card geometry ---
// Returns array of {x, y, w, h} objects (center-based, comp space).
function ebCardLayout(count) {
  var L     = EB_LAYOUT;
  var avail = L.compW - L.marginX * 2;
  var cardW = (avail - L.cardGap * (count - 1)) / count;
  var cardH = L.cardBottom - L.cardTop;
  var cards = [];
  for (var i = 0; i < count; i++) {
    var left = L.marginX + i * (cardW + L.cardGap);
    cards.push({
      x: left + cardW / 2,
      y: L.cardTop + cardH / 2,
      w: cardW,
      h: cardH
    });
  }
  return cards;
}

// --- Layer animation helpers ---

// Fade + slide-up entrance: opacity (0->100%) + Y-position slide keyframes.
// posAnim checkbox controls whether position keyframes are added at all.
// opDur  = opacity keyframe duration in frames (default 10)
// posDur = position keyframe duration in frames (default 14)
function ebAnimateFadeUp(layer, startFrame, fps, slideOffset, opDur, posDur) {
  // Master Animate In OFF: skip everything — layer remains visible from frame 1.
  if ($.global._ebSkipAnimIn) return;
  opDur  = opDur  || 10;
  posDur = posDur || 14;
  var t0 = startFrame / fps;
  slideOffset = slideOffset || 24;

  // Opacity + position animation — both controlled by _ebSkipPosAnim.
  // When posAnim is off, neither opacity nor position keyframes are added;
  // layers simply appear at inPoint with no entrance effect.
  if (!$.global._ebSkipPosAnim) {
    // Opacity: 0 → 100 linear.
    var opT1 = t0;
    var opT2 = t0 + opDur / fps;
    layer.opacity.setValueAtTime(opT1, 0);
    layer.opacity.setValueAtTime(opT2, 100);
    try { layer.opacity.setInterpolationTypeAtKey(layer.opacity.nearestKeyIndex(opT1), KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch(e) {}
    try { layer.opacity.setInterpolationTypeAtKey(layer.opacity.nearestKeyIndex(opT2), KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch(e) {}

    // Position slide-up.
    try {
      var dur    = posDur / fps;
      var posT1  = t0;
      var posT2  = t0 + dur;
      var posArr = layer.position.value; // [x, y]
      layer.position.setValueAtTime(posT1, [posArr[0], posArr[1] + slideOffset]);
      layer.position.setValueAtTime(posT2, [posArr[0], posArr[1]]);
      try { setEase(layer.position, layer.position.nearestKeyIndex(posT1), 33, 33); } catch(e) {}
      try { setEase(layer.position, layer.position.nearestKeyIndex(posT2), 33, 85); } catch(e) {}
    } catch(e) {}
  }

  // Set inPoint LAST — after all keyframes are committed.
  // AE resets inPoint on text layers when the first keyframe is written if inPoint
  // is set before the keyframes; setting it here prevents that silent reset.
  try { layer.inPoint = t0; } catch(e) {}
}

// Trim-path draw-in animation (lines, brackets, dividers).
function ebAnimateTrimDraw(trimProp, startFrame, fps) {
  if ($.global._ebSkipAnimIn) return;
  var t0 = startFrame / fps;
  var t1 = (startFrame + 18) / fps;
  // Trim the shape layer so it starts exactly at its first keyframe.
  // trimProp is the End property; walk up 5 levels to reach the shape layer.
  try { trimProp.propertyGroup(5).inPoint = t0; } catch(e) {}
  trimProp.setValueAtTime(t0, 0);
  trimProp.setValueAtTime(t1, 100);
  setEase(trimProp, 1, 66, 66);
  setEase(trimProp, 2, 66, 66);
}

// Text layer reveal: opacity (0->100%) + Y-slide entrance.
// Uses layer-level animation (same as ebAnimateFadeUp) -- reliable across
// all AE versions. Cascade effect comes from staggered startFrames at call sites.
// opDur/posDur passed through to ebAnimateFadeUp (optional, see above).
// Fails silently so it is safe to call on any layer type.
function ebTextAnimatorFadeUp(layer, startFrame, fps, yOffset, opDur, posDur) {
  yOffset = yOffset || 25;
  try { ebAnimateFadeUp(layer, startFrame, fps, yOffset, opDur, posDur); } catch(e) {}
}

// Stagger-only: sets inPoint so the layer pops in at startFrame with 100% opacity.
// Use for connector/arrow layers that must never have opacity=0 during playback.
// Respects _ebSkipAnimIn — does nothing when Animate In is OFF.
function ebStagger(layer, startFrame, fps) {
  if ($.global._ebSkipAnimIn) return;
  try { layer.inPoint = startFrame / fps; } catch(e) {}
}

// Opacity-only fade: LINEAR 0->100 + inPoint. No position slide.
// Use for connector/arrow layers that need a proper opacity fade but no slide.
// Note: ebAnimateFadeUp(layer, sf, fps, 0) triggers slideOffset=0||24=24 by accident.
function ebFadeOnly(layer, startFrame, fps, opDur) {
  if ($.global._ebSkipAnimIn) return;
  opDur = opDur || 10;
  var t0 = startFrame / fps;
  var t1 = t0 + opDur / fps;
  try { layer.opacity.setValueAtTime(t0, 0); } catch(e) {}
  try { layer.opacity.setValueAtTime(t1, 100); } catch(e) {}
  try { layer.opacity.setInterpolationTypeAtKey(layer.opacity.nearestKeyIndex(t0), KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch(e) {}
  try { layer.opacity.setInterpolationTypeAtKey(layer.opacity.nearestKeyIndex(t1), KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch(e) {}
  try { layer.inPoint = t0; } catch(e) {}
}

// --- Expression string helpers ---

// Auto-size expression: apply to ADBE Vector Rect Size.
// Card rect resizes to match a body text layer + padding.
function ebAutoSizeExpr(bodyLayerName, paddingW, paddingH) {
  paddingW = paddingW || 100;
  paddingH = paddingH || 200;
  return (
    'var t = thisComp.layer("' + bodyLayerName + '");\n' +
    'if (t) {\n' +
    '  var r = t.sourceRectAtTime();\n' +
    '  [r.width + ' + paddingW + ', r.height + ' + paddingH + ']\n' +
    '} else value'
  );
}

// Connector expression: apply to ADBE Vector Shape of a shape path.
// Draws a straight line between two named layers center-to-center.
// offA = [dx,dy] from center of layer A; offB = [dx,dy] from center of layer B.
function ebConnectorExpr(nodeAName, nodeBName, offA, offB) {
  var ax = offA ? offA[0] : 0;
  var ay = offA ? offA[1] : 0;
  var bx = offB ? offB[0] : 0;
  var by = offB ? offB[1] : 0;
  return (
    'var a = thisComp.layer("' + nodeAName + '").transform.position;\n' +
    'var b = thisComp.layer("' + nodeBName + '").transform.position;\n' +
    'createPath(\n' +
    '  [[a[0]+(' + ax + '), a[1]+(' + ay + ')],\n' +
    '   [b[0]+(' + bx + '), b[1]+(' + by + ')]],\n' +
    '  [], [], false\n' +
    ')'
  );
}

// --- Shape layer helpers ---

// Drop shadow effect
function ebDropShadow(layer, opacity, distance, softness) {
  var ds = layer.Effects.addProperty('ADBE Drop Shadow');
  try { ds.property('Shadow Color').setValue([0, 0, 0, 1]); } catch(e) {}
  try { ds.property('Opacity').setValue(opacity   || 18);   } catch(e) {}
  try { ds.property('Direction').setValue(135);              } catch(e) {}
  try { ds.property('Distance').setValue(distance || 7);    } catch(e) {}
  try { ds.property('Softness').setValue(softness || 22);   } catch(e) {}
}

// --- Text layer factories ---

// Paragraph text (word-wrap enabled). x, y = BASELINE of the first line.
// Uses addBoxText() to guarantee true box text — converting after addText() is unreliable.
// width = column width; box height = 400px (safe for multi-line content).
// justify: 'left' (default) | 'center' | 'right'
function ebTextParagraph(comp, text, x, y, size, fontKey, colorArr, width, justify) {
  var layer;
  // addBoxText creates a proper paragraph/box text layer from the start.
  try { layer = comp.layers.addBoxText([width || 400, 400], text); }
  catch(e) { throw new Error('[addBoxText-p] ' + e.message); }

  var srcProp = layer.property('Source Text');

  // Pass 1: size, color, justification — no font (avoids AE 2026 setValue bug
  // with NVIDIA Sans installed on company machines).
  var doc = srcProp.value;
  try { doc.fontSize = size; } catch(e) { throw new Error('[fontSize-p] ' + e.message); }
  try { doc.fillColor = [colorArr[0], colorArr[1], colorArr[2]]; } catch(e) { throw new Error('[fillColor-p] ' + e.message); }
  try { doc.applyFill = true; } catch(e) {}
  try { doc.applyStroke = false; } catch(e) {}
  try {
    if (justify === 'center')     { doc.justification = ParagraphJustification.CENTER_JUSTIFY; }
    else if (justify === 'right') { doc.justification = ParagraphJustification.RIGHT_JUSTIFY;  }
    else                          { doc.justification = ParagraphJustification.LEFT_JUSTIFY;   }
  } catch(e) {}
  try { srcProp.setValue(doc); } catch(e) { throw new Error('[setValue-p] ' + e.message); }

  // Pass 2: apply font + re-apply justification (AE may reset it when font changes).
  try {
    var doc2 = srcProp.value;
    doc2.font = EB_FONTS[fontKey] || EB_FONTS.regular;
    if (justify === 'center')     { doc2.justification = ParagraphJustification.CENTER_JUSTIFY; }
    else if (justify === 'right') { doc2.justification = ParagraphJustification.RIGHT_JUSTIFY;  }
    else                          { doc2.justification = ParagraphJustification.LEFT_JUSTIFY;   }
    srcProp.setValue(doc2);
  } catch(e) {}

  // addBoxText places its anchor at the TOP-LEFT of the text box,
  // whereas addText (point text) places the anchor at the baseline-left.
  // To keep x = center-of-text for CENTER_JUSTIFY (matching ebText convention),
  // shift the box left by half its width so the box is centered on x.
  // For RIGHT_JUSTIFY, x is the right edge: shift left by full width.
  // For LEFT_JUSTIFY, x is the left edge: no shift needed.
  // For addBoxText, AE's local [0,0] is the TOP-LEFT of the text box.
  // Explicitly anchor there so position.setValue([x,y]) places the
  // TOP-LEFT of the box at [x,y] in comp space.
  // Callers that need baseline alignment (e.g. next to a dot) must
  // add Math.round(size * EB_BOX_ASCENT) to their y before calling.
  var boxW = width || 400;
  var boxX = x;
  if (justify === 'center') { boxX = Math.round(x - boxW / 2); }
  else if (justify === 'right') { boxX = Math.round(x - boxW); }
  // addBoxText default anchorPoint is the box center [boxW/2, boxH/2].
  // anchorPoint.setValue([0,0]) silently fails in many AE versions.
  // Instead: read the actual anchor and offset position so TOP-LEFT lands at [boxX, y].
  var ap = layer.anchorPoint.value;
  layer.position.setValue([Math.round(boxX + ap[0]), Math.round(y + ap[1])]);
  return layer;
}

// justify: 'left' | 'center' | 'right'
function ebText(comp, text, x, y, size, fontKey, colorArr, justify) {
  var layer;
  try { layer = comp.layers.addText(text); }
  catch(e) { throw new Error('[addText] ' + e.message); }

  var srcProp = layer.property('Source Text');

  // Pass 1: size, color, justification — no font (avoids AE 2026 setValue bug
  // with NVIDIA Sans installed on company machines).
  var doc = srcProp.value;
  try { doc.fontSize = size; } catch(e) { throw new Error('[fontSize] ' + e.message); }
  try { doc.fillColor = [colorArr[0], colorArr[1], colorArr[2]]; } catch(e) { throw new Error('[fillColor] ' + e.message); }
  try { doc.applyFill = true; } catch(e) {}
  try { doc.applyStroke = false; } catch(e) {}
  try {
    if (justify === 'center')     { doc.justification = ParagraphJustification.CENTER_JUSTIFY; }
    else if (justify === 'right') { doc.justification = ParagraphJustification.RIGHT_JUSTIFY;  }
    else                          { doc.justification = ParagraphJustification.LEFT_JUSTIFY;   }
  } catch(e) {}
  try { srcProp.setValue(doc); } catch(e) { throw new Error('[setValue] ' + e.message); }

  // Pass 2: apply font + re-apply justification (AE may reset it when font changes).
  try {
    var doc2 = srcProp.value;
    doc2.font = EB_FONTS[fontKey] || EB_FONTS.regular;
    if (justify === 'center')     { doc2.justification = ParagraphJustification.CENTER_JUSTIFY; }
    else if (justify === 'right') { doc2.justification = ParagraphJustification.RIGHT_JUSTIFY;  }
    else                          { doc2.justification = ParagraphJustification.LEFT_JUSTIFY;   }
    srcProp.setValue(doc2);
  } catch(e) {}

  // Set initial position at baseline-left, then center the anchor on the bounding box.
  // sourceRectAtTime returns bbox in layer-local space (relative to the current anchor [0,0]).
  // After centering: anchor = bbox center, position compensated so the visible bbox edge
  // matches the requested justification — left edge at x for 'left', right edge at x for
  // 'right', center at x for 'center'. Without this compensation, fonts with non-zero
  // left/right sidebearings (e.g. semibold vs regular weights of the same family) appear
  // visually misaligned even though they share the same x.
  layer.position.setValue([x, y]);
  try {
    var sr  = layer.sourceRectAtTime(0, false);
    var acx = sr.left + sr.width  / 2;
    var acy = sr.top  + sr.height / 2;
    layer.anchorPoint.setValue([acx, acy]);
    // Compensate for sidebearing on every justification so the visible bbox
    // edge (or center) lands precisely on the requested x. Without this,
    // different-weight fonts at the same x drift apart visually because their
    // sr.left / acx differ slightly.
    var dx;
    if      (justify === 'left')  { dx = -sr.left; }                // bbox LEFT edge   at x
    else if (justify === 'right') { dx = -(sr.left + sr.width); }   // bbox RIGHT edge  at x
    else                          { dx = -acx; }                    // bbox CENTER      at x
    layer.position.setValue([x + acx + dx, y + acy]);
  } catch(e) {}
  return layer;
}

// --- Text centered at (cx, cy) without sourceRectAtTime ---
// For CENTER_JUSTIFY text with anchorPoint=[0,0], AE naturally centers the text
// at the layer's x position. No bounding-box adjustment needed or wanted.
// cy = vertical center of the text (NOT baseline). Baseline = cy + fontSize*0.35.
function ebTextCenter(comp, text, cx, cy, fontSize, fontKey, colorArr) {
  var layer;
  try { layer = comp.layers.addText(text); } catch(e) { return null; }
  var srcProp = layer.property('Source Text');
  try {
    var doc = srcProp.value;
    doc.fontSize = fontSize;
    doc.fillColor = [colorArr[0], colorArr[1], colorArr[2]];
    doc.applyFill = true;
    doc.applyStroke = false;
    doc.justification = ParagraphJustification.CENTER_JUSTIFY;
    srcProp.setValue(doc);
    var doc2 = srcProp.value;
    doc2.font = EB_FONTS[fontKey] || EB_FONTS.regular;
    doc2.justification = ParagraphJustification.CENTER_JUSTIFY;
    srcProp.setValue(doc2);
  } catch(e) {}
  // anchorPoint stays [0,0]. Center-justify makes text symmetric about x=cx.
  // Baseline is cy + cap-height offset (approx 0.35 * fontSize).
  try { layer.anchorPoint.setValue([0, 0]); } catch(e) {}
  try { layer.position.setValue([cx, cy + Math.round(fontSize * 0.35)]); } catch(e) {}
  return layer;
}

// --- Open path builder ---
// vertices: [[x,y], ...]  Returns a Shape object (closed=false).
function ebOpenPath(vertices) {
  var s = new Shape();
  s.vertices    = vertices;
  s.inTangents  = [];
  s.outTangents = [];
  for (var i = 0; i < vertices.length; i++) {
    s.inTangents.push([0, 0]);
    s.outTangents.push([0, 0]);
  }
  s.closed = false;
  return s;
}

// --- Per-layer position ease ---
// Applies Easy Ease to every Position keyframe on a single layer.
// Uses the combined 2D property directly (no dimension separation).
function ebEaseLayerY(layer) {
  try {
    var pos = layer.transform.position;
    if (!pos.isTimeVarying) return;
    var ee = new KeyframeEase(0, 33);
    var np = pos.numKeys;
    for (var k = 1; k <= np; k++) {
      try { pos.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch(e) {}
      try { pos.setTemporalEaseAtKey(k, [ee, ee], [ee, ee]); } catch(e) {}
    }
  } catch(e) {}
}

// --- Post-creation ease pass ---
// Apply Easy Ease to all animated layers in a comp.
// Call AFTER app.endUndoGroup().
// Works on combined 2D Position (no dimension separation) using [ee, ee] arrays.
// Returns diagnostic string 'op=N pos=N'.
function ebApplyEaseToComp(comp) {
  if (!comp) return 'no-comp';
  var ee   = new KeyframeEase(0, 33);
  var opN  = 0, posN = 0;

  for (var i = 1; i <= comp.numLayers; i++) {
    try {
      var lyr = comp.layers[i];

      // Opacity (1D) — linear (no ease) -------------------------------------------
      try {
        if (lyr.opacity.isTimeVarying) {
          var no = lyr.opacity.numKeys;
          for (var ko = 1; ko <= no; ko++) {
            try { lyr.opacity.setInterpolationTypeAtKey(ko, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); opN++; } catch(e) {}
          }
        }
      } catch(e) {}

      // Position (2D combined) ---------------------------------
      try {
        var pos = lyr.transform.position;
        if (pos.isTimeVarying) {
          var np = pos.numKeys;
          for (var kp = 1; kp <= np; kp++) {
            try { pos.setInterpolationTypeAtKey(kp, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch(e) {}
            try { pos.setTemporalEaseAtKey(kp, [ee, ee], [ee, ee]); posN++; } catch(e) {}
          }
        }
      } catch(e) {}

    } catch(e) {}
  }

  return 'op=' + opN + ' pos=' + posN;
}

// ebStrokeRect: stroke-only closed rectangle shape layer centered at [cx,cy].
function ebStrokeRect(comp, name, cx, cy, w, h, colorA, sw) {
  var lyr = comp.layers.addShape();
  lyr.name = name;
  lyr.position.setValue([cx, cy]);
  var gc = lyr.property('Contents');
  var grp = gc.addProperty('ADBE Vector Group');
  grp.name = 'Rect';
  var gi = grp.property('Contents');
  var sp = gi.addProperty('ADBE Vector Shape - Group');
  var hw2 = Math.round(w / 2), hh2 = Math.round(h / 2);
  var sh = new Shape();
  sh.vertices    = [[-hw2,-hh2],[hw2,-hh2],[hw2,hh2],[-hw2,hh2]];
  sh.inTangents  = [[0,0],[0,0],[0,0],[0,0]];
  sh.outTangents = [[0,0],[0,0],[0,0],[0,0]];
  sh.closed = true;
  try { sp.property('ADBE Vector Shape').setValue(sh); } catch(e) {}
  var str = gi.addProperty('ADBE Vector Graphic - Stroke');
  try { str.property('ADBE Vector Stroke Color').setValue(colorA); } catch(e) {}
  try { str.property('ADBE Vector Stroke Width').setValue(sw || 1.5); } catch(e) {}
  try { str.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  return lyr;
}

// ebStrokeLine: open path shape layer at world [0,0] with stroke.
// dashLen/gapLen: optional dash pattern (omit or 0 for solid).
function ebStrokeLine(comp, name, pts, colorA, sw, dashLen, gapLen) {
  var lyr = comp.layers.addShape();
  lyr.name = name;
  lyr.position.setValue([0, 0]);
  var gc  = lyr.property('Contents');
  var grp = gc.addProperty('ADBE Vector Group');
  grp.name = 'Path';
  var gi  = grp.property('Contents');
  var sp  = gi.addProperty('ADBE Vector Shape - Group');
  try { sp.property('ADBE Vector Shape').setValue(ebOpenPath(pts)); } catch(e) {}
  var str = gi.addProperty('ADBE Vector Graphic - Stroke');
  try { str.property('ADBE Vector Stroke Color').setValue(colorA); } catch(e) {}
  try { str.property('ADBE Vector Stroke Width').setValue(sw || 1.5); } catch(e) {}
  try { str.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  if (dashLen) {
    try {
      var dg = str.property('ADBE Vector Stroke Dashes');
      dg.addProperty('ADBE Vector Stroke Dash 1').setValue(dashLen);
      dg.addProperty('ADBE Vector Stroke Gap 1').setValue(gapLen || dashLen);
    } catch(e) {}
  }
  return lyr;
}

// Convenience: add Trim Paths to a layer returned by ebStrokeLine, then animate
// the draw-on effect.  ebAnimateTrimDraw() expects the Trim End *property*; this
// wrapper extracts it from the layer so call sites don't have to.
function ebStrokeLineTrimDraw(layer, startFrame, fps) {
  try {
    var gi  = layer.property('Contents').property(1).property('Contents');
    var tr  = gi.addProperty('ADBE Vector Filter - Trim');
    var trE = tr.property('ADBE Vector Trim End');
    try { layer.inPoint = startFrame / fps; } catch(e) {}
    ebAnimateTrimDraw(trE, startFrame, fps);
  } catch(e) {}
}

// Recursively set fill opacity to 0 on every fill inside a shape-group Contents.
// Called by createBlock when params.shapeFill === false.
function ebClearGroupFills(contents) {
  if (!contents) return;
  var n = 0;
  try { n = contents.numProperties; } catch(e) { return; }
  for (var _i = 1; _i <= n; _i++) {
    try {
      var _p = contents.property(_i);
      if (_p.matchName === 'ADBE Vector Group') {
        try { ebClearGroupFills(_p.property('Contents')); } catch(e) {}
      } else if (_p.matchName === 'ADBE Vector Graphic - Fill') {
        try { _p.property('ADBE Vector Fill Opacity').setValue(0); } catch(e) {}
      }
    } catch(e) {}
  }
}
