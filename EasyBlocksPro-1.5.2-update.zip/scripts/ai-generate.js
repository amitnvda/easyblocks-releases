/**
 * EasyBlocks Pro — AI Generate Bridge
 * Spawned by the CEP panel as: node ai-generate.js --config /tmp/ebp_xxx.json
 *
 * Config JSON: { systemPrompt, userMessage, imagePath (optional), outputPath }
 * On success: writes result text to outputPath, exits 0
 * Progress/logs: written to stderr as plain text lines
 */
'use strict';

var fs   = require('fs');
var os   = require('os');
var path = require('path');
var spawn = require('child_process').spawn;

// ── Parse args ────────────────────────────────────────────────────────────
var args = process.argv.slice(2);
var configIdx = args.indexOf('--config');
if (configIdx === -1 || !args[configIdx + 1]) {
  process.stderr.write('Usage: node ai-generate.js --config <path>\n');
  process.exit(1);
}
var config;
try {
  config = JSON.parse(fs.readFileSync(args[configIdx + 1], 'utf8'));
} catch(e) {
  process.stderr.write('Could not read config: ' + e.message + '\n');
  process.exit(1);
}

var systemPrompt = config.systemPrompt || '';
var userMessage  = config.userMessage  || '';
var imagePath    = config.imagePath    || null;
var outputPath   = config.outputPath;
var model        = config.model        || 'sonnet';

if (!outputPath) {
  process.stderr.write('config.outputPath required\n');
  process.exit(1);
}

// ── Find claude binary ────────────────────────────────────────────────────
var homedir = os.homedir();
var IS_WIN  = (process.platform === 'win32');
var claudeCandidates = IS_WIN ? [
  // Windows: npm-global installs, native installer locations, plus PATH fallback
  path.join(process.env.APPDATA || '', 'npm', 'claude.cmd'),
  path.join(process.env.APPDATA || '', 'npm', 'claude.exe'),
  path.join(process.env.LOCALAPPDATA || '', 'Programs', 'claude', 'claude.exe'),
  path.join(homedir, 'AppData', 'Roaming', 'npm', 'claude.cmd'),
  path.join(homedir, 'AppData', 'Roaming', 'npm', 'claude.exe'),
  path.join(homedir, '.npm-global', 'claude.cmd'),
  'C:\\Program Files\\nodejs\\claude.cmd'
] : [
  path.join(homedir, '.local', 'bin', 'claude'),
  '/usr/local/bin/claude',
  '/opt/homebrew/bin/claude',
  '/usr/bin/claude'
];
var claudeBin = IS_WIN ? 'claude.cmd' : 'claude';
for (var i = 0; i < claudeCandidates.length; i++) {
  try { if (claudeCandidates[i] && fs.existsSync(claudeCandidates[i])) { claudeBin = claudeCandidates[i]; break; } } catch(e) {}
}
process.stderr.write('claude: ' + claudeBin + '\n');

// ── Build stream-json input ────────────────────────────────────────────────
var content = [];
if (imagePath) {
  process.stderr.write('Loading image: ' + imagePath + '\n');
  try {
    var imgBuf  = fs.readFileSync(imagePath);
    var b64     = imgBuf.toString('base64');
    var ext     = path.extname(imagePath).slice(1).toLowerCase();
    var mimeMap = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp' };
    var mime    = mimeMap[ext] || 'image/png';
    content.push({ type: 'image', source: { type: 'base64', media_type: mime, data: b64 } });
    process.stderr.write('Image loaded: ' + Math.round(b64.length / 1024) + ' KB base64\n');
  } catch(e) {
    process.stderr.write('Warning: could not read image (' + e.message + ') — continuing text-only\n');
  }
}
content.push({ type: 'text', text: userMessage });

var streamInput = JSON.stringify({
  type: 'user',
  message: { role: 'user', content: content }
}) + '\n';

// ── Spawn claude ───────────────────────────────────────────────────────────
var childEnv = Object.assign({}, process.env);
delete childEnv.CLAUDECODE; // allow nested invocation

var pathSep = IS_WIN ? ';' : ':';
var extraPaths = IS_WIN ? [
  path.join(process.env.APPDATA || '', 'npm'),
  path.join(process.env.LOCALAPPDATA || '', 'Programs', 'claude'),
  'C:\\Program Files\\nodejs',
  path.join(homedir, '.npm-global')
].filter(Boolean).join(pathSep) : [
  homedir + '/.local/bin',
  '/usr/local/bin', '/opt/homebrew/bin',
  '/usr/bin', '/bin'
].join(pathSep);
childEnv.PATH = extraPaths + (childEnv.PATH ? pathSep + childEnv.PATH : '');

// Write the system prompt to a temp file and pass --system-prompt-file.
// Windows CreateProcess has a 32KB command-line limit and our v1.5+ prompt
// (with all schemas + composition section) is now ~25KB — too close for
// comfort. File-based is also safer on every platform because it avoids
// shell quoting issues with newlines, quotes, and special characters.
var promptFilePath = path.join(os.tmpdir(),
  'ebp_sysprompt_' + Date.now() + '_' + Math.floor(Math.random() * 100000) + '.txt');
try {
  fs.writeFileSync(promptFilePath, systemPrompt, 'utf8');
  process.stderr.write('System prompt written to ' + promptFilePath +
    ' (' + Math.round(systemPrompt.length / 1024) + ' KB)\n');
} catch(e) {
  process.stderr.write('Could not write system-prompt temp file: ' + e.message + '\n');
  process.exit(1);
}

var claudeArgs = [
  '--print',
  '--verbose',
  '--input-format',      'stream-json',
  '--output-format',     'stream-json',
  '--system-prompt-file', promptFilePath,
  '--model',             model,
  '--no-session-persistence',
  '--dangerously-skip-permissions'
];

process.stderr.write('Spawning claude…\n');

var child = spawn(claudeBin, claudeArgs, {
  stdio: ['pipe', 'pipe', 'pipe'],
  env: childEnv,
  cwd: os.tmpdir(),
  // Windows .cmd files require shell:true so the launcher script runs through cmd.exe.
  shell: IS_WIN
});

// Always clean up the temp prompt file when the child exits, success or not.
child.on('exit', function() { try { fs.unlinkSync(promptFilePath); } catch(_) {} });

child.stdin.write(streamInput);
child.stdin.end();
process.stderr.write('Prompt sent (' + Math.round(streamInput.length / 1024) + ' KB)\n');

// ── Collect output ─────────────────────────────────────────────────────────
var stdout = '';
var stderr = '';
var gotDelta = false;

child.stdout.on('data', function(d) {
  var chunk = d.toString();
  stdout += chunk;
  // Forward streaming progress signals
  chunk.split('\n').forEach(function(line) {
    line = line.trim();
    if (!line) return;
    try {
      var evt = JSON.parse(line);
      if (evt.type === 'content_block_delta' && evt.delta && evt.delta.type === 'text_delta') {
        if (!gotDelta) {
          process.stderr.write('STREAMING\n'); // signal to panel that response has started
          gotDelta = true;
        }
      }
    } catch(e) {}
  });
});

child.stderr.on('data', function(d) {
  var t = d.toString().trim();
  if (t) { stderr += t + '\n'; process.stderr.write(t + '\n'); }
});

child.on('error', function(e) {
  process.stderr.write('spawn error: ' + e.message + '\n');
  process.exit(1);
});

child.on('close', function(code) {
  process.stderr.write('claude exited: ' + code + '\n');

  // Parse stream-json output
  var deltaText = '', lastAssistant = '', resultText = '';
  stdout.split('\n').forEach(function(line) {
    line = line.trim();
    if (!line) return;
    try {
      var evt = JSON.parse(line);
      if (evt.type === 'content_block_delta' && evt.delta && evt.delta.type === 'text_delta') {
        deltaText += evt.delta.text;
      }
      if (evt.type === 'assistant' && evt.message && Array.isArray(evt.message.content)) {
        var t = evt.message.content.filter(function(b) { return b.type === 'text'; }).map(function(b) { return b.text; }).join('');
        if (t) lastAssistant = t;
      }
      if (evt.type === 'result' && evt.result) {
        resultText = evt.result;
      }
    } catch(e) {}
  });

  var result = (resultText || lastAssistant || deltaText).trim();

  if (!result) {
    process.stderr.write('ERROR: no text in output (code=' + code + ')\nstdout: ' + stdout.slice(0, 300) + '\n');
    process.exit(code || 1);
  }

  try {
    fs.writeFileSync(outputPath, result, 'utf8');
    process.stderr.write('OK: result written to ' + outputPath + '\n');
    process.exit(0);
  } catch(e) {
    process.stderr.write('Could not write output: ' + e.message + '\n');
    process.exit(1);
  }
});
