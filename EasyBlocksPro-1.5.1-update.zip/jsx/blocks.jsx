// blocks.jsx -- Block creation functions for EasyBlocks
// ASCII-only: AE's ExtendScript engine reads JSX as Latin-1, not UTF-8.
// Uses ADBE match names for shape sub-properties (version/locale safe).

// Ensure mono font key is present even if utils.jsx was loaded before this key was added.
if (typeof EB_FONTS !== 'undefined' && !EB_FONTS.mono) {
  EB_FONTS.mono = 'CourierNewPSMT';
}

// =============================================================
// TITLE + SUBTITLE (shared header for all blocks)
// Default colors: Black title, NVIDIA Green subtitle.
// =============================================================
// PRE-COMP HELPER
// Collects all layers added since layersBefore and precomposes them.
// layersBefore = comp.numLayers snapshot taken before the card was drawn.
// =============================================================
function _ebPrecompCard(comp, layersBefore, name, cardStart, fps, cx, cy) {
  var nNew = comp.numLayers - layersBefore;
  if (nNew <= 0) return;
  var indices = [];
  for (var k = 1; k <= nNew; k++) { indices.push(k); }
  try { comp.layers.precompose(indices, name, true); } catch(e) { return; }

  // Find the precomp layer in the parent comp
  var pcLayer = null;
  for (var li = 1; li <= comp.numLayers; li++) {
    try { if (comp.layers[li].name === name) { pcLayer = comp.layers[li]; break; } } catch(e) {}
  }
  if (!pcLayer) return;

  // Shift all inner layers earlier so the card's animation starts at frame 0 inside the precomp,
  // then offset the precomp layer in the parent to compensate — net result: correct timing, no double-offset
  if (cardStart !== undefined && fps) {
    var offset = cardStart / fps;
    var pcComp = pcLayer.source;
    if (pcComp && pcComp.numLayers) {
      for (var j = 1; j <= pcComp.numLayers; j++) {
        try {
          var il = pcComp.layers[j];
          il.startTime -= offset;
          il.inPoint   -= offset;
          il.outPoint  -= offset;
        } catch(e) {}
      }
    }
    try { pcLayer.startTime = offset; } catch(e) {}
  }

  // Center anchor point on the card so scale/rotate keyframes work from the card center
  if (cx !== undefined && cy !== undefined) {
    try {
      pcLayer.property('Transform').property('Anchor Point').setValue([cx, cy]);
      pcLayer.property('Transform').property('Position').setValue([cx, cy]);
    } catch(e) {}
  }
}

// =============================================================
function ebCreateHeader(comp, params, startFrame) {
  if (params && params.noHeader) return null;
  var fps     = comp.frameRate;
  var L       = EB_LAYOUT;
  var black   = [0, 0, 0];
  var green   = ebColorRGB('76B900');

  // Both title and subtitle are optional — only render layers if the
  // panel actually provided text. Empty input = no layer.
  var hasTitle    = params && params.title    && String(params.title).length    > 0;
  var hasSubtitle = params && params.subtitle && String(params.subtitle).length > 0;

  var titleLayer = null;
  if (hasTitle) {
    try {
      titleLayer = ebText(comp, params.title, L.titleCenterX, L.titleY, 55, 'bold', black, 'center');
    } catch(e) { throw new Error('[ebCreateHeader:title] ' + e.message); }
    titleLayer.name = 'EB_Title';
    // Center the anchor on the visible bbox so animation pivots feel natural.
    try {
      var tr  = titleLayer.sourceRectAtTime(0, false);
      var tay = tr.top + tr.height / 2;
      var tp  = titleLayer.position.value;
      titleLayer.anchorPoint.setValue([tr.left + tr.width / 2, tay]);
      titleLayer.position.setValue([960, tp[1] - tay]);
    } catch(e) {}
    ebTextAnimatorFadeUp(titleLayer, startFrame, fps, 28);
  }

  var subtitleLayer = null;
  if (hasSubtitle) {
    try {
      subtitleLayer = ebText(comp, params.subtitle, L.titleCenterX, L.subtitleY, 38, 'regular', green, 'center');
    } catch(e) { throw new Error('[ebCreateHeader:subtitle] ' + e.message); }
    subtitleLayer.name = 'EB_Subtitle';
    try {
      var sr  = subtitleLayer.sourceRectAtTime(0, false);
      var say = sr.top + sr.height / 2;
      var sp  = subtitleLayer.position.value;
      subtitleLayer.anchorPoint.setValue([sr.left + sr.width / 2, say]);
      subtitleLayer.position.setValue([960, sp[1] - say]);
    } catch(e) {}
    ebTextAnimatorFadeUp(subtitleLayer, startFrame + 12, fps, 24);
  }

  return { title: titleLayer, subtitle: subtitleLayer };
}

// =============================================================
// CARD BACKGROUND
// Two variants controlled by borderColor parameter:
//   borderColor = RGBA array  -> colored border (2.5px stroke) + light shadow
//   borderColor = null/false  -> no border + elegant drop shadow
// Always white fill.
// =============================================================
function ebCreateCardBg(comp, card, name, bodyLayerName, borderColor, showShadow, noFill, fillColor) {
  var layer  = comp.layers.addShape();
  layer.name = name || 'EB_CardBG';
  layer.position.setValue([card.x, card.y]);
  // Mark so the fill-clearing pass (shapeFill=false) skips this layer.
  // The white base fill must be preserved for Drop Shadow to have card-shaped alpha.
  try { layer.comment = 'ebp-cardbg'; } catch(e) {}

  var contents = layer.property('Contents');
  var group    = contents.addProperty('ADBE Vector Group');
  group.name   = 'BG';
  var gc       = group.property('Contents');

  var rect     = gc.addProperty('ADBE Vector Shape - Rect');
  var sizeProp = rect.property('ADBE Vector Rect Size');
  try { sizeProp.setValue([card.w, card.h]); } catch(e) {}
  try { rect.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}

  // Base fill: always present so Drop Shadow / border have card-shaped alpha to render from.
  // noFill=false + fillColor → accent fill (cards-1..5 with Fill Shapes ON)
  // noFill=false + no fillColor → grey (#EBEBEB)
  // noFill=true → white (invisible on white comp bg; border+shadow still render from shape alpha)
  var baseFillClr = noFill
    ? [1, 1, 1, 1]                                        // white — invisible, card BG hidden
    : (fillColor ? [fillColor[0], fillColor[1], fillColor[2], 1]
                 : [235/255, 235/255, 235/255, 1]);       // accent or #EBEBEB grey
  var baseFill = gc.addProperty('ADBE Vector Graphic - Fill');
  try { baseFill.property('ADBE Vector Fill Color').setValue(baseFillClr); } catch(e) {}

  if (borderColor) {
    // When the card has a colored fill, use white border so it contrasts.
    // When the card has no accent fill (white card), use the accent color border.
    var effectiveBorderClr = (!noFill && fillColor) ? [1, 1, 1, 1] : borderColor;
    var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
    try { stroke.property('ADBE Vector Stroke Color').setValue(effectiveBorderClr); } catch(e) {}
    try { stroke.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { stroke.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  }

  // Shadow: independent of border -- always renders from the white base fill.
  if (showShadow !== false) { try { ebDropShadow(layer, 30, 14, 40); } catch(e) {} }

  return layer;
}

// =============================================================
// CARD HEADER TEXT + UNDERLINE RULE (draws left-to-right)
// =============================================================
function ebCreateCardHeader(comp, card, headerText, colorArr, animateIn, headerStart, fps, align) {
  var L     = EB_LAYOUT;
  var left  = card.x - card.w / 2;
  var top   = card.y - card.h / 2;
  // Alignment: 'left' (default), 'center', or 'right'.
  var hAlign = (align === 'center' || align === 'right') ? align : 'left';
  var textX;
  if (hAlign === 'center')      textX = card.x;
  else if (hAlign === 'right')  textX = left + card.w - L.cardPadX;
  else                          textX = left + L.cardPadX;
  var textY = top  + L.cardPadTop + L.headerFontSize;

  var headerLayer = ebText(
    comp, headerText,
    textX, textY,
    L.headerFontSize, 'semibold', [colorArr[0], colorArr[1], colorArr[2]], hAlign
  );
  headerLayer.name = 'EB_CardHeader';

  if (headerStart !== undefined) {
    ebTextAnimatorFadeUp(headerLayer, headerStart, fps, 20);
  }

  // Underline rule with Trim Path (draws left-to-right)
  var lineLayer  = comp.layers.addShape();
  lineLayer.name = 'EB_HeaderRule';
  var lineY      = textY + 14;
  lineLayer.position.setValue([card.x, lineY]);

  var contents = lineLayer.property('Contents');
  var grp      = contents.addProperty('ADBE Vector Group');
  var gc       = grp.property('Contents');
  var lineW    = card.w - L.cardPadX * 2;

  var pathGrp = gc.addProperty('ADBE Vector Shape - Group');
  try { pathGrp.property('ADBE Vector Shape').setValue(ebOpenPath([[-lineW/2, 0], [lineW/2, 0]])); } catch(e) {}

  var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
  try { stroke.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}

  var trim    = gc.addProperty('ADBE Vector Filter - Trim');
  var trimEnd = trim.property('ADBE Vector Trim End');

  if (animateIn && headerStart !== undefined) {
    try { lineLayer.inPoint = (headerStart + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(trimEnd, headerStart + 1, fps); } catch(e) {}
  } else {
    try { trimEnd.setValue(100); } catch(e) {}  // static: line fully visible, no animation
  }

  return { header: headerLayer, rule: lineLayer, bottomY: lineY };
}

// =============================================================
// BULLET ITEM (vertical bar + body text, Text Animator cascade)
// =============================================================
// spacing: px between bullet centres (optional, default 160).
// A larger value spreads bullets to fill the card height better.
function ebCreateBullet(comp, card, text, colorArr, bulletIndex, zoneTopY, animateIn, bStart, fps, spacing) {
  var L       = EB_LAYOUT;
  var left    = card.x - card.w / 2;
  var barX    = left + L.cardPadX;
  spacing = spacing || 160;
  var bulletY = zoneTopY + bulletIndex * spacing + 40;

  var barLayer  = comp.layers.addShape();
  barLayer.name = 'EB_BulletBar_' + bulletIndex;
  barLayer.label = 9;
  barLayer.position.setValue([barX + L.bulletBarW / 2, bulletY]);

  var contents = barLayer.property('Contents');
  var grp      = contents.addProperty('ADBE Vector Group');
  var gc       = grp.property('Contents');
  var halfH    = L.bulletBarH / 2;

  var pathGrp = gc.addProperty('ADBE Vector Shape - Group');
  try { pathGrp.property('ADBE Vector Shape').setValue(ebOpenPath([[0, -halfH], [0, halfH]])); } catch(e) {}

  var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
  try { stroke.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Width').setValue(L.bulletBarW); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}

  // ebTextParagraph y = TOP of box. For cap-height centre to align with bar centre (bulletY):
  // top = bulletY - fSz*0.38  →  baseline = top + fSz*0.78 = bulletY + fSz*0.4
  //                             →  cap centre ≈ baseline - fSz*0.4 = bulletY ✓
  var _plFSz = 35;
  var txtX = barX + L.bulletBarW + 14;
  var textLayer = ebText(comp, text, txtX, bulletY + Math.round(_plFSz * 0.38),
    _plFSz, 'regular', [0, 0, 0], 'left');
  textLayer.name = 'EB_BulletText_' + bulletIndex;

  if (animateIn && bStart !== undefined) {
    try { ebAnimateFadeUp(barLayer, bStart, fps, 20); } catch(e) {}
  }
  if (bStart !== undefined) {
    ebTextAnimatorFadeUp(textLayer, bStart + 3, fps, 18);
  }

  return { bar: barLayer, text: textLayer };
}

// =============================================================
// ICON PLACEHOLDER (rect outline + label)
// =============================================================
function ebCreateIconPlaceholder(comp, card, name, animateIn, startFrame, fps) {
  var iconSize = Math.min(card.w * 0.44, 200);
  var iconX    = card.x;
  var iconY    = card.y + card.h * 0.14;

  var layer    = comp.layers.addShape();
  layer.name   = name || 'EB_Icon';
  layer.position.setValue([iconX, iconY]);

  var contents = layer.property('Contents');
  var grp      = contents.addProperty('ADBE Vector Group');
  grp.name     = 'Placeholder';
  var gc       = grp.property('Contents');

  var rect = gc.addProperty('ADBE Vector Shape - Rect');
  try { rect.property('ADBE Vector Rect Size').setValue([iconSize, iconSize]); } catch(e) {}

  var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
  try { stroke.property('ADBE Vector Stroke Color').setValue([0.75, 0.75, 0.75, 1]); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}

  var label = ebText(comp, '[ ICON ]', iconX, iconY - 8, 14, 'regular', [0.65, 0.65, 0.65], 'center');
  label.name = 'EB_IconLabel';

  if (animateIn && startFrame !== undefined) {
    try { ebAnimateFadeUp(layer, startFrame, fps, 20); } catch(e) {}
  }
  if (startFrame !== undefined) {
    try { ebAnimateFadeUp(label, startFrame + 2, fps, 20); } catch(e) {}
  }

  return { layer: layer, label: label };
}

// =============================================================
// SLIDE TITLE BLOCK
// =============================================================
function createSlideTitleBlock(comp, params) {
  ebCreateHeader(comp, params, 1);
}

// =============================================================
// ICON CARD BLOCK (1-5 cards)
// cardBorder true  -> 2.5px colored border + light shadow
// cardBorder false -> borderless white card + elegant shadow
//
// Animation sequence per card (staggered 7 frames):
//   +0   Card background fades in
//   +8   Card header text (Text Animator) + rule draws left-to-right
//   +14  Body text (Text Animator)
//   +18  Icon placeholder
// =============================================================
function createIconCardsBlock(comp, params, count) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var cards      = ebCardLayout(count);
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  for (var i = 0; i < count; i++) {
    var card      = cards[i];
    var cardStart = startFrame + 36 + i * 7;
    var bodyName  = 'EB_Body_' + (i+1);
    var _pcBefore = params.precomp ? comp.numLayers : 0;

    // 1. Card background (no auto-size: icon cards use fixed card geometry)
    var _cardNoFill  = (params.cardBg === false);
    var _cardFillClr = (params.shapeFill === false) ? null : color;
    var bgLayer = ebCreateCardBg(comp, card, 'EB_CardBG_' + (i+1), null, borderClr, showShadow, _cardNoFill, _cardFillClr);
    if (params.animateIn) {
      try { ebAnimateFadeUp(bgLayer, cardStart, fps, 40); } catch(e) {}
    }

    // 2. Card header + underline rule
    var cardData  = (params.cards && params.cards[i]) ? params.cards[i] : {};
    var cardLabel = cardData.label || ('Card ' + (i+1));
    ebCreateCardHeader(comp, card, cardLabel, color,
      params.animateIn, cardStart + 8, fps, params.titleAlign);

    // 3. Body text
    var bodyY   = card.y - card.h/2 + EB_LAYOUT.cardPadTop + EB_LAYOUT.headerFontSize + 60;
    var bs      = params.bodyStyle || 'text';
    // Scale padding, font size, and dot gap with card width so narrow columns (4-5 cards) fit cleanly.
    var _padX   = Math.max(16, Math.round(EB_LAYOUT.cardPadX * Math.min(1, card.w / 500)));
    var bodyX   = card.x - card.w/2 + _padX;
    var textW   = card.w - _padX * 2;
    var bFontSz = (card.w < 350) ? 20 : (card.w < 480) ? 23 : 26;
    var dotGap  = Math.round(bFontSz * 0.85); // gap between dot and text label
    var bul     = String.fromCharCode(8226);

    var lineAdv = bFontSz + 30;
    var rawBody = (cardData.body !== undefined && cardData.body !== null && cardData.body !== '') ? cardData.body : null;

    // Word-wrap safety net: compute char capacity from geometry
    var _cpl      = Math.max(10, Math.floor(textW / (bFontSz * 0.58)));
    var _textCpl  = _cpl;
    var _pipeCpl  = Math.max(8, _cpl - Math.round(dotGap / (bFontSz * 0.58)));
    var _bulCpl   = _pipeCpl;
    var _bottomY  = card.y + card.h/2 - 30;
    var _maxLines = Math.max(2, Math.floor((_bottomY - bodyY) / lineAdv));

    // Wrap body string: split on \r, word-wrap each item, return flat line array capped at maxLines
    function _wrapBody(body, charsPerLine, maxLines) {
      var raw = body.split('\r');
      var out = [];
      for (var _wi = 0; _wi < raw.length && out.length < maxLines; _wi++) {
        var item = raw[_wi];
        var isSub = (item.length > 1 && item.charAt(0) === ' ' && item.charAt(1) === ' ');
        var stripped = item.replace(/^\s+/, '');
        var wrapped = ebWordWrap(stripped, charsPerLine);
        for (var _wj = 0; _wj < wrapped.length && out.length < maxLines; _wj++) {
          out.push(isSub && _wj === 0 ? '  ' + wrapped[_wj] : wrapped[_wj]);
        }
      }
      return out;
    }

    if (bs === 'pipe') {
      // Pipe: one item per line with a | marker — wrapped continuations share the same marker row
      var pipeDef  = 'First item here\rSecond item here\rThird item here';
      var pipeBody = rawBody || pipeDef;
      var pipeItems = pipeBody.split('\r');
      var pipeClr  = [color[0], color[1], color[2]];
      var curPipeY = bodyY;
      var pTotalLines = 0;
      for (var pIdx = 0; pIdx < pipeItems.length && pTotalLines < _maxLines; pIdx++) {
        var pitem   = pipeItems[pIdx].replace(/^\s+/, '');
        var pWrapped = ebWordWrap(pitem, _pipeCpl);
        for (var pwIdx = 0; pwIdx < pWrapped.length && pTotalLines < _maxLines; pwIdx++) {
          var pln    = pWrapped[pwIdx];
          var pFrame = cardStart + 14 + pTotalLines * 4;
          var dY     = curPipeY + Math.round(bFontSz * 0.78);
          if (pwIdx === 0) {
            var pMark  = ebText(comp, '|', bodyX, dY, bFontSz, 'regular', pipeClr, 'left');
            pMark.name = 'EB_Pipe_' + (i+1) + '_' + pIdx;
            ebTextAnimatorFadeUp(pMark, pFrame, fps, 18);
          }
          var pLyr   = ebText(comp, pln, bodyX + dotGap, dY, bFontSz, 'regular', [0, 0, 0], 'left');
          pLyr.name  = 'EB_Body_' + (i+1) + '_' + pIdx + '_' + pwIdx;
          ebTextAnimatorFadeUp(pLyr, pFrame, fps, 18);
          curPipeY += lineAdv;
          pTotalLines++;
        }
      }

    } else if (bs === 'bullets') {
      // Bullets: green dot per item — wrapped continuations align under text, no extra dot
      var _defBullets = (count <= 2)
        ? 'First key point here\r  Supporting detail one\r  Supporting detail two\rSecond key point listed\r  Supporting detail one\r  Supporting detail two\rThird key point here\r  Supporting detail one'
        : 'First key point here\rSecond key point listed\rThird key point here';
      var bulBody    = rawBody || _defBullets;
      var bulItems   = bulBody.split('\r');
      var subSz      = bFontSz - 4;
      var subAdv     = subSz + 22;
      var segGap     = 20;
      var curBulY    = bodyY;
      var prevSub    = false;
      var bTotalLines = 0;
      for (var bIdx = 0; bIdx < bulItems.length && bTotalLines < _maxLines; bIdx++) {
        var bln    = bulItems[bIdx];
        var bIsSub = (bln.length > 1 && bln.charAt(0) === ' ' && bln.charAt(1) === ' ');
        var bText  = bln.replace(/^\s+/, '');
        var bCpl   = bIsSub ? Math.max(6, _bulCpl - Math.round(dotGap * 0.85 / (subSz * 0.58))) : _bulCpl;
        var bWrapped = ebWordWrap(bText, bCpl);
        if (!bIsSub && prevSub) { curBulY += segGap; }
        prevSub = bIsSub;
        for (var bwIdx = 0; bwIdx < bWrapped.length && bTotalLines < _maxLines; bwIdx++) {
          var bFrame = cardStart + 14 + bTotalLines * 4;
          if (bIsSub) {
            var sIndent = bodyX + dotGap + Math.round(dotGap * 0.85);
            var sDotY   = curBulY + Math.round(subSz * 0.78);
            if (bwIdx === 0) {
              var sDot  = ebText(comp, bul, sIndent - Math.round(dotGap * 0.75), sDotY, subSz, 'regular', ebColorRGB('76B900'), 'left');
              sDot.name = 'EB_SubDot_' + (i+1) + '_' + bIdx;
              ebTextAnimatorFadeUp(sDot, bFrame, fps, 14);
            }
            var sLyr    = ebText(comp, bWrapped[bwIdx], sIndent, sDotY, subSz, 'regular', [0.3, 0.3, 0.3], 'left');
            sLyr.name   = 'EB_Body_' + (i+1) + '_' + bIdx + '_' + bwIdx;
            ebTextAnimatorFadeUp(sLyr, bFrame, fps, 14);
            curBulY += subAdv;
          } else {
            var dY  = curBulY + Math.round(bFontSz * 0.78);
            if (bwIdx === 0) {
              var dot = ebText(comp, bul, bodyX, dY, bFontSz, 'regular', ebColorRGB('76B900'), 'left');
              dot.name = 'EB_Dot_' + (i+1) + '_' + bIdx;
              ebTextAnimatorFadeUp(dot, bFrame, fps, 18);
            }
            var txt = ebText(comp, bWrapped[bwIdx], bodyX + dotGap, dY, bFontSz, 'regular', [0, 0, 0], 'left');
            txt.name = 'EB_Body_' + (i+1) + '_' + bIdx + '_' + bwIdx;
            ebTextAnimatorFadeUp(txt, bFrame, fps, 18);
            curBulY += lineAdv;
          }
          bTotalLines++;
        }
      }

    } else {
      // Text: plain lines, no bullets
      var _defText = (count <= 2)
        ? 'First line of content here\rSecond line of supporting text\rThird point or detail here\rFourth line of content'
        : 'First line here\rSecond line here\rThird line here';
      var txtBody  = rawBody || _defText;
      var txtLines = _wrapBody(txtBody, _textCpl, _maxLines);
      var curTxtY  = bodyY;
      for (var tIdx = 0; tIdx < txtLines.length; tIdx++) {
        var tln    = txtLines[tIdx].replace(/^\s+/, '');
        var tFrame = cardStart + 14 + tIdx * 4;
        var tY     = curTxtY + Math.round(bFontSz * 0.78);
        var tLyr   = ebText(comp, tln, bodyX, tY, bFontSz, 'regular', [0, 0, 0], 'left');
        tLyr.name  = 'EB_Body_' + (i+1) + '_' + tIdx;
        ebTextAnimatorFadeUp(tLyr, tFrame, fps, 20);
        curTxtY += lineAdv;
      }
    }

    if (params.precomp) { _ebPrecompCard(comp, _pcBefore, 'Card ' + (i+1), cardStart, fps, card.x, card.y); }
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// COMPARISON BLOCK (2 cards, dual accent colors, bullets)
// Animation sequence per card (staggered 9 frames):
//   +0   Card bg
//   +8   Card header + rule
//   +14  Bullets cascade (3 x 4-frame stagger)
// =============================================================
function createComparisonBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var cards      = ebCardLayout(2);
  var colors     = [ebColor(params.leftColor || '76B900'), ebColor(params.rightColor || '5D1682')];
  var defLabels  = ['Option A', 'Option B'];

  var showShadow = params.dropShadow !== false;
  var bs         = params.bodyStyle || 'bullets';

  for (var i = 0; i < 2; i++) {
    var card      = cards[i];
    var colorArr  = colors[i];
    var cardStart = startFrame + 36 + i * 9;
    var borderClr = params.cardBorder ? colorArr : null;

    // 1. Card background
    var _cmpNoFill  = (params.cardBg === false);
    var _cmpFillClr = (params.shapeFill === false) ? null : colorArr;
    var bgLayer = ebCreateCardBg(comp, card, 'EB_CompareBG_' + (i+1), null, borderClr, showShadow, _cmpNoFill, _cmpFillClr);
    if (params.animateIn) {
      try { ebAnimateFadeUp(bgLayer, cardStart, fps, 40); } catch(e) {}
    }

    // 2. Card header + rule
    var cardData  = (params.cards && params.cards[i]) ? params.cards[i] : {};
    var cardLabel = cardData.label || defLabels[i];
    var hdr = ebCreateCardHeader(comp, card, cardLabel, colorArr,
      params.animateIn, cardStart + 8, fps, params.titleAlign);

    // 3. Body — respects bodyStyle: 'text' | 'bullets' | 'pipe'
    var bodyY   = hdr.bottomY + 30;
    var _padX   = Math.max(16, Math.round(EB_LAYOUT.cardPadX * Math.min(1, card.w / 500)));
    var bodyX   = card.x - card.w/2 + _padX;
    var bFontSz = (card.w < 350) ? 20 : (card.w < 480) ? 23 : 26;
    var dotGap  = Math.round(bFontSz * 0.85);
    var bul     = String.fromCharCode(8226);
    var lineAdv = bFontSz + 30;
    var rawBody = (cardData.body !== undefined && cardData.body !== null && cardData.body !== '') ? cardData.body : null;

    if (bs === 'pipe') {
      // Split by | and render each item as its own line with a colored | marker
      var pipeDef   = 'Value A|Value B|Value C';
      var pipeStr   = rawBody || pipeDef;
      var pipeParts = pipeStr.split('|');
      var curPipeY  = bodyY;
      var colorRGB  = [colorArr[0], colorArr[1], colorArr[2]];
      for (var pIdx = 0; pIdx < pipeParts.length; pIdx++) {
        var pTxt   = pipeParts[pIdx].replace(/^\s+|\s+$/g, '');
        var pFrame = cardStart + 14 + pIdx * 4;
        var pY     = curPipeY + Math.round(bFontSz * 0.78);
        var pMark  = ebText(comp, '|', bodyX, pY, bFontSz, 'semibold', colorRGB, 'left');
        pMark.name = 'EB_CmpPipeMark_' + (i+1) + '_' + pIdx;
        ebTextAnimatorFadeUp(pMark, pFrame, fps, 20);
        var pLayer = ebText(comp, pTxt, bodyX + dotGap, pY, bFontSz, 'regular', [0, 0, 0], 'left');
        pLayer.name = 'EB_CmpPipe_' + (i+1) + '_' + pIdx;
        ebTextAnimatorFadeUp(pLayer, pFrame, fps, 20);
        curPipeY += lineAdv;
      }

    } else if (bs === 'bullets') {
      var _defBullets = 'First key point here\rSecond point goes here\rThird supporting detail';
      var bulBody  = rawBody || _defBullets;
      var bulLines = bulBody.split('\r');
      var subSz    = bFontSz - 4;
      var subAdv   = subSz + 22;
      var segGap   = 20;
      var curBulY  = bodyY;
      var prevSub  = false;
      for (var bIdx = 0; bIdx < bulLines.length; bIdx++) {
        var bln    = bulLines[bIdx];
        var bIsSub = (bln.length > 1 && bln.charAt(0) === ' ' && bln.charAt(1) === ' ');
        var bFrame = cardStart + 14 + bIdx * 4;
        if (bIsSub) {
          var sTxt    = bln.replace(/^\s+/, '');
          var sIndent = bodyX + dotGap + Math.round(dotGap * 0.85);
          var sDotY   = curBulY + Math.round(subSz * 0.78);
          var sDot    = ebText(comp, bul, sIndent - Math.round(dotGap * 0.75), sDotY, subSz, 'regular', ebColorRGB('76B900'), 'left');
          sDot.name   = 'EB_CmpSubDot_' + (i+1) + '_' + bIdx;
          ebTextAnimatorFadeUp(sDot, bFrame, fps, 14);
          var sLyr    = ebText(comp, sTxt, sIndent, sDotY, subSz, 'regular', [0.3, 0.3, 0.3], 'left');
          sLyr.name   = 'EB_CmpBody_' + (i+1) + '_' + bIdx;
          ebTextAnimatorFadeUp(sLyr, bFrame, fps, 14);
          curBulY += subAdv;
          prevSub = true;
        } else {
          if (prevSub) { curBulY += segGap; }
          prevSub = false;
          var dY  = curBulY + Math.round(bFontSz * 0.78);
          var dot = ebText(comp, bul, bodyX, dY, bFontSz, 'regular', ebColorRGB('76B900'), 'left');
          dot.name = 'EB_CmpDot_' + (i+1) + '_' + bIdx;
          ebTextAnimatorFadeUp(dot, bFrame, fps, 18);
          var txt = ebText(comp, bln, bodyX + dotGap, dY, bFontSz, 'regular', [0, 0, 0], 'left');
          txt.name = 'EB_CmpBody_' + (i+1) + '_' + bIdx;
          ebTextAnimatorFadeUp(txt, bFrame, fps, 18);
          curBulY += lineAdv;
        }
      }

    } else {
      // Text: plain lines, no bullets
      var _defText = 'First line of content here\rSecond line of supporting text\rThird point or detail here\rFourth line of content';
      var txtBody  = rawBody || _defText;
      var txtLines = txtBody.split('\r');
      var curTxtY  = bodyY;
      for (var tIdx = 0; tIdx < txtLines.length; tIdx++) {
        var tln    = txtLines[tIdx].replace(/^\s+/, '');
        var tFrame = cardStart + 14 + tIdx * 4;
        var tY     = curTxtY + Math.round(bFontSz * 0.78);
        var tLyr   = ebText(comp, tln, bodyX, tY, bFontSz, 'regular', [0, 0, 0], 'left');
        tLyr.name  = 'EB_CmpBody_' + (i+1) + '_' + tIdx;
        ebTextAnimatorFadeUp(tLyr, tFrame, fps, 20);
        curTxtY += lineAdv;
      }
    }
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// MEDIA CARD BLOCK  (cards-media)
// 1–4 side-by-side cards: header + image placeholder + body text/bullets/pipes.
// =============================================================
function createMediaCardsBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var L          = EB_LAYOUT;
  var color      = ebColor(params.accentColor || '76B900');
  var showShadow = params.dropShadow !== false;
  var n          = Math.min(Math.max(params.cards ? params.cards.length : 2, 1), 4);
  var bs         = params.bodyStyle || 'text';

  var cardH    = L.cardBottom - L.cardTop;
  var cardY    = L.cardTop + cardH / 2;
  var _fullW   = Math.round((L.compW - 2*L.marginX - Math.max(n-1,0)*L.cardGap) / n);
  // For n=1, cap at the same width as one card in a 2-card layout so it doesn't look too wide
  var _twoCardW = Math.round((L.compW - 2*L.marginX - L.cardGap) / 2);
  var cardW    = (n === 1) ? _twoCardW : _fullW;
  var cardDefs = params.cards || [];

  for (var i = 0; i < n; i++) {
    var cx        = (n === 1) ? L.compW / 2 : L.marginX + cardW/2 + i * (cardW + L.cardGap);
    var card      = { x: cx, y: cardY, w: cardW, h: cardH };
    var cardData  = cardDefs[i] || {};
    var cardLabel = cardData.label || ('Card ' + (i+1));
    var cardStart = startFrame + 36 + i * 9;
    var borderClr = params.cardBorder ? color : null;
    var _pcBefore = params.precomp ? comp.numLayers : 0;

    // 1. Background
    var _noFill  = (params.cardBg === false);
    var _fillClr = (params.shapeFill === false) ? null : color;
    var bgLayer  = ebCreateCardBg(comp, card, 'EB_MediaBG_' + (i+1), null, borderClr, showShadow, _noFill, _fillClr);
    if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, cardStart, fps, 40); } catch(e) {} }

    // 2. Header + rule
    var hdr = ebCreateCardHeader(comp, card, cardLabel, color, params.animateIn, cardStart + 8, fps, params.titleAlign);

    // 3. Image placeholder (stroke-only rect, centered)
    var imgPadX  = Math.max(20, Math.round(cardW * 0.07));
    var imgW     = cardW - imgPadX * 2;
    var imgH     = Math.round(imgW * 0.6);
    var imgMaxH  = Math.round(cardH * 0.55); // prevent overflow in wide single-card layout
    if (imgH > imgMaxH) { imgH = imgMaxH; imgW = Math.round(imgH / 0.6); }
    var imgY    = hdr.bottomY + 24 + imgH / 2;

    var imgLyr = comp.layers.addShape();
    imgLyr.name = 'EB_MediaImg_' + (i+1);
    imgLyr.position.setValue([card.x, imgY]);
    var igc = imgLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var ir  = igc.addProperty('ADBE Vector Shape - Rect');
    try { ir.property('ADBE Vector Rect Size').setValue([imgW, imgH]); }   catch(e) {}
    try { ir.property('ADBE Vector Rect Roundness').setValue(4); }         catch(e) {}
    var ist = igc.addProperty('ADBE Vector Graphic - Stroke');
    try { ist.property('ADBE Vector Stroke Color').setValue([0,0,0,1]); }  catch(e) {}
    try { ist.property('ADBE Vector Stroke Width').setValue(2.5); }        catch(e) {}
    try { ist.property('ADBE Vector Stroke Line Cap').setValue(2); }       catch(e) {}
    try { ist.property('ADBE Vector Stroke Line Join').setValue(2); }      catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(imgLyr, cardStart + 10, fps, 20); } catch(e) {} }

    // 4. Body — text / bullets / pipes below image
    var rawBody  = (cardData.body !== undefined && cardData.body !== null && cardData.body !== '') ? cardData.body : null;
    var bFontSz  = (cardW < 400) ? 20 : (cardW < 560) ? 23 : 26;
    var lineAdv  = bFontSz + 14;
    var bodyX    = card.x - card.w/2 + L.cardPadX;
    var dotGap   = Math.round(bFontSz * 0.85);
    var curBodyY = imgY + imgH / 2 + 36;
    var bul      = String.fromCharCode(8226);

    if (bs === 'bullets') {
      var bulBody  = rawBody || 'First key point here\rSecond point listed\rThird point here';
      var bulLines = bulBody.split('\r');
      for (var bi = 0; bi < bulLines.length; bi++) {
        var bFrame = cardStart + 14 + bi * 4;
        var dY     = curBodyY + Math.round(bFontSz * 0.78);
        var dot    = ebText(comp, bul, bodyX, dY, bFontSz, 'regular', [color[0],color[1],color[2]], 'left');
        dot.name   = 'EB_MediaDot_' + (i+1) + '_' + bi;
        ebTextAnimatorFadeUp(dot, bFrame, fps, 18);
        var bLyr   = ebText(comp, bulLines[bi].replace(/^\s+/,''), bodyX + dotGap, dY, bFontSz, 'regular', [0,0,0], 'left');
        bLyr.name  = 'EB_MediaBody_' + (i+1) + '_' + bi;
        ebTextAnimatorFadeUp(bLyr, bFrame, fps, 18);
        curBodyY += lineAdv;
      }
    } else if (bs === 'pipe') {
      var pipeBody  = rawBody || 'First item here\rSecond item here\rThird item here';
      var pipeLines = pipeBody.split('\r');
      for (var pi = 0; pi < pipeLines.length; pi++) {
        var pFrame = cardStart + 14 + pi * 4;
        var pY     = curBodyY + Math.round(bFontSz * 0.78);
        var pMark  = ebText(comp, '|', bodyX, pY, bFontSz, 'regular', [color[0],color[1],color[2]], 'left');
        pMark.name = 'EB_MediaPipe_' + (i+1) + '_' + pi;
        ebTextAnimatorFadeUp(pMark, pFrame, fps, 18);
        var pLyr   = ebText(comp, pipeLines[pi].replace(/^\s+/,''), bodyX + dotGap, pY, bFontSz, 'regular', [0,0,0], 'left');
        pLyr.name  = 'EB_MediaBody_' + (i+1) + '_' + pi;
        ebTextAnimatorFadeUp(pLyr, pFrame, fps, 18);
        curBodyY += lineAdv;
      }
    } else {
      var txtBody  = rawBody || 'Description text for this card\rSecond line of supporting content';
      var txtLines = txtBody.split('\r');
      for (var li = 0; li < txtLines.length; li++) {
        var tFrame = cardStart + 14 + li * 4;
        var lY     = curBodyY + Math.round(bFontSz * 0.78);
        var lLyr   = ebText(comp, txtLines[li].replace(/^\s+|\s+$/g,''), card.x, lY, bFontSz, 'regular', [0,0,0], 'center');
        lLyr.name  = 'EB_MediaBody_' + (i+1) + '_' + li;
        ebTextAnimatorFadeUp(lLyr, tFrame, fps, 20);
        curBodyY += lineAdv;
      }
    }

    if (params.precomp) { _ebPrecompCard(comp, _pcBefore, 'Card ' + (i+1), cardStart, fps, card.x, card.y); }
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// CORNER BRACKET CARDS BLOCK  (cards-corner)
// 2x2 grid of cards with title + animated L-bracket corners.
// Each card colour can be set via params.cards[i].accentColor.
// The two brackets per card draw in with ease-in/out trim path.
// =============================================================
// Shared helper: draw one L-bracket as a shape layer with optional trim-path animation.
// pts = 3 absolute comp-space vertices [start, corner, end].
function _ebCornerBracket(comp, nm, pts, sw, clr4, animIn, fps, bStart) {
  var bl = comp.layers.addShape();
  bl.name = nm;
  bl.position.setValue([0, 0]);
  var bgc = bl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bps = bgc.addProperty('ADBE Vector Shape - Group');
  try { bps.property('ADBE Vector Shape').setValue(ebOpenPath(pts)); } catch(e) {}
  var bst = bgc.addProperty('ADBE Vector Graphic - Stroke');
  try { bst.property('ADBE Vector Stroke Color').setValue(clr4); }  catch(e) {}
  try { bst.property('ADBE Vector Stroke Width').setValue(sw); }    catch(e) {}
  try { bst.property('ADBE Vector Stroke Line Cap').setValue(2); }  catch(e) {}
  try { bst.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  if (animIn) {
    var tr    = bgc.addProperty('ADBE Vector Filter - Trim');
    var trEnd = tr.property('ADBE Vector Trim End');
    try { bl.inPoint = bStart / fps; } catch(e) {}
    ebAnimateTrimDraw(trEnd, bStart, fps);
  }
  return bl;
}

// Shared helper: render one corner card (bg + title + optional body lines + TL/BR brackets).
// bodyLines: array of strings, or empty/null for no body text.
function _ebCornerCard(comp, params, fps, nm, cx, cy, cardW, cardH, label, bodyLines, hexColor, cardStart) {
  var L    = EB_LAYOUT;
  var sw   = L.bracketStroke;
  var cArr = ebColor(hexColor);
  var cRGB = [cArr[0], cArr[1], cArr[2]];
  var c4   = [cArr[0], cArr[1], cArr[2], 1];
  var hw   = cardW / 2;
  var hh   = cardH / 2;
  var hArm = Math.round(cardW * 0.4);
  var vArm = Math.round(cardH * 0.4);

  var card       = { x: cx, y: cy, w: cardW, h: cardH };
  var _greyBorder = [0.7, 0.7, 0.7, 1];
  var borderClr  = params.cardBorder ? _greyBorder : null;
  var bgLayer = ebCreateCardBg(comp, card, 'EB_' + nm + 'BG', null, borderClr,
    params.dropShadow !== false, true, cArr);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, cardStart, fps, 30); } catch(e) {} }

  // Title/body alignment: 'left' (default), 'center', or 'right'.
  var tAlign = (params.titleAlign === 'center' || params.titleAlign === 'right') ? params.titleAlign : 'left';
  var textX;
  if (tAlign === 'center')      textX = cx;
  else if (tAlign === 'right')  textX = cx + hw - L.cardPadX;
  else                          textX = cx - hw + L.cardPadX;

  var _tFSz    = Math.max(16, Math.min(L.headerFontSize, Math.round((cardW - L.cardPadX * 2) / 7)));
  var titleY   = cy - hh + L.cardPadTop + _tFSz;
  var tlLyr    = ebText(comp, label, textX, titleY, _tFSz, 'semibold', cRGB, tAlign);
  tlLyr.name = 'EB_' + nm + 'Title';
  ebTextAnimatorFadeUp(tlLyr, cardStart + 8, fps, 18);

  // Body text lines (optional) — same horizontal alignment as title
  if (bodyLines && bodyLines.length) {
    // Scale font to fit available card width (card width minus both side paddings)
    var _availW  = cardW - L.cardPadX * 2;
    var bFSz     = Math.max(13, Math.min(Math.round(L.headerFontSize * 0.77), Math.round(_availW / 13)));
    var bLineAdv = bFSz + 16;
    var bY       = titleY + _tFSz + 10; // start below title baseline
    var maxLines = Math.min(bodyLines.length, 4);
    for (var bli = 0; bli < maxLines; bli++) {
      var bLyr = ebText(comp, bodyLines[bli], textX,
        bY + Math.round(bFSz * 0.78), bFSz, 'regular', [0, 0, 0], tAlign);
      bLyr.name = 'EB_' + nm + 'Body' + bli;
      ebTextAnimatorFadeUp(bLyr, cardStart + 12 + bli * 3, fps, 14);
      bY += bLineAdv;
    }
  }

  _ebCornerBracket(comp, 'EB_' + nm + 'TL',
    [[cx-hw, cy-hh+vArm], [cx-hw, cy-hh], [cx-hw+hArm, cy-hh]],
    sw, c4, params.animateIn, fps, cardStart);
  _ebCornerBracket(comp, 'EB_' + nm + 'BR',
    [[cx+hw, cy+hh-vArm], [cx+hw, cy+hh], [cx+hw-hArm, cy+hh]],
    sw, c4, params.animateIn, fps, cardStart + 4);
}

// =============================================================
// CORNER BRACKET CARDS — 2×2 RECTANGULAR  (cards-corner)
// =============================================================
function createCornerCardsBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var L        = EB_LAYOUT;
  var n        = Math.min(Math.max(params.cardCount || 4, 1), 6);
  var rows     = (params.cornerRows === 2) ? 2 : 1;
  var defHex   = ['76B900', '5D1682', '2F80ED', 'F2C94C', '890C58', '008564'];
  var cardDefs = params.cards || [];

  var slots = _ebCornerSlots(L, n, rows, 'rect');

  for (var i = 0; i < n; i++) {
    var cardData  = cardDefs[i] || {};
    var hex       = cardData.accentColor || params.accentColor || defHex[i % defHex.length];
    var bodyLines = cardData.body ? cardData.body.split('\r') : [];
    var sl        = slots[i];
    var cardStart = sf + 36 + i * 9;
    var _pcBefore = params.precomp ? comp.numLayers : 0;
    _ebCornerCard(comp, params, fps,
      'Crnr_' + (i+1) + '_',
      sl.x, sl.y, sl.w, sl.h,
      cardData.label || ('Title ' + (i+1)),
      bodyLines, hex, sf + 36 + i * 9);
    if (params.precomp) { _ebPrecompCard(comp, _pcBefore, 'Card ' + (i+1), cardStart, fps, sl.x, sl.y); }
  }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// CORNER BRACKET CARDS — 2×2 SQUARE  (cards-corner-sq)
// Cards are constrained to a square (equal w & h).
// =============================================================
function createCornerSquareBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var L        = EB_LAYOUT;
  var n        = Math.min(Math.max(params.cardCount || 4, 1), 6);
  var rows     = (params.cornerRows === 2) ? 2 : 1;
  var defHex   = ['76B900', '5D1682', '2F80ED', 'F2C94C', '890C58', '008564'];
  var cardDefs = params.cards || [];

  var slots = _ebCornerSlots(L, n, rows, 'square');

  for (var i = 0; i < n; i++) {
    var cardData  = cardDefs[i] || {};
    var hex       = cardData.accentColor || params.accentColor || defHex[i % defHex.length];
    var bodyLines = cardData.body ? cardData.body.split('\r') : [];
    var sl        = slots[i];
    var cardStart = sf + 36 + i * 9;
    var _pcBefore = params.precomp ? comp.numLayers : 0;
    _ebCornerCard(comp, params, fps,
      'CrnrSq_' + (i+1) + '_',
      sl.x, sl.y, sl.w, sl.h,
      cardData.label || ('Title ' + (i+1)),
      bodyLines, hex, sf + 36 + i * 9);
    if (params.precomp) { _ebPrecompCard(comp, _pcBefore, 'Card ' + (i+1), cardStart, fps, sl.x, sl.y); }
  }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// CORNER BRACKET CARDS — SLIM 1×4  (cards-corner-slim)
// Single row of 4 slim horizontal cards.
// =============================================================
function createCornerSlimBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var L        = EB_LAYOUT;
  var n        = Math.min(Math.max(params.cardCount || 4, 1), 6);
  var rows     = (params.cornerRows === 2) ? 2 : 1;
  var defHex   = ['76B900', '5D1682', '2F80ED', 'F2C94C', '890C58', '008564'];
  var cardDefs = params.cards || [];

  var slots = _ebCornerSlots(L, n, rows, 'slim');

  for (var i = 0; i < n; i++) {
    var cardData  = cardDefs[i] || {};
    var hex       = cardData.accentColor || params.accentColor || defHex[i % defHex.length];
    var bodyLines = cardData.body ? cardData.body.split('\r') : [];
    var sl        = slots[i];
    var cardStart = sf + 36 + i * 9;
    var _pcBefore = params.precomp ? comp.numLayers : 0;
    _ebCornerCard(comp, params, fps,
      'CrnrSlim_' + (i+1) + '_',
      sl.x, sl.y, sl.w, sl.h,
      cardData.label || ('Title ' + (i+1)),
      bodyLines, hex, sf + 36 + i * 9);
    if (params.precomp) { _ebPrecompCard(comp, _pcBefore, 'Card ' + (i+1), cardStart, fps, sl.x, sl.y); }
  }
  ebCreateHeader(comp, params, sf);
}

// Shared corner-card slot calculator. Returns array of {x,y,w,h} for n cards
// arranged in 1 or 2 rows, with sizing depending on the variant:
//   'rect'   — rectangular cards filling the content zone
//   'square' — square cards (w == h), centered in the zone
//   'slim'   — portrait (taller than wide), centered with fixed-ish width
// rows=2 splits top-heavy: ceil(n/2) on top, floor(n/2) on bottom.
function _ebCornerSlots(L, n, rows, variant) {
  variant = variant || 'rect';
  var gap   = L.cardGap;
  var fullW = L.compW - 2 * L.marginX;
  var fullH = L.cardBottom - L.cardTop;
  var cy    = (L.cardTop + L.cardBottom) / 2;
  var out   = [];

  // n=1 is always single full card regardless of variant or rows.
  if (n === 1) {
    if (variant === 'square') {
      var sq1 = Math.min(fullW, fullH);
      out.push({ x: L.compW / 2, y: cy, w: sq1, h: sq1 });
    } else if (variant === 'slim') {
      out.push({ x: L.compW / 2, y: cy, w: 280, h: Math.round(fullH * 0.62) });
    } else {
      out.push({ x: L.compW / 2, y: cy, w: fullW, h: fullH });
    }
    return out;
  }

  // Decide row sizes
  var topN = (rows === 2) ? Math.ceil(n / 2) : n;
  var botN = (rows === 2) ? (n - topN)       : 0;
  var rowsActive = botN > 0 ? 2 : 1;
  var rowH = rowsActive === 2 ? Math.round((fullH - gap) / 2) : fullH;
  var topY = rowsActive === 2 ? (L.cardTop + rowH / 2)              : cy;
  var botY = rowsActive === 2 ? (L.cardTop + rowH + gap + rowH / 2) : cy;

  function buildRow(count, y) {
    if (count <= 0) return;
    var w, h;
    if (variant === 'square') {
      // Each cell is square — sized to fit row height AND row width.
      var maxCellW = Math.floor((fullW - (count - 1) * gap) / count);
      h = Math.min(rowH, maxCellW);
      w = h;
    } else if (variant === 'slim') {
      // Portrait: prefer 280px wide but shrink to fit.
      var preferred = 280;
      var needed    = count * preferred + (count - 1) * gap;
      w = needed > fullW ? Math.floor((fullW - (count - 1) * gap) / count) : preferred;
      // Slim height = a bit shorter than the row height for portrait feel.
      h = Math.min(rowH, Math.round((L.cardBottom - L.cardTop) * 0.62));
    } else {
      // Rect: fill the row width evenly.
      w = Math.floor((fullW - (count - 1) * gap) / count);
      h = rowH;
    }
    var totalW = count * w + (count - 1) * gap;
    var startX = L.marginX + (fullW - totalW) / 2 + w / 2;
    for (var i = 0; i < count; i++) {
      out.push({ x: startX + i * (w + gap), y: y, w: w, h: h });
    }
  }

  buildRow(topN, topY);
  if (botN > 0) buildRow(botN, botY);
  return out;
}

// =============================================================
// SPECS CARDS  —  shared helpers
// =============================================================

// Chip/GPU icon: outer rounded rect + cross lines (layer at [cx,cy])
function _ebSpecsChipIcon(comp, nm, cx, cy, sz, clr4, animIn, frm, fps) {
  var l   = comp.layers.addShape(); l.name = nm;
  l.position.setValue([cx, cy]);
  var ct  = l.property('Contents');
  var arm = sz * 0.33;
  var g1c = ct.addProperty('ADBE Vector Group').property('Contents');
  var r1  = g1c.addProperty('ADBE Vector Shape - Rect');
  try { r1.property('ADBE Vector Rect Size').setValue([sz, sz]); }       catch(e){}
  try { r1.property('ADBE Vector Rect Roundness').setValue(4); }         catch(e){}
  var s1  = g1c.addProperty('ADBE Vector Graphic - Stroke');
  try { s1.property('ADBE Vector Stroke Color').setValue(clr4); }        catch(e){}
  try { s1.property('ADBE Vector Stroke Width').setValue(2); }           catch(e){}
  var g2c = ct.addProperty('ADBE Vector Group').property('Contents');
  var p2  = g2c.addProperty('ADBE Vector Shape - Group');
  try { p2.property('ADBE Vector Shape').setValue(ebOpenPath([[-arm,0],[arm,0]])); } catch(e){}
  var s2  = g2c.addProperty('ADBE Vector Graphic - Stroke');
  try { s2.property('ADBE Vector Stroke Color').setValue(clr4); }        catch(e){}
  try { s2.property('ADBE Vector Stroke Width').setValue(1.5); }         catch(e){}
  var g3c = ct.addProperty('ADBE Vector Group').property('Contents');
  var p3  = g3c.addProperty('ADBE Vector Shape - Group');
  try { p3.property('ADBE Vector Shape').setValue(ebOpenPath([[0,-arm],[0,arm]])); } catch(e){}
  var s3  = g3c.addProperty('ADBE Vector Graphic - Stroke');
  try { s3.property('ADBE Vector Stroke Color').setValue(clr4); }        catch(e){}
  try { s3.property('ADBE Vector Stroke Width').setValue(1.5); }         catch(e){}
  if (animIn) { try { ebAnimateFadeUp(l, frm, fps, 14); } catch(e){} }
  return l;
}

// Horizontal rule (layer at [0,0]; x1,x2,y in comp space)
function _ebSpecsRule(comp, nm, x1, x2, y, clr4, animIn, frm, fps) {
  var l = comp.layers.addShape(); l.name = nm;
  l.position.setValue([0, 0]);
  var gc = l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var ps = gc.addProperty('ADBE Vector Shape - Group');
  try { ps.property('ADBE Vector Shape').setValue(ebOpenPath([[x1,y],[x2,y]])); } catch(e){}
  var st = gc.addProperty('ADBE Vector Graphic - Stroke');
  try { st.property('ADBE Vector Stroke Color').setValue(clr4); } catch(e){}
  try { st.property('ADBE Vector Stroke Width').setValue(1); }    catch(e){}
  try { st.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e){}
  if (animIn && frm !== undefined && fps) {
    try { ebAnimateFadeUp(l, frm, fps, 8); } catch(e){}
  }
  return l;
}

/// Tag chip: rounded rect outline + centered text. Returns chip width + gap.
// leftX = chip box LEFT EDGE = content column x (= "Use Cases" alignment).
// Text sits padX inside the box on each side → perfectly centered.
function _ebSpecsTag(comp, nm, text, leftX, cy, clr4, animIn, frm, fps) {
  var fsz = 22; var padX = 22; var padY = 8;
  var chipH = fsz + padY * 2;
  var chW = 0;
  for (var ci = 0; ci < text.length; ci++) {
    var c = text.charCodeAt(ci);
    if      (c === 77 || c === 87)                { chW += 0.95; }
    else if (c >= 65 && c <= 90)                  { chW += 0.78; }
    else if (c === 32)                            { chW += 0.30; }
    else if (c >= 48 && c <= 57)                  { chW += 0.65; }
    else if (c === 105 || c === 108 || c === 106) { chW += 0.35; }
    else if (c === 109 || c === 119)              { chW += 0.92; }
    else                                          { chW += 0.66; }
  }
  var textW = Math.ceil(chW * fsz) + 10;
  var chipW = textW + padX * 2;
  var chipCX = leftX + chipW / 2;

  var tL = ebText(comp, text, leftX + padX, cy + Math.round(fsz * 0.38), fsz, 'regular', [clr4[0],clr4[1],clr4[2]], 'left');
  tL.name = nm + 'Txt';
  try {
    var sr = tL.sourceRectAtTime(0, false);
    if (sr.width > 20) { textW = Math.round(sr.width); chipW = textW + padX * 2; chipCX = leftX + chipW / 2; }
  } catch(e) {}

  var bgL = comp.layers.addShape(); bgL.name = nm + 'Bg';
  bgL.position.setValue([chipCX, cy]);
  var bgc = bgL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bgr = bgc.addProperty('ADBE Vector Shape - Rect');
  try { bgr.property('ADBE Vector Rect Size').setValue([chipW, chipH]); } catch(e){}
  try { bgr.property('ADBE Vector Rect Roundness').setValue(5); }         catch(e){}
  var bgs = bgc.addProperty('ADBE Vector Graphic - Stroke');
  try { bgs.property('ADBE Vector Stroke Color').setValue(clr4); }        catch(e){}
  try { bgs.property('ADBE Vector Stroke Width').setValue(1.5); }         catch(e){}
  try { bgL.moveAfter(tL); } catch(e) {}
  if (animIn) { try { ebAnimateFadeUp(bgL, frm, fps, 12); } catch(e){} }
  if (animIn) { try { ebTextAnimatorFadeUp(tL, frm, fps, 12); } catch(e){} }
  return chipW + 28;
}

// =============================================================
// SPECS CARD A  (cards-specs-a)
// Green bold title + subtitle | rule | icon + model name + right
// badge pill | "Use Cases" header | square bullets | tag pills
// =============================================================
function createSpecsCardA(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var L     = EB_LAYOUT;
  var color = ebColor(params.accentColor || '76B900');
  var c4    = [color[0],color[1],color[2],1];
  var cRGB  = [color[0],color[1],color[2]];
  var black = [0,0,0]; var grey = [0.5,0.5,0.5]; var dk = [0.3,0.3,0.3,1];

  var cardW = L.compW - 2*L.marginX; var cardH = 548;
  // Shift cardCY down by 24 so bottom of card extends by 48px while cTop stays the same.
  var cardCX = L.compW/2; var cardCY = (L.cardTop+L.cardBottom)/2 + 24;
  var card = {x:cardCX, y:cardCY, w:cardW, h:cardH};
  var left = cardCX - cardW/2 + L.cardPadX; var right = cardCX + cardW/2 - L.cardPadX;
  var cTop = cardCY - cardH/2;

  var bgL = ebCreateCardBg(comp, card, 'EB_SABg', null, color, params.dropShadow!==false, true, color);
  if (params.animateIn) { try { ebAnimateFadeUp(bgL, sf+36, fps, 40); } catch(e){} }

  // Title — full green bold
  var tFSz = 42; var Y = cTop + 44;
  var tLyr = ebText(comp, (params.configLabel||'Configuration')+' '+(params.configCode||'2-4-3-200'),
    left, Y + Math.round(tFSz*0.78), tFSz, 'bold', cRGB, 'left');
  tLyr.name = 'EB_SATitle';
  ebTextAnimatorFadeUp(tLyr, sf+36+8, fps, 18);
  Y += tFSz;

  // Subtitle
  var sFSz = 26; Y += 12;
  var sLyr = ebText(comp, params.subtitle||'Flexible Entry Point', left, Y+Math.round(sFSz*0.78), sFSz, 'regular', black, 'left');
  sLyr.name = 'EB_SASub';
  ebTextAnimatorFadeUp(sLyr, sf+36+10, fps, 14);
  Y += sFSz;

  // Rule
  Y += 16; _ebSpecsRule(comp, 'EB_SARule', left, right, Y, [0.75,0.75,0.75,1], params.animateIn, sf+36+11, fps);

  // Model row
  var iconSz = 38; Y += 44; var modelCY = Y + iconSz*0.1;
  // Icon vertically centred between H100 NVL + "or L40S" (group spans modelCY-5 to modelCY+45).
  _ebSpecsChipIcon(comp, 'EB_SAIcon', left+iconSz/2, modelCY+20, iconSz, [0.4,0.4,0.4,1], params.animateIn, sf+36+12, fps);
  var mFSz = 30; var mX = left + iconSz + 10;
  var mLyr = ebText(comp, params.modelName||'H100 NVL', mX, modelCY-6+Math.round(mFSz*0.78), mFSz, 'semibold', black, 'left');
  mLyr.name = 'EB_SAModel';
  ebTextAnimatorFadeUp(mLyr, sf+36+12, fps, 16);
  var aFSz = 22;
  var aLyr = ebText(comp, params.modelAlt||'or L40S', mX, modelCY+28+Math.round(aFSz*0.78), aFSz, 'regular', grey, 'left');
  aLyr.name = 'EB_SAAlt';
  ebTextAnimatorFadeUp(aLyr, sf+36+13, fps, 12);

  // Right badge pill — LEFT-justify at box_left+bPX so text is geometrically centred.
  var bdg = params.badge || '4 GPUs'; var bFSz = 22; var bPX = 18; var bPY = 9;
  var bH = bFSz + bPY * 2; var bMidY = modelCY + 20;
  var _bdgChW = 0;
  for (var _bi = 0; _bi < bdg.length; _bi++) {
    var _bc = bdg.charCodeAt(_bi);
    if (_bc===73||_bc===74){_bdgChW+=0.38;}else if(_bc===77||_bc===87){_bdgChW+=0.88;}else if(_bc>=65&&_bc<=90){_bdgChW+=0.72;}
    else if(_bc===32){_bdgChW+=0.27;}else if(_bc>=48&&_bc<=57){_bdgChW+=0.57;}
    else if(_bc===105||_bc===108||_bc===106){_bdgChW+=0.30;}else if(_bc===109||_bc===119){_bdgChW+=0.85;}else{_bdgChW+=0.58;}
  }
  var bdgTextW = Math.ceil(_bdgChW * bFSz) + 8;
  var bW = bdgTextW + bPX * 2;
  var bCX = right - bW / 2;
  var bdgT = ebText(comp, bdg, right - bW + bPX, bMidY + Math.round(bFSz * 0.38), bFSz, 'regular', black, 'left');
  bdgT.name = 'EB_SABadgeTxt';
  try {
    var _bdgSR = bdgT.sourceRectAtTime(0, false);
    if (_bdgSR.width > 10) { bdgTextW = Math.round(_bdgSR.width); bW = bdgTextW + bPX * 2; bCX = right - bW / 2; }
  } catch(e) {}
  // Badge border box
  var bdgL = comp.layers.addShape(); bdgL.name = 'EB_SABadge';
  bdgL.position.setValue([bCX, bMidY]);
  var bdgGC = bdgL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bdgR = bdgGC.addProperty('ADBE Vector Shape - Rect');
  try { bdgR.property('ADBE Vector Rect Size').setValue([bW, bH]); }     catch(e){}
  try { bdgR.property('ADBE Vector Rect Roundness').setValue(5); }       catch(e){}
  var bdgST = bdgGC.addProperty('ADBE Vector Graphic - Stroke');
  try { bdgST.property('ADBE Vector Stroke Color').setValue(c4); }       catch(e){}
  try { bdgST.property('ADBE Vector Stroke Width').setValue(2); }        catch(e){}
  try { bdgL.moveAfter(bdgT); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(bdgL, sf+36+12, fps, 10); } catch(e){} }
  ebTextAnimatorFadeUp(bdgT, sf+36+12, fps, 10);

  // Square bullets
  Y += iconSz + 44;
  var bullets = params.bullets || ['Visual Computing','Medium Inference','Small Training'];
  var bulFSz = 26; var sqSz = 18; var bulAdv = bulFSz + 20; var sqGap = 10;
  for (var b = 0; b < bullets.length; b++) {
    var bFrm = sf+36+16+b*3; var bRowY = Y + b*bulAdv;
    var sqCY = bRowY + Math.round(bulFSz * 0.5) - Math.round(sqSz * 0.5);
    var sqL = comp.layers.addSolid(cRGB, 'EB_SABulSq_'+b, sqSz, sqSz, 1);
    try { sqL.anchorPoint.setValue([0, 0]); } catch(e) {}
    sqL.position.setValue([left, sqCY]);
    try { ebAnimateFadeUp(sqL, bFrm, fps, 0); } catch(e) { try { sqL.inPoint = bFrm / fps; } catch(e2) {} }
    var btL = ebText(comp, bullets[b], left + sqSz + sqGap, bRowY+Math.round(bulFSz*0.78), bulFSz, 'regular', black, 'left');
    btL.name = 'EB_SABul_'+b; ebTextAnimatorFadeUp(btL, bFrm, fps, 14);
  }
  Y += bullets.length * bulAdv + 14;

  // Use Cases header + chip tags (below bullets)
  var ucFSz = 26;
  var ucL = ebText(comp, 'Use Cases', left, Y+Math.round(ucFSz*0.78), ucFSz, 'semibold', black, 'left');
  ucL.name = 'EB_SAUCHead'; ebTextAnimatorFadeUp(ucL, sf+36+14, fps, 14);
  Y += ucFSz + 16;
  var tags = params.tags || ['NVLink Inside','PCIe Scale-out'];
  var tagCY = Y + Math.round((22 + 16) * 0.5); var tagX = left;
  for (var t = 0; t < tags.length; t++) {
    tagX += _ebSpecsTag(comp, 'EB_SATag_'+t+'_', tags[t], tagX, tagCY, dk, params.animateIn, sf+36+22+t*3, fps);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// SPECS CARD B  (cards-specs-b)
// Icon + config title (black+green) | rule | bold key: value rows | "Use Cases" header | tag chip row
// =============================================================
function createSpecsCardB(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var L     = EB_LAYOUT;
  var color = ebColor(params.accentColor || '76B900');
  var c4    = [color[0],color[1],color[2],1];
  var cRGB  = [color[0],color[1],color[2]];
  var black = [0,0,0]; var dk = [0.3,0.3,0.3,1];

  var cardW = L.compW - 2*L.marginX; var cardH = 420;
  var cardCX = L.compW/2; var cardCY = (L.cardTop+L.cardBottom)/2;
  var card = {x:cardCX, y:cardCY, w:cardW, h:cardH};
  var left = cardCX - cardW/2 + L.cardPadX; var right = cardCX + cardW/2 - L.cardPadX;
  var cTop = cardCY - cardH/2;

  var bgL = ebCreateCardBg(comp, card, 'EB_SBBg', null, color, params.dropShadow!==false, true, color);
  if (params.animateIn) { try { ebAnimateFadeUp(bgL, sf+36, fps, 40); } catch(e){} }

  // Title row: icon + "Configuration " (black) + code (green)
  var iconSz = 34; var tFSz = 38;
  var Y = cTop + 52; var titleRowCY = Y + Math.round(iconSz * 0.45);
  _ebSpecsChipIcon(comp, 'EB_SBIcon', left+iconSz/2, titleRowCY+6, iconSz, [0.4,0.4,0.4,1], params.animateIn, sf+36+8, fps);
  var lblX = left + iconSz + 12;
  var lblStr = (params.configLabel || 'Configuration') + ' ';
  var lblLyr = ebText(comp, lblStr, lblX, titleRowCY+Math.round(tFSz*0.78)-tFSz*0.3, tFSz, 'semibold', black, 'left');
  lblLyr.name = 'EB_SBLabel'; ebTextAnimatorFadeUp(lblLyr, sf+36+8, fps, 16);
  var codeX = lblX;
  try { var sr = lblLyr.sourceRectAtTime(0,false); codeX = lblX + sr.width + 12; } catch(e) {
    codeX = lblX + Math.round(lblStr.length * tFSz * 0.52); }
  var codeLyr = ebText(comp, params.configCode||'2-2-3-400', codeX, titleRowCY+Math.round(tFSz*0.78)-tFSz*0.3, tFSz, 'bold', cRGB, 'left');
  codeLyr.name = 'EB_SBCode'; ebTextAnimatorFadeUp(codeLyr, sf+36+8, fps, 16);
  Y += iconSz;

  // Rule
  Y += 18; _ebSpecsRule(comp, 'EB_SBRule', left, right, Y, [0.75,0.75,0.75,1], params.animateIn, sf+36+10, fps);

  // Key-value rows
  var kvFSz = 26; var kvAdv = kvFSz + 26; Y += 36;
  var kvRows = params.kvRows || [
    {key:'Technology', value:'NVLink-C2C \u2014 GPUs access CPU memory directly'},
    {key:'Hardware',   value:'GH200 NVL2 Superchip'},
    {key:'Benefit',    value:'Ideal for memory-intensive workloads'}
  ];
  for (var k = 0; k < kvRows.length; k++) {
    var kFrm = sf+36+12+k*3; var kY = Y + k*kvAdv;
    var kBaseline = kY + Math.round(kvFSz*0.78);
    var kStr = kvRows[k].key + ':';
    var kLyr = ebText(comp, kStr, left, kBaseline, kvFSz, 'semibold', black, 'left');
    kLyr.name = 'EB_SBKey_'+k; ebTextAnimatorFadeUp(kLyr, kFrm, fps, 14);
    var vX = left;
    try { var kSR = kLyr.sourceRectAtTime(0,false); vX = left + kSR.width + 14; } catch(e) {
      vX = left + Math.round(kStr.length * kvFSz * 0.52) + 14; }
    var vLyr = ebText(comp, kvRows[k].value, vX, kBaseline, kvFSz, 'regular', black, 'left');
    vLyr.name = 'EB_SBVal_'+k; ebTextAnimatorFadeUp(vLyr, kFrm, fps, 14);
  }
  Y += kvRows.length * kvAdv;

  // Use Cases header
  var ucFSz = 26; Y += 18;
  var ucL = ebText(comp, 'Use Cases', left, Y+Math.round(ucFSz*0.78), ucFSz, 'semibold', black, 'left');
  ucL.name = 'EB_SBUCHead'; ebTextAnimatorFadeUp(ucL, sf+36+20, fps, 14);
  Y += ucFSz + 18;

  // Tag chips below "Use Cases"
  var tags = params.tags || ['RAG','Recommenders','Graph Neural Networks'];
  var tagCY = Y + Math.round((22 + 16) * 0.5); var tagX = left;
  for (var t = 0; t < tags.length; t++) {
    tagX += _ebSpecsTag(comp, 'EB_SBTag_'+t+'_', tags[t], tagX, tagCY, dk, params.animateIn, sf+36+22+t*3, fps);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// SPECS CARD C  (cards-specs-c)
// Icon + config title (black+green) | rule | table rows:
// green-bold label column | value column, separated by thin lines
// =============================================================
function createSpecsCardC(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var L     = EB_LAYOUT;
  var color = ebColor(params.accentColor || '76B900');
  var c4    = [color[0],color[1],color[2],1];
  var cRGB  = [color[0],color[1],color[2]];
  var black = [0,0,0];

  var cardW = L.compW - 2*L.marginX; var cardH = 360;
  var cardCX = L.compW/2; var cardCY = (L.cardTop+L.cardBottom)/2;
  var card = {x:cardCX, y:cardCY, w:cardW, h:cardH};
  var left = cardCX - cardW/2 + L.cardPadX; var right = cardCX + cardW/2 - L.cardPadX;
  var cTop = cardCY - cardH/2;

  var bgL = ebCreateCardBg(comp, card, 'EB_SCBg', null, color, params.dropShadow!==false, true, color);
  if (params.animateIn) { try { ebAnimateFadeUp(bgL, sf+36, fps, 40); } catch(e){} }

  // Title row: icon + "Configuration " (black) + code (green)
  var iconSz = 34; var tFSz = 38;
  var Y = cTop + 52; var titleRowCY = Y + Math.round(iconSz * 0.45);
  _ebSpecsChipIcon(comp, 'EB_SCIcon', left+iconSz/2, titleRowCY, iconSz, [0.4,0.4,0.4,1], params.animateIn, sf+36+8, fps);
  var lblX  = left + iconSz + 24;
  var lblStr = (params.configLabel || 'Configuration') + ' ';
  var lblLyr = ebText(comp, lblStr, lblX, titleRowCY+Math.round(tFSz*0.78)-tFSz*0.3, tFSz, 'semibold', black, 'left');
  lblLyr.name = 'EB_SCLabel'; ebTextAnimatorFadeUp(lblLyr, sf+36+8, fps, 16);
  var codeX = lblX;
  try { var sr = lblLyr.sourceRectAtTime(0,false); codeX = lblX + sr.width + 12; } catch(e) {
    codeX = lblX + Math.round(lblStr.length * tFSz * 0.52); }
  var codeLyr = ebText(comp, params.configCode||'2-8-9-400', codeX, titleRowCY+Math.round(tFSz*0.78)-tFSz*0.3, tFSz, 'bold', cRGB, 'left');
  codeLyr.name = 'EB_SCCode'; ebTextAnimatorFadeUp(codeLyr, sf+36+8, fps, 16);
  Y += iconSz;

  // Rule
  Y += 18; _ebSpecsRule(comp, 'EB_SCRule', left, right, Y, [0.75,0.75,0.75,1], params.animateIn, sf+36+10, fps);

  // Table rows: green label | value, with separator lines between rows
  var rowFSz = 28; var rowPad = 16; var rowH = rowFSz + rowPad*2;
  var labelColW = Math.round(cardW * 0.17);  // ~17% for label column
  var valX = left + labelColW + 24;
  var rows = params.rows || [
    {label:'Hardware',   value:'HGX H100, H200, or B200'},
    {label:'Bandwidth',  value:'400 GbE East-West Traffic per GPU'},
    {label:'Use Cases',  value:'Large Model Training, Heavy Fine-tuning'}
  ];
  Y += 28;
  for (var r = 0; r < rows.length; r++) {
    var rFrm = sf+36+12+r*4; var rTop = Y + r*rowH;
    var rBaseline = rTop + rowPad + Math.round(rowFSz*0.78);
    var lLyr = ebText(comp, rows[r].label, left, rBaseline, rowFSz, 'semibold', cRGB, 'left');
    lLyr.name = 'EB_SCLbl_'+r; ebTextAnimatorFadeUp(lLyr, rFrm, fps, 14);
    var vLyr = ebText(comp, rows[r].value, valX, rBaseline, rowFSz, 'regular', black, 'left');
    vLyr.name = 'EB_SCVal_'+r; ebTextAnimatorFadeUp(vLyr, rFrm, fps, 14);
    // Separator line between rows (skip after last)
    if (r < rows.length - 1) {
      _ebSpecsRule(comp, 'EB_SCSep_'+r, left, right, rTop + rowH - 1, [0.82,0.82,0.82,1], params.animateIn, rFrm, fps);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// SHARED HELPERS — card outline circle + card border rect
// =============================================================
function _ebCircleOutline(comp, name, cx, cy, D, strokeColor, strokeW, animSF, fps, doAnim) {
  var lyr = comp.layers.addShape();
  lyr.name = name;
  lyr.position.setValue([cx, cy]);
  var grp = lyr.property('Contents').addProperty('ADBE Vector Group');
  grp.name = 'Circle';
  var c = grp.property('Contents');
  var r = c.addProperty('ADBE Vector Shape - Rect');
  try { r.property('ADBE Vector Rect Size').setValue([D, D]); } catch(e) {}
  try { r.property('ADBE Vector Rect Roundness').setValue(D / 2); } catch(e) {}
  var s = c.addProperty('ADBE Vector Graphic - Stroke');
  try { s.property('ADBE Vector Stroke Color').setValue(strokeColor); } catch(e) {}
  try { s.property('ADBE Vector Stroke Width').setValue(strokeW || 2); } catch(e) {}
  if (doAnim) { ebAnimateFadeUp(lyr, animSF, fps, 16); }
  return lyr;
}

function _ebCardBorderRect(comp, name, cx, cy, w, h, animSF, fps, doAnim) {
  var lyr = comp.layers.addShape();
  lyr.name = name;
  lyr.position.setValue([cx, cy]);
  var grp = lyr.property('Contents').addProperty('ADBE Vector Group');
  grp.name = 'Border';
  var c = grp.property('Contents');
  var r = c.addProperty('ADBE Vector Shape - Rect');
  try { r.property('ADBE Vector Rect Size').setValue([w, h]); } catch(e) {}
  var s = c.addProperty('ADBE Vector Graphic - Stroke');
  try { s.property('ADBE Vector Stroke Color').setValue([0.87, 0.87, 0.87, 1]); } catch(e) {}
  try { s.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
  if (doAnim) { ebAnimateFadeUp(lyr, animSF, fps, 24); }
  return lyr;
}

// =============================================================
// TOP-BAR CARDS  (cards-top-bar)
// 3 white cards with accent bar at top, circle icon placeholder,
// bold title, left-aligned text body.
// =============================================================
function createTopBarCardsBlock(comp, params) {
  var fps     = comp.frameRate;
  var sf      = 1;
  var color   = ebColor(params.accentColor || '76B900');
  var cRGB    = [color[0], color[1], color[2]];
  var cArr    = [color[0], color[1], color[2], 1];
  var black   = [0, 0, 0];
  var textClr = [0.15, 0.15, 0.15];

  var N        = 3;
  var cardW    = 568;
  var cardH    = 740;
  var gap      = 28;
  var leftX    = 80;
  var cardTopY = 230;
  var cardCY   = cardTopY + cardH / 2;   // 600
  var barH     = 10;
  var circleD  = 72;

  var defCards = [
    { label: 'Service One',   text: 'First benefit or feature\nSecond benefit or feature\nThird benefit or feature\nFourth benefit' },
    { label: 'Service Two',   text: 'First benefit or feature\nSecond benefit or feature\nThird benefit or feature\nFourth benefit' },
    { label: 'Service Three', text: 'First benefit or feature\nSecond benefit or feature\nThird benefit or feature\nFourth benefit' }
  ];
  var bodyStyle = params.bodyStyle || 'text';
  var cards = [];
  for (var i = 0; i < N; i++) {
    var src = (params.cards && params.cards[i]) ? params.cards[i] : defCards[i];
    cards.push({ label: src.label || defCards[i].label, text: src.body || src.text || defCards[i].text });
  }

  for (var i = 0; i < N; i++) {
    var cx       = leftX + i * (cardW + gap) + cardW / 2;
    var cardLeft = leftX + i * (cardW + gap);
    var card     = cards[i];
    var nSF      = sf + i * 6;

    if (params.cardBg !== false) {
      var bgLyr = comp.layers.addSolid([1, 1, 1], 'EB_TBC_Bg_' + (i+1), cardW, cardH, 1);
      bgLyr.position.setValue([cx, cardCY]);
      ebAnimateFadeUp(bgLyr, nSF, fps, 24);
      if (params.dropShadow) { ebDropShadow(bgLyr); }
    }
    if (params.cardBorder) {
      _ebCardBorderRect(comp, 'EB_TBC_Bdr_' + (i+1), cx, cardCY, cardW, cardH, nSF, fps, params.animateIn);
    }

    var barLyr = comp.layers.addSolid(cRGB, 'EB_TBC_Bar_' + (i+1), cardW, barH, 1);
    barLyr.position.setValue([cx, cardTopY + barH / 2]);
    ebAnimateFadeUp(barLyr, nSF, fps, 24);

    // Circle: barH(10) + gap(44) + radius(36) below cardTopY = 320
    var circleY = cardTopY + barH + 44 + circleD / 2;
    _ebCircleOutline(comp, 'EB_TBC_Cir_' + (i+1), cx, circleY, circleD, cArr, 2, nSF + 2, fps, params.animateIn);

    // Title/body alignment: 'left' (default), 'center', or 'right'.
    var tAlign = (params.titleAlign === 'left' || params.titleAlign === 'right') ? params.titleAlign : 'center';
    var titleX, bodyX;
    if (tAlign === 'left')       { titleX = cardLeft + 32; bodyX = cardLeft + 32; }
    else if (tAlign === 'right') { titleX = cardLeft + cardW - 32; bodyX = cardLeft + cardW - 32; }
    else                         { titleX = cx; bodyX = cx; }

    // Title baseline: circleBottom + gap(38) = 320+36+38 = 394
    var titleY  = circleY + circleD / 2 + 38;
    var tLyr    = ebText(comp, card.label || '', titleX, titleY, 24, 'bold', black, tAlign);
    tLyr.name   = 'EB_TBC_Title_' + (i+1);
    ebTextAnimatorFadeUp(tLyr, nSF + 3, fps, 16);

    var lines  = card.text ? card.text.split(/[\r\n]+/) : [];
    var bodyY  = titleY + 42;
    for (var l = 0; l < lines.length && l < 8; l++) {
      if (!lines[l].trim()) continue;
      var lineText = (bodyStyle === 'bullets') ? '\u2022  ' + lines[l] : lines[l];
      var lLyr = ebText(comp, lineText, bodyX, bodyY + l * 32, 20, 'regular', textClr, tAlign);
      lLyr.name = 'EB_TBC_L' + (i+1) + '_' + (l+1);
      ebTextAnimatorFadeUp(lLyr, nSF + 4 + l, fps, 14);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// BOTTOM-BAR CARDS  (cards-bottom-bar)
// 3 white cards with circle icon placeholder, bold title,
// left-aligned text body, accent bar at bottom.
// =============================================================
function createBottomBarCardsBlock(comp, params) {
  var fps     = comp.frameRate;
  var sf      = 1;
  var color   = ebColor(params.accentColor || '76B900');
  var cRGB    = [color[0], color[1], color[2]];
  var cArr    = [color[0], color[1], color[2], 1];
  var black   = [0, 0, 0];
  var textClr = [0.15, 0.15, 0.15];

  var N        = 3;
  var cardW    = 568;
  var cardH    = 740;
  var gap      = 28;
  var leftX    = 80;
  var cardTopY = 230;
  var cardCY   = cardTopY + cardH / 2;   // 600
  var cardBotY = cardTopY + cardH;       // 970
  var barH     = 10;
  var circleD  = 72;

  var defCards = [
    { label: 'NVIDIA Deployed',      text: 'Ready to go from Day 1\nNVIDIA Reference Architectures\nco-engineered with CSPs\nPrivate clusters, dedicated workloads' },
    { label: 'NVIDIA Optimized',     text: 'Running on the latest infrastructure\nPerformance optimized in the full stack\nBest in networking, storage and systems\nNVIDIA constant development' },
    { label: 'Support from Experts', text: 'Short term contracts\n24/7 Business Critical Enterprise Support\nAccess to dedicated AI experts\nDedicated Technical Account Manager' }
  ];
  var bodyStyle = params.bodyStyle || 'text';
  var cards = [];
  for (var i = 0; i < N; i++) {
    var src = (params.cards && params.cards[i]) ? params.cards[i] : defCards[i];
    cards.push({ label: src.label || defCards[i].label, text: src.body || src.text || defCards[i].text });
  }

  for (var i = 0; i < N; i++) {
    var cx       = leftX + i * (cardW + gap) + cardW / 2;
    var cardLeft = leftX + i * (cardW + gap);
    var card     = cards[i];
    var nSF      = sf + i * 6;

    if (params.cardBg !== false) {
      var bgLyr = comp.layers.addSolid([1, 1, 1], 'EB_BBC_Bg_' + (i+1), cardW, cardH, 1);
      bgLyr.position.setValue([cx, cardCY]);
      ebAnimateFadeUp(bgLyr, nSF, fps, 24);
      if (params.dropShadow) { ebDropShadow(bgLyr); }
    }
    if (params.cardBorder) {
      _ebCardBorderRect(comp, 'EB_BBC_Bdr_' + (i+1), cx, cardCY, cardW, cardH, nSF, fps, params.animateIn);
    }

    var barLyr = comp.layers.addSolid(cRGB, 'EB_BBC_Bar_' + (i+1), cardW, barH, 1);
    barLyr.position.setValue([cx, cardBotY - barH / 2]);
    ebAnimateFadeUp(barLyr, nSF, fps, 24);

    // Circle: gap(44) + radius(36) below cardTopY = 310
    var circleY = cardTopY + 44 + circleD / 2;
    _ebCircleOutline(comp, 'EB_BBC_Cir_' + (i+1), cx, circleY, circleD, cArr, 2, nSF + 2, fps, params.animateIn);

    // Title/body alignment: 'left' (default), 'center', or 'right'.
    var tAlign = (params.titleAlign === 'left' || params.titleAlign === 'right') ? params.titleAlign : 'center';
    var titleX, bodyX;
    if (tAlign === 'left')       { titleX = cardLeft + 32; bodyX = cardLeft + 32; }
    else if (tAlign === 'right') { titleX = cardLeft + cardW - 32; bodyX = cardLeft + cardW - 32; }
    else                         { titleX = cx; bodyX = cx; }

    // Title baseline: circleBottom + gap(38) = 310+36+38 = 384
    var titleY  = circleY + circleD / 2 + 38;
    var tLyr    = ebText(comp, card.label || '', titleX, titleY, 24, 'bold', black, tAlign);
    tLyr.name   = 'EB_BBC_Title_' + (i+1);
    ebTextAnimatorFadeUp(tLyr, nSF + 3, fps, 16);

    var lines  = card.text ? card.text.split(/[\r\n]+/) : [];
    var bodyY  = titleY + 42;
    for (var l = 0; l < lines.length && l < 8; l++) {
      if (!lines[l].trim()) continue;
      var lineText = (bodyStyle === 'bullets') ? '\u2022  ' + lines[l] : lines[l];
      var lLyr = ebText(comp, lineText, bodyX, bodyY + l * 32, 20, 'regular', textClr, tAlign);
      lLyr.name = 'EB_BBC_L' + (i+1) + '_' + (l+1);
      ebTextAnimatorFadeUp(lLyr, nSF + 4 + l, fps, 14);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// BULLET LIST BLOCK
// Full-width card with 4 cascading bullet items.
// =============================================================
function createBulletListBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var L          = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  // 1. Card background (fill suppressed when Card BG is off; border/shadow still respect their own toggles)
  var _noFill0 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_BulletsBG', null, borderClr, showShadow, _noFill0, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, startFrame + 36, fps, 40); } catch(e) {} }

  // 2. Bullets (up to 6 items, 5-frame stagger)
  var _bulletDef = [
    'First key point -- a strong, memorable statement',
    'Second point that supports the core message clearly',
    'Third bullet with specific data or evidence here',
    'Final takeaway that drives the audience to action'
  ];
  var bulletItems = (params.bullets && params.bullets.length) ? params.bullets.slice(0, 6) : _bulletDef;
  var zoneTop = card.y - card.h / 2 + 60;
  // Dynamic spacing: cap at 160, reduce for 5-6 items to fit in available zone
  var _bSpacing = bulletItems.length <= 4 ? 160 : Math.floor(610 / (bulletItems.length - 1));
  for (var i = 0; i < bulletItems.length; i++) {
    var bStart = startFrame + 36 + i * 5;
    ebCreateBullet(comp, card, bulletItems[i], color, i, zoneTop,
      params.animateIn, bStart, fps, _bSpacing);
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// DEVICE CARD
// Light-bg card(s) with accent title, rule, image placeholder,
// and bullet list. 1 or 2 cards side-by-side.
// =============================================================
function createDeviceCardBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac     = [accent[0], accent[1], accent[2]];
  var N      = params.count || 2;

  var MARGIN  = 80;
  var GAP     = 40;
  var CARD_H  = 750;
  var CARD_TOP= 230;
  var CARD_BOT= 980;
  var CARD_CY = 605;
  var PAD     = 44;
  var TOTAL_W = 1920 - 2 * MARGIN; // 1760
  var CARD_W  = (N === 1) ? 1200 : Math.floor((TOTAL_W - GAP) / 2);

  var defaultCards = [
    { label: 'XDR Fabric',  bullets: ['Model: NVIDIA Quantum-X800 (Q3400-RA)', 'Speed: 800Gb/s', 'Architecture: 4U switch, 144 ports across 72 OSFP cages'] },
    { label: 'NDR Fabric',  bullets: ['Models: MQM3400-RA, SN2201', 'Speed: 400Gb/s InfiniBand interconnect'] }
  ];

  for (var ci = 0; ci < N; ci++) {
    var cd  = (params.cards && params.cards[ci]) ? params.cards[ci] : defaultCards[ci] || defaultCards[0];
    var cFr = sf + ci * 4;

    // Card center X
    var cx = (N === 1) ? 960 : (MARGIN + ci * (CARD_W + GAP) + Math.round(CARD_W / 2));
    var cardLeft  = cx - Math.round(CARD_W / 2);
    var cardRight = cx + Math.round(CARD_W / 2);

    // Card background — light gray
    var bgL = comp.layers.addSolid([0.93, 0.93, 0.93], 'EB_DC_Bg_' + (ci + 1), CARD_W, CARD_H, 1);
    bgL.position.setValue([cx, CARD_CY]);
    if (params.animateIn) { try { ebAnimateFadeUp(bgL, cFr, fps, 12); } catch(e) {} }

    // Card border — accent stroke
    var bdrL = comp.layers.addShape(); bdrL.name = 'EB_DC_Border_' + (ci + 1);
    bdrL.position.setValue([cx, CARD_CY]);
    var bGC = bdrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var bRc = bGC.addProperty('ADBE Vector Shape - Rect');
    try { bRc.property('ADBE Vector Rect Size').setValue([CARD_W, CARD_H]); } catch(e) {}
    var bSt = bGC.addProperty('ADBE Vector Graphic - Stroke');
    try { bSt.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
    try { bSt.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(bdrL, cFr, fps, 12); } catch(e) {} }

    // Title — accent color, top-left
    var titleTxt = cd.label || ('Device ' + (ci + 1));
    var titleY   = CARD_TOP + 62;
    var titleTx  = ebText(comp, titleTxt, cardLeft + PAD, titleY, 34, 'bold', ac, 'left');
    titleTx.name = 'EB_DC_Title_' + (ci + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(titleTx, cFr + 1, fps, 8); } catch(e) {} }

    // Thin accent rule below title
    var ruleY = CARD_TOP + 86;
    var ruleL = comp.layers.addShape(); ruleL.name = 'EB_DC_Rule_' + (ci + 1);
    ruleL.position.setValue([0, 0]);
    var rGC  = ruleL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var rPth = rGC.addProperty('ADBE Vector Shape - Group');
    try { rPth.property('ADBE Vector Shape').setValue(ebOpenPath([[cardLeft + PAD, ruleY], [cardRight - PAD, ruleY]])); } catch(e) {}
    var rStr = rGC.addProperty('ADBE Vector Graphic - Stroke');
    try { rStr.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
    try { rStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(ruleL, cFr + 1, fps, 8); } catch(e) {} }

    // Image placeholder
    var imgW  = CARD_W - 2 * PAD;
    var imgH  = (N === 1) ? 430 : 340;
    var imgTop= CARD_TOP + 108;
    var imgCX = cx;
    var imgCY = imgTop + Math.round(imgH / 2);

    var imgBg = comp.layers.addSolid([0.85, 0.85, 0.85], 'EB_DC_Img_' + (ci + 1), imgW, imgH, 1);
    imgBg.position.setValue([imgCX, imgCY]);
    if (params.animateIn) { try { ebAnimateFadeUp(imgBg, cFr + 2, fps, 10); } catch(e) {} }

    var imgBdr = comp.layers.addShape(); imgBdr.name = 'EB_DC_ImgBdr_' + (ci + 1);
    imgBdr.position.setValue([imgCX, imgCY]);
    var ibGC = imgBdr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var ibRc = ibGC.addProperty('ADBE Vector Shape - Rect');
    try { ibRc.property('ADBE Vector Rect Size').setValue([imgW, imgH]); } catch(e) {}
    var ibSt = ibGC.addProperty('ADBE Vector Graphic - Stroke');
    try { ibSt.property('ADBE Vector Stroke Color').setValue([0.68, 0.68, 0.68, 1]); } catch(e) {}
    try { ibSt.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(imgBdr, cFr + 2, fps, 10); } catch(e) {} }

    // Bullet list
    var rawBullets = cd.bullets || (cd.text ? [cd.text] : []);
    if (!rawBullets.length) { rawBullets = defaultCards[ci] ? defaultCards[ci].bullets : ['Spec A', 'Spec B']; }

    var bullStartY  = imgTop + imgH + 54;
    var BULL_SPACE  = 64;
    var bullChar    = String.fromCharCode(8226);
    var BULL_X      = cardLeft + PAD;
    var TEXT_X      = cardLeft + PAD + 28;

    for (var bi = 0; bi < rawBullets.length; bi++) {
      var bY  = bullStartY + bi * BULL_SPACE;
      var bFr = cFr + 3 + bi;

      var dotTx = ebText(comp, bullChar, BULL_X, bY, 28, 'bold', ac, 'left');
      dotTx.name = 'EB_DC_Dot_' + (ci + 1) + '_' + (bi + 1);
      if (params.animateIn) { try { ebTextAnimatorFadeUp(dotTx, bFr, fps, 6); } catch(e) {} }

      var bTx = ebText(comp, rawBullets[bi], TEXT_X, bY, 28, 'regular', [0, 0, 0], 'left');
      bTx.name = 'EB_DC_Bul_' + (ci + 1) + '_' + (bi + 1);
      if (params.animateIn) { try { ebTextAnimatorFadeUp(bTx, bFr, fps, 6); } catch(e) {} }
    }
  }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// FLOW DIAGRAM BLOCK (3 horizontal nodes + connectors)
// Layer order: node bgs first (bottom), connectors last (top)
// so arrows are never hidden behind card backgrounds.
// =============================================================
function createFlowDiagramBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var colorRGB   = [color[0], color[1], color[2]];
  var colorArr   = [color[0], color[1], color[2], 1];
  var L          = EB_LAYOUT;
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;
  var N          = Math.min(Math.max(parseInt(params.cardCount) || 3, 2), 5);
  var bodyStyle  = params.bodyStyle || 'text';
  var lineCount  = Math.min(Math.max(parseInt(params.cardLineCount) || 3, 2), 5);
  var bChar      = String.fromCharCode(8226);

  // Dynamic layout
  var gap   = N <= 3 ? 80 : (N === 4 ? 44 : 30);
  var nodeW = Math.floor((1760 - (N - 1) * gap) / N);
  var nodeH = N <= 3 ? 420 : L.cardBottom - L.cardTop;
  var nodeY = N <= 3 ? 610 : L.cardTop + Math.round((L.cardBottom - L.cardTop) / 2);
  var startX = 960 - Math.round((N * nodeW + (N - 1) * gap) / 2) + Math.round(nodeW / 2);
  var nodeXs = [];
  for (var _k = 0; _k < N; _k++) nodeXs.push(startX + _k * (nodeW + gap));
  var CONN_PAD = N <= 3 ? 16 : 4;

  var defLabels = ['Input', 'Process', 'Output', 'Phase 4', 'Phase 5'];
  var defBodies = ['Description text here.', 'Details here.', 'Output here.', 'Details here.', 'Details here.'];
  var items = [];
  for (var _n = 0; _n < N; _n++) {
    var _cd = (params.cards && params.cards[_n]) ? params.cards[_n] : {};
    items.push({ label: _cd.label || defLabels[_n], body: _cd.body || _cd.text || defBodies[_n] });
  }

  var hdrFSz  = L.headerFontSize;
  var bodyFSz = L.bodyFontSize;
  var numFSz  = 32;
  var noFill  = (params.cardBg === false);

  var pcBefore;
  // ── Pass 1: Node content ────────────────────────────────────────
  for (var i = 0; i < N; i++) {
    var nodeX   = nodeXs[i];
    var nodeTop = nodeY - Math.round(nodeH / 2);
    var node    = { x: nodeX, y: nodeY, w: nodeW, h: nodeH };
    var nodeStart = startFrame + 36 + i * 8;
    pcBefore = comp.numLayers;

    var bgLayer = ebCreateCardBg(comp, node, 'EB_Node_' + (i+1), null, borderClr, showShadow, noFill, null);
    ebTextAnimatorFadeUp(bgLayer, nodeStart, fps, 40);

    // Step number
    var badgeY  = nodeTop + 68;
    var numX    = nodeX - 9;
    var numLbl  = ebText(comp, '' + (i + 1), numX, badgeY, numFSz, 'bold', colorRGB, 'left');
    numLbl.name = 'EB_StepNum_' + (i+1);
    ebTextAnimatorFadeUp(numLbl, nodeStart + 3, fps, 20);

    // Label
    var labelY    = badgeY + 18 + Math.round(hdrFSz * 0.85);
    var labelLayer = ebText(comp, items[i].label, nodeX, labelY, hdrFSz, 'semibold', colorRGB, 'center');
    labelLayer.name = 'EB_NodeLabel_' + (i+1);
    ebTextAnimatorFadeUp(labelLayer, nodeStart + 6, fps, 18);

    // Rule line
    var ruleY  = labelY + 14;
    var ruleW  = nodeW - L.cardPadX * 2;
    var ruleL  = comp.layers.addShape();
    ruleL.name = 'EB_NodeRule_' + (i+1);
    ruleL.position.setValue([nodeX, ruleY]);
    var rc  = ruleL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var rp  = rc.addProperty('ADBE Vector Shape - Group');
    try { rp.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
    var rs  = rc.addProperty('ADBE Vector Graphic - Stroke');
    try { rs.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { rs.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var rt  = rc.addProperty('ADBE Vector Filter - Trim');
    var rtE = rt.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { ruleL.inPoint = (nodeStart + 7) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(rtE, nodeStart + 7, fps); } catch(e) {}
    } else { try { rtE.setValue(100); } catch(e) {} }

    // Body
    var bodyTop = ruleY + 28;
    var _nBodyTextW = nodeW - L.cardPadX * 2 - 26; // after dot/pipe marker
    var _nFullTextW = nodeW - L.cardPadX * 2;
    var _nLineH     = bodyFSz + 14;
    var _nCplFull   = Math.max(8, Math.floor(_nFullTextW / (bodyFSz * 0.58)));
    var _nCplMark   = Math.max(6, Math.floor(_nBodyTextW / (bodyFSz * 0.58)));
    var _nBottomY   = nodeY + nodeH/2 - 24;
    var _nMaxLines  = Math.max(2, Math.floor((_nBottomY - bodyTop) / _nLineH));

    function _wrapFlowBody(body, cpl, max) {
      var raw = body.split('\r'); var out = [];
      for (var _wi2 = 0; _wi2 < raw.length && out.length < max; _wi2++) {
        var _ww = ebWordWrap(raw[_wi2].replace(/^\s+/, ''), cpl);
        for (var _wj2 = 0; _wj2 < _ww.length && out.length < max; _wj2++) { out.push(_ww[_wj2]); }
      }
      return out;
    }

    if (bodyStyle === 'pipe') {
      var pFSz    = bodyFSz;
      var pipeX   = nodeX - Math.round(nodeW / 2) + L.cardPadX;
      var ptxtX   = pipeX + 26;
      var pItems  = items[i].body.split('\r');
      var pTotal  = 0;
      for (var pi = 0; pi < pItems.length && pTotal < _nMaxLines; pi++) {
        var pW = ebWordWrap(pItems[pi].replace(/^\s+/, ''), _nCplMark);
        for (var pwi = 0; pwi < pW.length && pTotal < _nMaxLines; pwi++) {
          var pY    = bodyTop + pTotal * _nLineH + pFSz;
          if (pwi === 0) {
            var pMark = ebText(comp, '|', pipeX, pY, pFSz, 'regular', colorRGB, 'left');
            pMark.name = 'EB_Pipe_' + i + '_' + pi;
            ebTextAnimatorFadeUp(pMark, nodeStart + 10 + pTotal, fps, 14);
          }
          var pTxt  = ebText(comp, pW[pwi], ptxtX, pY, pFSz, 'regular', [0,0,0], 'left');
          pTxt.name = 'EB_PipeTxt_' + i + '_' + pi + '_' + pwi;
          ebTextAnimatorFadeUp(pTxt, nodeStart + 10 + pTotal, fps, 14);
          pTotal++;
        }
      }
    } else if (bodyStyle === 'bullets') {
      var bFSz    = bodyFSz;
      var dotX    = nodeX - Math.round(nodeW / 2) + L.cardPadX;
      var txtX    = dotX + 26;
      var bItems  = items[i].body.split('\r');
      var bTotal  = 0;
      for (var li = 0; li < bItems.length && bTotal < _nMaxLines; li++) {
        var bW = ebWordWrap(bItems[li].replace(/^\s+/, ''), _nCplMark);
        for (var bwi = 0; bwi < bW.length && bTotal < _nMaxLines; bwi++) {
          var bY  = bodyTop + bTotal * _nLineH + bFSz;
          if (bwi === 0) {
            var dot = ebText(comp, bChar, dotX, bY, bFSz, 'regular', colorRGB, 'center');
            dot.name = 'EB_NBulDot_' + i + '_' + li;
            ebTextAnimatorFadeUp(dot, nodeStart + 10 + bTotal, fps, 14);
          }
          var txt = ebText(comp, bW[bwi], txtX, bY, bFSz, 'regular', [0,0,0], 'left');
          txt.name = 'EB_NBulTxt_' + i + '_' + li + '_' + bwi;
          ebTextAnimatorFadeUp(txt, nodeStart + 10 + bTotal, fps, 14);
          bTotal++;
        }
      }
    } else {
      var txItems = items[i].body.split('\r');
      var txNodeX = nodeX - Math.round(nodeW / 2) + L.cardPadX;
      var txTotal = 0;
      for (var tii = 0; tii < txItems.length && txTotal < _nMaxLines; tii++) {
        var txW = ebWordWrap(txItems[tii].replace(/^\s+/, ''), _nCplFull);
        for (var twi = 0; twi < txW.length && txTotal < _nMaxLines; twi++) {
          var tY2      = bodyTop + txTotal * _nLineH + bodyFSz;
          var bodyLayer = ebText(comp, txW[twi], txNodeX, tY2, bodyFSz, 'regular', [0,0,0], 'left');
          bodyLayer.name = 'EB_NodeBody_' + (i+1) + '_' + txTotal;
          ebTextAnimatorFadeUp(bodyLayer, nodeStart + 10 + txTotal, fps, 18);
          txTotal++;
        }
      }
    }

    if (params.precomp) {
      _ebPrecompCard(comp, pcBefore, 'EB_FlowStep_' + (i+1), nodeStart - startFrame, fps, nodeX, nodeY);
    }
  }

  // ── Pass 2: Connectors (drawn last → on top) ────────────────────
  for (var j = 0; j < N - 1; j++) {
    var srcX      = nodeXs[j];
    var dstX      = nodeXs[j + 1];
    var connStart = startFrame + 36 + j * 8 + 5;
    var halfW     = Math.round(nodeW / 2);
    var aX        = dstX - halfW - CONN_PAD;

    var cL = comp.layers.addShape();
    cL.name = 'EB_Connector_' + (j+1);
    cL.position.setValue([0, 0]);
    var cc = cL.property('Contents');

    var lineGrp = cc.addProperty('ADBE Vector Group'); lineGrp.name = 'Line';
    var lGC = lineGrp.property('Contents');
    var lPth = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[srcX+halfW+CONN_PAD, nodeY],[aX-9, nodeY]])); } catch(e) {}
    var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lStr.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}

    var aGrp = cc.addProperty('ADBE Vector Group'); aGrp.name = 'Arrow';
    var aGC  = aGrp.property('Contents');
    var aPth = aGC.addProperty('ADBE Vector Shape - Group');
    try { aPth.property('ADBE Vector Shape').setValue(ebOpenPath([[aX-11, nodeY-8],[aX, nodeY],[aX-11, nodeY+8]])); } catch(e) {}
    var aStr = aGC.addProperty('ADBE Vector Graphic - Stroke');
    try { aStr.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}

    ebFadeOnly(cL, connStart, fps);
  }

  ebCreateHeader(comp, params, startFrame);
}


// =============================================================
// TEXT-ONLY BLOCK HELPERS
// Place content directly on the slide -- no card background.
// =============================================================

// Small filled circle bullet marker (shape layer).
function ebDot(comp, x, y, radius, colorArr, name) {
  var layer = comp.layers.addShape();
  layer.name = name || 'EB_Dot';
  layer.position.setValue([x, y]);
  var gc = layer.property('Contents')
               .addProperty('ADBE Vector Group')
               .property('Contents');
  var ell = gc.addProperty('ADBE Vector Shape - Ellipse');
  try { ell.property('ADBE Vector Ellipse Size').setValue([radius*2, radius*2]); } catch(e) {}
  var fill = gc.addProperty('ADBE Vector Graphic - Fill');
  try { fill.property('ADBE Vector Fill Color').setValue(colorArr); } catch(e) {}
  return layer;
}

// One bullet row: dot + body text. Returns {dot, text}.
// dotX/dotY is the center of the circle in comp space.
function ebBulletRow(comp, dotX, dotY, text, fontSize, dotRadius, dotColor, bodyColor, fontKey, baseName) {
  var dot   = ebDot(comp, dotX, dotY, dotRadius, dotColor, baseName ? baseName + '_Dot' : 'EB_Dot');
  var textX = dotX + dotRadius + 22;
  var textY = dotY + Math.round(fontSize * 0.35); // baseline: dot at cap-height centre (matches DALIGN)
  var layer = ebText(comp, text, textX, textY, fontSize, fontKey || 'regular', bodyColor || [0,0,0], 'left');
  if (baseName) layer.name = baseName + '_Text';
  return { dot: dot, text: layer };
}

// Animate one bullet row: dot fades+slides up, text uses Text Animator.
function ebAnimateBulletRow(row, startFrame, fps, slideY) {
  slideY = slideY || 15;
  try { ebAnimateFadeUp(row.dot, startFrame, fps, slideY); } catch(e) {}
  ebTextAnimatorFadeUp(row.text, startFrame + 2, fps, 18);
}

// =============================================================
// TEXT BLOCK -- 4 BULLETS
// Title + subtitle + 4 bullet points. Fixed STEP spacing so
// the layout is stable at frame 0 (no sourceRectAtTime chaining).
// =============================================================
function createTextBulletsBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var L          = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill1 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_BullBG', null, borderClr, showShadow, _noFill1, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, startFrame + 36, fps, 40); } catch(e) {} }

  var items = (params.bullets && params.bullets.length) ? params.bullets.slice(0, 6) : [
    'Bullet text -- primary point or key statement here',
    'Secondary bullet with supporting information or data',
    'Use NVIDIA Sans font for consistent brand presentation',
    'Final point that reinforces the main takeaway clearly'
  ];

  // Same layout as Pipe List — replace bar with dot
  var left    = card.x - card.w / 2;
  var dotR    = 10;
  var dotX    = left + L.cardPadX + dotR;
  var txtX    = dotX + dotR + 16;
  var zoneTop = card.y - card.h / 2 + 60;
  var spacing = items.length <= 4 ? 160 : Math.floor(610 / (items.length - 1));
  var bFSz    = 35;

  var dotSz = dotR * 2;
  for (var i = 0; i < items.length; i++) {
    var bStart  = startFrame + 36 + i * 5;
    var bulletY = zoneTop + i * spacing + 40;
    var bn      = 'EB_BullB' + i;

    var dotL = comp.layers.addSolid([color[0],color[1],color[2]], bn+'_Dot', dotSz, dotSz, 1);
    dotL.label = 9;
    try { dotL.anchorPoint.setValue([dotR, dotR]); } catch(e) {}
    dotL.position.setValue([dotX, bulletY]);
    ebTextAnimatorFadeUp(dotL, bStart, fps, 20);

    var tl = ebText(comp, items[i], txtX, bulletY + Math.round(bFSz * 0.38),
      bFSz, 'regular', [0,0,0], 'left');
    tl.name = bn + '_Text';
    ebTextAnimatorFadeUp(tl, bStart + 3, fps, 18);
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// BULLET LIST BLOCK (filled circles + text, same layout as Squares List)
// =============================================================
function createBulletDotListBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var L          = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill2 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_BDotBG', null, borderClr, showShadow, _noFill2, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, startFrame + 36, fps, 40); } catch(e) {} }

  var items = (params.bullets && params.bullets.length) ? params.bullets.slice(0, 6) : [
    'Bullet text -- primary point or key statement here',
    'Secondary bullet with supporting information or data',
    'Use NVIDIA Sans font for consistent brand presentation',
    'Final point that reinforces the main takeaway clearly'
  ];

  var left    = card.x - card.w / 2;
  var dotR    = 10;
  var dotX    = left + L.cardPadX + dotR;
  var txtX    = dotX + dotR + 16;
  var zoneTop = card.y - card.h / 2 + 60;
  var spacing = items.length <= 4 ? 160 : Math.floor(610 / (items.length - 1));
  var bdFSz   = 35;

  var bChar   = String.fromCharCode(8226); // bullet character •
  var dotFSz  = 42;
  var cRGB    = [color[0], color[1], color[2]];

  for (var i = 0; i < items.length; i++) {
    var bStart  = startFrame + 36 + i * 5;
    var bulletY = zoneTop + i * spacing + 40;
    var bn      = 'EB_BDot' + i;

    // Bullet dot: text layer with • character in accent color — always renders
    var dotL = ebText(comp, bChar, dotX, bulletY + Math.round(bdFSz * 0.38), dotFSz, 'regular', cRGB, 'center');
    dotL.name = bn + '_Dot';
    dotL.label = 9;
    ebTextAnimatorFadeUp(dotL, bStart, fps, 20);

    var tl = ebText(comp, items[i], txtX, bulletY + Math.round(bdFSz * 0.38),
      bdFSz, 'regular', [0,0,0], 'left');
    tl.name = bn + '_Text';
    ebTextAnimatorFadeUp(tl, bStart + 3, fps, 18);
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// CHECKMARKS LIST BLOCK (shape-layer checkmark + text)
// Draws ✓ as a 3-point open stroke path — same proven technique
// as the pipe/rule lines. No Unicode glyph dependency.
// =============================================================
function createCheckmarksListBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var colorArr   = [color[0], color[1], color[2], 1];
  var L          = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill3 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_ChkBG', null, borderClr, showShadow, _noFill3, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, startFrame + 36, fps, 40); } catch(e) {} }

  var items = (params.bullets && params.bullets.length) ? params.bullets.slice(0, 6) : [
    'First key point or achievement highlighted here',
    'Secondary benefit or feature with supporting context',
    'Third item demonstrating value or capability clearly',
    'Final takeaway that reinforces the main message'
  ];

  var left    = card.x - card.w / 2;
  var chkCx   = left + L.cardPadX + 14; // horizontal centre of checkmark
  var txtX    = chkCx + 32;             // text left edge
  var zoneTop = card.y - card.h / 2 + 60;
  var spacing = items.length <= 4 ? 160 : Math.floor(610 / (items.length - 1));
  var chkFSz  = 35;

  for (var i = 0; i < items.length; i++) {
    var bStart  = startFrame + 36 + i * 5;
    var bulletY = zoneTop + i * spacing + 40;
    var bn      = 'EB_Chk' + i;

    // Checkmark shape: 3-point open path, scaled for 35px text
    var chkLayer = comp.layers.addShape();
    chkLayer.name = bn + '_Chk';
    chkLayer.label = 9;
    chkLayer.position.setValue([chkCx, bulletY]);

    var contents = chkLayer.property('Contents');
    var grp      = contents.addProperty('ADBE Vector Group');
    var gc       = grp.property('Contents');

    var pathGrp = gc.addProperty('ADBE Vector Shape - Group');
    try {
      pathGrp.property('ADBE Vector Shape').setValue(
        ebOpenPath([[-12, 0], [-2, 11], [14, -11]])
      );
    } catch(e) {}

    var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
    try { stroke.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { stroke.property('ADBE Vector Stroke Width').setValue(4); } catch(e) {}
    try { stroke.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}   // round cap
    try { stroke.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}  // round join

    ebTextAnimatorFadeUp(chkLayer, bStart, fps, 20);

    var tl = ebText(comp, items[i], txtX, bulletY + Math.round(chkFSz * 0.38),
      chkFSz, 'regular', [0,0,0], 'left');
    tl.name = bn + '_Text';
    ebTextAnimatorFadeUp(tl, bStart + 3, fps, 18);
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// TEXT BLOCK -- NESTED BULLETS
// 3 main circle bullets, each with 2 smaller indented sub-bullets.
// Uses same proven approach as Bullet List (• text char, ebText).
// =============================================================
function createTextNestedBlock(comp, params) {
  var fps        = comp.frameRate;
  var sf         = 1;
  var color      = ebColor(params.accentColor);
  var cRGB       = [color[0], color[1], color[2]];
  var L          = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill4 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_NestBG', null, borderClr, showShadow, _noFill4, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, sf + 36, fps, 40); } catch(e) {} }

  var bChar  = String.fromCharCode(8226);
  var left   = card.x - card.w / 2;

  // Main bullet sizing & position
  var mFSz   = 35;                         // main text size
  var mDotX  = left + L.cardPadX;          // dot left edge
  var mTxtX  = mDotX + 34;                // text left edge (gap for larger dot)

  // Sub-bullet sizing & position (smaller, indented)
  var sFSz   = 30;                         // sub text size
  var sDotX  = mDotX + 64;                // indented
  var sTxtX  = sDotX + 26;               // sub text left edge

  // Vertical rhythm
  var zoneTop    = card.y - card.h / 2 + 60; // 290
  var startY     = zoneTop + 40;              // 330 — first main Y
  var mainToSub  = 52;   // main baseline → first sub baseline
  var subToSub   = 44;   // sub baseline → next sub baseline
  var groupGap   = 68;   // last sub of group → next main

  var defaults = [
    { main: 'First primary point with key message here',
      subs: ['Supporting detail that expands on the main point', 'Additional context or evidence to reinforce it'] },
    { main: 'Second main point carries equal visual weight',
      subs: ['Sub-bullet with specific data or example here', 'Further clarification to help the audience'] },
    { main: 'Third key point that drives the message home',
      subs: ['Supporting sub-bullet with actionable insight', 'Final detail that closes the argument clearly'] }
  ];

  // Build items from params.bullets (array of {main,subs[]}) or fall back to defaults
  var rawItems = (params.bullets && params.bullets.length) ? params.bullets.slice(0, 3) : defaults;
  var nestedItems = [];
  for (var ni = 0; ni < rawItems.length; ni++) {
    var ri = rawItems[ni];
    var def = defaults[ni % defaults.length];
    if (typeof ri === 'string') {
      nestedItems.push({ main: ri, subs: def.subs });
    } else {
      nestedItems.push({
        main: ri.main || def.main,
        subs: (ri.subs && ri.subs.length) ? ri.subs : def.subs
      });
    }
  }

  // Determine actual sub count from first item (consistent across all items)
  var nSubs = nestedItems.length ? nestedItems[0].subs.length : 2;
  if (nSubs < 1) nSubs = 1;
  if (nSubs > 3) nSubs = 3;

  // Scale spacing to fit in available zone (startY=330, bottom ~940, available=610)
  // Total height = nMain * (mainToSub + nSubs*subToSub) + (nMain-1)*groupGap
  var nMain = nestedItems.length;
  var rawTotalH = nMain * (mainToSub + nSubs * subToSub) + Math.max(0, nMain - 1) * groupGap;
  var availH    = 610;
  var scale = rawTotalH > availH ? availH / rawTotalH : 1;
  var adjMainToSub = Math.round(mainToSub * scale);
  var adjSubToSub  = Math.round(subToSub  * scale);
  var adjGroupGap  = Math.round(groupGap  * scale);

  var curY = startY;
  var layersBefore;
  for (var gi = 0; gi < nestedItems.length; gi++) {
    layersBefore = comp.numLayers;
    var d   = nestedItems[gi];
    var mFr = sf + 36 + gi * 10;
    var bn  = 'EB_N' + gi;

    // Main dot + text
    var mDot = ebText(comp, bChar, mDotX, curY + Math.round(mFSz * 0.38), mFSz, 'regular', cRGB, 'left');
    mDot.name = bn + '_MDot';
    mDot.label = 9;
    ebTextAnimatorFadeUp(mDot, mFr, fps, 18);

    var mTxt = ebText(comp, d.main, mTxtX, curY + Math.round(mFSz * 0.38), mFSz, 'regular', [0,0,0], 'left');
    mTxt.name = bn + '_MTxt';
    ebTextAnimatorFadeUp(mTxt, mFr + 2, fps, 18);

    // Sub-bullets (variable count)
    var itemSubs = d.subs.slice(0, nSubs);
    for (var j = 0; j < itemSubs.length; j++) {
      var sY  = curY + adjMainToSub + j * adjSubToSub;
      var sFr = mFr + 5 + j * 3;
      var sn  = bn + '_S' + j;

      var sDot = ebText(comp, bChar, sDotX, sY + Math.round(sFSz * 0.38), sFSz, 'regular', cRGB, 'left');
      sDot.name = sn + '_Dot';
      sDot.label = 9;
      ebTextAnimatorFadeUp(sDot, sFr, fps, 14);

      var sTxt = ebText(comp, itemSubs[j] || d.subs[0], sTxtX, sY + Math.round(sFSz * 0.38), sFSz, 'regular', [0,0,0], 'left');
      sTxt.name = sn + '_Txt';
      ebTextAnimatorFadeUp(sTxt, sFr + 2, fps, 14);
    }

    var groupH = adjMainToSub + nSubs * adjSubToSub;
    curY += groupH + adjGroupGap;

    if (params.precomp) {
      var _gCX = Math.round(card.x);
      var _gCY = Math.round(curY - adjGroupGap - groupH / 2);
      _ebPrecompCard(comp, layersBefore, 'EB_Nest_' + gi, sf + 36 + gi * 8, fps, _gCX, _gCY);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// TEXT BLOCK -- 2-COLUMN BULLETS
// Title + subtitle + 3 bullets left, 3 bullets right.
// Each column chains independently so long text in one column
// pushes its own items down without affecting the other column.
// =============================================================
function createText2ColBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var cRGB     = [color[0], color[1], color[2]];
  var colorArr = [color[0], color[1], color[2], 1];
  var L        = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill5 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_2ColBG', null, borderClr, showShadow, _noFill5, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, sf + 36, fps, 40); } catch(e) {} }

  // Vertical divider at x=960
  var divL = comp.layers.addShape();
  divL.name = 'EB_ColDivider';
  divL.position.setValue([0, 0]);
  var dvGC  = divL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var dvPth = dvGC.addProperty('ADBE Vector Shape - Group');
  try { dvPth.property('ADBE Vector Shape').setValue(ebOpenPath([[960, L.cardTop + 40],[960, L.cardBottom - 40]])); } catch(e) {}
  var dvStr = dvGC.addProperty('ADBE Vector Graphic - Stroke');
  try { dvStr.property('ADBE Vector Stroke Color').setValue([0.25, 0.25, 0.25, 1]); } catch(e) {}
  try { dvStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) {
    var dvTrim    = dvGC.addProperty('ADBE Vector Filter - Trim');
    var dvTrimEnd = dvTrim.property('ADBE Vector Trim End');
    try { divL.inPoint = (sf + 30) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(dvTrimEnd, sf + 30, fps); } catch(e) {}
  }

  // Layout constants
  var cardLeft = card.x - card.w / 2;  // 80
  var lDotX    = cardLeft + L.cardPadX; // 112 — left column dot
  var lTxtX    = lDotX + 20;            // 132 — left column text
  var rDotX    = 960 + L.cardPadX;      // 992 — right column dot
  var rTxtX    = rDotX + 20;            // 1012 — right column text
  var zoneTop  = card.y - card.h / 2 + 60;  // 290
  var bFSz     = L.bodyFontSize;        // 30
  var bChar    = String.fromCharCode(8226);

  var leftDefs  = [
    'Left column first bullet point',
    'Left column second bullet point',
    'Left column third bullet point',
    'Left column fourth bullet point',
    'Left column fifth bullet point'
  ];
  var rightDefs = [
    'Right column first bullet point',
    'Right column second bullet point',
    'Right column third bullet point',
    'Right column fourth bullet point',
    'Right column fifth bullet point'
  ];
  var nRows   = Math.min(Math.max(parseInt(params.colCount) || 3, 2), 5);
  var spacing = Math.round(610 / nRows);
  var leftItems = [], rightItems = [];
  for (var pi = 0; pi < nRows; pi++) {
    var lc = (params.cards && params.cards[pi])         ? params.cards[pi]         : {};
    var rc = (params.cards && params.cards[pi + nRows]) ? params.cards[pi + nRows] : {};
    leftItems.push(lc.label || lc.text || leftDefs[pi]);
    rightItems.push(rc.label || rc.text || rightDefs[pi]);
  }

  for (var i = 0; i < nRows; i++) {
    var lf      = sf + 36 + i * 6;
    var rf      = lf + 3;
    var bulletY = zoneTop + i * spacing + 40;
    var textY   = bulletY + Math.round(bFSz * 0.38);

    // Left column: dot + text
    var lDot = ebText(comp, bChar, lDotX, textY, bFSz, 'regular', cRGB, 'center');
    lDot.name = 'EB_L' + i + '_Dot';
    ebTextAnimatorFadeUp(lDot, lf, fps, 20);
    var lTxt = ebText(comp, leftItems[i], lTxtX, textY, bFSz, 'regular', [0,0,0], 'left');
    lTxt.name = 'EB_L' + i + '_Text';
    ebTextAnimatorFadeUp(lTxt, lf + 3, fps, 18);

    // Right column: dot + text
    var rDot = ebText(comp, bChar, rDotX, textY, bFSz, 'regular', cRGB, 'center');
    rDot.name = 'EB_R' + i + '_Dot';
    ebTextAnimatorFadeUp(rDot, rf, fps, 20);
    var rTxt = ebText(comp, rightItems[i], rTxtX, textY, bFSz, 'regular', [0,0,0], 'left');
    rTxt.name = 'EB_R' + i + '_Text';
    ebTextAnimatorFadeUp(rTxt, rf + 3, fps, 18);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// TEXT BLOCK -- NUMBERED LIST
// Title + subtitle + 4 items, bold accent numbers (01, 02...).
// Body uses paragraph text; number label Y follows the body box.
// =============================================================
function createTextNumberedBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var cRGB     = [color[0], color[1], color[2]];
  var L        = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill6 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_NumBG', null, borderClr, showShadow, _noFill6, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, sf + 36, fps, 40); } catch(e) {} }

  var itemDefs = [
    'First numbered point or primary key statement here',
    'Second item that follows the first point logically',
    'Third point supported with specific data or evidence',
    'Fourth and final point that drives action or conclusion'
  ];
  var items = [];
  for (var pi = 0; pi < 4; pi++) {
    var ic = (params.bullets && params.bullets[pi]) ? params.bullets[pi] :
             (params.cards  && params.cards[pi])   ? (params.cards[pi].label || params.cards[pi].text) : null;
    items.push(ic || itemDefs[pi]);
  }

  // Layout: number on left, body text to the right
  var cardLeft = card.x - card.w / 2;  // 80
  var numX     = cardLeft + L.cardPadX + 20; // 132 — number centre
  var txtX     = numX + 70;                  // 202 — body text left edge
  var zoneTop  = card.y - card.h / 2 + 60;  // 290
  var spacing  = 160;
  var numFSz   = 38;
  var bodyFSz  = 35;

  for (var i = 0; i < items.length; i++) {
    var fr      = sf + 36 + i * 5;
    var bulletY = zoneTop + i * spacing + 40;
    var textY   = bulletY + Math.round(bodyFSz * 0.38);
    var numY    = bulletY + Math.round(numFSz * 0.38);
    var numStr  = (i + 1 < 10) ? '0' + (i + 1) : '' + (i + 1);

    // Number: bold, accent color
    var numLbl = ebText(comp, numStr, numX, numY, numFSz, 'bold', cRGB, 'center');
    numLbl.name = 'EB_Num_' + i;
    numLbl.label = 9;
    ebTextAnimatorFadeUp(numLbl, fr, fps, 18);

    // Body text: regular, black
    var bodyTxt = ebText(comp, items[i], txtX, textY, bodyFSz, 'regular', [0,0,0], 'left');
    bodyTxt.name = 'EB_NumBody_' + i;
    ebTextAnimatorFadeUp(bodyTxt, fr + 3, fps, 18);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// FLOW DIAGRAM -- 4-STEP (4 narrower nodes in a row)
// =============================================================
function createFlowDiagram4StepBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var colorRGB   = [color[0], color[1], color[2]];
  var L          = EB_LAYOUT;
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var colorArr = [color[0], color[1], color[2], 1];
  var nodeW   = 350;
  var nodeH   = L.cardBottom - L.cardTop;
  var nodeGap = 44;
  var nodeY   = L.cardTop + nodeH / 2;
  var totalW  = 4 * nodeW + 3 * nodeGap;
  var startX  = 960 - totalW / 2 + nodeW / 2;
  var defLabels4 = ['Phase 1', 'Phase 2', 'Phase 3', 'Phase 4'];
  var defBodies4 = ['Step details here', 'Step details here', 'Step details here', 'Step details here'];
  var nodeXs  = [];
  for (var n = 0; n < 4; n++) nodeXs.push(startX + n*(nodeW+nodeGap));

  // Pass 1: node content
  for (var i = 0; i < 4; i++) {
    var nodeX     = nodeXs[i];
    var node      = { x: nodeX, y: nodeY, w: nodeW, h: nodeH };
    var nodeStart = startFrame + 36 + i * 7;
    var _cd4      = (params.cards && params.cards[i]) ? params.cards[i] : {};
    var nodeLabel = _cd4.label || defLabels4[i];
    var nodeBody  = _cd4.body  || _cd4.text || defBodies4[i];

    var _4sNoFill = (params.cardBg === false);
    var _4sFill   = (params.shapeFill === false) ? null : color;
    var bgLayer = ebCreateCardBg(comp, node, 'EB_Node_' + (i+1), null, borderClr, showShadow, _4sNoFill, _4sFill);
    ebTextAnimatorFadeUp(bgLayer, nodeStart, fps, 40);

    var labelY = nodeY - nodeH/2 + L.cardPadTop + L.headerFontSize;
    var lbl    = ebText(comp, nodeLabel, nodeX, labelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    lbl.name   = 'EB_NodeLabel_' + (i+1);
    ebTextAnimatorFadeUp(lbl, nodeStart + 7, fps, 18);

    var ruleLayer  = comp.layers.addShape();
    ruleLayer.name = 'EB_NodeRule_' + (i+1);
    var ruleY      = labelY + 14;
    ruleLayer.position.setValue([nodeX, ruleY]);
    var ruleW      = nodeW - L.cardPadX * 2;
    var rc  = ruleLayer.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var rp  = rc.addProperty('ADBE Vector Shape - Group');
    try { rp.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
    var rs  = rc.addProperty('ADBE Vector Graphic - Stroke');
    try { rs.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { rs.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var rt  = rc.addProperty('ADBE Vector Filter - Trim');
    var rtE = rt.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { ruleLayer.inPoint = (nodeStart + 8) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(rtE, nodeStart + 8, fps); } catch(e) {}
    } else {
      try { rtE.setValue(100); } catch(e) {}
    }

    // Body: split on \r, render each line, left-aligned from card left edge
    var bodyLines = nodeBody.split('\r');
    var bFSz4 = L.bodyFontSize - 2;
    var bLineH4 = bFSz4 + 12;
    var bX4 = nodeX - nodeW / 2 + L.cardPadX;
    var bStartY = ruleY + 30;
    for (var bi = 0; bi < Math.min(bodyLines.length, 4); bi++) {
      var bln4 = bodyLines[bi].replace(/^\s+/, '');
      var bY4  = bStartY + bi * bLineH4 + bFSz4;
      var bLyr = ebText(comp, bln4, bX4, bY4, bFSz4, 'regular', [0,0,0], 'left');
      bLyr.name = 'EB_NodeBody_' + (i+1) + '_' + bi;
      ebTextAnimatorFadeUp(bLyr, nodeStart + 11 + bi, fps, 18);
    }
  }

  // Pass 2: connectors last (top of stack)
  // nodeGap=44px so CONN_PAD must be small (4px) to leave room for a visible shaft.
  var halfW    = nodeW / 2;
  var CONN_PAD = 4;
  for (var j = 0; j < 3; j++) {
    var cL = comp.layers.addShape();
    cL.name = 'EB_Connector_' + (j+1);
    cL.position.setValue([0, 0]);
    var cc = cL.property('Contents');

    // Compute arrowhead tip first so shaft endpoint aligns with arrowhead base.
    var aX4 = nodeXs[j+1] - halfW - CONN_PAD;

    var lineGrp = cc.addProperty('ADBE Vector Group');
    lineGrp.name = 'Line';
    var lGC = lineGrp.property('Contents');
    var lPth = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[nodeXs[j]+halfW+CONN_PAD, nodeY],[aX4-9, nodeY]])); } catch(e) {}
    var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lStr.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}

    var aGrp = cc.addProperty('ADBE Vector Group');
    aGrp.name = 'Arrow';
    var aGC  = aGrp.property('Contents');
    var aPth = aGC.addProperty('ADBE Vector Shape - Group');
    try { aPth.property('ADBE Vector Shape').setValue(ebOpenPath([[aX4-11, nodeY-8], [aX4, nodeY], [aX4-11, nodeY+8]])); } catch(e) {}
    var aStr = aGC.addProperty('ADBE Vector Graphic - Stroke');
    try { aStr.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}

    ebFadeOnly(cL, startFrame + 36 + j*7 + 5, fps);
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// FLOW DIAGRAM -- CYCLE (4 nodes in 2x2 grid, circular arrows)
// Arrows: TL→TR, TR→BR, BR→BL, BL→TL
// =============================================================
function createFlowCycleBlock(comp, params) {
  var fps        = comp.frameRate;
  var startFrame = 1;
  var color      = ebColor(params.accentColor);
  var colorRGB   = [color[0], color[1], color[2]];
  var L          = EB_LAYOUT;
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var NW = 340;  // node width
  var NH = 270;  // node height
  // Node center positions (2x2 grid)
  var positions = [
    { x: 460,  y: 348,  label: 'Plan'   },   // TL
    { x: 1460, y: 348,  label: 'Build'  },   // TR
    { x: 1460, y: 768,  label: 'Deploy' },   // BR
    { x: 460,  y: 768,  label: 'Monitor'}    // BL
  ];

  // Pass 1: all node content
  for (var i = 0; i < 4; i++) {
    var p         = positions[i];
    var node      = { x: p.x, y: p.y, w: NW, h: NH };
    var nodeStart = startFrame + 36 + i * 6;

    var _cyNoFill = (params.cardBg === false);
    var _cyFill   = (params.shapeFill === false) ? null : color;
    var bgLayer = ebCreateCardBg(comp, node, 'EB_CyNode_' + (i+1), null, borderClr, showShadow, _cyNoFill, _cyFill);
    ebTextAnimatorFadeUp(bgLayer, nodeStart, fps, 35);

    var labelY = p.y - NH/2 + L.cardPadTop + L.headerFontSize;
    var lbl    = ebText(comp, p.label, p.x, labelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    lbl.name   = 'EB_CyLabel_' + (i+1);
    ebTextAnimatorFadeUp(lbl, nodeStart + 6, fps, 16);

    var ruleLayer = comp.layers.addShape();
    ruleLayer.name = 'EB_CyRule_' + (i+1);
    var ruleY = labelY + 14;
    ruleLayer.position.setValue([p.x, ruleY]);
    var ruleW = NW - L.cardPadX * 2;
    var rc  = ruleLayer.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var rp  = rc.addProperty('ADBE Vector Shape - Group');
    try { rp.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
    var rs  = rc.addProperty('ADBE Vector Graphic - Stroke');
    try { rs.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { rs.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var rt  = rc.addProperty('ADBE Vector Filter - Trim');
    var rtE = rt.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { ruleLayer.inPoint = (nodeStart + 7) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(rtE, nodeStart + 7, fps); } catch(e) {}
    } else {
      try { rtE.setValue(100); } catch(e) {}
    }

    var body = ebText(comp, 'Description here.', p.x, p.y, L.bodyFontSize, 'regular', [0,0,0], 'center');
    body.name = 'EB_CyBody_' + (i+1);
    ebTextAnimatorFadeUp(body, nodeStart + 10, fps, 16);
  }

  // Pass 2: arrows last (top of stack, visible over all bgs)
  // Each arrow: [x0, y0, x1, y1, direction('right'|'down'|'left'|'up'), animFrame]
  var halfW    = NW / 2;
  var halfH    = NH / 2;
  var CONN_PAD = 18;  // px gap between arrow and card edge
  var arrows = [
    // TL→TR (right): from TL right edge + pad to TR left edge - pad, same Y
    { x0: positions[0].x+halfW+CONN_PAD, y0: positions[0].y, x1: positions[1].x-halfW-CONN_PAD, y1: positions[1].y, dir:'right', fr: startFrame+36+3 },
    // TR→BR (down): from TR bottom + pad to BR top - pad, same X
    { x0: positions[1].x, y0: positions[1].y+halfH+CONN_PAD, x1: positions[2].x, y1: positions[2].y-halfH-CONN_PAD, dir:'down', fr: startFrame+36+9 },
    // BR→BL (left): from BR left edge - pad to BL right edge + pad, same Y
    { x0: positions[2].x-halfW-CONN_PAD, y0: positions[2].y, x1: positions[3].x+halfW+CONN_PAD, y1: positions[3].y, dir:'left', fr: startFrame+36+15 },
    // BL→TL (up): from BL top - pad to TL bottom + pad, same X
    { x0: positions[3].x, y0: positions[3].y-halfH-CONN_PAD, x1: positions[0].x, y1: positions[0].y+halfH+CONN_PAD, dir:'up', fr: startFrame+36+21 }
  ];

  for (var a = 0; a < arrows.length; a++) {
    var ar = arrows[a];

    // Line layer — TrimDraw animates the line; no opacity animation on this layer.
    var lineL = comp.layers.addShape();
    lineL.name = 'EB_CyLine_' + (a+1);
    lineL.position.setValue([0, 0]);
    var lc  = lineL.property('Contents');
    var lGrp = lc.addProperty('ADBE Vector Group');
    lGrp.name = 'Line';
    var lGC = lGrp.property('Contents');
    var lPth = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[ar.x0,ar.y0],[ar.x1,ar.y1]])); } catch(e) {}
    var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    var lTr = lGC.addProperty('ADBE Vector Filter - Trim');
    var lTrE = lTr.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { lineL.inPoint = ar.fr / fps; } catch(e) {}
      try { ebAnimateTrimDraw(lTrE, ar.fr, fps); } catch(e) {}
    } else {
      try { lTrE.setValue(100); } catch(e) {}
    }

    // Arrowhead layer — separate, fades in after line is nearly finished drawing.
    // TrimDraw takes 18 frames; arrowhead starts at ar.fr+15 so it appears at the end.
    var arrL = comp.layers.addShape();
    arrL.name = 'EB_CyHead_' + (a+1);
    arrL.position.setValue([0, 0]);
    var ac  = arrL.property('Contents');
    var aGrp = ac.addProperty('ADBE Vector Group');
    aGrp.name = 'Arrow';
    var aGC  = aGrp.property('Contents');
    var aPth = aGC.addProperty('ADBE Vector Shape - Group');
    var v;
    if (ar.dir === 'right') {
      v = [[ar.x1-11,ar.y1-8],[ar.x1,ar.y1],[ar.x1-11,ar.y1+8]];
    } else if (ar.dir === 'down') {
      v = [[ar.x1-8,ar.y1-11],[ar.x1,ar.y1],[ar.x1+8,ar.y1-11]];
    } else if (ar.dir === 'left') {
      v = [[ar.x1+11,ar.y1-8],[ar.x1,ar.y1],[ar.x1+11,ar.y1+8]];
    } else { // up
      v = [[ar.x1-8,ar.y1+11],[ar.x1,ar.y1],[ar.x1+8,ar.y1+11]];
    }
    try { aPth.property('ADBE Vector Shape').setValue(ebOpenPath(v)); } catch(e) {}
    var aStr = aGC.addProperty('ADBE Vector Graphic - Stroke');
    try { aStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
    ebFadeOnly(arrL, ar.fr + 15, fps);
  }

  ebCreateHeader(comp, params, startFrame);
}

// =============================================================
// TABLE BLOCK (1-4 columns, header row + 3 data rows)
// All fills use addSolid — shape layer fills silently fail in AE 2024+.
// =============================================================
function createTableBlock(comp, params, legacyNumCols) {
  var fps = comp.frameRate;
  var sf  = 1;
  var acc = ebColor(params.accentColor);

  // Dimensions: numCols (1-8), numRows (2-10), tableStyle ('bar'|'minimal'|'outlined').
  // Legacy callers can still pass numCols as third arg (table-1col..4col aliases).
  var numCols = params.numCols || legacyNumCols || 3;
  numCols = Math.max(1, Math.min(8, numCols));
  var numRows = params.numRows || 3;
  numRows = Math.max(2, Math.min(10, numRows));
  var style = (params.tableStyle === 'minimal' || params.tableStyle === 'outlined') ? params.tableStyle : 'bar';

  var TX      = 80;
  var TW      = 1760;
  var TT      = 230;
  var BOTTOM  = 980;
  // Header bar height — minimal style has no fill, so make it slim; bar/outlined keep the existing 80px.
  var HDR_H   = (style === 'minimal') ? 70 : 80;
  var availH  = BOTTOM - TT - HDR_H;
  var ROW_H   = Math.round(availH / numRows);
  var tableH  = HDR_H + numRows * ROW_H;
  if (tableH % 2 !== 0) tableH++;
  var tableCY = TT + tableH / 2;
  var COL_W   = Math.round(TW / numCols);

  // Font auto-scaling so dense tables stay legible.
  // Standard: HDR 28 / CEL 26. Shrink when col-width or row-height is tight.
  var HDR_FSZ = 28;
  var CEL_FSZ = 26;
  if (COL_W < 250) { HDR_FSZ = 24; CEL_FSZ = 22; }
  if (COL_W < 180) { HDR_FSZ = 20; CEL_FSZ = 18; }
  if (ROW_H < 70)  { CEL_FSZ = Math.min(CEL_FSZ, 22); }
  if (ROW_H < 55)  { CEL_FSZ = Math.min(CEL_FSZ, 18); }

  // Default placeholder content scales to chosen dimensions.
  function _defaultColTitles(n) {
    var letters = ['A','B','C','D','E','F','G','H'];
    var out = [];
    for (var i = 0; i < n; i++) out.push('Column ' + letters[i]);
    return out;
  }
  function _defaultRow(n) {
    var out = [];
    for (var i = 0; i < n; i++) out.push('Data cell');
    return out;
  }
  var colTitles = (params.colTitles && params.colTitles.length >= numCols)
    ? params.colTitles.slice(0, numCols)
    : _defaultColTitles(numCols);
  var dataRows;
  if (params.rows && params.rows.length > 0) {
    dataRows = params.rows.slice(0, numRows);
    while (dataRows.length < numRows) dataRows.push(_defaultRow(numCols));
  } else {
    dataRows = [];
    for (var _di = 0; _di < numRows; _di++) dataRows.push(_defaultRow(numCols));
  }

  var accRGB     = [acc[0], acc[1], acc[2]];
  var accRGBA    = [acc[0], acc[1], acc[2], 1];
  var hdrTextClr = (style === 'bar') ? [1, 1, 1] : (style === 'minimal' ? accRGB : [0.15, 0.15, 0.15]);
  var cellClr    = [0.15, 0.15, 0.15];
  var hdrCY      = TT + Math.round(HDR_H / 2);

  // ── 1. Background ─────────────────────────────────────────────────
  // Minimal: no opaque table background (slide bg shows through).
  // Bar / Outlined: white card background.
  if (style !== 'minimal') {
    var tBG = comp.layers.addSolid([1, 1, 1], 'EB_TableBG', TW, tableH, 1);
    tBG.position.setValue([960, tableCY]);
    ebAnimateFadeUp(tBG, sf + 1, fps, 20);
  }

  // ── 2. Header treatment ───────────────────────────────────────────
  if (style === 'bar') {
    // Accent fill bar
    var hBG = comp.layers.addSolid(accRGB, 'EB_TableHdr', TW, HDR_H, 1);
    hBG.position.setValue([960, hdrCY]);
    ebAnimateFadeUp(hBG, sf + 1, fps, 16);
  } else if (style === 'minimal') {
    // 3px accent underline below header text
    var underH = 3;
    var underY = TT + HDR_H - underH;
    var underL = comp.layers.addSolid(accRGB, 'EB_TableHdrUnderline', TW, underH, 1);
    underL.position.setValue([960, underY + Math.round(underH / 2)]);
    ebAnimateFadeUp(underL, sf + 2, fps, 14);
  } else if (style === 'outlined') {
    // Soft accent-tinted band behind header text (15% accent)
    var hdrBand = comp.layers.addSolid([
      acc[0] * 0.15 + 0.85,
      acc[1] * 0.15 + 0.85,
      acc[2] * 0.15 + 0.85
    ], 'EB_TableHdrBand', TW, HDR_H, 1);
    hdrBand.position.setValue([960, hdrCY]);
    ebAnimateFadeUp(hdrBand, sf + 1, fps, 16);
  }

  // ── 3. Row backgrounds (bar style only — alternating stripes) ─────
  // CRITICAL: stripes are built as PER-COLUMN segments with explicit 4px gaps
  // at every column boundary so the stripe physically cannot cross a column
  // divider position. This is defensive — even if AE z-order somehow puts the
  // stripe above the divider, the gap leaves the divider visible.
  var COL_GAP = 4; // matches col divider width
  if (style === 'bar') {
    var stripeBorderInset = (params.cardBorder ? 4 : 0);
    for (var r = 0; r < numRows; r++) {
      if (r % 2 === 0) continue;
      var rowTop = TT + HDR_H + r * ROW_H;
      var isLastRow = (r === numRows - 1);
      var stripeH = ROW_H - (isLastRow ? stripeBorderInset : 0);
      var stripeCY = rowTop + Math.round(stripeH / 2);
      for (var sc = 0; sc < numCols; sc++) {
        var segL = TX + sc * COL_W;
        var segR = (sc === numCols - 1) ? (TX + TW) : (TX + (sc + 1) * COL_W);
        // Outer edge insets (for cardBorder), inner edge gaps (for col dividers)
        var insetL = (sc === 0)             ? stripeBorderInset : Math.floor(COL_GAP / 2);
        var insetR = (sc === numCols - 1)   ? stripeBorderInset : Math.ceil(COL_GAP / 2);
        var segW = segR - segL - insetL - insetR;
        if (segW <= 0) continue;
        var segCX = segL + insetL + segW / 2;
        var rSeg = comp.layers.addSolid([0.95, 0.95, 0.96], 'EB_TblRowBG_' + (r+1) + '_' + (sc+1), segW, stripeH, 1);
        rSeg.position.setValue([segCX, stripeCY]);
        ebAnimateFadeUp(rSeg, sf + 4, fps, 12);
      }
    }
  }

  // Divider colour: needs to be clearly visible on BOTH the white and the
  // light-grey stripe rows. The previous 0.82 grey blended into the stripes.
  var bodyDivClr = [0.68, 0.68, 0.68, 1];

  // Note: Column and row dividers are CREATED LAST (after cells, headers,
  // borders, shadow) — see "Final dividers" block at the end of this function.
  // This guarantees they're at the very top of the AE layer stack and can't
  // be visually swallowed by any other layer on top of them.

  // ── 5b. Outer border (bar style: opt-in via cardBorder; outlined: always) ─
  var addBorder = (style === 'outlined') || (style === 'bar' && params.cardBorder);
  if (addBorder) {
    var BSW    = (style === 'outlined') ? 2 : 4;
    var bT = comp.layers.addSolid(accRGB, 'EB_TblBT', TW, BSW, 1);
    bT.position.setValue([960, TT + Math.round(BSW / 2)]);
    ebAnimateFadeUp(bT, sf + 1, fps, 20);
    var bB = comp.layers.addSolid(accRGB, 'EB_TblBB', TW, BSW, 1);
    bB.position.setValue([960, TT + tableH - Math.round(BSW / 2)]);
    ebAnimateFadeUp(bB, sf + 1, fps, 20);
    var bL = comp.layers.addSolid(accRGB, 'EB_TblBL', BSW, tableH, 1);
    bL.position.setValue([TX + Math.round(BSW / 2), tableCY]);
    ebAnimateFadeUp(bL, sf + 1, fps, 20);
    var bR = comp.layers.addSolid(accRGB, 'EB_TblBR', BSW, tableH, 1);
    bR.position.setValue([TX + TW - Math.round(BSW / 2), tableCY]);
    ebAnimateFadeUp(bR, sf + 1, fps, 20);
  }

  // ── 6. Header text ────────────────────────────────────────────────
  var hdrTY = hdrCY + Math.round(HDR_FSZ * 0.36);
  for (var c = 0; c < numCols; c++) {
    var colCX = TX + c * COL_W + Math.round(COL_W / 2);
    var hTxt = ebText(comp, colTitles[c], colCX, hdrTY, HDR_FSZ, 'bold', hdrTextClr, 'center');
    hTxt.name = 'EB_TblHdr_' + (c + 1);
    ebTextAnimatorFadeUp(hTxt, sf + 8, fps, 12);
  }

  // ── 7. Data cell text ─────────────────────────────────────────────
  for (var row = 0; row < numRows; row++) {
    var rrCY  = TT + HDR_H + row * ROW_H + Math.round(ROW_H / 2);
    var cellTY = rrCY + Math.round(CEL_FSZ * 0.36);
    var rowData = (dataRows[row] && dataRows[row].length >= numCols)
      ? dataRows[row] : _defaultRow(numCols);
    for (var col2 = 0; col2 < numCols; col2++) {
      var cX = TX + col2 * COL_W + Math.round(COL_W / 2);
      var cTxt = ebText(comp, rowData[col2], cX, cellTY, CEL_FSZ, 'regular', cellClr, 'center');
      cTxt.name = 'EB_Cell_' + (row+1) + '_' + (col2+1);
      ebTextAnimatorFadeUp(cTxt, sf + 12 + row * 4, fps, 12);
    }
  }

  ebCreateHeader(comp, params, sf);

  // ── 8. Shadow layer (added LAST = top of stack) ───────────────────
  // BlendingMode.MULTIPLY makes white fill invisible; Shadow Only keeps only
  // the shadow.  Being at the top of the stack avoids compositing conflicts
  // with the border bars that broke Drop Shadow on tBG.
  if (params.dropShadow && style !== 'minimal') {
    var tShadow = comp.layers.addSolid([1, 1, 1], 'EB_TblShadow', TW, tableH, 1);
    tShadow.position.setValue([960, tableCY]);
    try { tShadow.blendingMode = BlendingMode.MULTIPLY; } catch(e) {}
    var tDS = tShadow.Effects.addProperty('ADBE Drop Shadow');
    try { tDS.property('Shadow Color').setValue([0, 0, 0, 1]); } catch(e) {}
    try { tDS.property('Opacity').setValue(20);                 } catch(e) {}
    try { tDS.property('Direction').setValue(135);              } catch(e) {}
    try { tDS.property('Distance').setValue(8);                 } catch(e) {}
    try { tDS.property('Softness').setValue(28);                } catch(e) {}
    try { tDS.property('Shadow Only').setValue(1);              } catch(e) {}
    ebAnimateFadeUp(tShadow, sf + 1, fps, 20);
  }

  // ── FINAL: Row + column dividers (added LAST → top of layer stack). ─
  // ebFadeOnly gives the dividers the same fade-in as the rest of the table.
  // For BAR style only, col dividers also get a 4px width to sit cleanly in
  // the stripe gap built in step 3. Minimal + Outlined retain their original
  // (thinner) treatment so they look identical to how they did before.
  var finalDivClrRGB = (style === 'outlined') ? accRGB : [0.68, 0.68, 0.68];
  // Row dividers
  if (style !== 'outlined') {
    for (var rrF = 0; rrF < numRows - 1; rrF++) {
      var rowDivYF = TT + HDR_H + (rrF + 1) * ROW_H;
      var rdLyrF = comp.layers.addSolid(finalDivClrRGB, 'EB_RowDiv_' + (rrF+1), TW, 1, 1);
      rdLyrF.position.setValue([960, rowDivYF]);
      ebFadeOnly(rdLyrF, sf + 6 + rrF * 3, fps, 10);
    }
  } else {
    for (var rrG = 0; rrG < numRows - 1; rrG++) {
      var rowDivYG = TT + HDR_H + (rrG + 1) * ROW_H;
      var rdLyrG = comp.layers.addSolid(accRGB, 'EB_RowDiv_' + (rrG+1), TW, 1, 1);
      rdLyrG.position.setValue([960, rowDivYG]);
      ebFadeOnly(rdLyrG, sf + 6 + rrG * 3, fps, 10);
    }
    var hdrSepLyrF = comp.layers.addSolid(accRGB, 'EB_RowDivHdr', TW, 2, 1);
    hdrSepLyrF.position.setValue([960, TT + HDR_H]);
    ebFadeOnly(hdrSepLyrF, sf + 4, fps, 10);
  }
  // Column dividers — bar: 4px wide (matches stripe gap); outlined: 1px.
  if (style !== 'minimal') {
    var colDivTopYF = (style === 'outlined') ? TT : TT + HDR_H;
    var colDivBotF  = TT + tableH;
    var colDivHF    = colDivBotF - colDivTopYF;
    var colDivCYF   = colDivTopYF + colDivHF / 2;
    var COL_DIV_W   = (style === 'bar') ? 4 : 1;
    for (var colF = 1; colF < numCols; colF++) {
      var divXF = TX + colF * COL_W;
      var cdLyrF = comp.layers.addSolid(finalDivClrRGB, 'EB_ColDiv_' + colF, COL_DIV_W, colDivHF, 1);
      cdLyrF.position.setValue([divXF, colDivCYF]);
      ebFadeOnly(cdLyrF, sf + 4, fps, 10);
    }
  }
}

// =============================================================
// BAR GRAPH BLOCK -- Horizontal animated bars (5 items)
// Bars extend left-to-right via Trim Path animation.
// =============================================================
function createBarGraphBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var color = ebColor(params.accentColor);
  var L     = EB_LAYOUT;

  var defaultItems = [
    { label: 'Category A', pct: 92 }, { label: 'Category B', pct: 74 },
    { label: 'Category C', pct: 58 }, { label: 'Category D', pct: 36 },
    { label: 'Category E', pct: 19 }, { label: 'Category F', pct: 51 },
    { label: 'Category G', pct: 68 }, { label: 'Category H', pct: 43 }
  ];
  var items   = (params.chartData && params.chartData.length >= 2)
                ? params.chartData.slice(0, 8) : defaultItems.slice(0, 5);
  var NUM_BAR = items.length;

  // Bar area symmetric around x=960: (360+1560)/2 = 960
  var LAB_X0   = L.marginX;            // 80
  var LAB_W    = 240;                   // label column (right-aligned)
  var BAR_X0   = LAB_X0 + LAB_W + 40;  // 360
  var BAR_X1   = L.compW - BAR_X0;     // 1560
  var BAR_FULL = BAR_X1 - BAR_X0;      // 1200

  // Height and gap scale with item count
  var hLay = [null,null,{h:80,g:160},{h:72,g:140},{h:64,g:120},{h:54,g:100},{h:46,g:90},{h:40,g:80},{h:36,g:72}];
  var BAR_H   = hLay[NUM_BAR].h;
  var BAR_GAP = hLay[NUM_BAR].g;
  var LAB_FSZ = NUM_BAR <= 5 ? 26 : NUM_BAR <= 7 ? 24 : 22;

  var totalH = (NUM_BAR - 1) * BAR_GAP + BAR_H;
  var firstY = Math.round(600 - totalH / 2 + BAR_H / 2);

  for (var i = 0; i < items.length; i++) {
    var item    = items[i];
    var barY    = Math.round(firstY + i * BAR_GAP);
    var barEndX = Math.round(BAR_X0 + BAR_FULL * Math.min(100, Math.max(0, item.pct)) / 100);
    var labY    = barY + Math.round(LAB_FSZ * 0.35);
    var fr      = sf + 36 + i * 6;

    // Background track
    var trackL = comp.layers.addShape();
    trackL.name = 'EB_Track_' + (i+1);
    trackL.position.setValue([0, 0]);
    var tGC  = trackL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tPth = tGC.addProperty('ADBE Vector Shape - Group');
    try { tPth.property('ADBE Vector Shape').setValue(ebOpenPath([[BAR_X0, barY],[BAR_X1, barY]])); } catch(e) {}
    var tStr = tGC.addProperty('ADBE Vector Graphic - Stroke');
    try { tStr.property('ADBE Vector Stroke Color').setValue([0.92,0.92,0.92,1]); } catch(e) {}
    try { tStr.property('ADBE Vector Stroke Width').setValue(BAR_H); } catch(e) {}
    try { tStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(trackL, fr, fps, 10); } catch(e) {} }

    // Colored bar (Trim Path grows left to right)
    var barL = comp.layers.addShape();
    barL.name = 'EB_Bar_' + (i+1);
    barL.position.setValue([0, 0]);
    var bGC  = barL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var bPth = bGC.addProperty('ADBE Vector Shape - Group');
    try { bPth.property('ADBE Vector Shape').setValue(ebOpenPath([[BAR_X0, barY],[barEndX, barY]])); } catch(e) {}
    var bStr = bGC.addProperty('ADBE Vector Graphic - Stroke');
    try { bStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { bStr.property('ADBE Vector Stroke Width').setValue(BAR_H); } catch(e) {}
    try { bStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
    var bTrm    = bGC.addProperty('ADBE Vector Filter - Trim');
    var bTrmEnd = bTrm.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { barL.inPoint = (fr + 2) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(bTrmEnd, fr + 2, fps); } catch(e) {}
    } else {
      try { bTrmEnd.setValue(100); } catch(e) {}
    }

    // Category label (right-aligned left column)
    var labTxt = ebText(comp, item.label, LAB_X0 + LAB_W, labY, LAB_FSZ, 'regular', [0,0,0], 'right');
    labTxt.name = 'EB_BarLabel_' + (i+1);
    try { ebTextAnimatorFadeUp(labTxt, fr, fps, 10); } catch(e) {}

    // Value (right-aligned fixed right column)
    var valTxt = ebText(comp, item.pct + '%', L.compW - L.marginX, labY, LAB_FSZ, 'bold', [color[0],color[1],color[2]], 'right');
    valTxt.name = 'EB_BarVal_' + (i+1);
    try { ebTextAnimatorFadeUp(valTxt, fr + 10, fps, 10); } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// VERTICAL BAR CHART BLOCK -- 5 vertical bars growing upward
// Bars use Trim Path on a vertical stroke (bottom to top).
// =============================================================
function createVerticalBarGraphBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var color = ebColor(params.accentColor);
  var L     = EB_LAYOUT;

  var defaultItems = [
    { label: 'Jan', pct: 72 }, { label: 'Feb', pct: 85 },
    { label: 'Mar', pct: 58 }, { label: 'Apr', pct: 91 },
    { label: 'May', pct: 64 }, { label: 'Jun', pct: 77 },
    { label: 'Jul', pct: 83 }, { label: 'Aug', pct: 69 }
  ];
  var items   = (params.chartData && params.chartData.length >= 2)
                ? params.chartData.slice(0, 8) : defaultItems.slice(0, 5);
  var NUM_BAR = items.length;

  var BAR_BOT = 900;
  var MAX_H   = 570;

  // Bar width and gap by count — bars always centered at x=960
  var vLay = [null,null,{w:200,g:200},{w:200,g:160},{w:180,g:140},{w:160,g:120},{w:140,g:100},{w:120,g:90},{w:110,g:80}];
  var BAR_W   = vLay[NUM_BAR].w;
  var BAR_GAP = vLay[NUM_BAR].g;
  var totalW  = NUM_BAR * BAR_W + (NUM_BAR - 1) * BAR_GAP;
  var firstX  = Math.round(960 - totalW / 2 + BAR_W / 2);

  var LAB_FSZ = NUM_BAR <= 5 ? 26 : NUM_BAR <= 7 ? 22 : 20;
  var VAL_FSZ = NUM_BAR <= 5 ? 28 : NUM_BAR <= 7 ? 24 : 22;

  // Baseline axis
  var axisL = comp.layers.addShape();
  axisL.name = 'EB_VBarAxis';
  axisL.position.setValue([0, 0]);
  var axGC  = axisL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var axPth = axGC.addProperty('ADBE Vector Shape - Group');
  try { axPth.property('ADBE Vector Shape').setValue(ebOpenPath([[L.marginX, BAR_BOT],[L.compW - L.marginX, BAR_BOT]])); } catch(e) {}
  var axStr = axGC.addProperty('ADBE Vector Graphic - Stroke');
  try { axStr.property('ADBE Vector Stroke Color').setValue([0.78,0.78,0.78,1]); } catch(e) {}
  try { axStr.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(axisL, sf+36, fps, 10); } catch(e) {} }

  for (var i = 0; i < items.length; i++) {
    var item   = items[i];
    var barX   = firstX + i * (BAR_W + BAR_GAP);
    var barH   = Math.round(MAX_H * Math.min(100, Math.max(0, item.pct)) / 100);
    var barTop = BAR_BOT - barH;
    var fr     = sf + 36 + i * 6;

    // Track (gray full-height)
    var trackL = comp.layers.addShape();
    trackL.name = 'EB_VTrack_' + (i+1);
    trackL.position.setValue([0, 0]);
    var tGC  = trackL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tPth = tGC.addProperty('ADBE Vector Shape - Group');
    try { tPth.property('ADBE Vector Shape').setValue(ebOpenPath([[barX, BAR_BOT],[barX, BAR_BOT - MAX_H]])); } catch(e) {}
    var tStr = tGC.addProperty('ADBE Vector Graphic - Stroke');
    try { tStr.property('ADBE Vector Stroke Color').setValue([0.92,0.92,0.92,1]); } catch(e) {}
    try { tStr.property('ADBE Vector Stroke Width').setValue(BAR_W); } catch(e) {}
    try { tStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(trackL, fr, fps, 10); } catch(e) {} }

    // Colored bar (Trim Path grows bottom to top)
    var barL = comp.layers.addShape();
    barL.name = 'EB_VBar_' + (i+1);
    barL.position.setValue([0, 0]);
    var bGC  = barL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var bPth = bGC.addProperty('ADBE Vector Shape - Group');
    try { bPth.property('ADBE Vector Shape').setValue(ebOpenPath([[barX, BAR_BOT],[barX, barTop]])); } catch(e) {}
    var bStr = bGC.addProperty('ADBE Vector Graphic - Stroke');
    try { bStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { bStr.property('ADBE Vector Stroke Width').setValue(BAR_W); } catch(e) {}
    try { bStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
    var bTrm    = bGC.addProperty('ADBE Vector Filter - Trim');
    var bTrmEnd = bTrm.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { barL.inPoint = (fr + 2) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(bTrmEnd, fr + 2, fps); } catch(e) {}
    } else {
      try { bTrmEnd.setValue(100); } catch(e) {}
    }

    // Value label (above bar, centered)
    var valY   = barTop - 16;
    var valTxt = ebText(comp, item.pct + '%', barX, valY, VAL_FSZ, 'bold', [color[0],color[1],color[2]], 'center');
    valTxt.name = 'EB_VBarVal_' + (i+1);
    try { ebTextAnimatorFadeUp(valTxt, fr + 14, fps, 12); } catch(e) {}

    // Category label (below baseline, centered)
    var labY   = BAR_BOT + 38;
    var labTxt = ebText(comp, item.label, barX, labY, LAB_FSZ, 'regular', [0,0,0], 'center');
    labTxt.name = 'EB_VBarLabel_' + (i+1);
    try { ebTextAnimatorFadeUp(labTxt, fr, fps, 10); } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// DONUT CHART BLOCK -- Segmented ring chart + right-side legend
// Each segment is an ellipse with Trim Path Start/End.
// Offset=-90 rotates start to 12-o'clock (top).
// =============================================================
function createDonutChartBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var CX     = 400;   // donut center X (outer left=145, content right=1775, center=960)
  var CY     = 590;   // donut center Y (vertically centered below header)
  var MID_R  = 200;
  var RING_W = 110;

  // 8 segment colors (5 brand + 3 extended)
  var segColors = [
    ebColor('76B900'),   // NVIDIA Green
    ebColor('0071C5'),   // Blue
    ebColor('5D1682'),   // Amethyst
    ebColor('FAC200'),   // Gold
    ebColor('890C58'),   // Crimson
    ebColor('00A8C8'),   // Teal
    ebColor('FF7043'),   // Deep Orange
    ebColor('7CB342')    // Lime Green
  ];
  var defaultSegs = [
    { label: 'Category A', pct: 32 }, { label: 'Category B', pct: 24 },
    { label: 'Category C', pct: 20 }, { label: 'Category D', pct: 15 },
    { label: 'Category E', pct:  9 }
  ];
  // Accept 2-8 segments from panel; fall back to 5-item defaults
  var rawSegs  = (params.chartData && params.chartData.length >= 2)
                 ? params.chartData.slice(0, 8) : defaultSegs;
  var NUM_SEGS = rawSegs.length;

  // Normalize to sum to 100 (safety net; panel pre-normalizes for donut)
  var segTotal = 0;
  for (var k = 0; k < rawSegs.length; k++) segTotal += rawSegs[k].pct;
  if (segTotal <= 0) segTotal = 100;
  var segs    = [];
  var runNorm = 0;
  for (var k = 0; k < rawSegs.length; k++) {
    var nPct = Math.round(rawSegs[k].pct / segTotal * 100);
    runNorm += nPct;
    if (k === rawSegs.length - 1) nPct += (100 - runNorm);
    segs.push({ label: rawSegs[k].label, pct: Math.max(0, nPct) });
  }

  // Gray background ring
  var bgRing = comp.layers.addShape();
  bgRing.name = 'EB_DonutTrack';
  bgRing.position.setValue([CX, CY]);
  var bgGC  = bgRing.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bgEll = bgGC.addProperty('ADBE Vector Shape - Ellipse');
  try { bgEll.property('ADBE Vector Ellipse Size').setValue([MID_R*2, MID_R*2]); } catch(e) {}
  var bgStr = bgGC.addProperty('ADBE Vector Graphic - Stroke');
  try { bgStr.property('ADBE Vector Stroke Color').setValue([0.92,0.92,0.92,1]); } catch(e) {}
  try { bgStr.property('ADBE Vector Stroke Width').setValue(RING_W); } catch(e) {}
  try { bgStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
  // ── Sequential timing: pre-compute per-segment start frame and duration ──
  // Duration is proportional to the arc size so every segment fills at the same
  // angular speed (each % ≈ 0.70 frames, minimum 6 frames for tiny slices).
  var SEG_START_F = sf + 36;
  var SEG_SPEED   = 0.70;
  var MIN_DUR     = 6;
  var segFrames   = [];
  var segCumF     = SEG_START_F;
  for (var k2 = 0; k2 < segs.length; k2++) {
    var segDur = Math.max(MIN_DUR, Math.round(segs[k2].pct * SEG_SPEED));
    segFrames.push({ start: segCumF, dur: segDur });
    segCumF += segDur;
  }
  var lastSegEndF = segCumF;  // frame when the last segment finishes

  // Background ring fades in just before first segment starts
  if (params.animateIn) { try { ebAnimateFadeUp(bgRing, SEG_START_F - 8, fps, 15); } catch(e) {} }

  // Colored segments — each draws fully before the next begins
  var cumPct = 0;
  for (var i = 0; i < segs.length; i++) {
    var seg    = segs[i];
    var sLayer = comp.layers.addShape();
    sLayer.name = 'EB_DonutSeg_' + (i+1);
    sLayer.position.setValue([CX, CY]);
    var sGC  = sLayer.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var sEll = sGC.addProperty('ADBE Vector Shape - Ellipse');
    try { sEll.property('ADBE Vector Ellipse Size').setValue([MID_R*2, MID_R*2]); } catch(e) {}
    var sStr = sGC.addProperty('ADBE Vector Graphic - Stroke');
    try { sStr.property('ADBE Vector Stroke Color').setValue(segColors[i % segColors.length]); } catch(e) {}
    try { sStr.property('ADBE Vector Stroke Width').setValue(RING_W); } catch(e) {}
    try { sStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
    var sTrm = sGC.addProperty('ADBE Vector Filter - Trim');
    try { sTrm.property('ADBE Vector Trim Start').setValue(cumPct); } catch(e) {}
    try { sTrm.property('ADBE Vector Trim Offset').setValue(-90); } catch(e) {}
    var sTrmEnd = sTrm.property('ADBE Vector Trim End');
    if (params.animateIn) {
      var sf0 = segFrames[i];
      try { sTrmEnd.setValueAtTime(sf0.start / fps, cumPct); } catch(e) {}
      try { sTrmEnd.setValueAtTime((sf0.start + sf0.dur) / fps, cumPct + seg.pct); } catch(e) {}
      try { setEase(sTrmEnd, sTrmEnd.nearestKeyIndex(sf0.start / fps),               66, 66); } catch(e) {}
      try { setEase(sTrmEnd, sTrmEnd.nearestKeyIndex((sf0.start + sf0.dur) / fps),  66, 66); } catch(e) {}
    } else {
      try { sTrmEnd.setValue(cumPct + seg.pct); } catch(e) {}
    }
    cumPct = Math.round((cumPct + seg.pct) * 1000) / 1000;
  }

  // Center labels — appear after all segments have finished drawing.
  // Strategy: create at the final position with CENTER_JUSTIFY (fallback if
  // sourceRectAtTime is unavailable), then use rect.left + rect.width/2 to
  // move the anchor to the true horizontal midpoint of each string.
  var cLbl = ebText(comp, 'Total', CX, CY - 14, 22, 'regular', [0,0,0], 'center');
  cLbl.name = 'EB_DonutCenterLbl';
  try {
    var r1 = cLbl.sourceRectAtTime(0, false);
    cLbl.anchorPoint.setValue([r1.left + r1.width / 2, 0]);
    cLbl.position.setValue([CX, CY - 14]);
  } catch(e) {}

  var cVal = ebText(comp, '100%', CX, CY + 24, 30, 'bold', [0.88,0.88,0.88], 'center');
  cVal.name = 'EB_DonutCenterVal';
  try {
    var r2 = cVal.sourceRectAtTime(0, false);
    cVal.anchorPoint.setValue([r2.left + r2.width / 2, 0]);
    cVal.position.setValue([CX, CY + 24]);
  } catch(e) {}
  try { ebTextAnimatorFadeUp(cLbl, lastSegEndF + 4, fps, 10); } catch(e) {}
  try { ebTextAnimatorFadeUp(cVal, lastSegEndF + 6, fps, 10); } catch(e) {}

  // Legend — gap and font scale by segment count; vertically centered at CY
  var LEG_X   = 720;
  var legGaps = [null,null,88,88,88,88,80,72,65];
  var LEG_GAP = legGaps[NUM_SEGS] || 80;
  var LEG_FSZ = NUM_SEGS <= 5 ? 28 : NUM_SEGS <= 7 ? 24 : 22;
  var SW      = NUM_SEGS <= 6 ? 22 : 18;
  var LEG_Y0  = Math.round(CY - (NUM_SEGS - 1) * LEG_GAP / 2);

  for (var j = 0; j < segs.length; j++) {
    var s2    = segs[j];
    var lY    = LEG_Y0 + j * LEG_GAP;
    var legFr = segFrames[j];  // timing mirrors the corresponding segment
    var cIdx  = j % segColors.length;
    var cRGB  = [segColors[cIdx][0], segColors[cIdx][1], segColors[cIdx][2]];

    // Color swatch — appears when the segment starts drawing
    var swL = comp.layers.addShape();
    swL.name = 'EB_LegSw_' + (j+1);
    swL.position.setValue([LEG_X + SW/2, lY]);
    var swGC  = swL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var swRct = swGC.addProperty('ADBE Vector Shape - Rect');
    try { swRct.property('ADBE Vector Rect Size').setValue([SW, SW]); } catch(e) {}
    try { swRct.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    var swFil = swGC.addProperty('ADBE Vector Graphic - Fill');
    try { swFil.property('ADBE Vector Fill Color').setValue(segColors[cIdx]); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(swL, legFr.start, fps, 10); } catch(e) {} }

    // Category label — appears 2 frames after the swatch
    var llY  = lY + Math.round(LEG_FSZ * 0.35);
    var lLblTxt = String(s2.label || ''); if (lLblTxt.length > 22) lLblTxt = lLblTxt.substring(0, 20) + '…';
    var lLbl = ebText(comp, lLblTxt, LEG_X + SW + 16, llY, LEG_FSZ, 'regular', [0,0,0], 'left');
    lLbl.name = 'EB_LegLbl_' + (j+1);
    try { ebTextAnimatorFadeUp(lLbl, legFr.start + 2, fps, 10); } catch(e) {}

    // Percentage — appears when the segment finishes drawing
    var pLbl = ebText(comp, s2.pct + '%', 1775, llY, LEG_FSZ, 'bold', cRGB, 'right');
    pLbl.name = 'EB_LegPct_' + (j+1);
    try { ebTextAnimatorFadeUp(pLbl, legFr.start + legFr.dur, fps, 10); } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// STACKED BAR CHART -- Vertical bars with two color segments
// Base segment (accent color) = within-quota allocation.
// Overflow segment (dark navy) = over-quota allocation.
// params.yMax   = max Y-axis value (default 100)
// params.items  = [{label, base, overflow}, ...]  overflow optional
// params.legend = {baseLabel, overflowLabel}
// =============================================================
function createStackedBarChartBlock(comp, params) {
  var fps  = comp.frameRate;
  var sf   = 1;

  var baseColor = ebColor(params.accentColor || 'FAC200');
  var ovColor   = [0.08, 0.08, 0.15, 1];   // dark navy for over-quota

  var defaultItems = [
    { label: 'Group A', base:  8, overflow: 0 },
    { label: 'Group B', base:  4, overflow: 7 },
    { label: 'Group C', base: 10, overflow: 0 }
  ];
  var items   = (params.items && params.items.length >= 1)
                ? params.items.slice(0, 6) : defaultItems;
  var NUM_BAR = items.length;

  var yMax      = params.yMax || 100;
  var legend    = params.legend || {};
  var baseLabel = legend.baseLabel     || 'Within quota';
  var ovLabel   = legend.overflowLabel || 'Over quota';

  // Chart geometry
  var BAR_BOT  = 900;
  var BAR_TOP  = 290;
  var MAX_H    = BAR_BOT - BAR_TOP;   // 610px for full scale

  // Bar dimensions by count
  var barLayouts = [
    null,
    { w: 280, g: 0   },  // 1 bar
    { w: 220, g: 220 },  // 2 bars
    { w: 180, g: 140 },  // 3 bars
    { w: 150, g: 110 },  // 4 bars
    { w: 130, g: 90  },  // 5 bars
    { w: 110, g: 76  }   // 6 bars
  ];
  var bl      = barLayouts[NUM_BAR] || { w: 100, g: 70 };
  var BAR_W   = bl.w;
  var BAR_GAP = bl.g;
  var totalW  = NUM_BAR * BAR_W + (NUM_BAR - 1) * BAR_GAP;
  var firstX  = Math.round(960 - totalW / 2 + BAR_W / 2);
  var chartLX = firstX - BAR_W / 2;
  var chartRX = firstX + (NUM_BAR - 1) * (BAR_W + BAR_GAP) + BAR_W / 2;
  var chartCX = Math.round((chartLX + chartRX) / 2);

  var LAB_FSZ  = NUM_BAR <= 3 ? 26 : NUM_BAR <= 5 ? 24 : 22;
  var VAL_FSZ  = NUM_BAR <= 3 ? 28 : 24;
  var GRID_FSZ = 22;
  var GRID_CLR = [0.82, 0.82, 0.82, 1];

  // Grid interval (nice round numbers)
  var gridInterval;
  if      (yMax <= 10)  gridInterval = 2;
  else if (yMax <= 20)  gridInterval = 4;
  else if (yMax <= 50)  gridInterval = 10;
  else if (yMax <= 100) gridInterval = 20;
  else                  gridInterval = Math.ceil(yMax / 5 / 10) * 10;

  // Y-axis vertical line
  var yAxisL = comp.layers.addShape();
  yAxisL.name = 'EB_SYAxis';
  yAxisL.position.setValue([0, 0]);
  var yaGC  = yAxisL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var yaPth = yaGC.addProperty('ADBE Vector Shape - Group');
  try { yaPth.property('ADBE Vector Shape').setValue(ebOpenPath([[chartLX, BAR_TOP],[chartLX, BAR_BOT]])); } catch(e) {}
  var yaStr = yaGC.addProperty('ADBE Vector Graphic - Stroke');
  try { yaStr.property('ADBE Vector Stroke Color').setValue(GRID_CLR); } catch(e) {}
  try { yaStr.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(yAxisL, sf, fps, 8); } catch(e) {} }

  // Horizontal gridlines + Y-axis labels
  var GRID_X = chartLX - 24;   // right edge of Y-axis number labels
  for (var g = 0; g <= yMax; g += gridInterval) {
    var gridY = BAR_BOT - Math.round(MAX_H * g / yMax);
    var isBase = (g === 0);

    var gridL = comp.layers.addShape();
    gridL.name = 'EB_SGrid_' + g;
    gridL.position.setValue([0, 0]);
    var ggc  = gridL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gpth = ggc.addProperty('ADBE Vector Shape - Group');
    try { gpth.property('ADBE Vector Shape').setValue(ebOpenPath([[chartLX, gridY],[chartRX, gridY]])); } catch(e) {}
    var gstr = ggc.addProperty('ADBE Vector Graphic - Stroke');
    try { gstr.property('ADBE Vector Stroke Color').setValue(GRID_CLR); } catch(e) {}
    try { gstr.property('ADBE Vector Stroke Width').setValue(isBase ? 2 : 1); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(gridL, sf, fps, 5); } catch(e) {} }

    var glbl = ebText(comp, '' + g, GRID_X, gridY + Math.round(GRID_FSZ * 0.35), GRID_FSZ, 'regular', [0,0,0], 'right');
    glbl.name = 'EB_SGridLbl_' + g;
    if (params.animateIn) { try { ebTextAnimatorFadeUp(glbl, sf, fps, 5); } catch(e) {} }
  }

  // Bars
  for (var i = 0; i < NUM_BAR; i++) {
    var item   = items[i];
    var barX   = firstX + i * (BAR_W + BAR_GAP);
    var base   = Math.max(0, Math.min(item.base    || 0, yMax));
    var ovflow = Math.max(0, Math.min(item.overflow || 0, yMax - base));
    var baseH  = Math.round(MAX_H * base   / yMax);
    var ovH    = Math.round(MAX_H * ovflow / yMax);
    var fr     = sf + 10 + i * 8;

    // Track (gray, full height)
    var trackL = comp.layers.addShape();
    trackL.name = 'EB_STrack_' + (i+1);
    trackL.position.setValue([0, 0]);
    var tGC  = trackL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tPth = tGC.addProperty('ADBE Vector Shape - Group');
    try { tPth.property('ADBE Vector Shape').setValue(ebOpenPath([[barX, BAR_BOT],[barX, BAR_TOP]])); } catch(e) {}
    var tStr = tGC.addProperty('ADBE Vector Graphic - Stroke');
    try { tStr.property('ADBE Vector Stroke Color').setValue([0.92,0.92,0.92,1]); } catch(e) {}
    try { tStr.property('ADBE Vector Stroke Width').setValue(BAR_W); } catch(e) {}
    try { tStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(trackL, fr, fps, 10); } catch(e) {} }

    // Base segment (accent color -- within quota)
    if (baseH > 0) {
      var baseTopY = BAR_BOT - baseH;
      var baseL = comp.layers.addShape();
      baseL.name = 'EB_SBase_' + (i+1);
      baseL.position.setValue([0, 0]);
      var bGC  = baseL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var bPth = bGC.addProperty('ADBE Vector Shape - Group');
      try { bPth.property('ADBE Vector Shape').setValue(ebOpenPath([[barX, BAR_BOT],[barX, baseTopY]])); } catch(e) {}
      var bStr = bGC.addProperty('ADBE Vector Graphic - Stroke');
      try { bStr.property('ADBE Vector Stroke Color').setValue(baseColor); } catch(e) {}
      try { bStr.property('ADBE Vector Stroke Width').setValue(BAR_W); } catch(e) {}
      try { bStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
      var bTrm    = bGC.addProperty('ADBE Vector Filter - Trim');
      var bTrmEnd = bTrm.property('ADBE Vector Trim End');
      if (params.animateIn) {
        try { baseL.inPoint = (fr + 2) / fps; } catch(e) {}
        try { ebAnimateTrimDraw(bTrmEnd, fr + 2, fps); } catch(e) {}
      } else {
        try { bTrmEnd.setValue(100); } catch(e) {}
      }
    }

    // Overflow segment (dark navy -- over quota), starts after base finishes
    if (ovH > 0) {
      var ovBotY = BAR_BOT - baseH;
      var ovTopY = BAR_BOT - baseH - ovH;
      var ovL = comp.layers.addShape();
      ovL.name = 'EB_SOver_' + (i+1);
      ovL.position.setValue([0, 0]);
      var oGC  = ovL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var oPth = oGC.addProperty('ADBE Vector Shape - Group');
      try { oPth.property('ADBE Vector Shape').setValue(ebOpenPath([[barX, ovBotY],[barX, ovTopY]])); } catch(e) {}
      var oStr = oGC.addProperty('ADBE Vector Graphic - Stroke');
      try { oStr.property('ADBE Vector Stroke Color').setValue(ovColor); } catch(e) {}
      try { oStr.property('ADBE Vector Stroke Width').setValue(BAR_W); } catch(e) {}
      try { oStr.property('ADBE Vector Stroke Line Cap').setValue(1); } catch(e) {}
      var oTrm    = oGC.addProperty('ADBE Vector Filter - Trim');
      var oTrmEnd = oTrm.property('ADBE Vector Trim End');
      if (params.animateIn) {
        try { ovL.inPoint = (fr + 20) / fps; } catch(e) {}
        try { ebAnimateTrimDraw(oTrmEnd, fr + 20, fps); } catch(e) {}
      } else {
        try { oTrmEnd.setValue(100); } catch(e) {}
      }
    }

    // Bar label (below baseline)
    var labY   = BAR_BOT + 38;
    var labTxt = ebText(comp, item.label, barX, labY, LAB_FSZ, 'regular', [0,0,0], 'center');
    labTxt.name = 'EB_SBarLab_' + (i+1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(labTxt, fr, fps, 10); } catch(e) {} }

    // Total value label (above bar top)
    var total   = (item.base || 0) + (item.overflow || 0);
    var valTopY = BAR_BOT - baseH - ovH - 20;
    if (total > 0) {
      var valTxt = ebText(comp, '' + total, barX, valTopY, VAL_FSZ, 'bold', [0,0,0], 'center');
      valTxt.name = 'EB_SBarVal_' + (i+1);
      if (params.animateIn) { try { ebTextAnimatorFadeUp(valTxt, fr + 30, fps, 10); } catch(e) {} }
    }
  }

  // Legend -- centered below bars
  var SW      = 20;
  var LEG_Y   = BAR_BOT + 68;
  var LEG_GAP = 220;
  var legX0   = Math.round(chartCX - LEG_GAP);

  // Base swatch
  var swBL = comp.layers.addShape();
  swBL.name = 'EB_SLegSwBase';
  swBL.position.setValue([legX0 + SW/2, LEG_Y]);
  var swBGC  = swBL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var swBRct = swBGC.addProperty('ADBE Vector Shape - Rect');
  try { swBRct.property('ADBE Vector Rect Size').setValue([SW, SW]); } catch(e) {}
  try { swBRct.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
  var swBFil = swBGC.addProperty('ADBE Vector Graphic - Fill');
  try { swBFil.property('ADBE Vector Fill Color').setValue(baseColor); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(swBL, sf + 40, fps, 5); } catch(e) {} }

  var baseLegY   = LEG_Y + Math.round(24 * 0.35);
  var baseLegLbl = ebText(comp, baseLabel, legX0 + SW + 12, baseLegY, 24, 'regular', [0,0,0], 'left');
  baseLegLbl.name = 'EB_SLegLblBase';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(baseLegLbl, sf + 42, fps, 5); } catch(e) {} }

  // Overflow swatch
  var swOX = legX0 + LEG_GAP;
  var swOL = comp.layers.addShape();
  swOL.name = 'EB_SLegSwOver';
  swOL.position.setValue([swOX + SW/2, LEG_Y]);
  var swOGC  = swOL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var swORct = swOGC.addProperty('ADBE Vector Shape - Rect');
  try { swORct.property('ADBE Vector Rect Size').setValue([SW, SW]); } catch(e) {}
  try { swORct.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
  var swOFil = swOGC.addProperty('ADBE Vector Graphic - Fill');
  try { swOFil.property('ADBE Vector Fill Color').setValue(ovColor); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(swOL, sf + 44, fps, 5); } catch(e) {} }

  var ovLegLbl = ebText(comp, ovLabel, swOX + SW + 12, baseLegY, 24, 'regular', [0,0,0], 'left');
  ovLegLbl.name = 'EB_SLegLblOver';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(ovLegLbl, sf + 46, fps, 5); } catch(e) {} }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// LINE CHART  (chart-line)
// =============================================================
function createLineChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX0=180,CX1=1760,CY0=300,CY1=880,CW=1580,CH=580;
  var CC=[[0.463,0.725,0],[0.357,0.553,0.851],[0.608,0.349,0.714],[0.980,0.761,0],[0.906,0.298,0.235]];
  var axC=[0.78,0.78,0.78,1], gC=[0.92,0.92,0.92,1];
  function _sl(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    return l;
  }
  var defS=[{label:'Series A',values:[42,58,73,61,85,90,78,95]}];
  var series=(params.series&&params.series.length)?params.series.slice(0,3):defS;
  var nPts=0;
  for(var _i=0;_i<series.length;_i++){var _v=(series[_i].values||[]);if(_v.length>nPts)nPts=_v.length;}
  nPts=Math.min(Math.max(nPts,2),10);
  var defXL=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct'];
  var xL=(params.xLabels&&params.xLabels.length)?params.xLabels:defXL.slice(0,nPts);
  var yMax=params.yMax||100, xSt=CW/(nPts-1);
  var yAx=_sl([[CX0,CY0],[CX0,CY1]],axC,2,'EB_LcYAx');ebAnimateFadeUp(yAx,sf,fps,8);
  var xAx=_sl([[CX0,CY1],[CX1,CY1]],axC,2,'EB_LcXAx');ebAnimateFadeUp(xAx,sf,fps,8);
  for(var gi=0;gi<=5;gi++){
    var gv=gi*20,gY=CY1-Math.round((gv/yMax)*CH);
    var gl=_sl([[CX0,gY],[CX1,gY]],gC,1,'EB_LcG'+gi);ebAnimateFadeUp(gl,sf,fps,8);
    var yl=ebText(comp,''+Math.round(gv*yMax/100),CX0-14,gY+7,20,'regular',[0.55,0.55,0.55],'right');
    yl.name='EB_LcYL'+gi;ebTextAnimatorFadeUp(yl,sf,fps,8);
  }
  for(var xi=0;xi<nPts;xi++){
    var xp=CX0+Math.round(xi*xSt);
    var xl=ebText(comp,xL[xi]||''+(xi+1),xp,CY1+38,22,'regular',[0.55,0.55,0.55],'center');
    xl.name='EB_LcXL'+xi;ebTextAnimatorFadeUp(xl,sf+36,fps,8);
  }
  for(var si=0;si<series.length;si++){
    var ser=series[si],c=CC[si%CC.length],cA=[c[0],c[1],c[2],1],frS=sf+36+si*24;
    var vts=[];
    for(var vi=0;vi<nPts;vi++){
      var vl=Math.min(Math.max(ser.values[vi]!==undefined?ser.values[vi]:0,0),yMax);
      vts.push([CX0+Math.round(vi*xSt),CY1-Math.round((vl/yMax)*CH)]);
    }
    var ll=comp.layers.addShape();ll.name='EB_LcLn'+si;ll.position.setValue([0,0]);
    var lgc=ll.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var lp=lgc.addProperty('ADBE Vector Shape - Group');
    try{lp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var ls=lgc.addProperty('ADBE Vector Graphic - Stroke');
    try{ls.property('ADBE Vector Stroke Color').setValue(cA);}catch(e){}
    try{ls.property('ADBE Vector Stroke Width').setValue(3.5);}catch(e){}
    try{ls.property('ADBE Vector Stroke Line Join').setValue(2);}catch(e){}
    var lt=lgc.addProperty('ADBE Vector Filter - Trim');
    var ltE=lt.property('ADBE Vector Trim End');
    if(params.animateIn){try{ebAnimateTrimDraw(ltE,frS,fps);}catch(e){}try{ll.inPoint=frS/fps;}catch(e){}}
    else{try{ltE.setValue(100);}catch(e){}}
    for(var di=0;di<nPts;di++){
      var dFr=frS+Math.round(di/Math.max(nPts-1,1)*20)+8;
      var dot=comp.layers.addSolid([c[0],c[1],c[2]],'EB_LcDt'+si+'_'+di,10,10,1);
      try{dot.anchorPoint.setValue([5,5]);}catch(e){}
      dot.position.setValue([vts[di][0],vts[di][1]]);ebAnimateFadeUp(dot,dFr,fps,6);
    }
    var lsw=comp.layers.addSolid([c[0],c[1],c[2]],'EB_LcLS'+si,28,5,1);
    try{lsw.anchorPoint.setValue([14,2.5]);}catch(e){}lsw.position.setValue([1594,310+si*44]);
    ebAnimateFadeUp(lsw,frS,fps,6);
    var ltx=ebText(comp,ser.label,1616,314+si*44,22,'regular',[0.3,0.3,0.3],'left');
    ltx.name='EB_LcLT'+si;ebTextAnimatorFadeUp(ltx,frS+2,fps,6);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// GROUPED BAR CHART  (chart-bar-grouped)
// =============================================================
function createGroupedBarChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX0=160,CX1=1760,CY0=300,CY1=880,CH=580;
  var CC=[[0.463,0.725,0],[0.357,0.553,0.851],[0.608,0.349,0.714],[0.980,0.761,0]];
  var axC=[0.78,0.78,0.78,1], gC=[0.92,0.92,0.92,1];
  function _sl2(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    return l;
  }
  var defSeries=[{label:'Series A',values:[65,82,74,91]},{label:'Series B',values:[40,55,68,45]}];
  var series=(params.series&&params.series.length)?params.series.slice(0,4):defSeries;
  var nSer=series.length;
  var defXL=['Q1','Q2','Q3','Q4','Q5','Q6'];
  var xLabels=(params.xLabels&&params.xLabels.length)?params.xLabels:defXL;
  var nGrp=0;
  for(var _i2=0;_i2<nSer;_i2++){var _vv=(series[_i2].values||[]);if(_vv.length>nGrp)nGrp=_vv.length;}
  nGrp=Math.min(Math.max(nGrp,2),6);
  var yMax=params.yMax||100;
  var bw=nSer<=2?80:nSer===3?60:44, bGap=4;
  var grpW=nSer*bw+(nSer-1)*bGap;
  var grpGap=Math.max(40,Math.round((CX1-CX0-nGrp*grpW)/(nGrp+1)));
  var firstGrpX=CX0+grpGap+Math.round(grpW/2);
  // Y axis + gridlines
  var yAx2=_sl2([[CX0,CY0],[CX0,CY1]],axC,2,'EB_GbYAx');ebAnimateFadeUp(yAx2,sf,fps,8);
  var xAx2=_sl2([[CX0,CY1],[CX1,CY1]],axC,2,'EB_GbXAx');ebAnimateFadeUp(xAx2,sf,fps,8);
  for(var gi2=0;gi2<=5;gi2++){
    var gv2=gi2*20,gY2=CY1-Math.round((gv2/yMax)*CH);
    var gl2=_sl2([[CX0,gY2],[CX1,gY2]],gC,1,'EB_GbGrd'+gi2);ebAnimateFadeUp(gl2,sf,fps,8);
    var yl2=ebText(comp,''+Math.round(gv2*yMax/100),CX0-14,gY2+7,20,'regular',[0.55,0.55,0.55],'right');
    yl2.name='EB_GbYL'+gi2;ebTextAnimatorFadeUp(yl2,sf,fps,8);
  }
  // Bars
  for(var gi3=0;gi3<nGrp;gi3++){
    var grpX=firstGrpX+gi3*(grpW+grpGap);
    for(var si2=0;si2<nSer;si2++){
      var c2=CC[si2%CC.length],frB=sf+36+gi3*8+si2*3;
      var pct=Math.min(Math.max(series[si2].values[gi3]||0,0),yMax);
      var barH=Math.round((pct/yMax)*CH);
      var barX=grpX-Math.round(grpW/2)+si2*(bw+bGap)+Math.round(bw/2);
      var barTop=CY1-barH;
      // Track
      var trk=comp.layers.addSolid([0.92,0.92,0.92],'EB_GbTrk'+gi3+'_'+si2,bw,CH,1);
      try{trk.anchorPoint.setValue([bw/2,0]);}catch(e){}
      trk.position.setValue([barX,CY0]);ebAnimateFadeUp(trk,frB,fps,8);
      // Bar
      if(barH>0){
        var bL=comp.layers.addShape();bL.name='EB_GbBar'+gi3+'_'+si2;bL.position.setValue([barX,CY1]);
        var bgc=bL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
        var bp=bgc.addProperty('ADBE Vector Shape - Group');
        try{bp.property('ADBE Vector Shape').setValue(ebOpenPath([[0,0],[0,-CH]]));}catch(e){}
        var bst=bgc.addProperty('ADBE Vector Graphic - Stroke');
        try{bst.property('ADBE Vector Stroke Color').setValue([c2[0],c2[1],c2[2],1]);}catch(e){}
        try{bst.property('ADBE Vector Stroke Width').setValue(bw);}catch(e){}
        var bTr=bgc.addProperty('ADBE Vector Filter - Trim');
        var bTE=bTr.property('ADBE Vector Trim End');
        try{bTr.property('ADBE Vector Trim Start').setValue(0);}catch(e){}
        try{bTE.setValue(0);}catch(e){}
        var bEndPct=Math.round((pct/yMax)*100);
        if(params.animateIn){
          try{bTE.setValueAtTime(frB/fps,0);bTE.setValueAtTime((frB+16)/fps,bEndPct);}catch(e){}
          try{bL.inPoint=frB/fps;}catch(e){}
        } else {try{bTE.setValue(bEndPct);}catch(e){}}
        // Value label
        if(pct>4){
          var vLbl=ebText(comp,''+Math.round(pct),barX,barTop-18,20,'bold',[c2[0],c2[1],c2[2]],'center');
          vLbl.name='EB_GbVal'+gi3+'_'+si2;ebTextAnimatorFadeUp(vLbl,frB+16,fps,8);
        }
      }
    }
    // Group label
    var xLbl2=ebText(comp,xLabels[gi3]||''+(gi3+1),grpX,CY1+36,22,'regular',[0.55,0.55,0.55],'center');
    xLbl2.name='EB_GbXL'+gi3;ebTextAnimatorFadeUp(xLbl2,sf+36,fps,8);
  }
  // Legend
  for(var si3=0;si3<nSer;si3++){
    var c3=CC[si3%CC.length],lY3=310+si3*44;
    var lsw3=comp.layers.addSolid([c3[0],c3[1],c3[2]],'EB_GbLS'+si3,28,14,1);
    try{lsw3.anchorPoint.setValue([14,7]);}catch(e){}lsw3.position.setValue([1594,lY3]);
    ebAnimateFadeUp(lsw3,sf+40,fps,6);
    var ltx3=ebText(comp,series[si3].label,1616,lY3+4,22,'regular',[0.3,0.3,0.3],'left');
    ltx3.name='EB_GbLT'+si3;ebTextAnimatorFadeUp(ltx3,sf+42,fps,6);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// AREA CHART  (chart-area)
// =============================================================
function createAreaChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX0=180,CX1=1760,CY0=300,CY1=880,CW=1580,CH=580;
  var c0=[0.463,0.725,0],cA=[0.463,0.725,0,1];
  var axC=[0.78,0.78,0.78,1], gC=[0.92,0.92,0.92,1];
  function _sl3(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    return l;
  }
  var defSer={label:'Revenue',values:[30,48,52,71,65,88,92,78]};
  var ser=(params.series&&params.series[0])?params.series[0]:defSer;
  var nPts=Math.min(Math.max((ser.values||[]).length,2),10);
  var defXL2=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct'];
  var xL2=(params.xLabels&&params.xLabels.length)?params.xLabels:defXL2.slice(0,nPts);
  var yMax2=params.yMax||100, xSt2=CW/(nPts-1);
  // Compute vertices
  var vts2=[];
  for(var vi2=0;vi2<nPts;vi2++){
    var vl2=Math.min(Math.max(ser.values[vi2]!==undefined?ser.values[vi2]:0,0),yMax2);
    vts2.push([CX0+Math.round(vi2*xSt2),CY1-Math.round((vl2/yMax2)*CH)]);
  }
  // Axes + grid
  var yAx3=_sl3([[CX0,CY0],[CX0,CY1]],axC,2,'EB_AcYAx');ebAnimateFadeUp(yAx3,sf,fps,8);
  var xAx3=_sl3([[CX0,CY1],[CX1,CY1]],axC,2,'EB_AcXAx');ebAnimateFadeUp(xAx3,sf,fps,8);
  for(var gi4=0;gi4<=5;gi4++){
    var gv4=gi4*20,gY4=CY1-Math.round((gv4/yMax2)*CH);
    var gl4=_sl3([[CX0,gY4],[CX1,gY4]],gC,1,'EB_AcG'+gi4);ebAnimateFadeUp(gl4,sf,fps,8);
    var yl4=ebText(comp,''+Math.round(gv4*yMax2/100),CX0-14,gY4+7,20,'regular',[0.55,0.55,0.55],'right');
    yl4.name='EB_AcYL'+gi4;ebTextAnimatorFadeUp(yl4,sf,fps,8);
  }
  for(var xi2=0;xi2<nPts;xi2++){
    var xp2=CX0+Math.round(xi2*xSt2);
    var xl2=ebText(comp,xL2[xi2]||''+(xi2+1),xp2,CY1+38,22,'regular',[0.55,0.55,0.55],'center');
    xl2.name='EB_AcXL'+xi2;ebTextAnimatorFadeUp(xl2,sf+36,fps,8);
  }
  // Area fill — one addSolid rect per segment between consecutive points
  var frA=sf+36;
  for(var ai=0;ai<nPts-1;ai++){
    var x1a=vts2[ai][0], x2a=vts2[ai+1][0];
    var y1a=vts2[ai][1], y2a=vts2[ai+1][1];
    var topY=Math.min(y1a,y2a), segH=CY1-topY;
    var segW=x2a-x1a;
    if(segH>0&&segW>0){
      var fill=comp.layers.addSolid([c0[0],c0[1],c0[2]],'EB_AcFill'+ai,segW,segH,1);
      try{fill.anchorPoint.setValue([0,0]);}catch(e){}
      fill.position.setValue([x1a,topY]);
      try{fill.opacity.setValue(25);}catch(e){}
      ebAnimateFadeUp(fill,frA+ai*2,fps,8);
    }
  }
  // Line
  var ll3=comp.layers.addShape();ll3.name='EB_AcLn';ll3.position.setValue([0,0]);
  var lgc3=ll3.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var lp3=lgc3.addProperty('ADBE Vector Shape - Group');
  try{lp3.property('ADBE Vector Shape').setValue(ebOpenPath(vts2));}catch(e){}
  var ls3=lgc3.addProperty('ADBE Vector Graphic - Stroke');
  try{ls3.property('ADBE Vector Stroke Color').setValue(cA);}catch(e){}
  try{ls3.property('ADBE Vector Stroke Width').setValue(3.5);}catch(e){}
  try{ls3.property('ADBE Vector Stroke Line Join').setValue(2);}catch(e){}
  var lt3=lgc3.addProperty('ADBE Vector Filter - Trim');
  var ltE3=lt3.property('ADBE Vector Trim End');
  if(params.animateIn){try{ebAnimateTrimDraw(ltE3,frA,fps);}catch(e){}try{ll3.inPoint=frA/fps;}catch(e){}}
  else{try{ltE3.setValue(100);}catch(e){}}
  // Dots
  for(var di3=0;di3<nPts;di3++){
    var dFr3=frA+Math.round(di3/Math.max(nPts-1,1)*20)+8;
    var dot3=comp.layers.addSolid([c0[0],c0[1],c0[2]],'EB_AcDt'+di3,10,10,1);
    try{dot3.anchorPoint.setValue([5,5]);}catch(e){}
    dot3.position.setValue([vts2[di3][0],vts2[di3][1]]);ebAnimateFadeUp(dot3,dFr3,fps,6);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// PROGRESS GAUGES  (chart-progress)
// =============================================================
function createProgressChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var defData=[
    {label:'GPU Utilization',pct:87},{label:'Memory',pct:62},
    {label:'Network',pct:45},{label:'Storage I/O',pct:91}
  ];
  var data=(params.chartData&&params.chartData.length)?params.chartData.slice(0,5):defData;
  var N=data.length;
  var segColors=[
    ebColor('76B900'),ebColor('0071C5'),ebColor('5D1682'),
    ebColor('FAC200'),ebColor('00A8C8')
  ];
  var MID_R=N===1?220:120, RING_W=N===1?32:20;
  var totalW=N*(MID_R*2+120), startX=Math.round(960-totalW/2+MID_R+60);
  var CY=N===1?560:530;
  for(var i=0;i<N;i++){
    var item=data[i], cx=startX+i*(MID_R*2+120), frG=sf+36+i*10;
    var pct=Math.min(Math.max(item.pct||0,0),100);
    var clr=segColors[i%segColors.length];
    // Background ring
    var bg=comp.layers.addShape();bg.name='EB_PgBg'+i;bg.position.setValue([cx,CY]);
    var bgc=bg.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var bge=bgc.addProperty('ADBE Vector Shape - Ellipse');
    try{bge.property('ADBE Vector Ellipse Size').setValue([MID_R*2,MID_R*2]);}catch(e){}
    var bgs=bgc.addProperty('ADBE Vector Graphic - Stroke');
    try{bgs.property('ADBE Vector Stroke Color').setValue([0.92,0.92,0.92,1]);}catch(e){}
    try{bgs.property('ADBE Vector Stroke Width').setValue(RING_W);}catch(e){}
    if(params.animateIn){try{ebAnimateFadeUp(bg,frG-4,fps,12);}catch(e){}}
    // Colored arc
    var arc=comp.layers.addShape();arc.name='EB_PgArc'+i;arc.position.setValue([cx,CY]);
    var ac=arc.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var ae=ac.addProperty('ADBE Vector Shape - Ellipse');
    try{ae.property('ADBE Vector Ellipse Size').setValue([MID_R*2,MID_R*2]);}catch(e){}
    var as2=ac.addProperty('ADBE Vector Graphic - Stroke');
    try{as2.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{as2.property('ADBE Vector Stroke Width').setValue(RING_W);}catch(e){}
    try{as2.property('ADBE Vector Stroke Line Cap').setValue(2);}catch(e){}
    var atr=ac.addProperty('ADBE Vector Filter - Trim');
    try{atr.property('ADBE Vector Trim Start').setValue(0);}catch(e){}
    try{atr.property('ADBE Vector Trim Offset').setValue(-90);}catch(e){}
    var atE=atr.property('ADBE Vector Trim End');
    if(params.animateIn){
      try{atE.setValueAtTime(frG/fps,0);atE.setValueAtTime((frG+Math.round(pct*0.5+10))/fps,pct);}catch(e){}
      try{setEase(atE,1,66,33);setEase(atE,2,33,66);}catch(e){}
      try{arc.inPoint=frG/fps;}catch(e){}
    } else {try{atE.setValue(pct);}catch(e){}}
    // Center pct text — counter via Source Text expression
    var _cnt0=frG/fps, _cnt1=(frG+Math.round(pct*0.5+10))/fps;
    var pctFSz=N===1?88:52;
    var pTx=ebText(comp,pct+'%',cx,CY+Math.round(pctFSz*0.3),pctFSz,'bold',[0,0,0],'center');
    pTx.name='EB_PgPct'+i;
    ebTextAnimatorFadeUp(pTx,frG,fps,10);
    if(params.animateIn){
      try{
        pTx.property('Source Text').expression=
          'Math.round(linear(time,'+_cnt0+','+_cnt1+',0,'+pct+'))+"%"';
      }catch(e){}
    }
    // Label below
    var lTx=ebText(comp,item.label,cx,CY+MID_R+44,N===1?30:24,'regular',[0.5,0.5,0.5],'center');
    lTx.name='EB_PgLbl'+i;ebTextAnimatorFadeUp(lTx,frG,fps,8);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// SCATTER PLOT  (chart-scatter)
// =============================================================
function createScatterPlotBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX0=180,CX1=1760,CY0=300,CY1=880,CW=1580,CH=580;
  var CC2=[[0.463,0.725,0],[0.357,0.553,0.851],[0.608,0.349,0.714],[0.980,0.761,0]];
  var axC2=[0.78,0.78,0.78,1], gC2=[0.92,0.92,0.92,1];
  var DOT=String.fromCharCode(9679);
  function _sl4(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    return l;
  }
  var defSer2=[{label:'Data Points',data:[
    {x:15,y:25},{x:28,y:60},{x:42,y:35},{x:55,y:72},
    {x:63,y:45},{x:71,y:88},{x:84,y:55},{x:92,y:70}
  ]}];
  var series2=(params.series&&params.series.length)?params.series.slice(0,3):defSer2;
  var xMax2=params.xMax||100, yMax3=params.yMax||100;
  // Axes
  var ya4=_sl4([[CX0,CY0],[CX0,CY1]],axC2,2,'EB_ScYAx');ebAnimateFadeUp(ya4,sf,fps,8);
  var xa4=_sl4([[CX0,CY1],[CX1,CY1]],axC2,2,'EB_ScXAx');ebAnimateFadeUp(xa4,sf,fps,8);
  // Grid
  for(var gi5=0;gi5<=5;gi5++){
    var gv5=gi5*20;
    var gY5=CY1-Math.round((gv5/yMax3)*CH);
    var gX5=CX0+Math.round((gv5/xMax2)*CW);
    if(gi5>0){
      var gh=_sl4([[CX0,gY5],[CX1,gY5]],gC2,1,'EB_ScGH'+gi5);ebAnimateFadeUp(gh,sf,fps,8);
      var gv6=_sl4([[gX5,CY0],[gX5,CY1]],gC2,1,'EB_ScGV'+gi5);ebAnimateFadeUp(gv6,sf,fps,8);
    }
    var ylS=ebText(comp,''+Math.round(gv5*yMax3/100),CX0-14,gY5+7,18,'regular',[0.6,0.6,0.6],'right');
    ylS.name='EB_ScYL'+gi5;ebTextAnimatorFadeUp(ylS,sf,fps,8);
    var xlS=ebText(comp,''+Math.round(gv5*xMax2/100),gX5,CY1+32,18,'regular',[0.6,0.6,0.6],'center');
    xlS.name='EB_ScXL'+gi5;ebTextAnimatorFadeUp(xlS,sf,fps,8);
  }
  // Axis labels
  if(params.xLabel){var xlA=ebText(comp,params.xLabel,960,CY1+70,24,'regular',[0.4,0.4,0.4],'center');xlA.name='EB_ScXA';ebTextAnimatorFadeUp(xlA,sf+36,fps,8);}
  if(params.yLabel){var ylA=ebText(comp,params.yLabel,CX0-90,(CY0+CY1)/2,22,'regular',[0.4,0.4,0.4],'right');ylA.name='EB_ScYA';ebTextAnimatorFadeUp(ylA,sf+36,fps,8);}
  // Data points
  for(var si4=0;si4<series2.length;si4++){
    var ser4=series2[si4], c4=CC2[si4%CC2.length], pts=ser4.data||[];
    for(var pi=0;pi<pts.length;pi++){
      var px=CX0+Math.round((Math.min(pts[pi].x,xMax2)/xMax2)*CW);
      var py=CY1-Math.round((Math.min(pts[pi].y,yMax3)/yMax3)*CH);
      var ptFr=sf+36+si4*8+pi*3;
      var ptL=ebText(comp,DOT,px,py+8,20,'regular',[c4[0],c4[1],c4[2]],'center');
      ptL.name='EB_ScPt'+si4+'_'+pi;ebTextAnimatorFadeUp(ptL,ptFr,fps,8);
    }
    // Legend
    var lDot=ebText(comp,DOT,1604,316+si4*44,18,'regular',[c4[0],c4[1],c4[2]],'center');
    lDot.name='EB_ScLD'+si4;ebTextAnimatorFadeUp(lDot,sf+40,fps,6);
    var lTxt4=ebText(comp,ser4.label,1616,316+si4*44,22,'regular',[0.3,0.3,0.3],'left');
    lTxt4.name='EB_ScLT'+si4;ebTextAnimatorFadeUp(lTxt4,sf+42,fps,6);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// PIE CHART  (chart-pie)
// =============================================================
function createPieChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX=420, CY=590, MID_R=200, RING_W=200;
  var segColors=[
    ebColor('76B900'),ebColor('0071C5'),ebColor('5D1682'),
    ebColor('FAC200'),ebColor('890C58'),ebColor('00A8C8'),ebColor('FF7043'),ebColor('7CB342')
  ];
  var defPie=[
    {label:'GPU Compute',pct:45},{label:'Memory BW',pct:30},
    {label:'Network I/O',pct:15},{label:'Storage',pct:10}
  ];
  var rawSegs2=(params.chartData&&params.chartData.length>=2)?params.chartData.slice(0,8):defPie;
  var NUM_SEGS2=rawSegs2.length;
  var segTotal2=0;
  for(var k=0;k<rawSegs2.length;k++)segTotal2+=rawSegs2[k].pct;
  if(segTotal2<=0)segTotal2=100;
  var segs2=[]; var runNorm2=0;
  for(var k2=0;k2<rawSegs2.length;k2++){
    var nPct2=Math.round(rawSegs2[k2].pct/segTotal2*100);
    runNorm2+=nPct2;
    if(k2===rawSegs2.length-1)nPct2+=(100-runNorm2);
    segs2.push({label:rawSegs2[k2].label,pct:Math.max(0,nPct2)});
  }
  // Background ring (big stroke = filled circle)
  var bgR=comp.layers.addShape();bgR.name='EB_PieTrack';bgR.position.setValue([CX,CY]);
  var bgRc=bgR.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bgRe=bgRc.addProperty('ADBE Vector Shape - Ellipse');
  try{bgRe.property('ADBE Vector Ellipse Size').setValue([MID_R*2,MID_R*2]);}catch(e){}
  var bgRs=bgRc.addProperty('ADBE Vector Graphic - Stroke');
  try{bgRs.property('ADBE Vector Stroke Color').setValue([0.92,0.92,0.92,1]);}catch(e){}
  try{bgRs.property('ADBE Vector Stroke Width').setValue(RING_W);}catch(e){}
  var SEG_START2=sf+36, SEG_SPEED2=0.70, MIN_DUR2=6;
  var segFrames2=[]; var segCumF2=SEG_START2;
  for(var k3=0;k3<segs2.length;k3++){
    var sDur=Math.max(MIN_DUR2,Math.round(segs2[k3].pct*SEG_SPEED2));
    segFrames2.push({start:segCumF2,dur:sDur}); segCumF2+=sDur;
  }
  if(params.animateIn){try{ebAnimateFadeUp(bgR,SEG_START2-8,fps,15);}catch(e){}}
  // Segments
  var cumPct2=0;
  for(var i2=0;i2<segs2.length;i2++){
    var seg2=segs2[i2], sf2=segFrames2[i2];
    var sL=comp.layers.addShape();sL.name='EB_PieSeg'+(i2+1);sL.position.setValue([CX,CY]);
    var sC=sL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var sE=sC.addProperty('ADBE Vector Shape - Ellipse');
    try{sE.property('ADBE Vector Ellipse Size').setValue([MID_R*2,MID_R*2]);}catch(e){}
    var sSt=sC.addProperty('ADBE Vector Graphic - Stroke');
    try{sSt.property('ADBE Vector Stroke Color').setValue(segColors[i2%segColors.length]);}catch(e){}
    try{sSt.property('ADBE Vector Stroke Width').setValue(RING_W);}catch(e){}
    try{sSt.property('ADBE Vector Stroke Line Cap').setValue(1);}catch(e){}
    var sTr=sC.addProperty('ADBE Vector Filter - Trim');
    try{sTr.property('ADBE Vector Trim Start').setValue(cumPct2);}catch(e){}
    try{sTr.property('ADBE Vector Trim Offset').setValue(-90);}catch(e){}
    var sTrE=sTr.property('ADBE Vector Trim End');
    if(params.animateIn){
      try{sTrE.setValueAtTime(sf2.start/fps,cumPct2);sTrE.setValueAtTime((sf2.start+sf2.dur)/fps,cumPct2+seg2.pct);}catch(e){}
      try{setEase(sTrE,sTrE.nearestKeyIndex(sf2.start/fps),66,66);setEase(sTrE,sTrE.nearestKeyIndex((sf2.start+sf2.dur)/fps),66,66);}catch(e){}
    } else {try{sTrE.setValue(cumPct2+seg2.pct);}catch(e){}}
    cumPct2=Math.round((cumPct2+seg2.pct)*1000)/1000;
  }
  // Legend
  var LEG_X2=720,LEG_GAP2=(NUM_SEGS2<=5?88:NUM_SEGS2<=7?80:65),LEG_FSZ2=(NUM_SEGS2<=5?28:NUM_SEGS2<=7?24:22);
  var SW2=NUM_SEGS2<=6?22:18, LEG_Y02=Math.round(CY-(NUM_SEGS2-1)*LEG_GAP2/2);
  for(var j2=0;j2<segs2.length;j2++){
    var s3=segs2[j2], lY4=LEG_Y02+j2*LEG_GAP2, lFr2=segFrames2[j2];
    var cIdx2=j2%segColors.length, cRGB2=[segColors[cIdx2][0],segColors[cIdx2][1],segColors[cIdx2][2]];
    var sw2L=comp.layers.addShape();sw2L.name='EB_PieSw'+(j2+1);sw2L.position.setValue([LEG_X2+SW2/2,lY4]);
    var sw2C=sw2L.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var sw2R=sw2C.addProperty('ADBE Vector Shape - Rect');
    try{sw2R.property('ADBE Vector Rect Size').setValue([SW2,SW2]);}catch(e){}
    var sw2F=sw2C.addProperty('ADBE Vector Graphic - Fill');
    try{sw2F.property('ADBE Vector Fill Color').setValue(segColors[cIdx2]);}catch(e){}
    if(params.animateIn){try{ebAnimateFadeUp(sw2L,lFr2.start,fps,10);}catch(e){}}
    var llY2=lY4+Math.round(LEG_FSZ2*0.35);
    var lLbl2Txt=String(s3.label||'');if(lLbl2Txt.length>22)lLbl2Txt=lLbl2Txt.substring(0,20)+'\u2026';
    var lLbl2=ebText(comp,lLbl2Txt,LEG_X2+SW2+16,llY2,LEG_FSZ2,'regular',[0,0,0],'left');
    lLbl2.name='EB_PieLbl'+(j2+1);try{ebTextAnimatorFadeUp(lLbl2,lFr2.start+2,fps,10);}catch(e){}
    var pLbl2=ebText(comp,s3.pct+'%',1775,llY2,LEG_FSZ2,'bold',cRGB2,'right');
    pLbl2.name='EB_PiePct'+(j2+1);try{ebTextAnimatorFadeUp(pLbl2,lFr2.start+lFr2.dur,fps,10);}catch(e){}
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// WATERFALL CHART  (chart-waterfall)
// =============================================================
function createWaterfallChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX0=160,CX1=1760,CY1=880,CY0=300,CH=580;
  var posClr=[0.463,0.725,0], negClr=[0.906,0.298,0.235], totClr=[0.4,0.4,0.4];
  var axC3=[0.78,0.78,0.78,1], gC3=[0.92,0.92,0.92,1];
  function _sl5(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    return l;
  }
  var defWF=[
    {label:'Start',value:50},{label:'Q1',value:20},{label:'Q2',value:15},
    {label:'Q3',value:-10},{label:'Q4',value:25},{label:'Total',value:100}
  ];
  var data2=(params.chartData&&params.chartData.length)?params.chartData.slice(0,8):defWF;
  var N2=data2.length;
  // Find value range
  var running=0, maxVal=-Infinity, minVal=Infinity;
  var cumVals=[0];
  for(var i3=0;i3<N2;i3++){
    var v=data2[i3].value||0;
    if(i3===0||i3===N2-1){running=v;}else{running+=v;}
    cumVals.push(running);
    if(running>maxVal)maxVal=running;
    if(running<minVal)minVal=running;
    if(v<0&&running-v>maxVal)maxVal=running-v;
  }
  maxVal=Math.max(maxVal,0)*1.1; minVal=Math.min(minVal,0);
  var valRange=maxVal-minVal||1;
  function toY(v){return CY1-Math.round(((v-minVal)/valRange)*CH);}
  var zeroY=toY(0);
  // X axis at zero
  var xa5=_sl5([[CX0,zeroY],[CX1,zeroY]],axC3,2,'EB_WfXAx');ebAnimateFadeUp(xa5,sf,fps,8);
  var ya5=_sl5([[CX0,CY0],[CX0,CY1]],axC3,1,'EB_WfYAx');ebAnimateFadeUp(ya5,sf,fps,8);
  // Gridlines
  for(var gi6=0;gi6<=4;gi6++){
    var gY6=CY0+Math.round(gi6*(CH/4));
    var gl6=_sl5([[CX0,gY6],[CX1,gY6]],gC3,1,'EB_WfGrd'+gi6);ebAnimateFadeUp(gl6,sf,fps,8);
  }
  // Bars
  var bw2=Math.min(120,Math.round((CX1-CX0-40)/N2*0.55));
  var step2=Math.round((CX1-CX0)/N2);
  var firstBX=CX0+Math.round(step2/2);
  var prevTopY=toY(0);
  for(var i4=0;i4<N2;i4++){
    var item2=data2[i4], v2=item2.value||0;
    var frW=sf+36+i4*8;
    var barX2=firstBX+i4*step2;
    var isTotal=(i4===0||i4===N2-1);
    var barClr=isTotal?totClr:(v2>=0?posClr:negClr);
    var baseVal=isTotal?0:cumVals[i4];
    var topVal=isTotal?v2:(baseVal+v2);
    var barTopY=toY(Math.max(baseVal,topVal));
    var barBotY=toY(Math.min(baseVal,topVal));
    var barH2=Math.max(barBotY-barTopY,2);
    var bar2=comp.layers.addSolid([barClr[0],barClr[1],barClr[2]],'EB_WfBar'+i4,bw2,barH2,1);
    try{bar2.anchorPoint.setValue([bw2/2,0]);}catch(e){}
    bar2.position.setValue([barX2,barTopY]);
    ebAnimateFadeUp(bar2,frW,fps,10);
    // Connector line to next bar
    if(!isTotal&&i4<N2-1&&!data2[i4+1]){} // skip last
    if(i4<N2-1){
      var nextBaseY=isTotal?toY(v2):toY(topVal);
      var conn=_sl5([[barX2+bw2/2,nextBaseY],[barX2+step2-bw2/2,nextBaseY]],[0.7,0.7,0.7,1],1.5,'EB_WfCon'+i4);
      ebAnimateFadeUp(conn,frW+6,fps,6);
    }
    // Labels
    var lblY5=v2>=0?(barTopY-22):(barBotY+32);
    var valTx=ebText(comp,(v2>=0?'+':'')+Math.round(v2),barX2,lblY5,22,'bold',barClr,'center');
    valTx.name='EB_WfVal'+i4;ebTextAnimatorFadeUp(valTx,frW+8,fps,8);
    var catTx=ebText(comp,item2.label,barX2,CY1+36,22,'regular',[0.5,0.5,0.5],'center');
    catTx.name='EB_WfCat'+i4;ebTextAnimatorFadeUp(catTx,frW,fps,8);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// RADAR / SPIDER CHART  (chart-radar)
// =============================================================
function createRadarChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CCX=960, CCY=570, R_MAX=270;
  var CC3=[[0.463,0.725,0],[0.357,0.553,0.851],[0.608,0.349,0.714]];
  var defAxes=['Performance','Efficiency','Reliability','Scalability','Security','Cost'];
  var axes=(params.axes&&params.axes.length>=3)?params.axes.slice(0,8):defAxes;
  var NA=axes.length;
  var defSeries2=[{label:'System A',values:[85,70,92,60,78,65]}];
  var series3=(params.series&&params.series.length)?params.series.slice(0,2):defSeries2;
  function _axPt(axIdx,r){
    var ang=(-Math.PI/2)+(axIdx/NA)*(2*Math.PI);
    return [Math.round(CCX+Math.cos(ang)*r), Math.round(CCY+Math.sin(ang)*r)];
  }
  function _closedShp(vts){
    var s=new Shape();s.closed=true;s.vertices=vts;
    s.inTangents=[];s.outTangents=[];
    for(var _ii=0;_ii<vts.length;_ii++){s.inTangents.push([0,0]);s.outTangents.push([0,0]);}
    return s;
  }
  function _shpClosed(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(_closedShp(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    try{gs.property('ADBE Vector Stroke Line Join').setValue(2);}catch(e){}
    return l;
  }
  // Background grid (concentric polygons)
  var gridLevels=[0.25,0.5,0.75,1.0];
  for(var gi7=0;gi7<gridLevels.length;gi7++){
    var gVts=[];for(var ai=0;ai<NA;ai++)gVts.push(_axPt(ai,R_MAX*gridLevels[gi7]));
    var gL=_shpClosed(gVts,[0.88,0.88,0.88,1],1,'EB_RdGrid'+gi7);
    ebAnimateFadeUp(gL,sf,fps,8);
  }
  // Spokes + labels
  for(var ai2=0;ai2<NA;ai2++){
    var outerPt=_axPt(ai2,R_MAX);
    var sl=comp.layers.addShape();sl.name='EB_RdSpk'+ai2;sl.position.setValue([0,0]);
    var sgc=sl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var sp=sgc.addProperty('ADBE Vector Shape - Group');
    try{sp.property('ADBE Vector Shape').setValue(ebOpenPath([[CCX,CCY],outerPt]));}catch(e){}
    var ss=sgc.addProperty('ADBE Vector Graphic - Stroke');
    try{ss.property('ADBE Vector Stroke Color').setValue([0.85,0.85,0.85,1]);}catch(e){}
    try{ss.property('ADBE Vector Stroke Width').setValue(1);}catch(e){}
    ebAnimateFadeUp(sl,sf+5,fps,8);
    // Axis label
    var lPt=_axPt(ai2,R_MAX+42);
    var lbl=ebText(comp,axes[ai2],lPt[0],lPt[1]+8,22,'regular',[0.35,0.35,0.35],'center');
    lbl.name='EB_RdLbl'+ai2;ebTextAnimatorFadeUp(lbl,sf+10,fps,8);
  }
  // Data polygons
  for(var si5=0;si5<series3.length;si5++){
    var ser5=series3[si5], c5=CC3[si5%CC3.length], cA5=[c5[0],c5[1],c5[2],1];
    var frR=sf+36+si5*16;
    var dVts=[];
    for(var ai3=0;ai3<NA;ai3++){
      var val5=Math.min(Math.max((ser5.values[ai3%ser5.values.length])||0,0),100);
      dVts.push(_axPt(ai3,R_MAX*(val5/100)));
    }
    var dL=_shpClosed(dVts,cA5,2.5,'EB_RdPoly'+si5);
    var dTr=dL.property('Contents').property(1).property('Contents').addProperty('ADBE Vector Filter - Trim');
    var dTrE=dTr.property('ADBE Vector Trim End');
    if(params.animateIn){try{ebAnimateTrimDraw(dTrE,frR,fps);}catch(e){}try{dL.inPoint=frR/fps;}catch(e){}}
    else{try{dTrE.setValue(100);}catch(e){}}
    // Dots at each vertex
    var DOT2=String.fromCharCode(9679);
    for(var ai4=0;ai4<NA;ai4++){
      var dtL=ebText(comp,DOT2,dVts[ai4][0],dVts[ai4][1]+8,14,'regular',[c5[0],c5[1],c5[2]],'center');
      dtL.name='EB_RdDt'+si5+'_'+ai4;ebTextAnimatorFadeUp(dtL,frR+20,fps,6);
    }
    // Legend
    var lsw5=comp.layers.addSolid([c5[0],c5[1],c5[2]],'EB_RdLS'+si5,28,5,1);
    try{lsw5.anchorPoint.setValue([14,2.5]);}catch(e){}lsw5.position.setValue([1594,310+si5*44]);
    ebAnimateFadeUp(lsw5,frR,fps,6);
    var ltx5=ebText(comp,ser5.label,1616,314+si5*44,22,'regular',[0.3,0.3,0.3],'left');
    ltx5.name='EB_RdLT'+si5;ebTextAnimatorFadeUp(ltx5,frR+2,fps,6);
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// BUBBLE CHART  (chart-bubble)
// =============================================================
function createBubbleChartBlock(comp, params) {
  var fps=comp.frameRate, sf=1;
  var CX0=180,CX1=1760,CY0=300,CY1=880,CW=1580,CH=580;
  var CC4=[[0.463,0.725,0],[0.357,0.553,0.851],[0.608,0.349,0.714],
           [0.980,0.761,0],[0.906,0.298,0.235],[0.102,0.737,0.612]];
  var axC4=[0.78,0.78,0.78,1], gC4=[0.92,0.92,0.92,1];
  var DOT3=String.fromCharCode(9679);
  function _sl6(vts,clr,w,nm){
    var l=comp.layers.addShape();l.name=nm;l.position.setValue([0,0]);
    var gc=l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var gp=gc.addProperty('ADBE Vector Shape - Group');
    try{gp.property('ADBE Vector Shape').setValue(ebOpenPath(vts));}catch(e){}
    var gs=gc.addProperty('ADBE Vector Graphic - Stroke');
    try{gs.property('ADBE Vector Stroke Color').setValue(clr);}catch(e){}
    try{gs.property('ADBE Vector Stroke Width').setValue(w);}catch(e){}
    return l;
  }
  var defBub=[
    {label:'H100',x:95,y:98,size:100},{label:'A100',x:85,y:92,size:90},
    {label:'L40S',x:70,y:75,size:60},{label:'A30',x:45,y:55,size:40},
    {label:'T4',x:30,y:35,size:25},{label:'A10',x:55,y:62,size:45}
  ];
  var data3=(params.chartData&&params.chartData.length)?params.chartData.slice(0,12):defBub;
  var xMax3=params.xMax||100, yMax4=params.yMax||100;
  // Axes + grid
  var ya6=_sl6([[CX0,CY0],[CX0,CY1]],axC4,2,'EB_BbYAx');ebAnimateFadeUp(ya6,sf,fps,8);
  var xa6=_sl6([[CX0,CY1],[CX1,CY1]],axC4,2,'EB_BbXAx');ebAnimateFadeUp(xa6,sf,fps,8);
  for(var gi8=0;gi8<=5;gi8++){
    var gv8=gi8*20;
    var gY8=CY1-Math.round((gv8/yMax4)*CH);
    var gX8=CX0+Math.round((gv8/xMax3)*CW);
    if(gi8>0){
      var gh2=_sl6([[CX0,gY8],[CX1,gY8]],gC4,1,'EB_BbGH'+gi8);ebAnimateFadeUp(gh2,sf,fps,8);
      var gv9=_sl6([[gX8,CY0],[gX8,CY1]],gC4,1,'EB_BbGV'+gi8);ebAnimateFadeUp(gv9,sf,fps,8);
    }
    var ylB=ebText(comp,''+Math.round(gv8*yMax4/100),CX0-14,gY8+7,18,'regular',[0.6,0.6,0.6],'right');
    ylB.name='EB_BbYL'+gi8;ebTextAnimatorFadeUp(ylB,sf,fps,8);
    var xlB=ebText(comp,''+Math.round(gv8*xMax3/100),gX8,CY1+32,18,'regular',[0.6,0.6,0.6],'center');
    xlB.name='EB_BbXL'+gi8;ebTextAnimatorFadeUp(xlB,sf,fps,8);
  }
  if(params.xLabel){var xlAb=ebText(comp,params.xLabel,960,CY1+70,24,'regular',[0.4,0.4,0.4],'center');xlAb.name='EB_BbXA';ebTextAnimatorFadeUp(xlAb,sf+36,fps,8);}
  if(params.yLabel){var ylAb=ebText(comp,params.yLabel,CX0-90,(CY0+CY1)/2,22,'regular',[0.4,0.4,0.4],'right');ylAb.name='EB_BbYA';ebTextAnimatorFadeUp(ylAb,sf+36,fps,8);}
  // Bubbles
  for(var bi=0;bi<data3.length;bi++){
    var item3=data3[bi], c6=CC4[bi%CC4.length];
    var px2=CX0+Math.round((Math.min(item3.x,xMax3)/xMax3)*CW);
    var py2=CY1-Math.round((Math.min(item3.y,yMax4)/yMax4)*CH);
    var bFSz=Math.round(20+(item3.size||50)/100*80);
    var bFr=sf+36+bi*5;
    var bL=ebText(comp,DOT3,px2,py2+Math.round(bFSz*0.38),bFSz,'regular',[c6[0],c6[1],c6[2]],'center');
    bL.name='EB_BbDot'+bi;
    try{bL.opacity.setValue(70);}catch(e){}
    ebTextAnimatorFadeUp(bL,bFr,fps,10);
    if(item3.label){
      var bLbl=ebText(comp,item3.label,px2,py2-Math.round(bFSz*0.6)-8,18,'regular',[0.3,0.3,0.3],'center');
      bLbl.name='EB_BbLbl'+bi;ebTextAnimatorFadeUp(bLbl,bFr+4,fps,8);
    }
  }
  ebCreateHeader(comp,params,sf);
}

// =============================================================
// RACK BLOCK -- Animated server rack with call-out labels
// Rack frame + green strips appear, then rack units build up
// top-to-bottom, then callout dots + leader lines + labels
// animate in one by one.
// =============================================================
function createRackBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac     = [accent[0], accent[1], accent[2]];

  // Rack geometry
  var RCX    = 960;
  var RCY    = 600;
  var RW     = 400;
  var RH     = 670;
  var RL     = RCX - RW / 2;
  var RR     = RCX + RW / 2;
  var RT     = RCY - RH / 2;
  var STRIP  = 14;
  var UNIT_W = RW - (STRIP + 8) * 2;

  // All fills use addSolid — shape layer rect fills silently fail in AE 2024+

  // 1. Rack frame background — addSolid
  var frameL = comp.layers.addSolid([0.10, 0.10, 0.10], 'EB_RackFrame', RW, RH, 1);
  frameL.position.setValue([RCX, RCY]);
  if (params.animateIn) { try { ebAnimateFadeUp(frameL, sf + 1, fps, 20); } catch(e) {} }

  // 1b. Frame border — stroke-only shape layer (strokes always work)
  var fBorder = comp.layers.addShape();
  fBorder.name = 'EB_RackBorder';
  fBorder.position.setValue([RCX, RCY]);
  var fbGC = fBorder.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var fbRct = fbGC.addProperty('ADBE Vector Shape - Rect');
  try { fbRct.property('ADBE Vector Rect Size').setValue([RW, RH]); } catch(e) {}
  var fbStr = fbGC.addProperty('ADBE Vector Graphic - Stroke');
  try { fbStr.property('ADBE Vector Stroke Color').setValue([0.28, 0.28, 0.28, 1]); } catch(e) {}
  try { fbStr.property('ADBE Vector Stroke Width').setValue(5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(fBorder, sf + 1, fps, 20); } catch(e) {} }

  // 2. Accent strips — addSolid
  var stripXs = [RL + STRIP/2 + 4, RR - STRIP/2 - 4];
  for (var si = 0; si < 2; si++) {
    var stripL = comp.layers.addSolid(ac, 'EB_Strip_' + (si + 1), STRIP, RH - 14, 1);
    stripL.position.setValue([stripXs[si], RCY]);
    if (params.animateIn) { try { ebAnimateFadeUp(stripL, sf + 3, fps, 12); } catch(e) {} }
  }

  // 3. Rack units — addSolid, varying grey fills
  var unitDefs = [
    { h: 52, rgb: [0.22, 0.22, 0.22] },  // ToR Switch
    { h: 52, rgb: [0.18, 0.18, 0.18] },  // IB Spine
    { h: 76, rgb: [0.30, 0.30, 0.30] },  // Compute A
    { h: 76, rgb: [0.30, 0.30, 0.30] },  // Compute B
    { h: 60, rgb: [0.20, 0.20, 0.20] },  // Storage
    { h: 52, rgb: [0.14, 0.14, 0.14] }   // PDU
  ];
  var totalUH = 0;
  for (var ui = 0; ui < unitDefs.length; ui++) totalUH += unitDefs[ui].h;
  var uGap = Math.round((RH - 18 - totalUH) / (unitDefs.length + 1));
  var curY = RT + 9 + uGap;
  var unitCYs = [];
  for (var u = 0; u < unitDefs.length; u++) {
    var ud  = unitDefs[u];
    var uCY = Math.round(curY + ud.h / 2);
    unitCYs.push(uCY);
    var unitL = comp.layers.addSolid(ud.rgb, 'EB_Unit_' + (u + 1), UNIT_W, ud.h, 1);
    unitL.position.setValue([RCX, uCY]);
    if (params.animateIn) { try { ebAnimateFadeUp(unitL, sf + 5 + u * 4, fps, 12); } catch(e) {} }
    curY += ud.h + uGap;
  }

  // 4. Callout dots + leader lines + labels
  var coDefs = [
    { unit: 0, side: 'left',  text: 'Top of Rack Switch' },
    { unit: 1, side: 'right', text: 'InfiniBand Spine Switches' },
    { unit: 2, side: 'left',  text: 'DGX A100 Compute Nodes' },
    { unit: 4, side: 'right', text: 'NVMe Storage Array' }
  ];
  var coBase  = sf + 5 + unitDefs.length * 4;
  var LLABX   = 640;
  var RLABX   = 1280;
  var DOT_R   = 8;
  var LAB_FSZ = 26;

  for (var c = 0; c < coDefs.length; c++) {
    var cd    = coDefs[c];
    var uY    = unitCYs[cd.unit];
    var dotX  = (cd.side === 'left') ? RL - DOT_R : RR + DOT_R;
    var lineX = (cd.side === 'left') ? LLABX + 12 : RLABX - 12;
    var labX  = (cd.side === 'left') ? LLABX : RLABX;
    var align = (cd.side === 'left') ? 'right' : 'left';
    var cName = 'EB_Co_' + (c + 1);
    var cFr   = coBase + c * 7;

    var coD = comp.layers.addSolid(ac, cName + '_Dot', DOT_R * 2, DOT_R * 2, 1);
    coD.position.setValue([dotX, uY]);
    if (params.animateIn) { try { ebAnimateFadeUp(coD, cFr, fps, 8); } catch(e) {} }

    var coLine = comp.layers.addShape();
    coLine.name = cName + '_Line';
    coLine.position.setValue([0, 0]);
    var lGC  = coLine.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var lPth = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[dotX, uY], [lineX, uY]])); } catch(e) {}
    var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lStr.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    try {
      var lDsh = lStr.property('ADBE Vector Stroke Dashes');
      lDsh.addProperty('ADBE Vector Stroke Dash 1');
      lDsh.addProperty('ADBE Vector Stroke Gap 1');
      lDsh.property('ADBE Vector Stroke Dash 1').setValue(10);
      lDsh.property('ADBE Vector Stroke Gap 1').setValue(7);
    } catch(e) {}
    var lTrm    = lGC.addProperty('ADBE Vector Filter - Trim');
    var lTrmEnd = lTrm.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { coLine.inPoint = (cFr + 1) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(lTrmEnd, cFr + 1, fps); } catch(e) {}
    } else {
      try { lTrmEnd.setValue(100); } catch(e) {}
    }

    var labY  = uY + Math.round(LAB_FSZ * 0.35);
    var coLbl = ebText(comp, cd.text, labX, labY, LAB_FSZ, 'regular', [0, 0, 0], align);
    coLbl.name = cName + '_Label';
    try { ebTextAnimatorFadeUp(coLbl, cFr + 3, fps, 10); } catch(e) {}
  }

  // 5. Rack feet — addSolid
  var footY  = RCY + RH / 2 + 10;
  var footXs = [RL + 55, RR - 55];
  for (var fi = 0; fi < 2; fi++) {
    var footL = comp.layers.addSolid([0.20, 0.20, 0.20], 'EB_Foot_' + (fi + 1), 70, 18, 1);
    footL.position.setValue([footXs[fi], footY]);
    if (params.animateIn) { try { ebAnimateFadeUp(footL, sf + 2, fps, 10); } catch(e) {} }
  }

  for (var di = 1; di <= comp.numLayers; di++) {
    try { comp.layer(di).selected = false; } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// COMP TIMELINE / ROADMAP
// Horizontal accent line, N milestones (3/4/5)
// Date label above line, dot on line, title + desc below
// =============================================================
function createCompTimelineBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac     = [accent[0], accent[1], accent[2]];
  var N      = params.count || 4;

  var LINE_Y   = 560;
  var LEFT_X   = 260;
  var RIGHT_X  = 1660;
  var SPAN     = RIGHT_X - LEFT_X;
  var DOT_SZ   = 22;
  var DATE_FSZ = 26;
  var TTL_FSZ  = 34;
  var DSC_FSZ  = 26;

  // Item X positions — evenly spaced
  var itemXs = [];
  for (var i = 0; i < N; i++) {
    itemXs.push(N === 1 ? 960 : Math.round(LEFT_X + i * SPAN / (N - 1)));
  }

  // Default content per count
  var DEF = {
    3: [
      { date: 'Phase 1', title: 'Foundation',   desc: 'Architecture & planning' },
      { date: 'Phase 2', title: 'Development',  desc: 'Build & integrate' },
      { date: 'Phase 3', title: 'Launch',        desc: 'Deploy & scale' }
    ],
    4: [
      { date: 'Q1 2025', title: 'Planning',      desc: 'Requirements & design' },
      { date: 'Q2 2025', title: 'Development',   desc: 'Build core infrastructure' },
      { date: 'Q3 2025', title: 'Validation',    desc: 'Testing & integration' },
      { date: 'Q4 2025', title: 'Launch',         desc: 'Deploy to production' }
    ],
    5: [
      { date: 'Q1',      title: 'Research',       desc: 'Discovery & requirements' },
      { date: 'Q2',      title: 'Architecture',   desc: 'System design' },
      { date: 'Q3',      title: 'Build',           desc: 'Core development' },
      { date: 'Q4',      title: 'Validate',        desc: 'Testing & QA' },
      { date: 'Q5',      title: 'Deploy',          desc: 'Launch & monitor' }
    ]
  };
  var items = DEF[N] || DEF[4];

  // 1. Horizontal timeline line — stroke, animated trim
  var lineL = comp.layers.addShape();
  lineL.name = 'EB_TL_Line';
  lineL.position.setValue([0, 0]);
  var lGC  = lineL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var lPth = lGC.addProperty('ADBE Vector Shape - Group');
  try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[LEFT_X, LINE_Y], [RIGHT_X, LINE_Y]])); } catch(e) {}
  var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
  try { lStr.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
  if (params.animateIn) {
    try {
      var lTrm    = lGC.addProperty('ADBE Vector Filter - Trim');
      var lTrmEnd = lTrm.property('ADBE Vector Trim End');
      lineL.inPoint = sf / fps;
      ebAnimateTrimDraw(lTrmEnd, sf, fps);
    } catch(e) {}
  }

  // 2. Per-milestone: tick, dot, date label, title, desc
  for (var m = 0; m < N; m++) {
    var mx   = itemXs[m];
    var item = items[m];
    var mFr  = sf + 10 + m * 5;

    // Tick mark (vertical stroke through dot)
    var tickL = comp.layers.addShape();
    tickL.name = 'EB_TL_Tick_' + (m + 1);
    tickL.position.setValue([0, 0]);
    var tkGC = tickL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tkP  = tkGC.addProperty('ADBE Vector Shape - Group');
    try { tkP.property('ADBE Vector Shape').setValue(ebOpenPath([[mx, LINE_Y - 36], [mx, LINE_Y + 36]])); } catch(e) {}
    var tkS  = tkGC.addProperty('ADBE Vector Graphic - Stroke');
    try { tkS.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
    try { tkS.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(tickL, mFr, fps, 8); } catch(e) {} }

    // Dot — addSolid
    var dotL = comp.layers.addSolid(ac, 'EB_TL_Dot_' + (m + 1), DOT_SZ, DOT_SZ, 1);
    dotL.position.setValue([mx, LINE_Y]);
    if (params.animateIn) { try { ebAnimateFadeUp(dotL, mFr + 1, fps, 6); } catch(e) {} }

    // Date label above
    var dateTx = ebText(comp, item.date, mx, LINE_Y - 62, DATE_FSZ, 'regular', ac, 'center');
    dateTx.name = 'EB_TL_Date_' + (m + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(dateTx, mFr, fps, 8); } catch(e) {} }

    // Title below
    var titTx = ebText(comp, item.title, mx, LINE_Y + 72, TTL_FSZ, 'bold', [0, 0, 0], 'center');
    titTx.name = 'EB_TL_Title_' + (m + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(titTx, mFr + 2, fps, 8); } catch(e) {} }

    // Description below title
    if (item.desc) {
      var dscTx = ebText(comp, item.desc, mx, LINE_Y + 118, DSC_FSZ, 'regular', [0.5, 0.5, 0.5], 'center');
      dscTx.name = 'EB_TL_Desc_' + (m + 1);
      if (params.animateIn) { try { ebTextAnimatorFadeUp(dscTx, mFr + 3, fps, 8); } catch(e) {} }
    }
  }

  for (var di = 1; di <= comp.numLayers; di++) {
    try { comp.layer(di).selected = false; } catch(e) {}
  }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// LOGO STRIP
// Row of N logo placeholder boxes (3–6), optional section label
// User replaces placeholder text/bg with actual logo PNGs in AE
// =============================================================
function createLogoStripBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac     = [accent[0], accent[1], accent[2]];
  var N      = params.count || 5;

  var MARGIN  = 80;
  var GAP     = 32;
  var BOX_H   = 160;
  var BOX_W   = Math.floor((1920 - 2 * MARGIN - (N - 1) * GAP) / N);
  var STRIP_Y = 600;   // center Y of logo boxes

  var defaultNames = ['PARTNER A', 'PARTNER B', 'PARTNER C', 'PARTNER D', 'PARTNER E', 'PARTNER F'];

  // Section label above boxes
  var labelTx = ebText(comp, 'ECOSYSTEM PARTNERS', 960, 440, 28, 'semibold', ac, 'center');
  labelTx.name = 'EB_LS_Label';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(labelTx, sf + 1, fps, 10); } catch(e) {} }

  // Accent rule below label
  var ruleL = comp.layers.addShape();
  ruleL.name = 'EB_LS_Rule';
  ruleL.position.setValue([0, 0]);
  var rGC  = ruleL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var rPth = rGC.addProperty('ADBE Vector Shape - Group');
  try { rPth.property('ADBE Vector Shape').setValue(ebOpenPath([[MARGIN, 464], [1920 - MARGIN, 464]])); } catch(e) {}
  var rStr = rGC.addProperty('ADBE Vector Graphic - Stroke');
  try { rStr.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
  try { rStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(ruleL, sf + 2, fps, 10); } catch(e) {} }

  // Logo boxes
  for (var i = 0; i < N; i++) {
    var bx = MARGIN + i * (BOX_W + GAP) + Math.round(BOX_W / 2);

    // Box fill — addSolid (dark card tone)
    var boxL = comp.layers.addSolid([0.14, 0.14, 0.14], 'EB_Logo_' + (i + 1), BOX_W, BOX_H, 1);
    boxL.position.setValue([bx, STRIP_Y]);
    if (params.animateIn) { try { ebAnimateFadeUp(boxL, sf + 4 + i * 3, fps, 14); } catch(e) {} }

    // Box border — stroke-only shape layer
    var bdrL = comp.layers.addShape();
    bdrL.name = 'EB_LogoBorder_' + (i + 1);
    bdrL.position.setValue([bx, STRIP_Y]);
    var bdGC  = bdrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var bdRct = bdGC.addProperty('ADBE Vector Shape - Rect');
    try { bdRct.property('ADBE Vector Rect Size').setValue([BOX_W, BOX_H]); } catch(e) {}
    var bdStr = bdGC.addProperty('ADBE Vector Graphic - Stroke');
    try { bdStr.property('ADBE Vector Stroke Color').setValue([0.30, 0.30, 0.30, 1]); } catch(e) {}
    try { bdStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(bdrL, sf + 4 + i * 3, fps, 14); } catch(e) {} }

    // Placeholder text (company name)
    var nmTx = ebText(comp, defaultNames[i] || ('PARTNER ' + (i + 1)), bx,
                      STRIP_Y + Math.round(28 * 0.35), 28, 'regular', [0.45, 0.45, 0.45], 'center');
    nmTx.name = 'EB_LogoName_' + (i + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(nmTx, sf + 5 + i * 3, fps, 10); } catch(e) {} }
  }

  for (var di = 1; di <= comp.numLayers; di++) {
    try { comp.layer(di).selected = false; } catch(e) {}
  }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// COMPARE TABLE
// Columns: FEATURE NAME | TRADITIONAL | NVIDIA SOLUTION
// N feature rows (4/5/6). Light/dark theme toggle.
// =============================================================
function createCompareBlock(comp, params) {
  var fps     = comp.frameRate;
  var sf      = 1;
  var accent  = ebColor(params.accentColor || '76B900');
  var ac      = [accent[0], accent[1], accent[2]];
  var N       = params.count || 5;
  var isLight = (params.compareTheme === 'light');

  // Theme colours
  var T = isLight ? {
    cardBg:   [0.97, 0.97, 0.97],
    tradHdrBg:[0.88, 0.88, 0.88],
    rowTint:  [0.92, 0.92, 0.92],
    featClr:  [0.15, 0.15, 0.15],
    tradHdrClr:[0.35, 0.35, 0.35],
    divClr:   [0.75, 0.75, 0.75, 1],
    sepClr:   [0.80, 0.80, 0.80, 1],
    crossClr: [0.60, 0.60, 0.60]
  } : {
    cardBg:   [0.10, 0.10, 0.10],
    tradHdrBg:[0.18, 0.18, 0.18],
    rowTint:  [0.13, 0.13, 0.13],
    featClr:  [0.82, 0.82, 0.82],
    tradHdrClr:[0.55, 0.55, 0.55],
    divClr:   [0.24, 0.24, 0.24, 1],
    sepClr:   [0.20, 0.20, 0.20, 1],
    crossClr: [0.32, 0.32, 0.32]
  };

  // Column layout: FEATURE (left) | TRADITIONAL (mid) | NVIDIA (right)
  var LEFT_X  = 80,  RIGHT_X = 1840;
  var TOP_Y   = 230, BOT_Y   = 980;
  var DIV1    = 760;   // feature | traditional boundary
  var DIV2    = 1300;  // traditional | nvidia boundary

  var FEAT_CX = Math.round((LEFT_X + DIV1) / 2);    // 420
  var FEAT_TX = LEFT_X + 40;                          // 120 — left-aligned text start
  var TRAD_CX = Math.round((DIV1 + DIV2) / 2);       // 1030
  var NVID_CX = Math.round((DIV2 + RIGHT_X) / 2);    // 1570

  var TRAD_W  = DIV2 - DIV1;   // 540
  var NVID_W  = RIGHT_X - DIV2; // 540

  var CARD_W  = RIGHT_X - LEFT_X;   // 1760
  var CARD_H  = BOT_Y - TOP_Y;      // 750
  var CARD_CY = TOP_Y + Math.round(CARD_H / 2);  // 605

  var HDR_H   = 130;
  var HDR_CY  = TOP_Y + Math.round(HDR_H / 2);   // 295
  var ROWS_TOP= TOP_Y + HDR_H;                    // 360
  var ROW_H   = Math.floor((BOT_Y - ROWS_TOP) / N);

  // Background card
  var bgL = comp.layers.addSolid(T.cardBg, 'EB_Cmp_Bg', CARD_W, CARD_H, 1);
  bgL.position.setValue([960, CARD_CY]);
  if (params.animateIn) { try { ebAnimateFadeUp(bgL, sf, fps, 10); } catch(e) {} }

  // TRADITIONAL header box
  var tradHdrL = comp.layers.addSolid(T.tradHdrBg, 'EB_Cmp_HdrTrad', TRAD_W, HDR_H, 1);
  tradHdrL.position.setValue([TRAD_CX, HDR_CY]);
  if (params.animateIn) { try { ebAnimateFadeUp(tradHdrL, sf + 2, fps, 8); } catch(e) {} }

  // NVIDIA header box — accent bg
  var nvidHdrL = comp.layers.addSolid(ac, 'EB_Cmp_HdrNvid', NVID_W, HDR_H, 1);
  nvidHdrL.position.setValue([NVID_CX, HDR_CY]);
  if (params.animateIn) { try { ebAnimateFadeUp(nvidHdrL, sf + 2, fps, 8); } catch(e) {} }

  // Header text
  var tradTxt = (params.cards && params.cards[0] && params.cards[0].label) ? params.cards[0].label : 'TRADITIONAL';
  var nvidTxt = (params.cards && params.cards[1] && params.cards[1].label) ? params.cards[1].label : 'NVIDIA SOLUTION';
  var tradHdrTx = ebText(comp, tradTxt, TRAD_CX, HDR_CY + Math.round(30 * 0.35), 30, 'semibold', T.tradHdrClr, 'center');
  tradHdrTx.name = 'EB_Cmp_HdrTradTx';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(tradHdrTx, sf + 3, fps, 8); } catch(e) {} }
  var nvidHdrTx = ebText(comp, nvidTxt, NVID_CX, HDR_CY + Math.round(30 * 0.35), 30, 'bold', [0, 0, 0], 'center');
  nvidHdrTx.name = 'EB_Cmp_HdrNvidTx';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(nvidHdrTx, sf + 3, fps, 8); } catch(e) {} }

  // Feature rows
  var defaultFeatures = [
    { label: 'Multi-GPU Scaling' },    { label: 'CUDA Optimization' },
    { label: 'Mixed Precision' },      { label: 'TensorRT Inference' },
    { label: 'NVLink Bandwidth' },     { label: 'AI Framework Support' }
  ];
  var features = [];
  var fi;
  if (params.bullets && params.bullets.length >= N) {
    for (fi = 0; fi < N; fi++) { features.push({ label: params.bullets[fi] }); }
  } else {
    for (fi = 0; fi < N; fi++) { features.push(defaultFeatures[fi] || { label: 'Feature ' + (fi + 1) }); }
  }

  // Symbols — use proven chars only. NVIDIASans has no U+2713 checkmark.
  // YES: bullet (U+2022, proven). NO: multiplication sign (U+00D7, proven).
  var yesChar  = String.fromCharCode(8226);  // •
  var noChar   = String.fromCharCode(215);   // x

  for (var ri = 0; ri < N; ri++) {
    var rowTopY = ROWS_TOP + ri * ROW_H;
    var rowCY   = rowTopY + Math.round(ROW_H / 2);
    var rFr     = sf + 5 + ri * 3;

    // Alternating row tint
    if (ri % 2 === 1) {
      var rowBgL = comp.layers.addSolid(T.rowTint, 'EB_Cmp_RowBg_' + (ri + 1), CARD_W, ROW_H - 1, 1);
      rowBgL.position.setValue([960, rowCY]);
      if (params.animateIn) { try { ebAnimateFadeUp(rowBgL, rFr, fps, 6); } catch(e) {} }
    }

    // Row separator
    if (ri > 0) {
      var sepL = comp.layers.addShape();
      sepL.name = 'EB_Cmp_Sep_' + ri; sepL.position.setValue([0, 0]);
      var sGC  = sepL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var sPth = sGC.addProperty('ADBE Vector Shape - Group');
      try { sPth.property('ADBE Vector Shape').setValue(ebOpenPath([[LEFT_X, rowTopY], [RIGHT_X, rowTopY]])); } catch(e) {}
      var sStr = sGC.addProperty('ADBE Vector Graphic - Stroke');
      try { sStr.property('ADBE Vector Stroke Color').setValue(T.sepClr); } catch(e) {}
      try { sStr.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
      if (params.animateIn) { try { ebAnimateFadeUp(sepL, rFr, fps, 6); } catch(e) {} }
    }

    var feat   = features[ri];
    var tyBase = rowCY + Math.round(32 * 0.35);
    var symBase= rowCY + Math.round(44 * 0.35);

    // Feature label — left-aligned in feature column
    var featTx = ebText(comp, feat.label, FEAT_TX, tyBase, 32, 'regular', T.featClr, 'left');
    featTx.name = 'EB_Cmp_Feat_' + (ri + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(featTx, rFr + 1, fps, 8); } catch(e) {} }

    // TRADITIONAL symbol (no = ×)
    var tradTx = ebText(comp, noChar, TRAD_CX, symBase, 44, 'bold', T.crossClr, 'center');
    tradTx.name = 'EB_Cmp_Trad_' + (ri + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(tradTx, rFr + 1, fps, 6); } catch(e) {} }

    // NVIDIA symbol (yes = •)
    var nvidTx = ebText(comp, yesChar, NVID_CX, symBase, 44, 'bold', ac, 'center');
    nvidTx.name = 'EB_Cmp_Nvid_' + (ri + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(nvidTx, rFr + 1, fps, 6); } catch(e) {} }
  }

  // Vertical dividers (full height)
  var vd;
  vd = comp.layers.addShape(); vd.name = 'EB_Cmp_VD1'; vd.position.setValue([0, 0]);
  var vd1c = vd.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var vd1p = vd1c.addProperty('ADBE Vector Shape - Group');
  try { vd1p.property('ADBE Vector Shape').setValue(ebOpenPath([[DIV1, TOP_Y], [DIV1, BOT_Y]])); } catch(e) {}
  var vd1s = vd1c.addProperty('ADBE Vector Graphic - Stroke');
  try { vd1s.property('ADBE Vector Stroke Color').setValue(T.divClr); } catch(e) {}
  try { vd1s.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(vd, sf + 2, fps, 8); } catch(e) {} }

  vd = comp.layers.addShape(); vd.name = 'EB_Cmp_VD2'; vd.position.setValue([0, 0]);
  var vd2c = vd.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var vd2p = vd2c.addProperty('ADBE Vector Shape - Group');
  try { vd2p.property('ADBE Vector Shape').setValue(ebOpenPath([[DIV2, TOP_Y], [DIV2, BOT_Y]])); } catch(e) {}
  var vd2s = vd2c.addProperty('ADBE Vector Graphic - Stroke');
  try { vd2s.property('ADBE Vector Stroke Color').setValue(T.divClr); } catch(e) {}
  try { vd2s.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(vd, sf + 2, fps, 8); } catch(e) {} }

  // Card border
  var bdrL = comp.layers.addShape(); bdrL.name = 'EB_Cmp_Border';
  bdrL.position.setValue([960, CARD_CY]);
  var bGC = bdrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bRc = bGC.addProperty('ADBE Vector Shape - Rect');
  try { bRc.property('ADBE Vector Rect Size').setValue([CARD_W, CARD_H]); } catch(e) {}
  var bSt = bGC.addProperty('ADBE Vector Graphic - Stroke');
  try { bSt.property('ADBE Vector Stroke Color').setValue(T.divClr); } catch(e) {}
  try { bSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(bdrL, sf, fps, 10); } catch(e) {} }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// TAGS / CHIPS
// Technology chip/badge strip. N items (4/6/8).
// Single row for N<=5, two rows for N>=6.
// =============================================================
function createTagsBlock(comp, params) {
  var fps = comp.frameRate;
  var sf  = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac  = [accent[0], accent[1], accent[2]];
  var N   = params.count || 6;

  var CHIP_W = 220, CHIP_H = 74;
  var GAP    = 28;

  var defaultTags = ['CUDA', 'TensorRT', 'cuDNN', 'NVLink', 'RAPIDS', 'Triton', 'cuBLAS', 'MLflow'];
  var tags = [];
  var ti;
  if (params.bullets && params.bullets.length >= N) {
    for (ti = 0; ti < N; ti++) { tags.push(params.bullets[ti]); }
  } else {
    for (ti = 0; ti < N; ti++) { tags.push(defaultTags[ti] || ('Tech ' + (ti + 1))); }
  }

  // Section label
  var labelTx = ebText(comp, 'TECHNOLOGIES', 960, 360, 28, 'semibold', ac, 'center');
  labelTx.name = 'EB_Tags_Label';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(labelTx, sf + 1, fps, 10); } catch(e) {} }

  // Accent rule
  var ruleL = comp.layers.addShape();
  ruleL.name = 'EB_Tags_Rule'; ruleL.position.setValue([0, 0]);
  var rGC  = ruleL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var rPth = rGC.addProperty('ADBE Vector Shape - Group');
  try { rPth.property('ADBE Vector Shape').setValue(ebOpenPath([[340, 398], [1580, 398]])); } catch(e) {}
  var rStr = rGC.addProperty('ADBE Vector Graphic - Stroke');
  try { rStr.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
  try { rStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(ruleL, sf + 2, fps, 10); } catch(e) {} }

  // Chip layout: single row or two rows
  var rows = [];
  if (N <= 5) {
    rows.push({ start: 0, count: N, y: 590 });
  } else {
    var perRow1 = Math.ceil(N / 2);
    rows.push({ start: 0,       count: perRow1,     y: 530 });
    rows.push({ start: perRow1, count: N - perRow1, y: 640 });
  }

  for (var ri = 0; ri < rows.length; ri++) {
    var row    = rows[ri];
    var totalW = row.count * CHIP_W + (row.count - 1) * GAP;
    var startX = Math.round((1920 - totalW) / 2);

    for (var ci = 0; ci < row.count; ci++) {
      var idx   = row.start + ci;
      var chipX = startX + ci * (CHIP_W + GAP) + Math.round(CHIP_W / 2);
      var chipY = row.y;
      var cFr   = sf + 4 + idx * 2;

      // Chip bg — addSolid (dark fill)
      var chipBg = comp.layers.addSolid([0.14, 0.14, 0.14], 'EB_Tag_Bg_' + (idx + 1), CHIP_W, CHIP_H, 1);
      chipBg.position.setValue([chipX, chipY]);
      if (params.animateIn) { try { ebAnimateFadeUp(chipBg, cFr, fps, 12); } catch(e) {} }

      // Chip border — stroke-only rounded rect
      var chipBdr = comp.layers.addShape();
      chipBdr.name = 'EB_Tag_Bdr_' + (idx + 1);
      chipBdr.position.setValue([chipX, chipY]);
      var cbGC = chipBdr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var cbRt = cbGC.addProperty('ADBE Vector Shape - Rect');
      try { cbRt.property('ADBE Vector Rect Size').setValue([CHIP_W, CHIP_H]); } catch(e) {}
      try { cbRt.property('ADBE Vector Rect Roundness').setValue(8); } catch(e) {}
      var cbSt = cbGC.addProperty('ADBE Vector Graphic - Stroke');
      try { cbSt.property('ADBE Vector Stroke Color').setValue(accent); } catch(e) {}
      try { cbSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
      if (params.animateIn) { try { ebAnimateFadeUp(chipBdr, cFr, fps, 12); } catch(e) {} }

      // Chip label
      var chipTx = ebText(comp, tags[idx], chipX, chipY + Math.round(28 * 0.35), 28, 'semibold', [0.90, 0.90, 0.90], 'center');
      chipTx.name = 'EB_Tag_Tx_' + (idx + 1);
      if (params.animateIn) { try { ebTextAnimatorFadeUp(chipTx, cFr + 1, fps, 8); } catch(e) {} }
    }
  }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// CALLOUT BLOCK
// Style variations:
//   dark        — dark card + accent bar + label + headline + body
//   box-solid   — stroke-only outline box + trim draw-on animation
//   box-dotted  — dotted outline box + trim animation
//   box-dashed  — dashed outline box + trim animation
//   line-solid  — full-width horizontal line + label + text
//   line-dotted — dotted line variation
//   line-dashed — dashed line variation
// =============================================================
function createCalloutBlock(comp, params) {
  var style = params.calloutStyle || 'dark';
  if (style === 'box-solid' || style === 'box-dotted' || style === 'box-dashed') {
    _calloutBoxStyle(comp, params, style);
  } else if (style === 'line-solid' || style === 'line-dotted' || style === 'line-dashed') {
    _calloutLineStyle(comp, params, style);
  } else {
    _calloutDarkStyle(comp, params);
  }
}

function _calloutDarkStyle(comp, params) {
  var fps = comp.frameRate;
  var sf  = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac  = [accent[0], accent[1], accent[2]];

  var CARD_W  = 1600, CARD_H = 380;
  var CARD_CX = 960,  CARD_CY = 570;
  var CARD_L  = CARD_CX - Math.round(CARD_W / 2);   // 160
  var CARD_T  = CARD_CY - Math.round(CARD_H / 2);   // 380
  var BAR_W   = 10;
  var TEXT_X  = CARD_L + BAR_W + 50;   // 220

  // Card bg — scale X wipe from left (no opacity fade = no flicker on white bg)
  // Layer order matters: bg created first → pushed to index 2 when bar is added → bar sits on top
  var bgL = comp.layers.addSolid([0.09, 0.09, 0.09], 'EB_CO_Bg', CARD_W, CARD_H, 1);
  if (params.animateIn && !$.global._ebSkipAnimIn) {
    try {
      bgL.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, CARD_H / 2]);
      bgL.position.setValue([CARD_L, CARD_CY]);
      var bgScale = bgL.property('ADBE Transform Group').property('ADBE Scale');
      bgScale.setValueAtTime(sf / fps, [0, 100]);
      bgScale.setValueAtTime((sf + 14) / fps, [100, 100]);
      try { setEase(bgScale, bgScale.nearestKeyIndex(sf / fps), 33, 33); } catch(e2) {}
      try { setEase(bgScale, bgScale.nearestKeyIndex((sf + 14) / fps), 33, 85); } catch(e2) {}
    } catch(e) {
      bgL.position.setValue([CARD_CX, CARD_CY]);
    }
    bgL.inPoint = sf / fps;
  } else {
    bgL.position.setValue([CARD_CX, CARD_CY]);
  }

  // Accent left bar — static position, no Y-slide (ebAnimateFadeUp caused height mismatch)
  var barL = comp.layers.addSolid(ac, 'EB_CO_Bar', BAR_W, CARD_H, 1);
  barL.position.setValue([CARD_L + Math.round(BAR_W / 2), CARD_CY]);
  if (params.animateIn && !$.global._ebSkipAnimIn) { barL.inPoint = sf / fps; }

  // Card border (stroke only)
  var bdrL = comp.layers.addShape(); bdrL.name = 'EB_CO_Border';
  bdrL.position.setValue([CARD_CX, CARD_CY]);
  var bGC = bdrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bRc = bGC.addProperty('ADBE Vector Shape - Rect');
  try { bRc.property('ADBE Vector Rect Size').setValue([CARD_W, CARD_H]); } catch(e) {}
  var bSt = bGC.addProperty('ADBE Vector Graphic - Stroke');
  try { bSt.property('ADBE Vector Stroke Color').setValue([0.25, 0.25, 0.25, 1]); } catch(e) {}
  try { bSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(bdrL, sf, fps, 12); } catch(e) {} }

  var LABEL_Y = CARD_T + 78;    // category label
  var HEAD_Y  = CARD_T + 160;   // headline
  var BODY_Y  = CARD_T + 258;   // body text

  // "KEY INSIGHT" label
  var lblTxt = (params.cards && params.cards[0] && params.cards[0].label) ? params.cards[0].label : 'KEY INSIGHT';
  var lblTx = ebText(comp, lblTxt, TEXT_X, LABEL_Y, 24, 'semibold', ac, 'left');
  lblTx.name = 'EB_CO_Label';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(lblTx, sf + 2, fps, 8); } catch(e) {} }

  // Headline
  var headTxt = (params.cards && params.cards[0] && params.cards[0].text) ? params.cards[0].text :
                (params.bullets && params.bullets[0]) ? params.bullets[0] :
                'NVIDIA accelerates every workload with purpose-built silicon.';
  var headTx = ebText(comp, headTxt, TEXT_X, HEAD_Y, 46, 'bold', [0.95, 0.95, 0.95], 'left');
  headTx.name = 'EB_CO_Head';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(headTx, sf + 3, fps, 8); } catch(e) {} }

  // Body text
  var bodyTxt = (params.bullets && params.bullets[1]) ? params.bullets[1] :
                'From training to inference, the full NVIDIA AI stack delivers unmatched performance.';
  var bodyTx = ebText(comp, bodyTxt, TEXT_X, BODY_Y, 30, 'regular', [0.55, 0.55, 0.55], 'left');
  bodyTx.name = 'EB_CO_Body';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(bodyTx, sf + 4, fps, 8); } catch(e) {} }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

function _calloutBoxStyle(comp, params, style) {
  var fps = comp.frameRate;
  var sf  = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac  = [accent[0], accent[1], accent[2]];

  var CARD_W  = 1600, CARD_H = 380;
  var CARD_CX = 960,  CARD_CY = 570;
  var CARD_L  = CARD_CX - Math.round(CARD_W / 2);   // 160
  var CARD_T  = CARD_CY - Math.round(CARD_H / 2);   // 380
  var TEXT_X  = CARD_L + 40;                         // 200

  // Outline box — ADBE Vector Shape - Rect (proven; ADBE Vector Shape - Path crashes AE 2024+)
  var shapeL = comp.layers.addShape(); shapeL.name = 'EB_CO_OutlineBox';
  shapeL.position.setValue([CARD_CX, CARD_CY]);
  var gc = shapeL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  var rect = gc.addProperty('ADBE Vector Shape - Rect');
  try { rect.property('ADBE Vector Rect Size').setValue([CARD_W, CARD_H]); } catch(e) {}

  var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
  try { stroke.property('ADBE Vector Stroke Color').setValue([ac[0], ac[1], ac[2], 1]); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {} // round

  if (style === 'box-dotted') {
    try {
      var dotD = stroke.property('ADBE Vector Stroke Dashes');
      dotD.addProperty('ADBE Vector Stroke Dash 1').setValue(2);
      dotD.addProperty('ADBE Vector Stroke Gap 1').setValue(16);
    } catch(e) {}
  } else if (style === 'box-dashed') {
    try {
      var dashD = stroke.property('ADBE Vector Stroke Dashes');
      dashD.addProperty('ADBE Vector Stroke Dash 1').setValue(22);
      dashD.addProperty('ADBE Vector Stroke Gap 1').setValue(10);
    } catch(e) {}
  }

  // Trim path draw-on animation
  try {
    var trim = gc.addProperty('ADBE Vector Filter - Trim');
    var trimEnd = trim.property('ADBE Vector Trim End');
    if (params.animateIn) {
      trimEnd.setValueAtTime(sf / fps, 0);
      trimEnd.setValueAtTime((sf + 20) / fps, 100);
      try {
        trimEnd.setInterpolationTypeAtKey(1, KeyframeInterpolationType.LINEAR);
        trimEnd.setInterpolationTypeAtKey(2, KeyframeInterpolationType.BEZIER);
        trimEnd.setTemporalEaseAtKey(2, [new KeyframeEase(0, 66)], [new KeyframeEase(0, 66)]);
      } catch(e2) {}
    }
  } catch(e) {}
  if (params.animateIn) { shapeL.inPoint = sf / fps; }

  var LABEL_Y = CARD_T + 78;    // category label
  var HEAD_Y  = CARD_T + 160;   // headline
  var BODY_Y  = CARD_T + 258;   // body text

  var lblTxt = (params.cards && params.cards[0] && params.cards[0].label) ? params.cards[0].label : 'KEY INSIGHT';
  var lblTx = ebText(comp, lblTxt, TEXT_X, LABEL_Y, 24, 'semibold', ac, 'left');
  lblTx.name = 'EB_CO_Label';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(lblTx, sf + 4, fps, 8); } catch(e) {} }

  var headTxt = (params.cards && params.cards[0] && params.cards[0].text) ? params.cards[0].text :
                (params.bullets && params.bullets[0]) ? params.bullets[0] :
                'NVIDIA accelerates every workload with purpose-built silicon.';
  var headTx = ebText(comp, headTxt, TEXT_X, HEAD_Y, 46, 'bold', [0.06, 0.06, 0.06], 'left');
  headTx.name = 'EB_CO_Head';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(headTx, sf + 5, fps, 8); } catch(e) {} }

  var bodyTxt = (params.bullets && params.bullets[1]) ? params.bullets[1] :
                'From training to inference, the full NVIDIA AI stack delivers unmatched performance.';
  var bodyTx = ebText(comp, bodyTxt, TEXT_X, BODY_Y, 30, 'regular', [0.30, 0.30, 0.30], 'left');
  bodyTx.name = 'EB_CO_Body';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(bodyTx, sf + 6, fps, 8); } catch(e) {} }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

function _calloutLineStyle(comp, params, style) {
  var fps = comp.frameRate;
  var sf  = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac  = [accent[0], accent[1], accent[2]];

  var X1 = 160, X2 = 1760;
  var LINE_CX = (X1 + X2) / 2;   // 960
  var LINE_W  = X2 - X1;          // 1600
  var LINE_Y  = 540;
  var TEXT_X  = X1;
  var LABEL_Y = LINE_Y - 52;      // 488 — label above line
  var HEAD_Y  = LINE_Y + 72;      // 612 — headline below line
  var BODY_Y  = LINE_Y + 124;     // 664

  // Horizontal line — zero-height Rect = single horizontal line
  // (ADBE Vector Shape - Path crashes AE 2024+; Rect with h=0 is the proven alternative)
  var lineL = comp.layers.addShape(); lineL.name = 'EB_CO_Line';
  lineL.position.setValue([LINE_CX, LINE_Y]);
  var gc = lineL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  var rect = gc.addProperty('ADBE Vector Shape - Rect');
  try { rect.property('ADBE Vector Rect Size').setValue([LINE_W, 0]); } catch(e) {}

  var stroke = gc.addProperty('ADBE Vector Graphic - Stroke');
  try { stroke.property('ADBE Vector Stroke Color').setValue([ac[0], ac[1], ac[2], 1]); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
  try { stroke.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {} // round

  if (style === 'line-dotted') {
    try {
      var dotD = stroke.property('ADBE Vector Stroke Dashes');
      dotD.addProperty('ADBE Vector Stroke Dash 1').setValue(2);
      dotD.addProperty('ADBE Vector Stroke Gap 1').setValue(16);
    } catch(e) {}
  } else if (style === 'line-dashed') {
    try {
      var dashD = stroke.property('ADBE Vector Stroke Dashes');
      dashD.addProperty('ADBE Vector Stroke Dash 1').setValue(22);
      dashD.addProperty('ADBE Vector Stroke Gap 1').setValue(10);
    } catch(e) {}
  }

  // Trim path draw-on right-to-left:
  // Zero-height rect: 0-50% = left→right (top edge), 50-100% = right→left (bottom edge).
  // Fix trimStart=50, animate trimEnd 50→100 to draw right-to-left.
  try {
    var trim = gc.addProperty('ADBE Vector Filter - Trim');
    var trimStart = trim.property('ADBE Vector Trim Start');
    var trimEnd   = trim.property('ADBE Vector Trim End');
    trimStart.setValue(50);
    if (params.animateIn) {
      trimEnd.setValueAtTime(sf / fps, 50);
      trimEnd.setValueAtTime((sf + 20) / fps, 100);
      try {
        trimEnd.setInterpolationTypeAtKey(1, KeyframeInterpolationType.LINEAR);
        trimEnd.setInterpolationTypeAtKey(2, KeyframeInterpolationType.BEZIER);
        trimEnd.setTemporalEaseAtKey(2, [new KeyframeEase(0, 66)], [new KeyframeEase(0, 66)]);
      } catch(e2) {}
    } else {
      trimEnd.setValue(100);
    }
  } catch(e) {}
  if (params.animateIn) { lineL.inPoint = sf / fps; }

  var lblTxt = (params.cards && params.cards[0] && params.cards[0].label) ? params.cards[0].label : 'KEY INSIGHT';
  var lblTx = ebText(comp, lblTxt, TEXT_X, LABEL_Y, 24, 'semibold', ac, 'left');
  lblTx.name = 'EB_CO_Label';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(lblTx, sf + 2, fps, 8); } catch(e) {} }

  var headTxt = (params.cards && params.cards[0] && params.cards[0].text) ? params.cards[0].text :
                (params.bullets && params.bullets[0]) ? params.bullets[0] :
                'NVIDIA accelerates every workload with purpose-built silicon.';
  var headTx = ebText(comp, headTxt, TEXT_X, HEAD_Y, 46, 'bold', [0.06, 0.06, 0.06], 'left');
  headTx.name = 'EB_CO_Head';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(headTx, sf + 4, fps, 8); } catch(e) {} }

  var bodyTxt = (params.bullets && params.bullets[1]) ? params.bullets[1] :
                'From training to inference, the full NVIDIA AI stack delivers unmatched performance.';
  var bodyTx = ebText(comp, bodyTxt, TEXT_X, BODY_Y, 30, 'regular', [0.30, 0.30, 0.30], 'left');
  bodyTx.name = 'EB_CO_Body';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(bodyTx, sf + 5, fps, 8); } catch(e) {} }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// ICON GRID
// Row of N icon placeholder squares (3–6) + label + desc below.
// Icons evenly distributed from x=240 to x=1680.
// =============================================================
function createIconGridBlock(comp, params) {
  var fps = comp.frameRate;
  var sf  = 1;
  var accent = ebColor(params.accentColor || '76B900');
  var ac  = [accent[0], accent[1], accent[2]];
  var N   = params.count || 4;

  var ICON_SZ = 90;
  var ICON_Y  = 490;
  var LABEL_Y = ICON_Y + Math.round(ICON_SZ / 2) + 56;   // 591
  var DESC_Y  = LABEL_Y + 44;                              // 635

  // Evenly space N icons from x=240 to x=1680
  var xs = [];
  if (N === 1) {
    xs = [960];
  } else {
    var usable  = 1680 - 240;
    var spacing = Math.round(usable / (N - 1));
    for (var i = 0; i < N; i++) { xs.push(240 + i * spacing); }
  }

  // Connecting line below icons (appears behind icons)
  if (N > 1) {
    var lineL = comp.layers.addShape();
    lineL.name = 'EB_IG_Line'; lineL.position.setValue([0, 0]);
    var lGC = lineL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var lPt = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPt.property('ADBE Vector Shape').setValue(ebOpenPath([[xs[0], ICON_Y], [xs[N - 1], ICON_Y]])); } catch(e) {}
    var lSt = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lSt.property('ADBE Vector Stroke Color').setValue([0.22, 0.22, 0.22, 1]); } catch(e) {}
    try { lSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    if (params.animateIn) { try { ebAnimateFadeUp(lineL, sf + 1, fps, 10); } catch(e) {} }
  }

  var defaultNames = ['GPU Compute', 'Networking', 'Storage', 'AI Software', 'Security', 'Orchestration'];
  var defaultDescs = ['H100 Tensor Cores', 'InfiniBand 400G', 'GPUDirect Storage', 'CUDA + TensorRT', 'Confidential Compute', 'Kubernetes'];

  for (var gi = 0; gi < N; gi++) {
    var gx    = xs[gi];
    var gFr   = sf + 2 + gi * 4;
    var gName = (params.cards && params.cards[gi] && params.cards[gi].label) ? params.cards[gi].label : (defaultNames[gi] || ('Item ' + (gi + 1)));
    var gDesc = (params.cards && params.cards[gi] && params.cards[gi].text)  ? params.cards[gi].text  : (defaultDescs[gi] || '');

    // Icon placeholder (accent square)
    var iconL = comp.layers.addSolid(ac, 'EB_IG_Icon_' + (gi + 1), ICON_SZ, ICON_SZ, 1);
    iconL.position.setValue([gx, ICON_Y]);
    if (params.animateIn) { try { ebAnimateFadeUp(iconL, gFr, fps, 14); } catch(e) {} }

    // Label
    var nameTx = ebText(comp, gName, gx, LABEL_Y, 30, 'bold', [0.90, 0.90, 0.90], 'center');
    nameTx.name = 'EB_IG_Name_' + (gi + 1);
    if (params.animateIn) { try { ebTextAnimatorFadeUp(nameTx, gFr + 1, fps, 8); } catch(e) {} }

    // Description
    if (gDesc) {
      var descTx = ebText(comp, gDesc, gx, DESC_Y, 24, 'regular', [0.48, 0.48, 0.48], 'center');
      descTx.name = 'EB_IG_Desc_' + (gi + 1);
      if (params.animateIn) { try { ebTextAnimatorFadeUp(descTx, gFr + 2, fps, 8); } catch(e) {} }
    }
  }

  for (var di = 1; di <= comp.numLayers; di++) { try { comp.layer(di).selected = false; } catch(e) {} }
  ebCreateHeader(comp, params, sf);
}

// =============================================================
// TREE 1->3  (one root, three children)
// Root: top of card zone. Children: fill lower 2/3.
// T-connector: trunk -> horizontal bus -> three drop lines.
// =============================================================
function createTree3Block(comp, params) {
  var fps       = comp.frameRate;
  var sf        = 1;
  var color     = ebColor(params.accentColor);
  var colorRGB  = [color[0], color[1], color[2]];
  var L         = EB_LAYOUT;
  var borderClr = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  // ── Layout ────────────────────────────────────────────────
  var rootW  = 560;
  var rootH  = 150;
  var rootCX = 960;
  var rootCY = 305;   // top=230, bottom=380

  var childW   = 510;
  var childH   = 430;
  var childCY  = 765; // top=550, bottom=980
  var childGap = 55;
  var childMarL = (L.compW - (3 * childW + 2 * childGap)) / 2;
  var childXs = [
    childMarL + childW / 2,
    childMarL + childW + childGap + childW / 2,
    childMarL + 2 * (childW + childGap) + childW / 2
  ];

  var rootBot  = rootCY + rootH / 2;   // 380
  var childTop = childCY - childH / 2; // 550
  var busY     = Math.round((rootBot + childTop) / 2); // 465

  var childLabels = ['Child A', 'Child B', 'Child C'];

  // params.cards: [0]=root, [1-3]=children (label=header, text=body)
  var rootC3      = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var rootLblTxt3  = rootC3.label || 'Root Node';
  var rootBodyTxt3 = rootC3.text  || 'Top-level concept.';
  var childBodyTxts = [];
  for (var cpi = 0; cpi < 3; cpi++) {
    var cpc = (params.cards && params.cards[cpi + 1]) ? params.cards[cpi + 1] : {};
    if (cpc.label) { childLabels[cpi] = cpc.label; }
    childBodyTxts.push(cpc.text || 'Supporting details.');
  }

  // ── Root node ────────────────────────────────────────────
  var rootStart = sf + 20;
  var rootNode  = { x: rootCX, y: rootCY, w: rootW, h: rootH };
  var rootBg = ebCreateCardBg(comp, rootNode, 'EB_Root', null, borderClr, showShadow, params.shapeFill === false, color);
  if (params.animateIn) { try { ebAnimateFadeUp(rootBg, rootStart, fps, 30); } catch(e) {} }

  var rootLabelY = rootCY - rootH / 2 + L.cardPadTop + L.headerFontSize;
  var rootLbl = ebText(comp, rootLblTxt3, rootCX, rootLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
  rootLbl.name = 'EB_RootLabel';
  ebTextAnimatorFadeUp(rootLbl, rootStart + 6, fps, 16);

  var rootRuleY = rootLabelY + 14;
  var rrL = comp.layers.addShape();
  rrL.name = 'EB_RootRule';
  rrL.position.setValue([rootCX, rootRuleY]);
  var rrW  = rootW - L.cardPadX * 2;
  var rrGC = rrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var rrP  = rrGC.addProperty('ADBE Vector Shape - Group');
  try { rrP.property('ADBE Vector Shape').setValue(ebOpenPath([[-rrW/2, 0], [rrW/2, 0]])); } catch(e) {}
  var rrS  = rrGC.addProperty('ADBE Vector Graphic - Stroke');
  try { rrS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { rrS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var rrT  = rrGC.addProperty('ADBE Vector Filter - Trim');
  var rrTE = rrT.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { rrL.inPoint = (rootStart + 7) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(rrTE, rootStart + 7, fps); } catch(e) {}
  } else {
    try { rrTE.setValue(100); } catch(e) {}
  }

  var rootBodyY3 = rootRuleY + Math.round(L.bodyFontSize * 1.35);
  var rootBody = ebText(comp, rootBodyTxt3, rootCX, rootBodyY3, L.bodyFontSize, 'regular', [0,0,0], 'center');
  rootBody.name = 'EB_RootBody';
  ebTextAnimatorFadeUp(rootBody, rootStart + 10, fps, 16);

  // ── Child nodes (added before connectors so connectors render on top) ─
  var connStart     = sf + 36;
  var childrenStart = connStart + 20;

  for (var i = 0; i < 3; i++) {
    var cX        = childXs[i];
    var childNode = { x: cX, y: childCY, w: childW, h: childH };
    var childStart = childrenStart + i * 9;

    var cBg = ebCreateCardBg(comp, childNode, 'EB_Child_' + (i+1), null, borderClr, showShadow, params.shapeFill === false, color);
    if (params.animateIn) { try { ebAnimateFadeUp(cBg, childStart, fps, 35); } catch(e) {} }

    var cLabelY = childCY - childH / 2 + L.cardPadTop + L.headerFontSize;
    var cLbl = ebText(comp, childLabels[i], cX, cLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    cLbl.name = 'EB_ChildLabel_' + (i+1);
    ebTextAnimatorFadeUp(cLbl, childStart + 6, fps, 18);

    var cRuleY = cLabelY + 14;
    var crL = comp.layers.addShape();
    crL.name = 'EB_ChildRule_' + (i+1);
    crL.position.setValue([cX, cRuleY]);
    var crW  = childW - L.cardPadX * 2;
    var crGC = crL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var crP  = crGC.addProperty('ADBE Vector Shape - Group');
    try { crP.property('ADBE Vector Shape').setValue(ebOpenPath([[-crW/2, 0], [crW/2, 0]])); } catch(e) {}
    var crS  = crGC.addProperty('ADBE Vector Graphic - Stroke');
    try { crS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { crS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var crT  = crGC.addProperty('ADBE Vector Filter - Trim');
    var crTE = crT.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { crL.inPoint = (childStart + 7) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(crTE, childStart + 7, fps); } catch(e) {}
    } else {
      try { crTE.setValue(100); } catch(e) {}
    }

    var cBodyY = cRuleY + Math.round(L.bodyFontSize * 1.35);
    var cBody = ebText(comp, childBodyTxts[i], cX, cBodyY, L.bodyFontSize, 'regular', [0,0,0], 'center');
    cBody.name = 'EB_ChildBody_' + (i+1);
    ebTextAnimatorFadeUp(cBody, childStart + 10, fps, 18);
  }

  // ── T-connector: trunk -> h-bus -> 3 drops (one trim path draws all) ──
  // Added LAST so connectors sit on top of card backgrounds.
  var connL = comp.layers.addShape();
  connL.name = 'EB_TreeConnectors';
  connL.position.setValue([0, 0]);
  var lGC = connL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  // 1. Trunk (root bottom -> bus)
  var tp = lGC.addProperty('ADBE Vector Shape - Group');
  try { tp.property('ADBE Vector Shape').setValue(ebOpenPath([[rootCX, rootBot], [rootCX, busY]])); } catch(e) {}
  // 2. H-bus (left child -> right child, at bus level)
  var bp = lGC.addProperty('ADBE Vector Shape - Group');
  try { bp.property('ADBE Vector Shape').setValue(ebOpenPath([[childXs[0], busY], [childXs[2], busY]])); } catch(e) {}
  // 3-5. Drop lines (bus -> each child top)
  for (var d = 0; d < 3; d++) {
    var dp = lGC.addProperty('ADBE Vector Shape - Group');
    try { dp.property('ADBE Vector Shape').setValue(ebOpenPath([[childXs[d], busY], [childXs[d], childTop]])); } catch(e) {}
  }
  var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
  try { lStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  var lTrim  = lGC.addProperty('ADBE Vector Filter - Trim');
  var lTrimE = lTrim.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { connL.inPoint = connStart / fps; } catch(e) {}
    try { ebAnimateTrimDraw(lTrimE, connStart, fps); } catch(e) {}
  } else {
    try { lTrimE.setValue(100); } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// TREE 1->2->4  (root -> 2 L1 nodes -> 4 L2 leaf nodes)
// Two levels of T-connectors, animated hierarchically.
// =============================================================
function createTree2LevelBlock(comp, params) {
  var fps       = comp.frameRate;
  var sf        = 1;
  var color     = ebColor(params.accentColor);
  var colorRGB  = [color[0], color[1], color[2]];
  var L         = EB_LAYOUT;
  var borderClr = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  // ── Layout ─────────────────────────────────────────────────
  // Root (1 node)
  var rootW = 500;  var rootH = 160;  var rootCX = 960;  var rootCY = 310;
  // rootTop=230, rootBot=390

  // L1 (2 nodes)
  var l1W = 420;  var l1H = 170;  var l1CY = 530;
  var l1Xs = [480, 1440];
  // l1Top=445, l1Bot=615

  // L2 leaves (4 nodes) -- pair centers align with L1 cx values
  var l2W = 300;  var l2H = 280;  var l2CY = 835;
  var l2Xs = [270, 690, 1230, 1650];
  // l2Top=695, l2Bot=975
  // Left pair center = (270+690)/2 = 480  == l1Xs[0]
  // Right pair center = (1230+1650)/2 = 1440 == l1Xs[1]

  var rootBot = rootCY + rootH / 2;  // 340
  var l1Top   = l1CY   - l1H   / 2;  // 445
  var l1Bot   = l1CY   + l1H   / 2;  // 615
  var l2Top   = l2CY   - l2H   / 2;  // 695
  var l1BusY  = Math.round((rootBot + l1Top) / 2);  // 392
  var l2BusY  = Math.round((l1Bot   + l2Top) / 2);  // 655

  var l1Labels = ['Branch A', 'Branch B'];
  var l2Labels = ['Leaf 1', 'Leaf 2', 'Leaf 3', 'Leaf 4'];

  // params.cards: [0]=root, [1-2]=L1, [3-6]=L2 (label=header, text=body)
  var rootC2      = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var rootLblTxt2 = rootC2.label || 'Root';
  var rootBodyTxt2 = rootC2.text || 'Overview.';
  var l1BodyTxts  = [];
  var l2BodyTxts  = [];
  for (var lpi = 0; lpi < 2; lpi++) {
    var lpc = (params.cards && params.cards[lpi + 1]) ? params.cards[lpi + 1] : {};
    if (lpc.label) { l1Labels[lpi] = lpc.label; }
    l1BodyTxts.push(lpc.text || 'Category details.');
  }
  for (var lpi2 = 0; lpi2 < 4; lpi2++) {
    var lpc2 = (params.cards && params.cards[lpi2 + 3]) ? params.cards[lpi2 + 3] : {};
    if (lpc2.label) { l2Labels[lpi2] = lpc2.label; }
    l2BodyTxts.push(lpc2.text || 'Details.');
  }

  // ── Root node ─────────────────────────────────────────────
  var rootStart = sf + 18;
  var rootNode  = { x: rootCX, y: rootCY, w: rootW, h: rootH };
  var rootBg = ebCreateCardBg(comp, rootNode, 'EB_Root', null, borderClr, showShadow, params.shapeFill === false, color);
  if (params.animateIn) { try { ebAnimateFadeUp(rootBg, rootStart, fps, 25); } catch(e) {} }

  var rootLabelY = rootCY - rootH / 2 + L.cardPadTop + L.headerFontSize;
  var rootLbl = ebText(comp, rootLblTxt2, rootCX, rootLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
  rootLbl.name = 'EB_RootLabel';
  ebTextAnimatorFadeUp(rootLbl, rootStart + 5, fps, 14);

  var rootRuleY = rootLabelY + 14;
  var rrL2 = comp.layers.addShape();
  rrL2.name = 'EB_RootRule';
  rrL2.position.setValue([rootCX, rootRuleY]);
  var rrW2  = rootW - L.cardPadX * 2;
  var rrGC2 = rrL2.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var rrP2  = rrGC2.addProperty('ADBE Vector Shape - Group');
  try { rrP2.property('ADBE Vector Shape').setValue(ebOpenPath([[-rrW2/2, 0], [rrW2/2, 0]])); } catch(e) {}
  var rrS2  = rrGC2.addProperty('ADBE Vector Graphic - Stroke');
  try { rrS2.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { rrS2.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var rrT2  = rrGC2.addProperty('ADBE Vector Filter - Trim');
  var rrTE2 = rrT2.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { rrL2.inPoint = (rootStart + 6) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(rrTE2, rootStart + 6, fps); } catch(e) {}
  } else {
    try { rrTE2.setValue(100); } catch(e) {}
  }

  var rootBodyY2 = rootRuleY + Math.round(L.bodyFontSize * 1.35);
  var rootBody = ebText(comp, rootBodyTxt2, rootCX, rootBodyY2, L.bodyFontSize, 'regular', [0,0,0], 'center');
  rootBody.name = 'EB_RootBody';
  ebTextAnimatorFadeUp(rootBody, rootStart + 9, fps, 14);

  // ── L1 nodes ──────────────────────────────────────────────
  var l1ConnStart  = sf + 32;
  var l1NodesStart = l1ConnStart + 20;

  for (var i = 0; i < 2; i++) {
    var l1X     = l1Xs[i];
    var l1Node  = { x: l1X, y: l1CY, w: l1W, h: l1H };
    var l1Start = l1NodesStart + i * 8;

    var l1Bg = ebCreateCardBg(comp, l1Node, 'EB_L1_' + (i+1), null, borderClr, showShadow, params.shapeFill === false, color);
    if (params.animateIn) { try { ebAnimateFadeUp(l1Bg, l1Start, fps, 30); } catch(e) {} }

    var l1LabelY = l1CY - l1H / 2 + L.cardPadTop + L.headerFontSize;
    var l1Lbl = ebText(comp, l1Labels[i], l1X, l1LabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    l1Lbl.name = 'EB_L1Label_' + (i+1);
    ebTextAnimatorFadeUp(l1Lbl, l1Start + 5, fps, 18);

    var l1RuleY = l1LabelY + 14;
    var l1rL = comp.layers.addShape();
    l1rL.name = 'EB_L1Rule_' + (i+1);
    l1rL.position.setValue([l1X, l1RuleY]);
    var l1rW  = l1W - L.cardPadX * 2;
    var l1rGC = l1rL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var l1rP  = l1rGC.addProperty('ADBE Vector Shape - Group');
    try { l1rP.property('ADBE Vector Shape').setValue(ebOpenPath([[-l1rW/2, 0], [l1rW/2, 0]])); } catch(e) {}
    var l1rS  = l1rGC.addProperty('ADBE Vector Graphic - Stroke');
    try { l1rS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { l1rS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var l1rT  = l1rGC.addProperty('ADBE Vector Filter - Trim');
    var l1rTE = l1rT.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { l1rL.inPoint = (l1Start + 6) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(l1rTE, l1Start + 6, fps); } catch(e) {}
    } else {
      try { l1rTE.setValue(100); } catch(e) {}
    }

    var l1BodyY = l1RuleY + Math.round(L.bodyFontSize * 1.35);
    var l1Body = ebText(comp, l1BodyTxts[i], l1X, l1BodyY, L.bodyFontSize, 'regular', [0,0,0], 'center');
    l1Body.name = 'EB_L1Body_' + (i+1);
    ebTextAnimatorFadeUp(l1Body, l1Start + 9, fps, 18);
  }

  // ── L2 leaf nodes ─────────────────────────────────────────
  var l2ConnStart  = l1NodesStart + 22;
  var l2NodesStart = l2ConnStart  + 20;

  for (var j = 0; j < 4; j++) {
    var l2X    = l2Xs[j];
    var l2Node = { x: l2X, y: l2CY, w: l2W, h: l2H };
    var l2Start = l2NodesStart + j * 7;

    var l2Bg = ebCreateCardBg(comp, l2Node, 'EB_L2_' + (j+1), null, borderClr, showShadow, params.shapeFill === false, color);
    if (params.animateIn) { try { ebAnimateFadeUp(l2Bg, l2Start, fps, 28); } catch(e) {} }

    var l2LabelY = l2CY - l2H / 2 + L.cardPadTop + L.headerFontSize;
    var l2Lbl = ebText(comp, l2Labels[j], l2X, l2LabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    l2Lbl.name = 'EB_L2Label_' + (j+1);
    ebTextAnimatorFadeUp(l2Lbl, l2Start + 5, fps, 16);

    var l2RuleY = l2LabelY + 14;
    var l2rL = comp.layers.addShape();
    l2rL.name = 'EB_L2Rule_' + (j+1);
    l2rL.position.setValue([l2X, l2RuleY]);
    var l2rW  = l2W - L.cardPadX * 2;
    var l2rGC = l2rL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var l2rP  = l2rGC.addProperty('ADBE Vector Shape - Group');
    try { l2rP.property('ADBE Vector Shape').setValue(ebOpenPath([[-l2rW/2, 0], [l2rW/2, 0]])); } catch(e) {}
    var l2rS  = l2rGC.addProperty('ADBE Vector Graphic - Stroke');
    try { l2rS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { l2rS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var l2rT  = l2rGC.addProperty('ADBE Vector Filter - Trim');
    var l2rTE = l2rT.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { l2rL.inPoint = (l2Start + 6) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(l2rTE, l2Start + 6, fps); } catch(e) {}
    } else {
      try { l2rTE.setValue(100); } catch(e) {}
    }

    var l2BodyY = l2RuleY + Math.round(L.bodyFontSize * 1.35);
    var l2Body = ebText(comp, l2BodyTxts[j], l2X, l2BodyY, L.bodyFontSize, 'regular', [0,0,0], 'center');
    l2Body.name = 'EB_L2Body_' + (j+1);
    ebTextAnimatorFadeUp(l2Body, l2Start + 9, fps, 16);
  }

  // ── L1 connector layer (trunk -> h-bus -> 2 drops) ────────
  // Added after all node content so it renders on top.
  var l1cL = comp.layers.addShape();
  l1cL.name = 'EB_L1Connectors';
  l1cL.position.setValue([0, 0]);
  var l1cGC = l1cL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  var l1c1 = l1cGC.addProperty('ADBE Vector Shape - Group');
  try { l1c1.property('ADBE Vector Shape').setValue(ebOpenPath([[rootCX, rootBot], [rootCX, l1BusY]])); } catch(e) {}
  var l1c2 = l1cGC.addProperty('ADBE Vector Shape - Group');
  try { l1c2.property('ADBE Vector Shape').setValue(ebOpenPath([[l1Xs[0], l1BusY], [l1Xs[1], l1BusY]])); } catch(e) {}
  for (var d1 = 0; d1 < 2; d1++) {
    var l1cd = l1cGC.addProperty('ADBE Vector Shape - Group');
    try { l1cd.property('ADBE Vector Shape').setValue(ebOpenPath([[l1Xs[d1], l1BusY], [l1Xs[d1], l1Top]])); } catch(e) {}
  }
  var l1cStr = l1cGC.addProperty('ADBE Vector Graphic - Stroke');
  try { l1cStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { l1cStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
  try { l1cStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { l1cStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  var l1cTrim  = l1cGC.addProperty('ADBE Vector Filter - Trim');
  var l1cTrimE = l1cTrim.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { l1cL.inPoint = l1ConnStart / fps; } catch(e) {}
    try { ebAnimateTrimDraw(l1cTrimE, l1ConnStart, fps); } catch(e) {}
  } else {
    try { l1cTrimE.setValue(100); } catch(e) {}
  }

  // ── L2 connector layer (2 sub-trees, drawn left then right) ─
  var l2cL = comp.layers.addShape();
  l2cL.name = 'EB_L2Connectors';
  l2cL.position.setValue([0, 0]);
  var l2cGC = l2cL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  for (var s = 0; s < 2; s++) {
    var sX  = l1Xs[s];
    var lx0 = l2Xs[s * 2];
    var lx1 = l2Xs[s * 2 + 1];
    var sc1 = l2cGC.addProperty('ADBE Vector Shape - Group');
    try { sc1.property('ADBE Vector Shape').setValue(ebOpenPath([[sX, l1Bot], [sX, l2BusY]])); } catch(e) {}
    var sc2 = l2cGC.addProperty('ADBE Vector Shape - Group');
    try { sc2.property('ADBE Vector Shape').setValue(ebOpenPath([[lx0, l2BusY], [lx1, l2BusY]])); } catch(e) {}
    var sc3 = l2cGC.addProperty('ADBE Vector Shape - Group');
    try { sc3.property('ADBE Vector Shape').setValue(ebOpenPath([[lx0, l2BusY], [lx0, l2Top]])); } catch(e) {}
    var sc4 = l2cGC.addProperty('ADBE Vector Shape - Group');
    try { sc4.property('ADBE Vector Shape').setValue(ebOpenPath([[lx1, l2BusY], [lx1, l2Top]])); } catch(e) {}
  }
  var l2cStr = l2cGC.addProperty('ADBE Vector Graphic - Stroke');
  try { l2cStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { l2cStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
  try { l2cStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { l2cStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  var l2cTrim  = l2cGC.addProperty('ADBE Vector Filter - Trim');
  var l2cTrimE = l2cTrim.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { l2cL.inPoint = l2ConnStart / fps; } catch(e) {}
    try { ebAnimateTrimDraw(l2cTrimE, l2ConnStart, fps); } catch(e) {}
  } else {
    try { l2cTrimE.setValue(100); } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// HORIZONTAL TREE 1→3  (root at left, 3 branches at right)
// Classic left-to-right org chart.  Root card vertically
// centered; 3 equal child cards span the full content height.
// params.cards: [0]=root, [1–3]=children  (label + text)
// =============================================================
function createTreeH3Block(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var colorRGB = [color[0], color[1], color[2]];
  var L        = EB_LAYOUT;
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  // ── Layout ──────────────────────────────────────────────
  var rootW  = 360;  var rootH  = 200;
  var rootCX = 260;  var rootCY = 605;
  var childW = 380;  var childH = 210;
  var childCX  = 1640;
  var childCYs = [335, 605, 875];      // gap = (750-3×210)/2 = 60
  var busX     = 945;                  // midpoint: root-right=440, child-left=1450

  var rootRight = rootCX + rootW / 2;  // 440
  var childLeft = childCX - childW / 2; // 1450

  // ── Content ─────────────────────────────────────────────
  var rootC    = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var rootLbl  = rootC.label || 'Root Node';
  var rootBody = rootC.text  || 'Top-level concept.';
  var childLabels = ['Branch A', 'Branch B', 'Branch C'];
  var childBodies = [];
  for (var ci = 0; ci < 3; ci++) {
    var cc = (params.cards && params.cards[ci + 1]) ? params.cards[ci + 1] : {};
    if (cc.label) childLabels[ci] = cc.label;
    childBodies.push(cc.text || 'Supporting detail.');
  }

  // ── Root node ───────────────────────────────────────────
  var rootStart = sf + 20;
  var rootNode  = { x: rootCX, y: rootCY, w: rootW, h: rootH };
  var rootBg = ebCreateCardBg(comp, rootNode, 'EB_Root', null, borderClr, showShadow, params.shapeFill === false, color);
  if (params.animateIn) { try { ebAnimateFadeUp(rootBg, rootStart, fps, 30); } catch(e) {} }

  var rootLabelY = rootCY - rootH / 2 + L.cardPadTop + L.headerFontSize;
  var rootLblLyr = ebText(comp, rootLbl, rootCX, rootLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
  rootLblLyr.name = 'EB_RootLabel';
  ebTextAnimatorFadeUp(rootLblLyr, rootStart + 6, fps, 16);

  var rootRuleY = rootLabelY + 14;
  var rrL = comp.layers.addShape();
  rrL.name = 'EB_RootRule';
  rrL.position.setValue([rootCX, rootRuleY]);
  var rrW  = rootW - L.cardPadX * 2;
  var rrGC = rrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var rrP  = rrGC.addProperty('ADBE Vector Shape - Group');
  try { rrP.property('ADBE Vector Shape').setValue(ebOpenPath([[-rrW/2, 0], [rrW/2, 0]])); } catch(e) {}
  var rrS  = rrGC.addProperty('ADBE Vector Graphic - Stroke');
  try { rrS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { rrS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var rrT  = rrGC.addProperty('ADBE Vector Filter - Trim');
  var rrTE = rrT.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { rrL.inPoint = (rootStart + 7) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(rrTE, rootStart + 7, fps); } catch(e) {}
  } else { try { rrTE.setValue(100); } catch(e) {} }

  var rootBodyY = rootRuleY + Math.round(L.bodyFontSize * 1.35);
  var rootBodyLyr = ebText(comp, rootBody, rootCX, rootBodyY, L.bodyFontSize, 'regular', [0,0,0], 'center');
  rootBodyLyr.name = 'EB_RootBody';
  ebTextAnimatorFadeUp(rootBodyLyr, rootStart + 10, fps, 16);

  // ── Child nodes (added before connectors so lines sit on top) ──
  var connStart     = sf + 36;
  var childrenStart = connStart + 20;

  for (var i = 0; i < 3; i++) {
    var cCY    = childCYs[i];
    var cNode  = { x: childCX, y: cCY, w: childW, h: childH };
    var cStart = childrenStart + i * 9;

    var cBg = ebCreateCardBg(comp, cNode, 'EB_Child_' + (i+1), null, borderClr, showShadow, params.shapeFill === false, color);
    if (params.animateIn) { try { ebAnimateFadeUp(cBg, cStart, fps, 28); } catch(e) {} }

    var cLabelY = cCY - childH / 2 + L.cardPadTop + L.headerFontSize;
    var cLbl = ebText(comp, childLabels[i], childCX, cLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    cLbl.name = 'EB_ChildLabel_' + (i+1);
    ebTextAnimatorFadeUp(cLbl, cStart + 6, fps, 18);

    var cRuleY = cLabelY + 14;
    var crL = comp.layers.addShape();
    crL.name = 'EB_ChildRule_' + (i+1);
    crL.position.setValue([childCX, cRuleY]);
    var crW  = childW - L.cardPadX * 2;
    var crGC = crL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var crP  = crGC.addProperty('ADBE Vector Shape - Group');
    try { crP.property('ADBE Vector Shape').setValue(ebOpenPath([[-crW/2, 0], [crW/2, 0]])); } catch(e) {}
    var crS  = crGC.addProperty('ADBE Vector Graphic - Stroke');
    try { crS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { crS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var crT  = crGC.addProperty('ADBE Vector Filter - Trim');
    var crTE = crT.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { crL.inPoint = (cStart + 7) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(crTE, cStart + 7, fps); } catch(e) {}
    } else { try { crTE.setValue(100); } catch(e) {} }

    var cBodyY = cRuleY + Math.round(L.bodyFontSize * 1.35);
    var cBody  = ebText(comp, childBodies[i], childCX, cBodyY, L.bodyFontSize, 'regular', [0,0,0], 'center');
    cBody.name = 'EB_ChildBody_' + (i+1);
    ebTextAnimatorFadeUp(cBody, cStart + 10, fps, 18);
  }

  // ── Connectors (added last so they render on top) ────────
  var connL = comp.layers.addShape();
  connL.name = 'EB_TreeConnectors';
  connL.position.setValue([0, 0]);
  var lGC = connL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  // 1. Trunk: root right → busX (horizontal, at rootCY)
  var tp = lGC.addProperty('ADBE Vector Shape - Group');
  try { tp.property('ADBE Vector Shape').setValue(ebOpenPath([[rootRight, rootCY], [busX, rootCY]])); } catch(e) {}
  // 2. V-bus: top child CY → bottom child CY (at busX)
  var bp = lGC.addProperty('ADBE Vector Shape - Group');
  try { bp.property('ADBE Vector Shape').setValue(ebOpenPath([[busX, childCYs[0]], [busX, childCYs[2]]])); } catch(e) {}
  // 3-5. Horizontal branches: busX → each child left
  for (var d = 0; d < 3; d++) {
    var dp = lGC.addProperty('ADBE Vector Shape - Group');
    try { dp.property('ADBE Vector Shape').setValue(ebOpenPath([[busX, childCYs[d]], [childLeft, childCYs[d]]])); } catch(e) {}
  }

  var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
  try { lStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  var lTrim  = lGC.addProperty('ADBE Vector Filter - Trim');
  var lTrimE = lTrim.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { connL.inPoint = connStart / fps; } catch(e) {}
    try { ebAnimateTrimDraw(lTrimE, connStart, fps); } catch(e) {}
  } else { try { lTrimE.setValue(100); } catch(e) {} }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// HORIZONTAL TREE 1→5  (root at left, 5 branches at right)
// Compact org chart for 5 equal categories.
// params.cards: [0]=root, [1–5]=children  (label + optional text)
// =============================================================
function createTreeH5Block(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var colorRGB = [color[0], color[1], color[2]];
  var L        = EB_LAYOUT;
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  // ── Layout ──────────────────────────────────────────────
  // 5 children h=130, gap=25 → total=5×130+4×25=750 fills content zone perfectly
  var rootW  = 320;  var rootH  = 150;
  var rootCX = 240;  var rootCY = 605;
  var childW = 350;  var childH = 130;
  var childCX  = 1665;
  var childCYs = [295, 450, 605, 760, 915];  // CY[i] = 230+65+i×155
  var busX     = 945;                         // midpoint: root-right=400, child-left=1490

  var rootRight = rootCX + rootW / 2;   // 400
  var childLeft = childCX - childW / 2; // 1490

  // ── Content ─────────────────────────────────────────────
  var rootC    = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var rootLbl  = rootC.label || 'Root';
  var rootBody = rootC.text  || '';
  var childLabels = ['Branch A', 'Branch B', 'Branch C', 'Branch D', 'Branch E'];
  var childBodies = [];
  for (var ci = 0; ci < 5; ci++) {
    var cc = (params.cards && params.cards[ci + 1]) ? params.cards[ci + 1] : {};
    if (cc.label) childLabels[ci] = cc.label;
    childBodies.push(cc.text || '');
  }

  // ── Root node ───────────────────────────────────────────
  var rootStart = sf + 20;
  var rootNode  = { x: rootCX, y: rootCY, w: rootW, h: rootH };
  var rootBg = ebCreateCardBg(comp, rootNode, 'EB_Root', null, borderClr, showShadow, params.shapeFill === false, color);
  if (params.animateIn) { try { ebAnimateFadeUp(rootBg, rootStart, fps, 30); } catch(e) {} }

  var rootLabelY = rootCY - rootH / 2 + L.cardPadTop + L.headerFontSize;
  var rootLblLyr = ebText(comp, rootLbl, rootCX, rootLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
  rootLblLyr.name = 'EB_RootLabel';
  ebTextAnimatorFadeUp(rootLblLyr, rootStart + 6, fps, 16);

  var rootRuleY = rootLabelY + 14;
  var rrL = comp.layers.addShape();
  rrL.name = 'EB_RootRule';
  rrL.position.setValue([rootCX, rootRuleY]);
  var rrW  = rootW - L.cardPadX * 2;
  var rrGC = rrL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var rrP  = rrGC.addProperty('ADBE Vector Shape - Group');
  try { rrP.property('ADBE Vector Shape').setValue(ebOpenPath([[-rrW/2, 0], [rrW/2, 0]])); } catch(e) {}
  var rrS  = rrGC.addProperty('ADBE Vector Graphic - Stroke');
  try { rrS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { rrS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var rrT  = rrGC.addProperty('ADBE Vector Filter - Trim');
  var rrTE = rrT.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { rrL.inPoint = (rootStart + 7) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(rrTE, rootStart + 7, fps); } catch(e) {}
  } else { try { rrTE.setValue(100); } catch(e) {} }

  if (rootBody) {
    var rootBodyY = rootRuleY + Math.round(L.bodyFontSize * 1.2);
    var rootBodyLyr = ebText(comp, rootBody, rootCX, rootBodyY, L.bodyFontSize - 4, 'regular', [0,0,0], 'center');
    rootBodyLyr.name = 'EB_RootBody';
    ebTextAnimatorFadeUp(rootBodyLyr, rootStart + 10, fps, 16);
  }

  // ── Child nodes (added before connectors) ───────────────
  var connStart     = sf + 36;
  var childrenStart = connStart + 20;

  for (var i = 0; i < 5; i++) {
    var cCY    = childCYs[i];
    var cNode  = { x: childCX, y: cCY, w: childW, h: childH };
    var cStart = childrenStart + i * 7;

    var cBg = ebCreateCardBg(comp, cNode, 'EB_Child_' + (i+1), null, borderClr, showShadow, params.shapeFill === false, color);
    if (params.animateIn) { try { ebAnimateFadeUp(cBg, cStart, fps, 22); } catch(e) {} }

    // Label — positioned slightly above center due to short card height
    var cLabelY = cCY - childH / 2 + L.cardPadTop + L.headerFontSize;
    var cLbl    = ebText(comp, childLabels[i], childCX, cLabelY, L.headerFontSize, 'semibold', colorRGB, 'center');
    cLbl.name   = 'EB_ChildLabel_' + (i+1);
    ebTextAnimatorFadeUp(cLbl, cStart + 5, fps, 16);

    var cRuleY = cLabelY + 10;
    var crL = comp.layers.addShape();
    crL.name = 'EB_ChildRule_' + (i+1);
    crL.position.setValue([childCX, cRuleY]);
    var crW  = childW - L.cardPadX * 2;
    var crGC = crL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var crP  = crGC.addProperty('ADBE Vector Shape - Group');
    try { crP.property('ADBE Vector Shape').setValue(ebOpenPath([[-crW/2, 0], [crW/2, 0]])); } catch(e) {}
    var crS  = crGC.addProperty('ADBE Vector Graphic - Stroke');
    try { crS.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { crS.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    var crT  = crGC.addProperty('ADBE Vector Filter - Trim');
    var crTE = crT.property('ADBE Vector Trim End');
    if (params.animateIn) {
      try { crL.inPoint = (cStart + 6) / fps; } catch(e) {}
      try { ebAnimateTrimDraw(crTE, cStart + 6, fps); } catch(e) {}
    } else { try { crTE.setValue(100); } catch(e) {} }

    if (childBodies[i]) {
      var cBodyY = cRuleY + Math.round((L.bodyFontSize - 4) * 1.25);
      var cBody  = ebText(comp, childBodies[i], childCX, cBodyY, L.bodyFontSize - 4, 'regular', [0,0,0], 'center');
      cBody.name = 'EB_ChildBody_' + (i+1);
      ebTextAnimatorFadeUp(cBody, cStart + 8, fps, 16);
    }
  }

  // ── Connectors ──────────────────────────────────────────
  var connL = comp.layers.addShape();
  connL.name = 'EB_TreeConnectors';
  connL.position.setValue([0, 0]);
  var lGC = connL.property('Contents').addProperty('ADBE Vector Group').property('Contents');

  // 1. Trunk: root right → busX (at rootCY)
  var tp = lGC.addProperty('ADBE Vector Shape - Group');
  try { tp.property('ADBE Vector Shape').setValue(ebOpenPath([[rootRight, rootCY], [busX, rootCY]])); } catch(e) {}
  // 2. V-bus: top child → bottom child
  var bp = lGC.addProperty('ADBE Vector Shape - Group');
  try { bp.property('ADBE Vector Shape').setValue(ebOpenPath([[busX, childCYs[0]], [busX, childCYs[4]]])); } catch(e) {}
  // 3-7. Horizontal branches: busX → each child left
  for (var d = 0; d < 5; d++) {
    var dp = lGC.addProperty('ADBE Vector Shape - Group');
    try { dp.property('ADBE Vector Shape').setValue(ebOpenPath([[busX, childCYs[d]], [childLeft, childCYs[d]]])); } catch(e) {}
  }

  var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
  try { lStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { lStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
  var lTrim  = lGC.addProperty('ADBE Vector Filter - Trim');
  var lTrimE = lTrim.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { connL.inPoint = connStart / fps; } catch(e) {}
    try { ebAnimateTrimDraw(lTrimE, connStart, fps); } catch(e) {}
  } else { try { lTrimE.setValue(100); } catch(e) {} }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// PARALLEL SPLIT DIAGRAM BLOCK
// Left panel : 4 GPU blocks (horizontal strip) = Tensor Parallelism
// Right panel: 4 stacked rows = Pipeline Parallelism
// Vertical divider at x=960.
//
// params.cards[0].label/body = TP section header / caption
// params.cards[1].label/body = PP section header / caption
// =============================================================
function createParallelSplitBlock(comp, params) {
  var fps     = comp.frameRate;
  var L       = EB_LAYOUT;
  var acColor = ebColor(params.accentColor);
  var acRGB   = [acColor[0], acColor[1], acColor[2]];
  var lgray4  = [0.78, 0.78, 0.78, 1];
  var dgray   = [0, 0, 0];
  var white   = [1, 1, 1];

  // ── Geometry ──────────────────────────────────────────────
  var divX    = 960;
  var leftCX  = 490;
  var rightCX = 1430;

  var secHdrY  = 290;   // section title baseline
  var secRuleY = 306;   // underline rule
  var secCapY  = 352;   // caption baseline
  var ruleW    = 600;

  // GPU blocks (left side, TP)
  var gpuW = 164, gpuH = 260, gpuGap = 14;
  var gpuSW = 4*gpuW + 3*gpuGap;             // 698px strip width
  var gpuY  = 620;
  var gpuX0 = leftCX - gpuSW/2 + gpuW/2;    // 223
  var gpuXs = [];
  for (var gi = 0; gi < 4; gi++) gpuXs.push(gpuX0 + gi*(gpuW+gpuGap));

  // Bracket annotation below GPU strip
  var brkY    = gpuY + gpuH/2 + 26;   // 776
  var brkL    = gpuXs[0] - gpuW/2;    // 141
  var brkR    = gpuXs[3] + gpuW/2;    // 839
  var brkCapY = brkY + 36;             // 812

  // Pipeline rows (right side, PP)
  var pipeW = 740, pipeH = 108, pipeGap = 12;
  var pipeSH = 4*pipeH + 3*pipeGap;           // 468px stack height
  var pipeY0 = gpuY - pipeSH/2 + pipeH/2;    // 440
  var pipeYs = [];
  for (var pi2 = 0; pi2 < 4; pi2++) pipeYs.push(pipeY0 + pi2*(pipeH+pipeGap));

  var pipeTxtL = rightCX - pipeW/2 + 50;     // 1110 left-anchored GPU label
  var pipeTxtR = rightCX + pipeW/2 - 50;     // 1750 right-anchored layers label

  var LAYER_RANGES = ['Layers 1-8', 'Layers 9-16', 'Layers 17-24', 'Layers 25-32'];

  // ── Animation timing ──────────────────────────────────────
  var divFrame  = 30;
  var lHdrFrame = 38;
  var rHdrFrame = 42;
  var capFrame  = 50;
  var gpuF0     = 56;
  var rowF0     = 60;
  var stagger   = 7;
  var brkFrame  = gpuF0 + 3*stagger + 14;   // 91

  // ── 1. Vertical divider ────────────────────────────────────
  var divH   = L.cardBottom - L.cardTop;
  var divLyr = comp.layers.addShape();
  divLyr.name = 'EB_Divider';
  divLyr.position.setValue([divX, L.cardTop + divH/2]);
  var dv_gc = divLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var dv_pg = dv_gc.addProperty('ADBE Vector Shape - Group');
  try { dv_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[0, -divH/2], [0, divH/2]])); } catch(e) {}
  var dv_s  = dv_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { dv_s.property('ADBE Vector Stroke Color').setValue(lgray4); } catch(e) {}
  try { dv_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var dv_tr = dv_gc.addProperty('ADBE Vector Filter - Trim');
  var dv_te = dv_tr.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { divLyr.inPoint = divFrame / fps; } catch(e) {}
    try { ebAnimateTrimDraw(dv_te, divFrame, fps); } catch(e) {}
  } else {
    try { dv_te.setValue(100); } catch(e) {}
  }

  // ── 2. Left section header + rule + caption (TP) ──────────
  var tpCard  = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var tpLabel = tpCard.label || 'Tensor Parallelism (TP)';
  var tpCap   = tpCard.body  || 'Splits one layer across multiple GPUs';

  var tpHdr  = ebText(comp, tpLabel, leftCX, secHdrY, 28, 'semibold', acRGB, 'center');
  tpHdr.name = 'EB_TP_Hdr';
  ebTextAnimatorFadeUp(tpHdr, lHdrFrame, fps, 20);

  var tpRl  = comp.layers.addShape();
  tpRl.name = 'EB_TP_Rule';
  tpRl.position.setValue([leftCX, secRuleY]);
  var tr_gc = tpRl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var tr_pg = tr_gc.addProperty('ADBE Vector Shape - Group');
  try { tr_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2, 0], [ruleW/2, 0]])); } catch(e) {}
  var tr_s  = tr_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { tr_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { tr_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var tr_t  = tr_gc.addProperty('ADBE Vector Filter - Trim');
  var tr_te = tr_t.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { tpRl.inPoint = (lHdrFrame + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(tr_te, lHdrFrame+1, fps); } catch(e) {}
  } else {
    try { tr_te.setValue(100); } catch(e) {}
  }

  var tpCapL  = ebText(comp, tpCap, leftCX, secCapY, 20, 'regular', dgray, 'center');
  tpCapL.name = 'EB_TP_Cap';
  ebTextAnimatorFadeUp(tpCapL, capFrame, fps, 16);

  // ── 3. GPU blocks (4 horizontal, left side) ───────────────
  for (var gi = 0; gi < 4; gi++) {
    var gx = gpuXs[gi];
    var gf = gpuF0 + gi*stagger;

    var gLyr  = comp.layers.addShape();
    gLyr.name = 'EB_GPU_' + gi;
    gLyr.position.setValue([gx, gpuY]);
    var g_gc = gLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var g_r  = g_gc.addProperty('ADBE Vector Shape - Rect');
    try { g_r.property('ADBE Vector Rect Size').setValue([gpuW, gpuH]); } catch(e) {}
    try { g_r.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    if (params.strokeOnly) {
      var g_st = g_gc.addProperty('ADBE Vector Graphic - Stroke');
      try { g_st.property('ADBE Vector Stroke Color').setValue([acColor[0], acColor[1], acColor[2], 1]); } catch(e) {}
      try { g_st.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    } else {
      var g_f  = g_gc.addProperty('ADBE Vector Graphic - Fill');
      var gAlpha = 1 - gi*0.14;
      try { g_f.property('ADBE Vector Fill Color').setValue([acColor[0], acColor[1], acColor[2], gAlpha]); } catch(e) {}
    }
    if (params.animateIn) { try { ebAnimateFadeUp(gLyr, gf, fps, 28); } catch(e) {} }

    var gLblClr = params.strokeOnly ? acRGB : white;
    var gTxt  = ebText(comp, 'GPU ' + gi, gx, gpuY+10, 26, 'bold', gLblClr, 'center');
    gTxt.name = 'EB_GPULbl_' + gi;
    ebTextAnimatorFadeUp(gTxt, gf+5, fps, 14);
  }

  // ── 4. Bracket annotation: "one full layer" ───────────────
  var brkLyr  = comp.layers.addShape();
  brkLyr.name = 'EB_Bracket';
  brkLyr.position.setValue([0, 0]);
  var brk_c = brkLyr.property('Contents');

  var bh_g  = brk_c.addProperty('ADBE Vector Group'); bh_g.name = 'HBar';
  var bh_gc = bh_g.property('Contents');
  var bh_p  = bh_gc.addProperty('ADBE Vector Shape - Group');
  try { bh_p.property('ADBE Vector Shape').setValue(ebOpenPath([[brkL, brkY], [brkR, brkY]])); } catch(e) {}
  var bh_s  = bh_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { bh_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { bh_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}

  var bl_g  = brk_c.addProperty('ADBE Vector Group'); bl_g.name = 'LTick';
  var bl_gc = bl_g.property('Contents');
  var bl_p  = bl_gc.addProperty('ADBE Vector Shape - Group');
  try { bl_p.property('ADBE Vector Shape').setValue(ebOpenPath([[brkL, brkY-12], [brkL, brkY]])); } catch(e) {}
  var bl_s  = bl_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { bl_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { bl_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}

  var br_g  = brk_c.addProperty('ADBE Vector Group'); br_g.name = 'RTick';
  var br_gc = br_g.property('Contents');
  var br_p  = br_gc.addProperty('ADBE Vector Shape - Group');
  try { br_p.property('ADBE Vector Shape').setValue(ebOpenPath([[brkR, brkY-12], [brkR, brkY]])); } catch(e) {}
  var br_s  = br_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { br_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { br_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}

  if (params.animateIn) { try { ebAnimateFadeUp(brkLyr, brkFrame, fps, 10); } catch(e) {} }

  var brkCap  = ebText(comp, 'one full layer', (brkL+brkR)/2, brkCapY, 19, 'regular', acRGB, 'center');
  brkCap.name = 'EB_BrkCap';
  ebTextAnimatorFadeUp(brkCap, brkFrame+5, fps, 10);

  // ── 5. Right section header + rule + caption (PP) ─────────
  var ppCard  = (params.cards && params.cards[1]) ? params.cards[1] : {};
  var ppLabel = ppCard.label || 'Pipeline Parallelism (PP)';
  var ppCap   = ppCard.body  || 'Full layer groups assigned to each GPU';

  var ppHdr  = ebText(comp, ppLabel, rightCX, secHdrY, 28, 'semibold', acRGB, 'center');
  ppHdr.name = 'EB_PP_Hdr';
  ebTextAnimatorFadeUp(ppHdr, rHdrFrame, fps, 20);

  var ppRl  = comp.layers.addShape();
  ppRl.name = 'EB_PP_Rule';
  ppRl.position.setValue([rightCX, secRuleY]);
  var pr_gc = ppRl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var pr_pg = pr_gc.addProperty('ADBE Vector Shape - Group');
  try { pr_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2, 0], [ruleW/2, 0]])); } catch(e) {}
  var pr_s  = pr_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { pr_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { pr_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var pr_t  = pr_gc.addProperty('ADBE Vector Filter - Trim');
  var pr_te = pr_t.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { ppRl.inPoint = (rHdrFrame + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(pr_te, rHdrFrame+1, fps); } catch(e) {}
  } else {
    try { pr_te.setValue(100); } catch(e) {}
  }

  var ppCapL  = ebText(comp, ppCap, rightCX, secCapY, 20, 'regular', dgray, 'center');
  ppCapL.name = 'EB_PP_Cap';
  ebTextAnimatorFadeUp(ppCapL, capFrame+4, fps, 16);

  // ── 6. Pipeline rows (4 stacked, right side) ──────────────
  for (var pi = 0; pi < 4; pi++) {
    var py = pipeYs[pi];
    var pf = rowF0 + pi*stagger;

    var pLyr  = comp.layers.addShape();
    pLyr.name = 'EB_PRow_' + pi;
    pLyr.position.setValue([rightCX, py]);
    var p_gc = pLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var p_r  = p_gc.addProperty('ADBE Vector Shape - Rect');
    try { p_r.property('ADBE Vector Rect Size').setValue([pipeW, pipeH]); } catch(e) {}
    try { p_r.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    if (params.strokeOnly) {
      var p_st = p_gc.addProperty('ADBE Vector Graphic - Stroke');
      try { p_st.property('ADBE Vector Stroke Color').setValue([acColor[0], acColor[1], acColor[2], 1]); } catch(e) {}
      try { p_st.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    } else {
      var p_f  = p_gc.addProperty('ADBE Vector Graphic - Fill');
      var pAlpha = 1 - pi*0.14;
      try { p_f.property('ADBE Vector Fill Color').setValue([acColor[0], acColor[1], acColor[2], pAlpha]); } catch(e) {}
    }
    if (params.animateIn) { try { ebAnimateFadeUp(pLyr, pf, fps, 22); } catch(e) {} }

    var pRowClr = params.strokeOnly ? acRGB : white;
    var gpuOff  = Math.round(24 * 0.35);
    var gpuLbl  = ebText(comp, 'GPU ' + pi, pipeTxtL, py, 24, 'bold', pRowClr, 'left');
    gpuLbl.name = 'EB_PGPU_' + pi;
    try { gpuLbl.anchorPoint.setValue([0, -gpuOff]); } catch(e) {}
    ebTextAnimatorFadeUp(gpuLbl, pf+5, fps, 14);

    var layOff  = Math.round(20 * 0.35);
    var layLbl  = ebText(comp, LAYER_RANGES[pi], pipeTxtR, py, 20, 'regular', pRowClr, 'right');
    layLbl.name = 'EB_PLayers_' + pi;
    try { layLbl.anchorPoint.setValue([0, -layOff]); } catch(e) {}
    ebTextAnimatorFadeUp(layLbl, pf+7, fps, 12);
  }

  // ── 7. Slide title + subtitle ─────────────────────────────
  ebCreateHeader(comp, params, 1);
}

// =============================================================
// SPLIT BLOCK (2 / 3 / 5 items) -- Generic columns-vs-rows
// Left: N tall blocks side by side.  Right: N horizontal rows.
// Placeholder labels are white-label; override via params.cards.
// =============================================================
function createSplitBlock(comp, params, count) {
  var fps     = comp.frameRate;
  var L       = EB_LAYOUT;
  var acColor = ebColor(params.accentColor);
  var acRGB   = [acColor[0], acColor[1], acColor[2]];
  var lgray4  = [0.78, 0.78, 0.78, 1];
  var dgray   = [0, 0, 0];
  var white   = [1, 1, 1];

  // ── Geometry by item count ────────────────────────────────
  var GEOM = {
    2: { gpuW:268, gpuH:300, gpuGap:20, pipeH:170, pipeGap:20 },
    3: { gpuW:196, gpuH:270, gpuGap:14, pipeH:132, pipeGap:14 },
    5: { gpuW:120, gpuH:250, gpuGap:12, pipeH: 80, pipeGap:10 }
  }[count] || { gpuW:164, gpuH:260, gpuGap:14, pipeH:108, pipeGap:12 };

  var gpuW = GEOM.gpuW, gpuH = GEOM.gpuH, gpuGap = GEOM.gpuGap;
  var pipeW = 740, pipeH = GEOM.pipeH, pipeGap = GEOM.pipeGap;
  var ALPHA_STEP = (count >= 5) ? 0.10 : 0.15;

  var divX    = 960;
  var leftCX  = 490;
  var rightCX = 1430;
  var secHdrY  = 290;
  var secRuleY = 306;
  var secCapY  = 352;
  var ruleW    = 600;
  var gpuY     = 620;

  // Left block positions
  var gpuSW = count*gpuW + (count-1)*gpuGap;
  var gpuX0 = leftCX - gpuSW/2 + gpuW/2;
  var gpuXs = [];
  for (var gi0 = 0; gi0 < count; gi0++) gpuXs.push(gpuX0 + gi0*(gpuW+gpuGap));

  // Bracket below left strip
  var brkY    = gpuY + gpuH/2 + 26;
  var brkL    = gpuXs[0] - gpuW/2;
  var brkR    = gpuXs[count-1] + gpuW/2;
  var brkCapY = brkY + 36;

  // Right row positions
  var pipeSH = count*pipeH + (count-1)*pipeGap;
  var pipeY0 = gpuY - pipeSH/2 + pipeH/2;
  var pipeYs = [];
  for (var ri0 = 0; ri0 < count; ri0++) pipeYs.push(pipeY0 + ri0*(pipeH+pipeGap));

  var pipeTxtL = rightCX - pipeW/2 + 50;
  var pipeTxtR = rightCX + pipeW/2 - 50;

  // ── Animation timing ──────────────────────────────────────
  var divFrame  = 30;
  var lHdrFrame = 38;
  var rHdrFrame = 42;
  var capFrame  = 50;
  var gpuF0     = 56;
  var rowF0     = 60;
  var stagger   = 7;
  var brkFrame  = gpuF0 + (count-1)*stagger + 14;

  // ── 1. Vertical divider ────────────────────────────────────
  var divH   = L.cardBottom - L.cardTop;
  var divLyr = comp.layers.addShape();
  divLyr.name = 'EB_Divider';
  divLyr.position.setValue([divX, L.cardTop + divH/2]);
  var dv_gc = divLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var dv_pg = dv_gc.addProperty('ADBE Vector Shape - Group');
  try { dv_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[0,-divH/2],[0,divH/2]])); } catch(e) {}
  var dv_s  = dv_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { dv_s.property('ADBE Vector Stroke Color').setValue(lgray4); } catch(e) {}
  try { dv_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var dv_tr = dv_gc.addProperty('ADBE Vector Filter - Trim');
  var dv_te = dv_tr.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { divLyr.inPoint = divFrame / fps; } catch(e) {}
    try { ebAnimateTrimDraw(dv_te, divFrame, fps); } catch(e) {}
  } else {
    try { dv_te.setValue(100); } catch(e) {}
  }

  // ── 2. Left section header + rule + caption ────────────────
  var lpCard  = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var lpLabel = lpCard.label || 'Section A';
  var lpCap   = lpCard.body  || 'Items arranged side by side';

  var lpHdr = ebText(comp, lpLabel, leftCX, secHdrY, 28, 'semibold', acRGB, 'center');
  lpHdr.name = 'EB_LP_Hdr';
  ebTextAnimatorFadeUp(lpHdr, lHdrFrame, fps, 20);

  var lpRl  = comp.layers.addShape();
  lpRl.name = 'EB_LP_Rule';
  lpRl.position.setValue([leftCX, secRuleY]);
  var tr_gc = lpRl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var tr_pg = tr_gc.addProperty('ADBE Vector Shape - Group');
  try { tr_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
  var tr_s  = tr_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { tr_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { tr_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var tr_t  = tr_gc.addProperty('ADBE Vector Filter - Trim');
  var tr_te = tr_t.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { lpRl.inPoint = (lHdrFrame + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(tr_te, lHdrFrame+1, fps); } catch(e) {}
  } else {
    try { tr_te.setValue(100); } catch(e) {}
  }

  var lpCapL = ebText(comp, lpCap, leftCX, secCapY, 20, 'regular', dgray, 'center');
  lpCapL.name = 'EB_LP_Cap';
  ebTextAnimatorFadeUp(lpCapL, capFrame, fps, 16);

  // ── 3. Left items (tall vertical blocks) ──────────────────
  var gFsz = (count >= 5) ? 20 : (count >= 4 ? 24 : 26);
  for (var gi = 0; gi < count; gi++) {
    var gx = gpuXs[gi];
    var gf = gpuF0 + gi*stagger;
    var glabel = (params.cards && params.cards[gi+2] && params.cards[gi+2].label)
      ? params.cards[gi+2].label : String.fromCharCode(65+gi);

    var gLyr = comp.layers.addShape();
    gLyr.name = 'EB_LItem_' + gi;
    gLyr.position.setValue([gx, gpuY]);
    var g_gc = gLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var g_r  = g_gc.addProperty('ADBE Vector Shape - Rect');
    try { g_r.property('ADBE Vector Rect Size').setValue([gpuW, gpuH]); } catch(e) {}
    try { g_r.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    if (params.strokeOnly) {
      var g_st = g_gc.addProperty('ADBE Vector Graphic - Stroke');
      try { g_st.property('ADBE Vector Stroke Color').setValue([acColor[0], acColor[1], acColor[2], 1]); } catch(e) {}
      try { g_st.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    } else {
      var g_f = g_gc.addProperty('ADBE Vector Graphic - Fill');
      try { g_f.property('ADBE Vector Fill Color').setValue([acColor[0], acColor[1], acColor[2], 1-gi*ALPHA_STEP]); } catch(e) {}
    }
    if (params.animateIn) { try { ebAnimateFadeUp(gLyr, gf, fps, 28); } catch(e) {} }

    var gLblClr = params.strokeOnly ? acRGB : white;
    var gTxt = ebText(comp, glabel, gx, gpuY + Math.round(gFsz*0.35), gFsz, 'bold', gLblClr, 'center');
    gTxt.name = 'EB_LLbl_' + gi;
    ebTextAnimatorFadeUp(gTxt, gf+5, fps, 14);
  }

  // ── 4. Bracket annotation ─────────────────────────────────
  var brkLyr = comp.layers.addShape();
  brkLyr.name = 'EB_Bracket';
  brkLyr.position.setValue([0, 0]);
  var brk_c = brkLyr.property('Contents');
  var bh_g  = brk_c.addProperty('ADBE Vector Group'); bh_g.name = 'HBar';
  var bh_gc = bh_g.property('Contents');
  var bh_p  = bh_gc.addProperty('ADBE Vector Shape - Group');
  try { bh_p.property('ADBE Vector Shape').setValue(ebOpenPath([[brkL,brkY],[brkR,brkY]])); } catch(e) {}
  var bh_s  = bh_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { bh_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { bh_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var bl_g  = brk_c.addProperty('ADBE Vector Group'); bl_g.name = 'LTick';
  var bl_gc = bl_g.property('Contents');
  var bl_p  = bl_gc.addProperty('ADBE Vector Shape - Group');
  try { bl_p.property('ADBE Vector Shape').setValue(ebOpenPath([[brkL,brkY-12],[brkL,brkY]])); } catch(e) {}
  var bl_s  = bl_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { bl_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { bl_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var br_g  = brk_c.addProperty('ADBE Vector Group'); br_g.name = 'RTick';
  var br_gc = br_g.property('Contents');
  var br_p  = br_gc.addProperty('ADBE Vector Shape - Group');
  try { br_p.property('ADBE Vector Shape').setValue(ebOpenPath([[brkR,brkY-12],[brkR,brkY]])); } catch(e) {}
  var br_s  = br_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { br_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { br_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(brkLyr, brkFrame, fps, 10); } catch(e) {} }

  var brkCap = ebText(comp, 'one unit', (brkL+brkR)/2, brkCapY, 19, 'regular', acRGB, 'center');
  brkCap.name = 'EB_BrkCap';
  ebTextAnimatorFadeUp(brkCap, brkFrame+5, fps, 10);

  // ── 5. Right section header + rule + caption ──────────────
  var rpCard  = (params.cards && params.cards[1]) ? params.cards[1] : {};
  var rpLabel = rpCard.label || 'Section B';
  var rpCap   = rpCard.body  || 'Items arranged in sequence';

  var ppHdr = ebText(comp, rpLabel, rightCX, secHdrY, 28, 'semibold', acRGB, 'center');
  ppHdr.name = 'EB_RP_Hdr';
  ebTextAnimatorFadeUp(ppHdr, rHdrFrame, fps, 20);

  var ppRl  = comp.layers.addShape();
  ppRl.name = 'EB_RP_Rule';
  ppRl.position.setValue([rightCX, secRuleY]);
  var pr_gc = ppRl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var pr_pg = pr_gc.addProperty('ADBE Vector Shape - Group');
  try { pr_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
  var pr_s  = pr_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { pr_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { pr_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var pr_t  = pr_gc.addProperty('ADBE Vector Filter - Trim');
  var pr_te = pr_t.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { ppRl.inPoint = (rHdrFrame + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(pr_te, rHdrFrame+1, fps); } catch(e) {}
  } else {
    try { pr_te.setValue(100); } catch(e) {}
  }

  var ppCapL = ebText(comp, rpCap, rightCX, secCapY, 20, 'regular', dgray, 'center');
  ppCapL.name = 'EB_RP_Cap';
  ebTextAnimatorFadeUp(ppCapL, capFrame+4, fps, 16);

  // ── 6. Right rows ─────────────────────────────────────────
  var rowFsz = (count >= 5) ? 20 : 24;
  var valFsz = (count >= 5) ? 17 : 20;
  for (var ri = 0; ri < count; ri++) {
    var py = pipeYs[ri];
    var pf = rowF0 + ri*stagger;
    var rowLabel = (params.cards && params.cards[ri+2] && params.cards[ri+2].label)
      ? params.cards[ri+2].label : 'Step ' + (ri+1);
    var rowValue = (params.cards && params.cards[ri+2] && params.cards[ri+2].body)
      ? params.cards[ri+2].body : 'Group ' + (ri+1);

    var pLyr = comp.layers.addShape();
    pLyr.name = 'EB_RRow_' + ri;
    pLyr.position.setValue([rightCX, py]);
    var p_gc = pLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var p_r  = p_gc.addProperty('ADBE Vector Shape - Rect');
    try { p_r.property('ADBE Vector Rect Size').setValue([pipeW, pipeH]); } catch(e) {}
    try { p_r.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    if (params.strokeOnly) {
      var p_st = p_gc.addProperty('ADBE Vector Graphic - Stroke');
      try { p_st.property('ADBE Vector Stroke Color').setValue([acColor[0], acColor[1], acColor[2], 1]); } catch(e) {}
      try { p_st.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    } else {
      var p_f = p_gc.addProperty('ADBE Vector Graphic - Fill');
      try { p_f.property('ADBE Vector Fill Color').setValue([acColor[0], acColor[1], acColor[2], 1-ri*ALPHA_STEP]); } catch(e) {}
    }
    if (params.animateIn) { try { ebAnimateFadeUp(pLyr, pf, fps, 22); } catch(e) {} }

    var pRowClr = params.strokeOnly ? acRGB : white;
    var gpuOff = Math.round(rowFsz * 0.35);
    var rLbl   = ebText(comp, rowLabel, pipeTxtL, py, rowFsz, 'bold', pRowClr, 'left');
    rLbl.name  = 'EB_RLbl_' + ri;
    try { rLbl.anchorPoint.setValue([0, -gpuOff]); } catch(e) {}
    ebTextAnimatorFadeUp(rLbl, pf+5, fps, 14);

    var valOff = Math.round(valFsz * 0.35);
    var vLbl   = ebText(comp, rowValue, pipeTxtR, py, valFsz, 'regular', pRowClr, 'right');
    vLbl.name  = 'EB_RVal_' + ri;
    try { vLbl.anchorPoint.setValue([0, -valOff]); } catch(e) {}
    ebTextAnimatorFadeUp(vLbl, pf+7, fps, 12);
  }

  // ── 7. Slide title + subtitle ─────────────────────────────
  ebCreateHeader(comp, params, 1);
}

// =============================================================
// SPLIT MIRROR -- Both sides show stacked horizontal rows.
// Use for comparing two parallel pipelines / sequences.
// =============================================================
function createSplitMirrorBlock(comp, params) {
  var fps     = comp.frameRate;
  var L       = EB_LAYOUT;
  var acColor = ebColor(params.accentColor);
  var acRGB   = [acColor[0], acColor[1], acColor[2]];
  var lgray4  = [0.78, 0.78, 0.78, 1];
  var dgray   = [0, 0, 0];
  var white   = [1, 1, 1];

  var count   = 4;
  var divX    = 960;
  var leftCX  = 430;
  var rightCX = 1490;
  var rowW    = 590;
  var rowH    = 108;
  var rowGap  = 14;
  var stripH  = count*rowH + (count-1)*rowGap;
  var centerY = 620;
  var rowY0   = centerY - stripH/2 + rowH/2;
  var rowYs   = [];
  for (var ri0 = 0; ri0 < count; ri0++) rowYs.push(rowY0 + ri0*(rowH+rowGap));

  var secHdrY  = 290;
  var secRuleY = 306;
  var secCapY  = 352;
  var ruleW    = 500;
  var divFrame  = 30;
  var lHdrFrame = 38;
  var rHdrFrame = 42;
  var capFrame  = 50;
  var lF0       = 56;
  var rF0       = 60;
  var stagger   = 7;

  // ── 1. Vertical divider ────────────────────────────────────
  var divH   = L.cardBottom - L.cardTop;
  var divLyr = comp.layers.addShape();
  divLyr.name = 'EB_Divider';
  divLyr.position.setValue([divX, L.cardTop + divH/2]);
  var dv_gc = divLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var dv_pg = dv_gc.addProperty('ADBE Vector Shape - Group');
  try { dv_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[0,-divH/2],[0,divH/2]])); } catch(e) {}
  var dv_s  = dv_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { dv_s.property('ADBE Vector Stroke Color').setValue(lgray4); } catch(e) {}
  try { dv_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var dv_tr = dv_gc.addProperty('ADBE Vector Filter - Trim');
  var dv_te = dv_tr.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { divLyr.inPoint = divFrame / fps; } catch(e) {}
    try { ebAnimateTrimDraw(dv_te, divFrame, fps); } catch(e) {}
  } else {
    try { dv_te.setValue(100); } catch(e) {}
  }

  // Safety net: caption is a single-line point-text; multi-line input here
  // would overflow downward and collide with the first row card. Collapse
  // newlines + bullet chars into single-space and cap length so an AI that
  // dumps a full bullet list into `body` still renders cleanly.
  function _capClean(s) {
    if (!s) return '';
    var t = String(s).replace(/[\r\n]+/g, ' ').replace(/\s{2,}/g, ' ').replace(/^[\s,;:\-•·]+|[\s,;:\-•·]+$/g, '');
    if (t.length > 60) t = t.substring(0, 57).replace(/\s+\S*$/, '') + '…';
    return t;
  }
  // ── 2. Left section header ─────────────────────────────────
  var lpCard  = (params.cards && params.cards[0]) ? params.cards[0] : {};
  var lpLabel = lpCard.label || 'Process A';
  var lpCap   = _capClean(lpCard.body) || 'Sequential steps';

  var lpHdr = ebText(comp, lpLabel, leftCX, secHdrY, 28, 'semibold', acRGB, 'center');
  lpHdr.name = 'EB_LP_Hdr';
  ebTextAnimatorFadeUp(lpHdr, lHdrFrame, fps, 20);

  var lpRl = comp.layers.addShape();
  lpRl.name = 'EB_LP_Rule';
  lpRl.position.setValue([leftCX, secRuleY]);
  var tr_gc = lpRl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var tr_pg = tr_gc.addProperty('ADBE Vector Shape - Group');
  try { tr_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
  var tr_s  = tr_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { tr_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { tr_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var tr_t  = tr_gc.addProperty('ADBE Vector Filter - Trim');
  var tr_te = tr_t.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { lpRl.inPoint = (lHdrFrame + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(tr_te, lHdrFrame+1, fps); } catch(e) {}
  } else {
    try { tr_te.setValue(100); } catch(e) {}
  }

  var lpCapL = ebText(comp, lpCap, leftCX, secCapY, 20, 'regular', dgray, 'center');
  lpCapL.name = 'EB_LP_Cap';
  ebTextAnimatorFadeUp(lpCapL, capFrame, fps, 16);

  // ── 3. Right section header ────────────────────────────────
  var rpCard  = (params.cards && params.cards[1]) ? params.cards[1] : {};
  var rpLabel = rpCard.label || 'Process B';
  var rpCap   = _capClean(rpCard.body) || 'Sequential steps';

  var rpHdr = ebText(comp, rpLabel, rightCX, secHdrY, 28, 'semibold', acRGB, 'center');
  rpHdr.name = 'EB_RP_Hdr';
  ebTextAnimatorFadeUp(rpHdr, rHdrFrame, fps, 20);

  var rpRl = comp.layers.addShape();
  rpRl.name = 'EB_RP_Rule';
  rpRl.position.setValue([rightCX, secRuleY]);
  var pr_gc = rpRl.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var pr_pg = pr_gc.addProperty('ADBE Vector Shape - Group');
  try { pr_pg.property('ADBE Vector Shape').setValue(ebOpenPath([[-ruleW/2,0],[ruleW/2,0]])); } catch(e) {}
  var pr_s  = pr_gc.addProperty('ADBE Vector Graphic - Stroke');
  try { pr_s.property('ADBE Vector Stroke Color').setValue(acColor); } catch(e) {}
  try { pr_s.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  var pr_t  = pr_gc.addProperty('ADBE Vector Filter - Trim');
  var pr_te = pr_t.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { rpRl.inPoint = (rHdrFrame + 1) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(pr_te, rHdrFrame+1, fps); } catch(e) {}
  } else {
    try { pr_te.setValue(100); } catch(e) {}
  }

  var rpCapL = ebText(comp, rpCap, rightCX, secCapY, 20, 'regular', dgray, 'center');
  rpCapL.name = 'EB_RP_Cap';
  ebTextAnimatorFadeUp(rpCapL, capFrame+4, fps, 16);

  // ── 4. Left rows ───────────────────────────────────────────
  var lOff = Math.round(24 * 0.35);
  for (var li = 0; li < count; li++) {
    var ly = rowYs[li];
    var lf = lF0 + li*stagger;
    var lLabel = (params.cards && params.cards[li+2] && params.cards[li+2].label)
      ? params.cards[li+2].label : 'Step ' + String.fromCharCode(65+li);

    var lLyr = comp.layers.addShape();
    lLyr.name = 'EB_LRow_' + li;
    lLyr.position.setValue([leftCX, ly]);
    var l_gc = lLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var l_r  = l_gc.addProperty('ADBE Vector Shape - Rect');
    try { l_r.property('ADBE Vector Rect Size').setValue([rowW, rowH]); } catch(e) {}
    try { l_r.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    if (params.strokeOnly) {
      var l_st = l_gc.addProperty('ADBE Vector Graphic - Stroke');
      try { l_st.property('ADBE Vector Stroke Color').setValue([acColor[0], acColor[1], acColor[2], 1]); } catch(e) {}
      try { l_st.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    } else {
      var l_f  = l_gc.addProperty('ADBE Vector Graphic - Fill');
      try { l_f.property('ADBE Vector Fill Color').setValue([acColor[0], acColor[1], acColor[2], 1-li*0.14]); } catch(e) {}
    }
    if (params.animateIn) { try { ebAnimateFadeUp(lLyr, lf, fps, 22); } catch(e) {} }

    var lRowClr = params.strokeOnly ? acRGB : white;
    var lTxt = ebText(comp, lLabel, leftCX, ly, 24, 'bold', lRowClr, 'center');
    lTxt.name = 'EB_LRowLbl_' + li;
    try { lTxt.anchorPoint.setValue([0, -lOff]); } catch(e) {}
    ebTextAnimatorFadeUp(lTxt, lf+5, fps, 14);
  }

  // ── 5. Right rows ──────────────────────────────────────────
  var rOff = Math.round(24 * 0.35);
  for (var ri = 0; ri < count; ri++) {
    var ry = rowYs[ri];
    var rf = rF0 + ri*stagger;
    var rLabel = (params.cards && params.cards[ri+count+2] && params.cards[ri+count+2].label)
      ? params.cards[ri+count+2].label : 'Phase ' + (ri+1);

    var rLyr = comp.layers.addShape();
    rLyr.name = 'EB_RRow_' + ri;
    rLyr.position.setValue([rightCX, ry]);
    var r_gc = rLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var r_r  = r_gc.addProperty('ADBE Vector Shape - Rect');
    try { r_r.property('ADBE Vector Rect Size').setValue([rowW, rowH]); } catch(e) {}
    try { r_r.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}
    if (params.strokeOnly) {
      var r_st = r_gc.addProperty('ADBE Vector Graphic - Stroke');
      try { r_st.property('ADBE Vector Stroke Color').setValue([acColor[0], acColor[1], acColor[2], 1]); } catch(e) {}
      try { r_st.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    } else {
      var r_f  = r_gc.addProperty('ADBE Vector Graphic - Fill');
      try { r_f.property('ADBE Vector Fill Color').setValue([acColor[0], acColor[1], acColor[2], 1-ri*0.14]); } catch(e) {}
    }
    if (params.animateIn) { try { ebAnimateFadeUp(rLyr, rf, fps, 22); } catch(e) {} }

    var rRowClr = params.strokeOnly ? acRGB : white;
    var rTxt = ebText(comp, rLabel, rightCX, ry, 24, 'bold', rRowClr, 'center');
    rTxt.name = 'EB_RRowLbl_' + ri;
    try { rTxt.anchorPoint.setValue([0, -rOff]); } catch(e) {}
    ebTextAnimatorFadeUp(rTxt, rf+5, fps, 14);
  }

  // ── 6. Slide title + subtitle ─────────────────────────────
  ebCreateHeader(comp, params, 1);
}


// =============================================================
// HELPER: ebWordWrap
// JS-based word-wrap. Returns array of line strings, each at
// most charsPerLine characters long (split at word boundaries).
// =============================================================
function ebWordWrap(text, charsPerLine) {
  if (!text) return [];
  var words = text.split(' ');
  var lines = [];
  var line  = '';
  for (var wi = 0; wi < words.length; wi++) {
    var test = line ? line + ' ' + words[wi] : words[wi];
    if (test.length <= charsPerLine) {
      line = test;
    } else {
      if (line) lines.push(line);
      line = words[wi];
    }
  }
  if (line) lines.push(line);
  return lines.length > 0 ? lines : [text];
}

// =============================================================
// HELPER: ebAddCodeBg
// Adds a light-grey rounded-rect behind a single-line code text
// layer. Size is pre-calculated from Courier New monospaced metrics
// (charW * length + padding) — no expressions.
// =============================================================
function ebAddCodeBg(comp, codeLayer, codeStr, textX, bY, codeFSz, codeCharW) {
  var padH = 8;   // horizontal padding per side
  var padV = 4;   // vertical padding per side
  var nm   = codeLayer.name;

  // Courier New metrics at codeFSz:
  //   ascent  ≈ 0.75 × fSz
  //   descent ≈ 0.25 × fSz
  //   line H  = fSz  (ascent + descent)
  //   cap-centre (optical) = baseline − (ascent − lineH/2)
  //                        = baseline − (0.75fSz − 0.5fSz) = baseline − 0.25fSz
  var bgH   = Math.round(codeFSz * 1.0) + padV * 2;           // line height + padding
  var bgCY  = bY - Math.round(codeFSz * 0.25);                // optical centre
  var bgW   = codeStr.length * codeCharW + padH * 2;          // initial width
  var bgCX  = textX + (codeStr.length * codeCharW) / 2;      // centred on text

  var bg = comp.layers.addShape();
  bg.name = nm + '_BG';
  bg.position.setValue([bgCX, bgCY]);

  var grp  = bg.property('Contents').addProperty('ADBE Vector Group');
  var gc   = grp.property('Contents');
  var rect = gc.addProperty('ADBE Vector Shape - Rect');
  rect.property('ADBE Vector Rect Size').setValue([bgW, bgH]);
  try { rect.property('ADBE Vector Rect Roundness').setValue(2); } catch(e) {}

  var fill = gc.addProperty('ADBE Vector Graphic - Fill');
  try { fill.property('Color').setValue([0.90, 0.90, 0.90, 1]); } catch(e) {}

  bg.moveAfter(codeLayer);
  return bg;
}


// =============================================================
// TEXT + CODE BULLETS BLOCK
// Title + subtitle + up to 5 annotated items: green monospaced
// code fragment + regular-font description (inline, word-wrapped
// via JS so nothing overflows the canvas).
// params:
//   cards[]: { code: '...', label: '...' }
//   cards[0] typically has only code (full command, no label)
//   cards[1-N] have code + label (flag + explanation)
// =============================================================
function createTextCodeBulletsBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var color = ebColor(params.accentColor);
  var acRGB = [color[0], color[1], color[2]];
  var black = [0, 0, 0];

  var dotX       = 130;
  var dotR       = 8;
  var codeFSz    = 30;
  var descFSz    = 32;
  var codeCharW  = Math.round(codeFSz * 0.61);  // ~18px (Courier New monospaced)
  var descCharW  = 17;                           // conservative avg for NVIDIA Sans 32px
  var DALIGN     = Math.round(codeFSz * 0.35);   // ~11px dot above baseline
  var codeLineH  = Math.round(codeFSz * 1.35);   // ~41px
  var descLineH  = Math.round(descFSz * 1.35);   // ~43px
  var GAP        = 38;   // gap below each item before the next item's baseline
  var textX      = dotX + dotR + 22;             // 160

  var maxItems = 5;
  var numItems = (params.cards && params.cards.length)
    ? Math.min(params.cards.length, maxItems) : 3;

  var defaults = [
    { code: 'run single -w workload --dtype fp8 --scale 256' },
    { code: 'run single',  label: 'Specifies that you are running a single benchmark instance.' },
    { code: '-w workload', label: 'The workload flag. Tells the framework which pre-configured recipe to use.' },
    { code: '--dtype fp8', label: 'Sets the numerical precision for the training run (FP8, BF16, etc.).' },
    { code: '--scale 256', label: 'The scale flag. Defines the total number of GPUs for the job.' }
  ];

  // ---- Pre-pass: compute desc X/W, word-wrapped lines, and Y for every item ----
  var items = [];  // {code, codeStr, hasDesc, descX, descW, lines, codeLineY, descLineY0}
  var y = 215;

  for (var ii = 0; ii < numItems; ii++) {
    var cd_ii = (params.cards && params.cards[ii]) ? params.cards[ii] : defaults[ii] || {};
    var code_ii    = cd_ii.code  || ('--flag' + ii + ' value');
    var hasDesc_ii = !!(cd_ii.label && cd_ii.label.length > 0);

    var codeStrLen = (hasDesc_ii ? code_ii + ':' : code_ii).length;
    var codeW_ii   = codeStrLen * codeCharW;

    var descX_ii = 0, descW_ii = 0, lines_ii = [], descBelow_ii = false;
    if (hasDesc_ii) {
      descX_ii = textX + codeW_ii + codeCharW;        // code + 1 char gap
      descW_ii = comp.width - descX_ii - 80;
      if (descW_ii < 480) {                            // code too long: desc below
        descX_ii   = textX + 40;
        descW_ii   = comp.width - descX_ii - 80;
        descBelow_ii = true;
      }
      var chars_ii = Math.floor(descW_ii / descCharW);
      lines_ii = ebWordWrap(cd_ii.label, chars_ii);
    }

    // Slot height: code line + (if desc below: all desc lines) + gap
    var descH_ii = 0;
    if (hasDesc_ii) {
      if (descBelow_ii) {
        descH_ii = codeLineH + descLineH * lines_ii.length;  // code + desc stacked
      } else {
        // Inline: height is max(code, desc lines)
        descH_ii = Math.max(codeLineH, descLineH * lines_ii.length);
      }
    }
    var slotH_ii = (hasDesc_ii ? descH_ii : codeLineH) + GAP;

    items.push({
      code:       code_ii,
      codeStr:    hasDesc_ii ? code_ii + ':' : code_ii,
      hasDesc:    hasDesc_ii,
      label:      cd_ii.label || '',
      descX:      descX_ii,
      descW:      descW_ii,
      lines:      lines_ii,
      descBelow:  descBelow_ii,
      codeLineY:  y,
      descLineY0: descBelow_ii ? y + codeLineH + 4 : y
    });
    y += slotH_ii;
  }

  // ---- Render ----
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    var fr = sf + 30 + i * 6;
    var bn = 'EB_CB' + i;

    // Dot
    var dot = ebDot(comp, dotX, it.codeLineY - DALIGN, dotR, color, bn + '_Dot');
    dot.label = 9;
    if (params.animateIn) { try { ebAnimateFadeUp(dot, fr, fps, 15); } catch(e) {} }

    // Code text
    var codeL = ebText(comp, it.codeStr, textX, it.codeLineY, codeFSz, 'mono', acRGB, 'left');
    codeL.name = bn + '_Code';
    try { ebTextAnimatorFadeUp(codeL, fr + 2, fps, 0); } catch(e) {}

    // Grey pill behind code — animate in sync with the code text
    var bgL = ebAddCodeBg(comp, codeL, it.codeStr, textX, it.codeLineY, codeFSz, codeCharW);
    if (params.animateIn) { try { ebAnimateFadeUp(bgL, fr + 2, fps, 0); } catch(e) {} }

    // Description lines (manual word-wrap, one ebText layer per line)
    if (it.hasDesc) {
      for (var li = 0; li < it.lines.length; li++) {
        var lineY = it.descLineY0 + li * descLineH;
        var lineL = ebText(comp, it.lines[li], it.descX, lineY, descFSz, 'regular', black, 'left');
        lineL.name = bn + '_Desc' + li;
        try { ebTextAnimatorFadeUp(lineL, fr + 4 + li * 2, fps, 18); } catch(e) {}
      }
    }
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// TEXT + CODE BULLETS + CLI BLOCK
// Title + subtitle + up to 5 annotated code-bullet items
// (green monospaced term + description inline, same as
// createTextCodeBulletsBlock), followed by a bold section label
// and a multi-line terminal log box.
// params:
//   cards[]:    { code: '...', label: '...' }
//   cliLabel:   bold label above terminal (default 'Sample Log Snippet:')
//   cliLines[]: array of log line strings shown in the terminal box
// =============================================================
function createTextCodeCLIBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var acRGB    = [color[0], color[1], color[2]];
  var colorArr = [color[0], color[1], color[2], 1];
  var black    = [0, 0, 0];
  var L        = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill7 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_CodeLogBG', null, borderClr, showShadow, _noFill7, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, sf + 36, fps, 40); } catch(e) {} }

  var cardLeft  = card.x - card.w / 2;  // 80
  var codeX     = cardLeft + L.cardPadX; // 112 — left edge of code label
  var monoCharW = 18;                    // Courier New ~18px at 30px size
  var codeFSz   = 30;
  var bodyFSz   = L.bodyFontSize;        // 30
  var zoneTop   = card.y - card.h / 2 + 60;  // 290
  var spacing   = 100;

  var defaults = [
    { code: 'loss',              label: 'Primary measure of model error; should decrease over time.' },
    { code: 'iteration or step', label: 'Tracks how many batches of data the model has processed.' },
    { code: 'throughput',        label: 'Training speed in tokens per second; key hardware metric.' }
  ];
  var numItems = (params.cards && params.cards.length) ? Math.min(params.cards.length, 3) : 3;

  // ---- Render 3 code-label + description items ----
  for (var i = 0; i < numItems; i++) {
    var cd   = (params.cards && params.cards[i]) ? params.cards[i] : defaults[i] || {};
    var code = cd.code  || ('metric' + i);
    var desc = cd.label || '';
    var fr   = sf + 30 + i * 6;
    var bn   = 'EB_CB' + i;

    var bulletY = zoneTop + i * spacing + 40;
    var textY   = bulletY + Math.round(codeFSz * 0.38);

    // Code label: mono font, accent color
    var codeStr = desc.length ? (code + ':') : code;
    var codeL   = ebText(comp, codeStr, codeX, textY, codeFSz, 'mono', acRGB, 'left');
    codeL.name  = bn + '_Code';
    ebTextAnimatorFadeUp(codeL, fr, fps, 18);

    // Description: regular font, black — starts after code label width
    if (desc.length) {
      var descX = codeX + codeStr.length * monoCharW + 20;
      var descL = ebText(comp, desc, descX, textY, bodyFSz, 'regular', black, 'left');
      descL.name = bn + '_Desc';
      ebTextAnimatorFadeUp(descL, fr + 3, fps, 18);
    }
  }

  // ---- Section label ----
  var labelY  = zoneTop + numItems * spacing + 56;
  var labelFr = sf + 30 + numItems * 6 + 4;
  var cliLbl  = params.cliLabel || 'Sample Log Snippet:';
  var lbl     = ebText(comp, cliLbl, codeX, labelY + Math.round(bodyFSz * 0.38), bodyFSz, 'bold', black, 'left');
  lbl.name    = 'EB_CliLabel';
  ebTextAnimatorFadeUp(lbl, labelFr, fps, 12);

  // ---- Multi-line terminal log box ----
  var cliLines = (params.cliLines && params.cliLines.length) ? params.cliLines : [
    'iteration 200 | loss: 6.54 | step_time: 2.3s | throughput: 450321 tokens/sec',
    'iteration 300 | loss: 6.21 | step_time: 2.3s | throughput: 450335 tokens/sec',
    'iteration 400 | loss: 5.98 | step_time: 2.3s | throughput: 450318 tokens/sec'
  ];
  var numLines = cliLines.length;
  var cmdFSz   = 24;
  var cmdLineH = Math.round(cmdFSz * 1.4);  // ~34px
  var wPadV    = 22;
  var wPadH    = 32;
  var wH       = numLines * cmdLineH + wPadV * 2;
  var wW       = card.w - L.cardPadX * 2;  // 1696 — full card width minus padding
  var wCX      = card.x;                   // horizontally centred with card
  var wCY      = labelY + Math.round(bodyFSz * 1.5) + 20 + wH / 2;
  var cliFr    = labelFr + 6;

  // Box background: addSolid — guaranteed to render (shape layer fills unreliable)
  var boxBg = comp.layers.addSolid([1, 1, 1], 'EB_CliBoxBg', wW, wH, 1);
  boxBg.position.setValue([wCX, wCY]);
  if (params.animateIn) { try { ebAnimateFadeUp(boxBg, cliFr, fps, 10); } catch(e) {} }

  // Border stroke (shape layer, stroke only — no fill needed)
  var borderL = comp.layers.addShape();
  borderL.name = 'EB_CliBoxBorder';
  borderL.position.setValue([wCX, wCY]);
  var bdGC  = borderL.property('Contents').addProperty('ADBE Vector Group').property('Contents');
  var bdPth = bdGC.addProperty('ADBE Vector Shape - Rect');
  bdPth.property('ADBE Vector Rect Size').setValue([wW, wH]);
  bdPth.property('ADBE Vector Rect Roundness').setValue(4);
  var bdStr = bdGC.addProperty('ADBE Vector Graphic - Stroke');
  try { bdStr.property('ADBE Vector Stroke Color').setValue([0.75, 0.75, 0.75, 1]); } catch(e) {}
  try { bdStr.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
  if (params.animateIn) { try { ebAnimateFadeUp(borderL, cliFr, fps, 10); } catch(e) {} }

  // Green left accent bar: addSolid
  var barSolid = comp.layers.addSolid([color[0], color[1], color[2]], 'EB_CliBar', 5, wH, 1);
  barSolid.position.setValue([wCX - wW / 2 + 2.5, wCY]);
  if (params.animateIn) { try { ebAnimateFadeUp(barSolid, cliFr, fps, 10); } catch(e) {} }

  // Log text lines — white on dark background
  var lineBaseY = wCY - wH / 2 + wPadV + Math.round(cmdFSz * 0.75);
  var cmdX      = wCX - wW / 2 + wPadH;
  for (var cii = 0; cii < numLines; cii++) {
    var cliLineL = ebText(comp, cliLines[cii], cmdX, lineBaseY + cii * cmdLineH,
                          cmdFSz, 'mono', [0, 0, 0], 'left');
    cliLineL.name = 'EB_CliLine' + cii;
    if (params.animateIn) { try { ebTextAnimatorFadeUp(cliLineL, cliFr + 4 + cii * 2, fps, 0); } catch(e) {} }
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// TEXT + CLI BLOCK
// Title + subtitle + up to 3 dynamic bullets + section label +
// terminal command box + optional body text below.
// params:
//   cards[]:       { label } for each bullet (up to 3)
//   cliLabel:      bold label before the terminal (default 'Example Command:')
//   cliCommand:    the command string shown as '$ <cmd>'
//   bodyText:      optional description paragraph below the terminal
// =============================================================
function createTextCLIBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var color = ebColor(params.accentColor);
  var acRGB = [color[0], color[1], color[2]];
  var black = [0, 0, 0];
  var gray  = [0, 0, 0];

  // ---- Bullet geometry ----
  var dotX   = 130;
  var dotR   = 8;
  var fSz    = 36;
  var lineH  = Math.round(fSz * 1.35);   // ~49px per text line
  var DALIGN = Math.round(fSz * 0.35);   // ~13 -- dot above baseline (cap-centre)
  var textX  = dotX + dotR + 22;         // 160
  var textW  = comp.width - textX - 100; // 1660

  // ---- CLI box geometry ----
  var wW = comp.width - dotX - 100;      // 1690
  var wH = 116;
  var wX = dotX + wW / 2;               // horizontal centre of box

  // ---- Fixed Y layout (no sourceRectAtTime expressions -- unreliable at create-time) ----
  // Budget 2 wrapped lines per bullet + inter-bullet gap.
  var numBullets = 3;
  if (params.cards && params.cards.length > 0) {
    numBullets = Math.min(params.cards.length, 3);
  }

  var bulSlot  = lineH * 2 + 36;           // 134px: 2-line text budget + gap below
  var baseY    = 245;                       // baseline of first bullet
  var lastBotY = baseY + (numBullets - 1) * bulSlot + lineH * 2; // est. bottom of last bullet
  var labelY   = lastBotY + 48;            // "Example Command:" baseline
  var cliBoxCY = labelY + Math.round(32 * 1.35) + 14 + wH / 2; // box centre
  var bodyY    = cliBoxCY + wH / 2 + 24 + Math.round(30 * 0.55); // body baseline

  // ---- Render bullets ----
  var defaults = [
    'Primary bullet explaining the key concept or command.',
    'Secondary bullet with supporting context or behavior.',
    'Third bullet summarizing the underlying mechanism.'
  ];
  for (var i = 0; i < numBullets; i++) {
    var bn  = 'EB_B' + i;
    var fr  = sf + 36 + i * 5;
    var cd  = (params.cards && params.cards[i]) ? params.cards[i] : {};
    var txt = cd.label || defaults[i];
    var bY  = baseY + i * bulSlot;

    var tl = ebTextParagraph(comp, txt, textX, bY, fSz, 'regular', black, textW);
    tl.name = bn + '_Text';
    try { ebTextAnimatorFadeUp(tl, fr + 2, fps, 18); } catch(e) {}

    var dot = ebDot(comp, dotX, bY - DALIGN, dotR, color, bn + '_Dot');
    dot.label = 9;
    if (params.animateIn) { try { ebAnimateFadeUp(dot, fr, fps, 15); } catch(e) {} }
  }

  // ---- Section label ----
  var lblFr  = sf + 36 + numBullets * 5 + 4;
  var cliLbl = params.cliLabel || 'Example Command:';
  var lbl    = ebText(comp, cliLbl, textX, labelY, 32, 'bold', black, 'left');
  lbl.name   = 'EB_CliLabel';
  try { ebTextAnimatorFadeUp(lbl, lblFr, fps, 12); } catch(e) {}

  // ---- CLI terminal box (light grey, green left bar) ----
  var cliFr  = lblFr + 6;
  var cliBox = comp.layers.addShape();
  cliBox.name = 'EB_CliBox';
  cliBox.position.setValue([wX, cliBoxCY]);

  // Light grey background
  var bgGrp  = cliBox.property('Contents').addProperty('ADBE Vector Group');
  var bgGC   = bgGrp.property('Contents');
  var bgRect = bgGC.addProperty('ADBE Vector Shape - Rect');
  bgRect.property('ADBE Vector Rect Size').setValue([wW, wH]);
  bgRect.property('ADBE Vector Rect Roundness').setValue(2);
  var bgFill = bgGC.addProperty('ADBE Vector Graphic - Fill');
  bgFill.property('Color').setValue([0.94, 0.94, 0.94, 1]);
  // Subtle border
  var bgStr  = bgGC.addProperty('ADBE Vector Graphic - Stroke');
  bgStr.property('Color').setValue([0.80, 0.80, 0.80, 1]);
  bgStr.property('Stroke Width').setValue(1);

  // Green left accent bar
  var barGrp  = cliBox.property('Contents').addProperty('ADBE Vector Group');
  var barGC   = barGrp.property('Contents');
  var barRect = barGC.addProperty('ADBE Vector Shape - Rect');
  barRect.property('ADBE Vector Rect Size').setValue([5, wH - 2]);
  barRect.property('ADBE Vector Rect Position').setValue([-wW / 2 + 2.5, 0]);
  barRect.property('ADBE Vector Rect Roundness').setValue(2);
  var barFill = barGC.addProperty('ADBE Vector Graphic - Fill');
  barFill.property('Color').setValue([acRGB[0], acRGB[1], acRGB[2], 1]);

  if (params.animateIn) { try { ebAnimateFadeUp(cliBox, cliFr, fps, 10); } catch(e) {} }

  // ---- "$ " prompt (accent color) + command text (dark) ----
  var cliCmd  = params.cliCommand || 'command --option value';
  var cmdFSz  = 28;
  var cmdX    = dotX + 30;
  // Prompt "$" in green -- baseline at cap-centre of box (DALIGN above box centre)
  var cmdBaseY = cliBoxCY + Math.round(cmdFSz * 0.35); // cap-centre at box centre
  var promptL = ebText(comp, '$', cmdX, cmdBaseY, cmdFSz, 'mono', acRGB, 'left');
  promptL.name = 'EB_CliPrompt';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(promptL, cliFr + 4, fps, 0); } catch(e) {} }
  // Command in dark -- offset by roughly 2 monospace chars ("$ ")
  var charW   = Math.round(cmdFSz * 0.61);  // Courier New ~0.61 em
  var cmdL    = ebText(comp, cliCmd, cmdX + charW * 2, cmdBaseY, cmdFSz, 'mono', [0, 0, 0], 'left');
  cmdL.name   = 'EB_CliCmd';
  if (params.animateIn) { try { ebTextAnimatorFadeUp(cmdL, cliFr + 4, fps, 0); } catch(e) {} }

  // ---- Body text ----
  var bodyText = params.bodyText || '';
  if (bodyText) {
    var bodyTl = ebTextParagraph(comp, bodyText, dotX, bodyY, 30, 'regular', gray,
                   comp.width - dotX - 100);
    bodyTl.name = 'EB_BodyText';
    try { ebTextAnimatorFadeUp(bodyTl, cliFr + 12, fps, 12); } catch(e) {}
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// TEXT LINKS BLOCK
// Title + subtitle + up to 5 resource rows.
// Each row: bold resource name + monospace URL below it,
// separated by a thin horizontal rule between rows.
// params:
//   cards[]: { label: string, url: string }
// =============================================================
function createTextLinksBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var color  = ebColor(params.accentColor || '76B900');
  var acRGB  = [color[0], color[1], color[2]];
  var dark   = [0, 0, 0];
  var sepClr = [0.82, 0.82, 0.82, 1];

  // ---- Geometry ----
  var textX     = 130;
  var lineW     = comp.width - textX - 100;  // 1690
  var nameFSz   = 38;
  var urlFSz    = 30;
  var nameLineH = Math.round(nameFSz * 1.35); // 52
  var urlLineH  = Math.round(urlFSz  * 1.35); // 41
  var NAME_URL_GAP = 8;   // baseline-to-baseline extra gap
  var ITEM_GAP     = 90;  // gap from URL baseline to next name baseline

  // ---- Default content (generic placeholders) ----
  var defaultItems = [
    { label: 'Resource Name',   url: 'resource.example.com/path' },
    { label: 'Resource Name',   url: 'resource.example.com/path' },
    { label: 'Resource Name',   url: 'resource.example.com/path' }
  ];

  var rawItems = (params.cards && params.cards.length) ? params.cards : defaultItems;
  var numItems = Math.min(rawItems.length, 5);

  // ---- Render items ----
  var y = 270;
  for (var i = 0; i < numItems; i++) {
    var item = rawItems[i];
    var iFr  = sf + 18 + i * 10;
    var iNm  = 'EB_Lnk' + i;

    // Separator line above item (not before first item)
    if (i > 0) {
      var sepY   = y - Math.round(ITEM_GAP / 2);
      var sepLyr = comp.layers.addShape();
      sepLyr.name = iNm + '_Sep';
      sepLyr.position.setValue([0, 0]);
      var sGrp = sepLyr.property('Contents').addProperty('ADBE Vector Group');
      sGrp.name = 'Line';
      var sGC   = sGrp.property('Contents');
      var sPth  = sGC.addProperty('ADBE Vector Shape - Group');
      try { sPth.property('ADBE Vector Shape').setValue(ebOpenPath([[textX, sepY], [textX + lineW, sepY]])); } catch(e) {}
      var sStr  = sGC.addProperty('ADBE Vector Graphic - Stroke');
      try { sStr.property('ADBE Vector Stroke Color').setValue(sepClr); } catch(e) {}
      try { sStr.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
      if (params.animateIn) { try { ebAnimateFadeUp(sepLyr, iFr - 2, fps, 0); } catch(e) {} }
    }

    // Resource name (bold, dark)
    var nameLyr = ebText(comp, item.label || 'Resource Name', textX, y, nameFSz, 'bold', dark, 'left');
    nameLyr.name = iNm + '_Name';
    try { ebTextAnimatorFadeUp(nameLyr, iFr, fps, 16); } catch(e) {}
    y += nameLineH + NAME_URL_GAP;

    // URL (NVIDIA Sans regular, accent green)
    var urlLyr = ebText(comp, item.url || 'resource.url/path', textX, y, urlFSz, 'regular', acRGB, 'left');
    urlLyr.name = iNm + '_URL';
    try { ebTextAnimatorFadeUp(urlLyr, iFr + 4, fps, 12); } catch(e) {}
    y += urlLineH + ITEM_GAP;
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// TEXT + BODY + BULLETS BLOCK
// Title + subtitle + up to 4 plain body paragraphs (no dots),
// followed by up to 4 bullet items. Each bullet can have:
//   label: optional bold accent-colored key term (e.g. "Log Location:")
//   text:  description paragraph (word-wrapped, one layer per line)
//   code:  optional monospace path/command with grey pill background
// params:
//   bodyText[]: array of plain paragraph strings
//   cards[]:    { label?, text?, code? }
// =============================================================
function createTextBodyBulletsBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var color = ebColor(params.accentColor);
  var acRGB = [color[0], color[1], color[2]];
  var black   = [0, 0, 0];
  var darkGray = [0, 0, 0];

  // ---- Geometry ----
  var textX      = 130;
  var textW      = comp.width - textX - 100;     // 1690
  var dotX       = 130;
  var dotR       = 8;
  var DALIGN     = 13;                            // dot above baseline (cap-centre for 35px)
  var bulletTextX = dotX + dotR + 22;            // 160
  var bulletTextW = comp.width - bulletTextX - 100; // 1660
  var bodyFSz    = 35;
  var bodyLineH  = Math.round(bodyFSz * 1.35);   // 47px
  var bodyCharW  = 19;   // conservative avg char width for NVIDIA Sans 35px
  var BODY_GAP   = 28;   // gap between consecutive body paragraphs
  var BODY_TO_BULLETS_GAP = 48; // gap from last body para to first bullet
  var BULLET_GAP = 40;   // gap between bullet items
  var codeFSz    = 28;
  var codeCharW  = Math.round(codeFSz * 0.61);   // ~17px (Courier New)
  var codeLineH  = Math.round(codeFSz * 1.35);   // ~38px
  var CODE_GAP   = 12;   // gap above code line within a bullet item
  var bodyCharsPerLine   = Math.floor(textW       / bodyCharW); // 93
  var bulletCharsPerLine = Math.floor(bulletTextW / bodyCharW); // 92

  // ---- Pre-pass: word-wrap body paragraphs ----
  var bodyTextDefaults = ['Opening statement that frames the context and sets up the key points below.'];
  var rawBodyItems = (params.bodyText && params.bodyText.length) ? params.bodyText : bodyTextDefaults;
  var bodyData = [];
  for (var bi = 0; bi < rawBodyItems.length; bi++) {
    bodyData.push({ lines: ebWordWrap(rawBodyItems[bi], bodyCharsPerLine) });
  }

  // ---- Pre-pass: word-wrap bullet descriptions ----
  var maxBullets  = 4;
  var cardDefaults = [
    { label: 'First point',  text: 'Explanation or supporting detail for the first key point.' },
    { label: 'Second point', text: 'Explanation or supporting detail for the second key point.' },
    { label: 'Third point',  text: 'Explanation or supporting detail for the third key point.' }
  ];
  var rawCards   = (params.cards && params.cards.length) ? params.cards : cardDefaults;
  var numBullets = Math.min(rawCards.length, maxBullets);
  var bulletData = [];
  for (var ci = 0; ci < numBullets; ci++) {
    var card = rawCards[ci];
    var hasLabel  = !!(card.label && card.label.length > 0);
    var descLines = card.text ? ebWordWrap(card.text, bulletCharsPerLine) : [];
    bulletData.push({
      label:     card.label || '',
      hasLabel:  hasLabel,
      descLines: descLines,
      code:      card.code || ''
    });
  }

  // ---- Compute Y positions (fixed -- no sourceRectAtTime at create-time) ----
  var y = 310;  // baseline of first content line

  var bodyY = [];
  for (var bi2 = 0; bi2 < bodyData.length; bi2++) {
    bodyY.push(y);
    y += bodyData[bi2].lines.length * bodyLineH;
    if (bi2 < bodyData.length - 1) { y += BODY_GAP; }
  }
  if (bodyData.length > 0) { y += BODY_TO_BULLETS_GAP; }

  var bulletItemY = [];
  for (var ci2 = 0; ci2 < bulletData.length; ci2++) {
    bulletItemY.push(y);
    var bd = bulletData[ci2];
    var itemH = 0;
    if (bd.hasLabel)              { itemH += bodyLineH; }
    itemH += bd.descLines.length  * bodyLineH;
    if (bd.code)                  { itemH += CODE_GAP + codeLineH; }
    y += itemH + BULLET_GAP;
  }

  // ---- Render body paragraphs ----
  for (var bi3 = 0; bi3 < bodyData.length; bi3++) {
    var bLines = bodyData[bi3].lines;
    for (var li = 0; li < bLines.length; li++) {
      var lY  = bodyY[bi3] + li * bodyLineH;
      var fr  = sf + 18 + bi3 * 6 + li * 2;
      var tl  = ebText(comp, bLines[li], textX, lY, bodyFSz, 'regular', darkGray, 'left');
      tl.name = 'EB_Body' + bi3 + '_L' + li;
      try { ebTextAnimatorFadeUp(tl, fr, fps, 18); } catch(e) {}
    }
  }

  // ---- Render bullet items ----
  var bulletStartFrame = sf + 18 + bodyData.length * 6 + 10;
  for (var ci3 = 0; ci3 < bulletData.length; ci3++) {
    var bd3  = bulletData[ci3];
    var fr3  = bulletStartFrame + ci3 * 8;
    var bn   = 'EB_Bul' + ci3;
    var curY = bulletItemY[ci3];

    // Dot aligned to cap-centre of first text line in this bullet
    var dot = ebDot(comp, dotX, curY - DALIGN, dotR, color, bn + '_Dot');
    dot.label = 9;
    if (params.animateIn) { try { ebAnimateFadeUp(dot, fr3, fps, 15); } catch(e) {} }

    // Bold label (accent color) -- optional
    if (bd3.hasLabel) {
      var lbl = ebText(comp, bd3.label, bulletTextX, curY, bodyFSz, 'bold', acRGB, 'left');
      lbl.name = bn + '_Lbl';
      try { ebTextAnimatorFadeUp(lbl, fr3 + 2, fps, 12); } catch(e) {}
      curY += bodyLineH;
    }

    // Description lines (one ebText layer per wrapped line)
    for (var li3 = 0; li3 < bd3.descLines.length; li3++) {
      var dL  = ebText(comp, bd3.descLines[li3], bulletTextX, curY, bodyFSz, 'regular', black, 'left');
      dL.name = bn + '_Desc' + li3;
      try { ebTextAnimatorFadeUp(dL, fr3 + 4 + li3 * 2, fps, 15); } catch(e) {}
      curY += bodyLineH;
    }

    // Code path with grey pill background
    if (bd3.code) {
      curY += CODE_GAP;
      var codeL = ebText(comp, bd3.code, bulletTextX, curY, codeFSz, 'mono', [0, 0, 0], 'left');
      codeL.name = bn + '_Code';
      try { ebTextAnimatorFadeUp(codeL, fr3 + 6, fps, 0); } catch(e) {}
      var bgL = ebAddCodeBg(comp, codeL, bd3.code, bulletTextX, curY, codeFSz, codeCharW);
      if (params.animateIn) { try { ebAnimateFadeUp(bgL, fr3 + 6, fps, 0); } catch(e) {} }
    }
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// TEXT ERRORS BLOCK
// Title + subtitle + up to 3 error groups inside ONE unified card:
//   "Error: " bold accent label + monospaced error name (same line)
//   Sub-bullets: bold prefix ("Meaning:" / "Fix:") + description
// params:
//   cards[]: { code: '...', items: [{ label: '...', text: '...' }] }
// =============================================================
function createTextErrorsBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var cRGB     = [color[0], color[1], color[2]];
  var black    = [0, 0, 0];
  var L        = EB_LAYOUT;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var _noFill8 = (params.cardBg === false);
  var bgLayer = ebCreateCardBg(comp, card, 'EB_ErrBG', null, borderClr, showShadow, _noFill8, null);
  if (params.animateIn) { try { ebAnimateFadeUp(bgLayer, sf + 36, fps, 40); } catch(e) {} }

  // Layout
  var cardLeft = card.x - card.w / 2;  // 80
  var labelX   = cardLeft + L.cardPadX; // 112
  var codeX    = labelX + 168;          // 280 — after "Error:  " (~8 chars × 21px)
  var descCol  = labelX + 210;          // 322 — after "Meaning:  " (~10 chars × 18px + gap)
  var zoneTop  = card.y - card.h / 2 + 60;  // 290

  var errFSz   = 32;  // "Error:" header
  var monoFSz  = 28;  // error code (mono)
  var subFSz   = 28;  // Meaning / Fix rows
  var hdrToRow = 58;  // vertical gap from group top to first sub-row
  var rowStep  = 52;  // vertical spacing between sub-rows

  var defaultErrors = [
    {
      code: 'ErrorCodeOrName',
      items: [
        { label: 'Meaning:', text: 'Description of what this error means and when it typically occurs.' },
        { label: 'Fix:', text: 'Steps to resolve or work around this error effectively.' }
      ]
    },
    {
      code: 'AnotherError',
      items: [
        { label: 'Meaning:', text: 'Description of what this error means and when it typically occurs.' },
        { label: 'Fix:', text: 'Steps to resolve or work around this error effectively.' }
      ]
    }
  ];

  var rawErrors = (params.cards && params.cards.length) ? params.cards : defaultErrors;
  var numErrors = Math.min(rawErrors.length, 3);

  // Each group height: errFSz line + hdrToRow gap + 2 sub-rows
  var groupH  = hdrToRow + 2 * rowStep;  // 58+104 = 162
  var divGap  = 44;                       // space around divider line

  var groupY = zoneTop + 20;  // top of first error group

  for (var i = 0; i < numErrors; i++) {
    var err   = rawErrors[i];
    var code  = err.code || err.label || 'Error';
    var items = (err.items && err.items.length) ? err.items :
                [{ label: 'Meaning:', text: '' }, { label: 'Fix:', text: '' }];
    var fr    = sf + 36 + i * 14;
    var hdrY  = groupY + Math.round(errFSz * 0.38);  // baseline of header row

    // ── Error header: "Error:" (bold, accent) + code (mono, black) ──
    var errLbl = ebText(comp, 'Error:', labelX, hdrY, errFSz, 'bold', cRGB, 'left');
    errLbl.name = 'EB_Err' + i + '_Lbl';
    ebTextAnimatorFadeUp(errLbl, fr, fps, 12);

    var errCode = ebText(comp, code, codeX, hdrY, monoFSz, 'mono', black, 'left');
    errCode.name = 'EB_Err' + i + '_Code';
    ebTextAnimatorFadeUp(errCode, fr + 2, fps, 12);

    // ── Sub-rows: "Meaning:" / "Fix:" label + description ──
    for (var j = 0; j < items.length && j < 2; j++) {
      var it   = items[j];
      var iFr  = fr + 6 + j * 4;
      var rowY = groupY + hdrToRow + j * rowStep;
      var iY   = rowY + Math.round(subFSz * 0.38);  // baseline

      var lbl = ebText(comp, it.label || '', labelX, iY, subFSz, 'semibold', black, 'left');
      lbl.name = 'EB_Err' + i + '_I' + j + '_Lbl';
      ebTextAnimatorFadeUp(lbl, iFr, fps, 12);

      if (it.text) {
        var desc = ebText(comp, it.text, descCol, iY, subFSz, 'regular', black, 'left');
        desc.name = 'EB_Err' + i + '_I' + j + '_Desc';
        ebTextAnimatorFadeUp(desc, iFr + 2, fps, 15);
      }
    }

    // ── Horizontal divider between error groups ──
    if (i < numErrors - 1) {
      var divY    = groupY + groupH + divGap / 2;
      var lineL   = labelX;
      var lineR   = card.x + card.w / 2 - L.cardPadX;
      var divLyr  = comp.layers.addShape();
      divLyr.name = 'EB_ErrDiv' + i;
      divLyr.position.setValue([0, 0]);
      var dvGC  = divLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var dvPth = dvGC.addProperty('ADBE Vector Shape - Group');
      try { dvPth.property('ADBE Vector Shape').setValue(ebOpenPath([[lineL, divY], [lineR, divY]])); } catch(e) {}
      var dvStr = dvGC.addProperty('ADBE Vector Graphic - Stroke');
      try { dvStr.property('ADBE Vector Stroke Color').setValue([0.25, 0.25, 0.25, 1]); } catch(e) {}
      try { dvStr.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
      if (params.animateIn) {
        var dvTrim = dvGC.addProperty('ADBE Vector Filter - Trim');
        var dvTrimEnd = dvTrim.property('ADBE Vector Trim End');
        try { divLyr.inPoint = (fr + 10) / fps; } catch(e) {}
        try { ebAnimateTrimDraw(dvTrimEnd, fr + 10, fps); } catch(e) {}
      }

      groupY = divY + divGap / 2;
    }
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// DIAGRAM PROCESS-2
// Title + subtitle + 2 horizontal process rows.
// Each row has a bold green centered label above 3 nodes
// connected by green arrows (line + filled arrowhead).
// params:
//   rows[]: { label: string, nodes: [{ text, sub? }] }
// =============================================================
function createDiagramProcess2Block(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor || '76B900');
  var acColor  = [color[0], color[1], color[2]];
  var acArr    = [color[0], color[1], color[2], 1];
  var darkGray   = [0, 0, 0];
  var midGray    = [0, 0, 0];
  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  // ---- Geometry ----
  var nodeW      = 430;
  var nodeH      = 150;
  var arrowGap   = 95;   // space between node edges (contains the connector)
  var CONN_PAD   = 12;   // gap between arrowhead/line and node edge
  var labelFSz   = 34;
  var mainFSz    = 30;
  var subFSz     = 24;
  // Center 3 nodes across the full comp width
  var totalW    = 3 * nodeW + 2 * arrowGap;  // 1480
  var leftStart = Math.round((comp.width - totalW) / 2); // 220

  var nodeCXs = [];
  for (var ni0 = 0; ni0 < 3; ni0++) {
    nodeCXs.push(leftStart + ni0 * (nodeW + arrowGap) + Math.round(nodeW / 2));
  }
  // nodeCXs = [435, 960, 1485]

  // Two rows: label Y + node CY -- fills cardTop(230) to cardBottom(980)
  var rowLabelYs = [260, 550];
  var rowNodeCYs = [380, 670];

  // ---- Default content (generic placeholders) ----
  var defaultRows = [
    {
      label: 'Row Label 1',
      nodes: [
        { text: 'Step 1', sub: 'description' },
        { text: 'Step 2', sub: 'description' },
        { text: 'Step 3', sub: 'description' }
      ]
    },
    {
      label: 'Row Label 2',
      nodes: [
        { text: 'Step 1', sub: 'description' },
        { text: 'Step 2', sub: 'description' },
        { text: 'Step 3', sub: 'description' }
      ]
    }
  ];

  var rows = (params.rows && params.rows.length >= 2) ? params.rows : defaultRows;

  // ---- Render rows ----
  for (var ri = 0; ri < 2; ri++) {
    var row  = rows[ri];
    var rCY  = rowNodeCYs[ri];
    var rLY  = rowLabelYs[ri];
    var rFr  = sf + 15 + ri * 32;

    // Row label (bold green, centered)
    var lbl = ebText(comp, row.label, 960, rLY, labelFSz, 'bold', acColor, 'center');
    lbl.name = 'EB_R' + ri + '_Lbl';
    try { ebTextAnimatorFadeUp(lbl, rFr, fps, 16); } catch(e) {}

    // Pass 1: node backgrounds + text (bgs land at bottom of comp stack)
    var nodeArr = row.nodes || [];
    for (var ni = 0; ni < 3; ni++) {
      var nd  = nodeArr[ni] || { text: 'Step ' + (ni + 1) };
      var nCX = nodeCXs[ni];
      var nFr = rFr + 8 + ni * 8;
      var nNm = 'EB_R' + ri + 'N' + ni;

      // Node card background
      var nodeCard  = { x: nCX, y: rCY, w: nodeW, h: nodeH };
      var _p2NoFill = (params.cardBg === false);
      var _p2Fill   = (params.shapeFill === false) ? null : color;
      var bgLyr = ebCreateCardBg(comp, nodeCard, nNm + '_Bg', null, borderClr, showShadow, _p2NoFill, _p2Fill);
      ebTextAnimatorFadeUp(bgLyr, nFr, fps, 10);

      // Main text -- vertically centered in node
      var hasSub  = !!(nd.sub && nd.sub.length > 0);
      var mainY   = hasSub ? rCY - 12 : rCY + 10;
      var mainLyr = ebText(comp, nd.text, nCX, mainY, mainFSz, 'bold', darkGray, 'center');
      mainLyr.name = nNm + '_Txt';
      try { ebTextAnimatorFadeUp(mainLyr, nFr + 4, fps, 10); } catch(e) {}

      // Sub text
      if (hasSub) {
        var subLyr  = ebText(comp, nd.sub, nCX, rCY + 22, subFSz, 'regular', midGray, 'center');
        subLyr.name = nNm + '_Sub';
        try { ebTextAnimatorFadeUp(subLyr, nFr + 6, fps, 10); } catch(e) {}
      }
    }

    // Pass 2: connectors added last -- render on top of node bgs
    for (var ai = 0; ai < 2; ai++) {
      var srcX    = nodeCXs[ai];
      var dstX    = nodeCXs[ai + 1];
      var aFr     = rFr + 8 + ai * 8 + 5;
      var halfW   = Math.round(nodeW / 2);

      var connLyr = comp.layers.addShape();
      connLyr.name = 'EB_R' + ri + 'Conn' + ai;
      connLyr.position.setValue([0, 0]);
      var cc = connLyr.property('Contents');

      // Arrow line (stroke)
      var lineGrp = cc.addProperty('ADBE Vector Group');
      lineGrp.name = 'Line';
      var lGC  = lineGrp.property('Contents');
      var lPath = lGC.addProperty('ADBE Vector Shape - Group');
      try {
        lPath.property('ADBE Vector Shape').setValue(
          ebOpenPath([[srcX + halfW + CONN_PAD, rCY], [dstX - halfW - CONN_PAD, rCY]])
        );
      } catch(e) {}
      var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
      try { lStr.property('ADBE Vector Stroke Color').setValue(acArr); } catch(e) {}
      try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
      try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}

      // Arrowhead (V-stroke -- fill unreliable in AE 2024+)
      var arrGrp = cc.addProperty('ADBE Vector Group');
      arrGrp.name = 'Arrow';
      var aGC  = arrGrp.property('Contents');
      var aPth = aGC.addProperty('ADBE Vector Shape - Group');
      var aX   = dstX - halfW - CONN_PAD;
      try { aPth.property('ADBE Vector Shape').setValue(ebOpenPath([[aX - 11, rCY - 8], [aX, rCY], [aX - 11, rCY + 8]])); } catch(e) {}
      var aStr = aGC.addProperty('ADBE Vector Graphic - Stroke');
      try { aStr.property('ADBE Vector Stroke Color').setValue(acArr); } catch(e) {}
      try { aStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
      try { aStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
      try { aStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}

      ebFadeOnly(connLyr, aFr, fps);
    }
  }

  ebCreateHeader(comp, params, sf);
}


// =============================================================
// ELEMENTS  (single-layer or small-group reusable components)
// ASCII-only: AE ExtendScript reads JSX as Latin-1.
// =============================================================
function createElementBlock(comp, params) {
  var fps     = comp.frameRate;
  var L       = EB_LAYOUT;
  var acColor = ebColor(params.accentColor || '76B900');
  var acRGB   = [acColor[0], acColor[1], acColor[2]];
  var black   = [0, 0, 0];
  var white   = [1, 1, 1];
  var f0      = 1;
  var cx      = 960;
  var cy      = 540;
  var bt      = params.blockType;

  // ── Shared inner helpers ──────────────────────────────────

  // Returns {lyr, gc} where gc = Contents of the first Vector Group.
  function newShape(name, x, y) {
    var lyr = comp.layers.addShape();
    lyr.name = name;
    lyr.position.setValue([x !== undefined ? x : cx, y !== undefined ? y : cy]);
    var grp = lyr.property('Contents').addProperty('ADBE Vector Group');
    return { lyr: lyr, gc: grp.property('Contents') };
  }

  // Add a rect to gc. Pass null fillColor to omit fill (transparent).
  function gcRect(gc, w, h, rx, fillColor, strokeColor, strokeW) {
    var r = gc.addProperty('ADBE Vector Shape - Rect');
    try { r.property('ADBE Vector Rect Size').setValue([w, h]); } catch(e) {}
    if (rx) { try { r.property('ADBE Vector Rect Roundness').setValue(rx); } catch(e) {} }
    if (fillColor) {
      var f = gc.addProperty('ADBE Vector Graphic - Fill');
      try { f.property('ADBE Vector Fill Color').setValue(fillColor); } catch(e) {}
    } else {
      var nf = gc.addProperty('ADBE Vector Graphic - Fill');
      try { nf.property('ADBE Vector Fill Opacity').setValue(0); } catch(e) {}
    }
    if (strokeColor) {
      var s = gc.addProperty('ADBE Vector Graphic - Stroke');
      try { s.property('ADBE Vector Stroke Color').setValue(strokeColor); } catch(e) {}
      try { s.property('ADBE Vector Stroke Width').setValue(strokeW || 3); } catch(e) {}
    }
  }

  // Add an open-path line to gc.
  function gcLine(gc, pts, strokeColor, strokeW, roundCap) {
    var sp = gc.addProperty('ADBE Vector Shape - Group');
    try { sp.property('ADBE Vector Shape').setValue(ebOpenPath(pts)); } catch(e) {}
    var st = gc.addProperty('ADBE Vector Graphic - Stroke');
    try { st.property('ADBE Vector Stroke Color').setValue(strokeColor); } catch(e) {}
    try { st.property('ADBE Vector Stroke Width').setValue(strokeW || 3); } catch(e) {}
    if (roundCap) { try { st.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {} }
  }

  // Add a filled closed polygon to gc.
  function gcPoly(gc, pts, fillColor) {
    var sp = gc.addProperty('ADBE Vector Shape - Group');
    var sh = new Shape();
    sh.vertices = pts;
    sh.inTangents  = []; sh.outTangents = [];
    for (var i = 0; i < pts.length; i++) { sh.inTangents.push([0,0]); sh.outTangents.push([0,0]); }
    sh.closed = true;
    try { sp.property('ADBE Vector Shape').setValue(sh); } catch(e) {}
    var f = gc.addProperty('ADBE Vector Graphic - Fill');
    try { f.property('ADBE Vector Fill Color').setValue(fillColor); } catch(e) {}
  }

  // Add ellipse to gc.
  function gcEllipse(gc, diam, fillColor, strokeColor, strokeW) {
    var e = gc.addProperty('ADBE Vector Shape - Ellipse');
    try { e.property('ADBE Vector Ellipse Size').setValue([diam, diam]); } catch(e) {}
    if (fillColor) {
      var f = gc.addProperty('ADBE Vector Graphic - Fill');
      try { f.property('ADBE Vector Fill Color').setValue(fillColor); } catch(e) {}
    } else {
      var nf = gc.addProperty('ADBE Vector Graphic - Fill');
      try { nf.property('ADBE Vector Fill Opacity').setValue(0); } catch(e) {}
    }
    if (strokeColor) {
      var s = gc.addProperty('ADBE Vector Graphic - Stroke');
      try { s.property('ADBE Vector Stroke Color').setValue(strokeColor); } catch(e) {}
      try { s.property('ADBE Vector Stroke Width').setValue(strokeW || 3); } catch(e) {}
    }
  }

  // Optional fade-up wrapper (respects params.animateIn).
  function anim(lyr, frame, yOff) {
    if (!params.animateIn) return;
    try { ebAnimateFadeUp(lyr, frame || f0, fps, yOff || 20); } catch(e) {}
  }
  function animTxt(lyr, frame) {
    if (!params.animateIn) return;
    try { ebTextAnimatorFadeUp(lyr, frame || f0, fps, 20); } catch(e) {}
  }
  // Scale pop-in (80% -> 100%) for shape elements, combined with fade.
  function animShape(lyr, frame) {
    if (!params.animateIn) return;
    try { ebAnimateFadeUp(lyr, frame || f0, fps, 0); } catch(e) {}
    try {
      var fr  = frame || f0;
      var dur = 14;
      var sp  = lyr.transform.scale;
      sp.setValueAtTime(fr / fps,         [80, 80]);
      sp.setValueAtTime((fr + dur) / fps, [100, 100]);
      var eIn  = new KeyframeEase(0.5, 80);
      var eOut = new KeyframeEase(0.5, 20);
      try { sp.setTemporalEaseAtKey(sp.nearestKeyIndex(fr / fps),         [eIn,  eIn]);  } catch(e) {}
      try { sp.setTemporalEaseAtKey(sp.nearestKeyIndex((fr + dur) / fps), [eOut, eOut]); } catch(e) {};
    } catch(e) {}
  }

  // ── LINES & CONNECTORS ───────────────────────────────────

  if (bt === 'element-line-h') {
    var s = newShape('EB_LineH', cx, cy);
    gcLine(s.gc, [[-400, 0], [400, 0]], acColor, 4, true);
    if (params.animateIn) {
      try {
        var trim = s.gc.addProperty('ADBE Vector Filter - Trim');
        ebAnimateTrimDraw(trim.property('End'), f0, fps);
      } catch(e) {}
    }
    return;
  }

  if (bt === 'element-line-v') {
    var s = newShape('EB_LineV', cx, cy);
    gcLine(s.gc, [[0, -300], [0, 300]], acColor, 4, true);
    if (params.animateIn) {
      try {
        var trim = s.gc.addProperty('ADBE Vector Filter - Trim');
        ebAnimateTrimDraw(trim.property('End'), f0, fps);
      } catch(e) {}
    }
    return;
  }

  if (bt === 'element-arrow') {
    var s = newShape('EB_Arrow', cx, cy);
    gcLine(s.gc, [[-360, 0], [300, 0]], acColor, 4, true);
    gcPoly(s.gc, [[300, -20], [370, 0], [300, 20]], acColor);
    anim(s.lyr, f0);
    return;
  }

  if (bt === 'element-arrow-bi') {
    var s = newShape('EB_ArrowBi', cx, cy);
    gcLine(s.gc, [[-300, 0], [300, 0]], acColor, 4);
    gcPoly(s.gc, [[-300, -20], [-370, 0], [-300, 20]], acColor);
    gcPoly(s.gc, [[300, -20],  [370, 0],  [300, 20]],  acColor);
    anim(s.lyr, f0);
    return;
  }

  if (bt === 'element-bracket') {
    var s = newShape('EB_Bracket', cx, cy);
    gcLine(s.gc, [[-380, 0],  [380, 0]],  acColor, 3, true);
    gcLine(s.gc, [[-380,-44], [-380, 44]], acColor, 3, true);
    gcLine(s.gc, [[380, -44], [380, 44]],  acColor, 3, true);
    anim(s.lyr, f0);
    var lbl = ebText(comp, params.title || 'Label', cx, cy - 60, 30, 'bold', acRGB, 'center');
    lbl.name = 'EB_BracketLabel';
    animTxt(lbl, f0 + 10);
    return;
  }

  if (bt === 'element-connector') {
    var ax = cx - 320; var ay = cy - 160;
    var bx = cx + 320; var by = cy + 160;

    // Elbow line: its own layer so its stroke never shares a group with the arrowhead fill.
    var ls = comp.layers.addShape(); ls.name = 'EB_ConnLine';
    ls.position.setValue([0, 0]);
    var lgrp = ls.property('Contents').addProperty('ADBE Vector Group');
    var lgc  = lgrp.property('Contents');
    gcLine(lgc, [[ax, ay], [ax, by], [bx - 30, by]], acColor, 3, true);

    // Arrowhead: newShape at [bx, by] so coords are relative — safe for anim().
    var la = newShape('EB_ConnArrow', bx, by);
    gcPoly(la.gc, [[-30, -16], [4, 0], [-30, 16]], acColor);

    // Node A / Node B circles
    var na = newShape('EB_NodeA', ax, ay);
    gcEllipse(na.gc, 30, acColor);
    var nb = newShape('EB_NodeB', bx, by);
    gcEllipse(nb.gc, 30, acColor);

    if (params.animateIn) {
      // Node A appears first
      anim(na.lyr, f0);
      // Line draws via Trim Path
      try {
        var trim = lgc.addProperty('ADBE Vector Filter - Trim');
        ebAnimateTrimDraw(trim.property('End'), f0 + 4, fps);
      } catch(e) { anim(ls, f0 + 4); }
      // Arrowhead and node B appear when line reaches them
      anim(la.lyr, f0 + 20);
      anim(nb.lyr, f0 + 20);
    }
    return;
  }

  // ── SHAPES ──────────────────────────────────────────────

  if (bt === 'element-rect') {
    var s = newShape('EB_Rect', cx, cy);
    gcRect(s.gc, 700, 280, 8, acColor);
    animShape(s.lyr, f0);
    return;
  }

  if (bt === 'element-rect-outline') {
    var s = newShape('EB_RectOutline', cx, cy);
    gcRect(s.gc, 700, 280, 8, null, acColor, 4);
    animShape(s.lyr, f0);
    return;
  }

  if (bt === 'element-circle') {
    var s = newShape('EB_Circle', cx, cy);
    gcEllipse(s.gc, 300, acColor);
    animShape(s.lyr, f0);
    return;
  }

  if (bt === 'element-pill') {
    var s = newShape('EB_Pill', cx, cy);
    gcRect(s.gc, 500, 80, 40, acColor);
    var lbl = ebText(comp, params.title || 'Tag Label', cx, cy, 28, 'bold', white, 'center');
    lbl.name = 'EB_PillLabel';
    try { lbl.anchorPoint.setValue([0, -Math.round(28 * 0.35)]); } catch(e) {}
    animShape(s.lyr, f0); animTxt(lbl, f0 + 6);
    return;
  }

  if (bt === 'element-diamond') {
    var s = newShape('EB_Diamond', cx, cy);
    gcPoly(s.gc, [[0,-200],[280,0],[0,200],[-280,0]], acColor);
    animShape(s.lyr, f0);
    return;
  }

  if (bt === 'element-badge') {
    var s = newShape('EB_BadgeBg', cx, cy);
    gcRect(s.gc, 640, 100, 6, [0.14,0.14,0.14,1], acColor, 1.5);
    var acc = newShape('EB_BadgeAccent', cx - 316, cy);
    gcRect(acc.gc, 12, 100, 3, acColor);
    var lbl = ebText(comp, params.title || 'Badge Label', cx + 20, cy, 30, 'bold', [0.88,0.88,0.88], 'center');
    lbl.name = 'EB_BadgeLabel';
    try { lbl.anchorPoint.setValue([0, -Math.round(30 * 0.35)]); } catch(e) {}
    animShape(s.lyr, f0); animShape(acc.lyr, f0 + 3); animTxt(lbl, f0 + 6);
    return;
  }

  // ── TEXT ────────────────────────────────────────────────

  if (bt === 'element-headline') {
    var t = ebText(comp, params.title || 'Headline Text', cx, cy - 20, 72, 'bold', black, 'center');
    t.name = 'EB_Headline';
    var sub = ebText(comp, params.subtitle || '', cx, cy + 58, 38, 'regular', acRGB, 'center');
    sub.name = 'EB_HeadlineSub';
    animTxt(t, f0); animTxt(sub, f0 + 10);
    return;
  }

  if (bt === 'element-body-text') {
    var t = ebTextParagraph(comp,
      params.title || 'Body text goes here. This paragraph wraps automatically to multiple lines.',
      L.marginX, 440, 32, 'regular', black, 1760);
    t.name = 'EB_BodyText';
    animTxt(t, f0);
    return;
  }

  if (bt === 'element-quote') {
    // Left accent bar
    var bar = newShape('EB_QuoteBar', L.marginX, cy);
    gcRect(bar.gc, 6, 280, 0, acColor);
    // Quote text
    var qt = ebTextParagraph(comp,
      params.title || '"Your quote goes here."',
      L.marginX + 56, cy - 72, 36, 'regular', black, 1320);
    qt.name = 'EB_QuoteText';
    // Attribution
    var attr = ebText(comp, params.subtitle || 'Attribution', L.marginX + 56, cy + 128, 24, 'semibold', acRGB, 'left');
    attr.name = 'EB_QuoteAttr';
    anim(bar.lyr, f0); animTxt(qt, f0 + 5); animTxt(attr, f0 + 12);
    return;
  }

  if (bt === 'element-code-inline') {
    var bg = newShape('EB_CodeBg', cx, cy);
    gcRect(bg.gc, 1400, 110, 8, [0.06,0.06,0.06,1], [0.22,0.22,0.22,1], 1);
    var ct = ebText(comp, params.title || '$ command --option value', cx, cy, 30, 'mono', acRGB, 'center');
    ct.name = 'EB_CodeText';
    try { ct.anchorPoint.setValue([0, -Math.round(30 * 0.35)]); } catch(e) {}
    anim(bg.lyr, f0); animTxt(ct, f0 + 4);
    return;
  }

  if (bt === 'element-cli') {
    var wW = 1400; var wH = 380;
    // Window body
    var win = newShape('EB_CliWin', cx, cy);
    gcRect(win.gc, wW, wH, 10, [0.07,0.07,0.07,1], [0.18,0.18,0.18,1], 1.5);
    // Title bar
    var tbar = newShape('EB_CliBar', cx, cy - wH/2 + 24);
    gcRect(tbar.gc, wW, 48, 0, [0.13,0.13,0.13,1]);
    // Traffic-light dots
    var dotData = [
      { name:'EB_CliR', x: cx - wW/2 + 28, c:[0.87,0.33,0.33,1] },
      { name:'EB_CliY', x: cx - wW/2 + 56, c:[0.98,0.76,0.0, 1] },
      { name:'EB_CliG', x: cx - wW/2 + 84, c:[acColor[0],acColor[1],acColor[2],1] }
    ];
    for (var di = 0; di < dotData.length; di++) {
      var dl = newShape(dotData[di].name, dotData[di].x, cy - wH/2 + 24);
      gcEllipse(dl.gc, 20, dotData[di].c);
    }
    // Code lines
    var cLines = [
      { txt: '$ ' + (params.title || 'run-script --config prod.yaml'), col: acRGB,                y: cy - 70  },
      { txt: params.subtitle || '> Building project...',               col: [0.7,0.7,0.7],        y: cy - 10  },
      { txt: '> [OK] Completed in 2.4s',                               col: [0,0,0],        y: cy + 50  },
      { txt: '$',                                                       col: acRGB,                y: cy + 110 }
    ];
    for (var li = 0; li < cLines.length; li++) {
      var cl = ebText(comp, cLines[li].txt, cx - wW/2 + 40, cLines[li].y, 26, 'mono', cLines[li].col, 'left');
      cl.name = 'EB_CliL' + li;
      if (params.animateIn) { try { ebTextAnimatorFadeUp(cl, f0 + li * 8, fps, 0); } catch(e) {} }
    }
    anim(win.lyr, f0); anim(tbar.lyr, f0);
    return;
  }

  if (bt === 'element-auto-text') {
    var bodyW = 1200;
    var bg = newShape('EB_AutoBg', cx, cy);
    gcRect(bg.gc, bodyW + 120, 200, 8, [0.94,0.94,0.94,1]);
    var t = ebTextParagraph(comp,
      params.title || 'Auto-resizing text box. This background grows to fit the content.',
      cx - bodyW/2, cy - 50, 32, 'regular', black, bodyW);
    t.name = 'EB_AutoText';
    bg.lyr.moveAfter(t);
    anim(bg.lyr, f0); animTxt(t, f0 + 5);
    return;
  }

  // ── BULLETS ─────────────────────────────────────────────

  if (bt === 'element-bullet') {
    var bar = newShape('EB_BBar', L.marginX + 4, cy);
    gcRect(bar.gc, L.bulletBarW, L.bulletBarH, 0, acColor);
    var t = ebTextParagraph(comp,
      params.title || 'Bullet point text. Replace with your content.',
      L.marginX + 40, cy - 14, 34, 'regular', black, 1740);
    t.name = 'EB_BText';
    anim(bar.lyr, f0); animTxt(t, f0 + 4);
    return;
  }

  if (bt === 'element-bullet-sub') {
    var topY = cy - 90; var subY = cy + 80;
    var bar = newShape('EB_BBar', L.marginX + 4, topY);
    gcRect(bar.gc, L.bulletBarW, L.bulletBarH, 0, acColor);
    var t = ebTextParagraph(comp,
      params.title || 'Main bullet point text.',
      L.marginX + 40, topY - 14, 34, 'regular', black, 1740);
    t.name = 'EB_BText';
    var subBar = newShape('EB_SubBar', L.marginX + 60, subY);
    gcRect(subBar.gc, L.bulletBarW - 1, L.bulletBarH - 18, 0, [acColor[0],acColor[1],acColor[2],0.6]);
    var st = ebTextParagraph(comp,
      params.subtitle || 'Supporting sub-point with additional context.',
      L.marginX + 100, subY - 10, 28, 'regular', [0.37,0.37,0.37], 1700);
    st.name = 'EB_SubText';
    anim(bar.lyr, f0); animTxt(t, f0 + 4);
    anim(subBar.lyr, f0 + 10); animTxt(st, f0 + 14);
    return;
  }

  if (bt === 'element-numbered') {
    var numX = L.marginX + 28;
    var bg = newShape('EB_NumBg', numX, cy);
    gcRect(bg.gc, 56, 56, 8, acColor);
    var numT = ebText(comp, '1', numX, cy, 32, 'bold', white, 'center');
    numT.name = 'EB_NumT';
    try { numT.anchorPoint.setValue([0, -Math.round(32 * 0.35)]); } catch(e) {}
    var t = ebTextParagraph(comp,
      params.title || 'Numbered list item with supporting body text.',
      L.marginX + 80, cy - 12, 34, 'regular', black, 1680);
    t.name = 'EB_NumBody';
    anim(bg.lyr, f0); animTxt(numT, f0 + 3); animTxt(t, f0 + 6);
    return;
  }

  if (bt === 'element-check') {
    var cbX = L.marginX + 28;
    var cb = newShape('EB_CheckBox', cbX, cy);
    gcRect(cb.gc, 52, 52, 7, null, acColor, 3);
    var ck = newShape('EB_Checkmark', cbX, cy);
    gcLine(ck.gc, [[-14, 2], [-4, 14], [15,-14]], acColor, 4, true);
    var t = ebTextParagraph(comp,
      params.title || 'Checklist item text.',
      L.marginX + 80, cy - 12, 34, 'regular', black, 1680);
    t.name = 'EB_CheckTxt';
    anim(cb.lyr, f0); animTxt(t, f0 + 4); anim(ck.lyr, f0 + 8);
    return;
  }

  if (bt === 'element-icon-label') {
    var iconX = L.marginX + 40;
    var ib = newShape('EB_IconBox', iconX, cy);
    gcRect(ib.gc, 80, 80, 12, [0.12,0.12,0.12,1], acColor, 1.5);
    var ic = newShape('EB_IconMark', iconX, cy);
    gcLine(ic.gc, [[-20, 0], [20, 0]], acColor, 3, true);
    gcLine(ic.gc, [[0, -20], [0, 20]], acColor, 3, true);
    var t = ebTextParagraph(comp,
      params.title || 'Icon label text',
      L.marginX + 112, cy - 12, 34, 'semibold', black, 1660);
    t.name = 'EB_IconLbl';
    anim(ib.lyr, f0); anim(ic.lyr, f0 + 4); animTxt(t, f0 + 6);
    return;
  }

  // ── CALLOUTS & NOTES ────────────────────────────────────

  if (bt === 'element-callout-l' || bt === 'element-callout-r') {
    var isLeft = (bt === 'element-callout-l');
    var bW = 900; var bH = 300;
    var bX = isLeft ? cx - 80 : cx + 80;
    var box = newShape('EB_CBox', bX, cy);
    gcRect(box.gc, bW, bH, 12, [0.12,0.12,0.12,1]);
    var triX = isLeft ? bX + bW/2 : bX - bW/2;
    var tri = newShape('EB_CTri', triX, cy);
    var triPts = isLeft ? [[0,-28],[54,0],[0,28]] : [[0,-28],[-54,0],[0,28]];
    gcPoly(tri.gc, triPts, [0.12,0.12,0.12,1]);
    var txLeft = bX - bW/2 + 40;
    var ttl = ebText(comp, params.title || 'Callout Header', txLeft, cy - 72, 34, 'bold', acRGB, 'left');
    ttl.name = 'EB_CTitle';
    var body = ebTextParagraph(comp, params.subtitle || 'Callout body text.', txLeft, cy - 22, 28, 'regular', [0.78,0.78,0.78], bW - 80);
    body.name = 'EB_CBody';
    anim(box.lyr, f0); anim(tri.lyr, f0); animTxt(ttl, f0 + 5); animTxt(body, f0 + 8);
    return;
  }

  if (bt === 'element-tooltip') {
    var bW = 700; var bH = 160;
    var box = newShape('EB_TBox', cx, cy - 100);
    gcRect(box.gc, bW, bH, 10, [0.12,0.12,0.12,1]);
    var tri = newShape('EB_TTri', cx, cy - 100 + bH/2);
    gcPoly(tri.gc, [[-20,0],[20,0],[0,28]], [0.12,0.12,0.12,1]);
    var t = ebTextParagraph(comp, params.title || 'Tooltip text here', cx - bW/2 + 28, cy - 132, 28, 'regular', [0.88,0.88,0.88], bW - 56);
    t.name = 'EB_TTxt';
    anim(box.lyr, f0); anim(tri.lyr, f0); animTxt(t, f0 + 4);
    return;
  }

  if (bt === 'element-note') {
    var bW = 1400; var bH = 200;
    var box = newShape('EB_NBox', cx, cy);
    gcRect(box.gc, bW, bH, 10, [0.12,0.12,0.12,1]);
    var acc = newShape('EB_NAcc', cx - bW/2 + 4, cy);
    gcRect(acc.gc, 8, bH, 3, acColor);
    var t = ebTextParagraph(comp, params.title || 'Note: important information here.', cx - bW/2 + 58, cy - 32, 30, 'regular', [0.88,0.88,0.88], bW - 100);
    t.name = 'EB_NTxt';
    anim(box.lyr, f0); anim(acc.lyr, f0 + 3); animTxt(t, f0 + 5);
    return;
  }

  if (bt === 'element-sticky') {
    var sW = 500; var sH = 400;
    var yC = [0.98,0.76,0.0,1];
    var box = newShape('EB_SBox', cx, cy);
    gcRect(box.gc, sW, sH, 4, [yC[0],yC[1],yC[2],0.18], [yC[0],yC[1],yC[2],0.55], 1.5);
    var hdr = newShape('EB_SHdr', cx, cy - sH/2 + 28);
    gcRect(hdr.gc, sW, 56, 0, [yC[0],yC[1],yC[2],0.38]);
    var t = ebTextParagraph(comp, params.title || 'Note', cx - sW/2 + 24, cy - sH/2 + 80, 26, 'regular', [0,0,0], sW - 48);
    t.name = 'EB_STxt';
    anim(box.lyr, f0); anim(hdr.lyr, f0); animTxt(t, f0 + 5);
    return;
  }

  if (bt === 'element-annotation') {
    var tgX = cx - 320; var tgY = cy + 100;
    var lbX = cx + 80;  var lbY = cy - 100;
    // Target circle
    var tc = newShape('EB_AnnCirc', tgX, tgY);
    gcEllipse(tc.gc, 80, null, acColor, 2.5);
    // Dot at center
    var dot = newShape('EB_AnnDot', tgX, tgY);
    gcEllipse(dot.gc, 14, acColor);
    // Leader line (absolute coords, layer at [0,0])
    var line = comp.layers.addShape(); line.name = 'EB_AnnLine';
    line.position.setValue([0, 0]);
    var lgrp = line.property('Contents').addProperty('ADBE Vector Group');
    gcLine(lgrp.property('Contents'), [[tgX,tgY],[lbX,lbY]], acColor, 2, true);
    // Label box
    var lb = newShape('EB_AnnBox', lbX + 170, lbY);
    gcRect(lb.gc, 340, 80, 8, [0.12,0.12,0.12,1], acColor, 1.5);
    var lt = ebText(comp, params.title || 'Component Name', lbX + 16, lbY, 26, 'bold', acRGB, 'left');
    lt.name = 'EB_AnnLbl';
    try { lt.anchorPoint.setValue([0, -Math.round(26 * 0.35)]); } catch(e) {}
    anim(tc.lyr, f0); anim(dot.lyr, f0);
    anim(line, f0 + 6); anim(lb.lyr, f0 + 14); animTxt(lt, f0 + 16);
    return;
  }

  // ── STATS & DATA ─────────────────────────────────────────

  if (bt === 'element-stat') {
    var card = newShape('EB_StatCard', cx, cy);
    gcRect(card.gc, 600, 300, 14, [0.12,0.12,0.12,1]);
    var num = ebText(comp, params.title || '99%', cx - 80, cy, 96, 'bold', acRGB, 'center');
    num.name = 'EB_StatNum';
    try { num.anchorPoint.setValue([0, -Math.round(96 * 0.35)]); } catch(e) {}
    var lbl = ebText(comp, params.subtitle || 'Metric Label', cx + 110, cy - 20, 28, 'semibold', [0.78,0.78,0.78], 'left');
    lbl.name = 'EB_StatLbl';
    anim(card.lyr, f0); animTxt(num, f0 + 6); animTxt(lbl, f0 + 10);
    return;
  }

  if (bt === 'element-progress') {
    var bW = 1400; var bH = 12; var bRx = 6;
    var rows = [
      { lbl:'Metric A', pct:75, y:cy - 110 },
      { lbl:'Metric B', pct:45, y:cy       },
      { lbl:'Metric C', pct:88, y:cy + 110 }
    ];
    for (var pi = 0; pi < rows.length; pi++) {
      var row = rows[pi];
      var fW  = Math.round(bW * row.pct / 100);
      var fX  = cx - bW/2 + fW/2;
      // Track
      var trk = newShape('EB_PrgTrk' + pi, cx, row.y);
      gcRect(trk.gc, bW, bH, bRx, [0.2,0.2,0.2,1]);
      // Fill
      var fil = newShape('EB_PrgFil' + pi, fX, row.y);
      gcRect(fil.gc, fW, bH, bRx, acColor);
      // Label
      var lb = ebText(comp, row.lbl, L.marginX, row.y - 22, 24, 'bold', [0.7,0.7,0.7], 'left');
      lb.name = 'EB_PrgLbl' + pi;
      var pv = ebText(comp, row.pct + '%', L.marginX + bW, row.y - 22, 22, 'regular', acRGB, 'right');
      pv.name = 'EB_PrgPct' + pi;
      if (params.animateIn) {
        var sf = f0 + pi * 8;
        animTxt(lb, sf); anim(trk.lyr, sf + 2);
        // Grow fill from left
        try {
          fil.lyr.position.setValueAtTime((sf+3)/fps, [cx - bW/2, row.y]);
          fil.lyr.position.setValueAtTime((sf+18)/fps, [fX, row.y]);
          fil.lyr.opacity.setValueAtTime((sf+3)/fps, 100);
          var sP = fil.lyr.property('Contents').property(1).property('Contents')
                       .property('ADBE Vector Shape - Rect').property('ADBE Vector Rect Size');
          sP.setValueAtTime((sf+3)/fps,  [0,  bH]);
          sP.setValueAtTime((sf+18)/fps, [fW, bH]);
        } catch(e) { anim(fil.lyr, sf + 3); }
        animTxt(pv, sf + 20);
      }
    }
    return;
  }

  if (bt === 'element-pct-badge') {
    var rR = 140; var sW = 28;
    var rX = cx - 220; var rY = cy;
    var pct = 75;
    // BG ring
    var bgR = newShape('EB_PctBg', rX, rY);
    gcEllipse(bgR.gc, rR * 2, null, [0.2,0.2,0.2,1], sW);
    // FG arc (trim path)
    var fgR = newShape('EB_PctFg', rX, rY);
    gcEllipse(fgR.gc, rR * 2, null, acColor, sW);
    try {
      var trim = fgR.gc.addProperty('ADBE Vector Filter - Trim');
      trim.property('End').setValue(pct);
      trim.property('Offset').setValue(-90);
      if (params.animateIn) {
        trim.property('End').setValueAtTime(f0/fps, 0);
        trim.property('End').setValueAtTime((f0 + 24)/fps, pct);
      }
    } catch(e) {}
    // Pct text
    var pTxt = ebText(comp, pct + '%', rX, rY, 52, 'bold', acRGB, 'center');
    pTxt.name = 'EB_PctNum';
    try { pTxt.anchorPoint.setValue([0, -Math.round(52 * 0.35)]); } catch(e) {}
    // Side labels
    var sL = ebText(comp, params.title || 'Completion Rate', cx + 60, cy - 36, 32, 'bold', black, 'left');
    sL.name = 'EB_PctSide';
    var sD = ebText(comp, params.subtitle || 'As of current period', cx + 60, cy + 18, 24, 'regular', [0,0,0], 'left');
    sD.name = 'EB_PctDesc';
    anim(bgR.lyr, f0); animTxt(pTxt, f0 + 20);
    animTxt(sL, f0 + 10); animTxt(sD, f0 + 14);
    return;
  }

  // Fallback (unknown element subtype)
  throw new Error('Unknown element type: ' + bt);
}

// =============================================================
// COMPARE ICONS BLOCK (pixel-locked, precomp-based, static)
// Spec: two 560x700 cards in a 1920x1080 layout precomp.
// Left card: green accent. Right card: blue accent.
// All icon art built as nested precomps (110x110).
// No keyframes -- static at t=0.
// =============================================================
function createCompareIconsBlock(comp, params) {
  var proj = app.project;
  var fps  = comp.frameRate; // 30

  // Colors (RGBA 0-1)
  var CWHITE = [1, 1, 1, 1];
  var C111   = ebColor('111111'); // #111111 text
  var C6F    = ebColor('6F6F6F'); // icon stroke
  var CC8    = ebColor('C8C8C8'); // divider
  var CGRN   = ebColor('76B900'); // green accent
  var CBLU   = ebColor('2F80ED'); // blue accent
  var CYEL   = ebColor('F2C94C'); // sand yellow

  // -- Shape-layer helpers (operate on any target comp) --

  function mkRectFill(dc, nm, cx, cy, w, h, rx, fc) {
    var l = dc.layers.addShape(); l.name = nm;
    l.position.setValue([cx, cy]);
    var gc = l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var r  = gc.addProperty('ADBE Vector Shape - Rect');
    try { r.property('ADBE Vector Rect Size').setValue([w,h]); }       catch(ex) {}
    try { r.property('ADBE Vector Rect Roundness').setValue(rx||0); }  catch(ex) {}
    var fi = gc.addProperty('ADBE Vector Graphic - Fill');
    try { fi.property('ADBE Vector Fill Color').setValue(fc); }        catch(ex) {}
    return l;
  }

  function mkRectStroke(dc, nm, cx, cy, w, h, rx, sc, sw) {
    var l = dc.layers.addShape(); l.name = nm;
    l.position.setValue([cx, cy]);
    var gc = l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var r  = gc.addProperty('ADBE Vector Shape - Rect');
    try { r.property('ADBE Vector Rect Size').setValue([w,h]); }       catch(ex) {}
    try { r.property('ADBE Vector Rect Roundness').setValue(rx||0); }  catch(ex) {}
    var st = gc.addProperty('ADBE Vector Graphic - Stroke');
    try { st.property('ADBE Vector Stroke Color').setValue(sc); }      catch(ex) {}
    try { st.property('ADBE Vector Stroke Width').setValue(sw||3); }   catch(ex) {}
    try { st.property('ADBE Vector Stroke Line Cap').setValue(2); }    catch(ex) {}
    try { st.property('ADBE Vector Stroke Line Join').setValue(2); }   catch(ex) {}
    return l;
  }

  function mkEllFill(dc, nm, cx, cy, dw, dh, fc) {
    var l = dc.layers.addShape(); l.name = nm;
    l.position.setValue([cx, cy]);
    var gc = l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var el = gc.addProperty('ADBE Vector Shape - Ellipse');
    try { el.property('ADBE Vector Ellipse Size').setValue([dw,dh]); } catch(ex) {}
    var fi = gc.addProperty('ADBE Vector Graphic - Fill');
    try { fi.property('ADBE Vector Fill Color').setValue(fc); }        catch(ex) {}
    return l;
  }

  function mkEllStroke(dc, nm, cx, cy, d, sc, sw) {
    var l = dc.layers.addShape(); l.name = nm;
    l.position.setValue([cx, cy]);
    var gc = l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var el = gc.addProperty('ADBE Vector Shape - Ellipse');
    try { el.property('ADBE Vector Ellipse Size').setValue([d,d]); }   catch(ex) {}
    var st = gc.addProperty('ADBE Vector Graphic - Stroke');
    try { st.property('ADBE Vector Stroke Color').setValue(sc); }      catch(ex) {}
    try { st.property('ADBE Vector Stroke Width').setValue(sw||3); }   catch(ex) {}
    try { st.property('ADBE Vector Stroke Line Cap').setValue(2); }    catch(ex) {}
    return l;
  }

  // Closed/open polygon. Layer at [0,0] so vertices = absolute dc coords.
  function mkPath(dc, nm, verts, closed, fc, sc, sw) {
    var l = dc.layers.addShape(); l.name = nm;
    l.position.setValue([0, 0]);
    var gc = l.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var pg = gc.addProperty('ADBE Vector Shape - Group');
    var s  = new Shape();
    s.vertices = verts; s.inTangents = []; s.outTangents = [];
    for (var vi = 0; vi < verts.length; vi++) { s.inTangents.push([0,0]); s.outTangents.push([0,0]); }
    s.closed = !!closed;
    try { pg.property('ADBE Vector Shape').setValue(s); } catch(ex) {}
    if (fc) {
      var fi = gc.addProperty('ADBE Vector Graphic - Fill');
      try { fi.property('ADBE Vector Fill Color').setValue(fc); }     catch(ex) {}
    }
    if (sc) {
      var st = gc.addProperty('ADBE Vector Graphic - Stroke');
      try { st.property('ADBE Vector Stroke Color').setValue(sc); }   catch(ex) {}
      try { st.property('ADBE Vector Stroke Width').setValue(sw||3); } catch(ex) {}
      try { st.property('ADBE Vector Stroke Line Cap').setValue(2); }  catch(ex) {}
      try { st.property('ADBE Vector Stroke Line Join').setValue(2); } catch(ex) {}
    }
    return l;
  }

  // Center-justified text in target comp. leading optional for multi-line.
  function mkTxt(dc, nm, text, cx, cy, sz, fkey, fc, leading) {
    var l = ebText(dc, text, cx, cy, sz, fkey||'regular', fc||C111, 'center');
    l.name = nm;
    if (leading) {
      try {
        var sp = l.property('Source Text');
        var doc = sp.value;
        doc.leading = leading;
        sp.setValue(doc);
      } catch(ex) {}
    }
    return l;
  }

  // Drop shadow per spec: 18% opacity, direction 90 (down), dist 14, soft 50
  function applyDS(layer) {
    try {
      var ds = layer.Effects.addProperty('ADBE Drop Shadow');
      try { ds.property('Shadow Color').setValue([0,0,0,1]); } catch(ex) {}
      try { ds.property('Opacity').setValue(18); }             catch(ex) {}
      try { ds.property('Direction').setValue(90); }           catch(ex) {}
      try { ds.property('Distance').setValue(14); }            catch(ex) {}
      try { ds.property('Softness').setValue(50); }            catch(ex) {}
    } catch(ex) {}
  }

  // Add srcComp as a precomp layer (anchor defaults to comp center)
  function placeComp(dc, src, cx, cy, lname) {
    var l = dc.layers.add(src);
    if (lname) l.name = lname;
    l.position.setValue([cx, cy]);
    return l;
  }

  function newComp(name, w, h) {
    return proj.items.addComp(name, w, h, 1, 10, fps);
  }

  // ================================================================
  // ICON PRECOMPS (110x110). All positions in icon-comp space (0,0=TL).
  // ================================================================

  // ICON_RapidPrototyping: device plate + crosshair target
  var icRP = newComp('ICON_RapidPrototyping', 110, 110);
  mkRectStroke(icRP, 'SHP_Plate',  55, 48, 44, 56, 6, C6F, 3);
  mkEllStroke( icRP, 'SHP_Circle', 55, 48, 22,     C6F, 3);
  mkRectFill(  icRP, 'SHP_CrossH', 55, 48, 26,  3, 0, C6F);
  mkRectFill(  icRP, 'SHP_CrossV', 55, 48,  3, 26, 0, C6F);

  // ICON_LatencyResponse: clock face + hands
  var icLR = newComp('ICON_LatencyResponse', 110, 110);
  mkEllStroke(icLR, 'SHP_Face',    55, 50, 56,     C6F, 3);
  mkRectFill( icLR, 'SHP_MinHand', 55, 42,  3, 22, 0, C6F);
  mkRectFill( icLR, 'SHP_HrHand',  62, 50, 18,  3, 0, C6F);

  // ICON_InterimDevStage: hourglass (bottom fill first, then outlines on top)
  var icID = newComp('ICON_InterimDevStage', 110, 110);
  mkPath(icID, 'SHP_SandFill', [[55,90],[30,60],[80,60]], true, CYEL, null, 0);
  mkPath(icID, 'SHP_HgTop',    [[55,20],[30,50],[80,50]], true, null, C6F,  3);
  mkPath(icID, 'SHP_HgBot',    [[55,90],[30,60],[80,60]], true, null, C6F,  3);

  // ICON_TaggedPreview: rounded tag + hole + PREVIEW text
  var icTP = newComp('ICON_TaggedPreview', 110, 110);
  mkRectStroke(icTP, 'SHP_Tag',  55, 55, 76, 26, 13, C6F, 3);
  mkEllStroke( icTP, 'SHP_Hole', 25, 55,  6,      C6F, 3);
  mkTxt(icTP, 'TXT_Prev', 'PREVIEW', 65, 59, 14, 'semibold', CGRN);

  // ICON_CustomInfra: 3 building rects + ground fill
  var icCI = newComp('ICON_CustomInfra', 110, 110);
  mkRectStroke(icCI, 'SHP_Bld1',   38, 55, 14, 38, 0, C6F, 3);
  mkRectStroke(icCI, 'SHP_Bld2',   55, 46, 14, 56, 0, C6F, 3);
  mkRectStroke(icCI, 'SHP_Bld3',   72, 52, 14, 44, 0, C6F, 3);
  mkRectFill(  icCI, 'SHP_Ground', 55, 75, 64,  3, 0, C6F);

  // ICON_MetricScaling: 4 increasing bars (stroke) + green arrow (shaft + head)
  var icMS = newComp('ICON_MetricScaling', 110, 110);
  mkRectStroke(icMS, 'SHP_Bar1',     35, 70, 10, 18, 0, C6F,  3);
  mkRectStroke(icMS, 'SHP_Bar2',     48, 65, 10, 28, 0, C6F,  3);
  mkRectStroke(icMS, 'SHP_Bar3',     61, 60, 10, 38, 0, C6F,  3);
  mkRectStroke(icMS, 'SHP_Bar4',     74, 53, 10, 52, 0, C6F,  3);
  mkRectFill(  icMS, 'SHP_ArrShaft', 82, 36,  3, 28, 0, CGRN);
  mkPath(      icMS, 'SHP_ArrHead',  [[82,18],[74,30],[90,30]], true, CGRN, null, 0);

  // ICON_TotalAIControl: 3 filled tracks + 3 green knobs
  var icTA = newComp('ICON_TotalAIControl', 110, 110);
  mkRectFill(icTA, 'SHP_Trk1', 55, 42, 60, 3, 0, C6F);
  mkRectFill(icTA, 'SHP_Trk2', 55, 55, 60, 3, 0, C6F);
  mkRectFill(icTA, 'SHP_Trk3', 55, 68, 60, 3, 0, C6F);
  mkEllFill( icTA, 'SHP_Knb1', 40, 42, 10, 10, CGRN);
  mkEllFill( icTA, 'SHP_Knb2', 60, 55, 10, 10, CGRN);
  mkEllFill( icTA, 'SHP_Knb3', 50, 68, 10, 10, CGRN);

  // ICON_RunAnywhere: rounded tag + blue badge + text
  var icRA = newComp('ICON_RunAnywhere', 110, 110);
  mkRectStroke(icRA, 'SHP_Tag',   55, 55, 76, 26, 13, C6F,  3);
  mkRectFill(  icRA, 'SHP_Badge', 28, 55, 16, 16,  3, CBLU);
  mkTxt(icRA, 'TXT_Run', 'Run Anywhere', 70, 59, 12, 'regular', CGRN);

  // ================================================================
  // CARD PRECOMPS (560x700).
  // Internal coord system: (0,0)=top-left, (560,700)=bottom-right.
  // COL_L_X=180, COL_R_X=380, ROW1_ICON_Y=230, ROW2_ICON_Y=360.
  // ROW1_LABEL_Y=310, ROW2_LABEL_Y=450.
  // ================================================================
  function buildCard(name, isLeft) {
    var cc = newComp(name, 560, 700);

    // Card background: rounded rect 560x700 r=10, white fill, drop shadow
    var bgL = cc.layers.addShape(); bgL.name = 'SHP_Card_BG';
    bgL.position.setValue([280, 350]);
    var grp = bgL.property('Contents').addProperty('ADBE Vector Group');
    grp.name = 'BG';
    var bgGC = grp.property('Contents');
    var bgR  = bgGC.addProperty('ADBE Vector Shape - Rect');
    try { bgR.property('ADBE Vector Rect Size').setValue([560, 700]); } catch(ex) {}
    try { bgR.property('ADBE Vector Rect Roundness').setValue(2); }    catch(ex) {}
    var bgFi = bgGC.addProperty('ADBE Vector Graphic - Fill');
    try { bgFi.property('ADBE Vector Fill Color').setValue(CWHITE); }   catch(ex) {}
    applyDS(bgL);

    // Card title (centered, semibold 30px, baseline at Y=80)
    mkTxt(cc, 'TXT_CardTitle',
      isLeft ? 'Hosted API' : 'Downloadable NIM',
      280, 80, 30, 'semibold', C111);

    // Divider: 392x2 gray fill at center X=280, Y=125
    mkRectFill(cc, 'SHP_Divider', 280, 125, 392, 2, 0, CC8);

    // Icon precomps (center positions: COL_L=180, COL_R=380, ROW1=230, ROW2=360)
    if (isLeft) {
      placeComp(cc, icRP, 180, 230, 'ICON_RapidPrototyping');
      placeComp(cc, icLR, 380, 230, 'ICON_LatencyResponse');
      placeComp(cc, icID, 180, 360, 'ICON_InterimDevStage');
      placeComp(cc, icTP, 380, 360, 'ICON_TaggedPreview');
    } else {
      placeComp(cc, icCI, 180, 230, 'ICON_CustomInfra');
      placeComp(cc, icMS, 380, 230, 'ICON_MetricScaling');
      placeComp(cc, icTA, 180, 360, 'ICON_TotalAIControl');
      placeComp(cc, icRA, 380, 360, 'ICON_RunAnywhere');
    }

    // Labels (18px regular, center, leading=22 for multi-line)
    if (isLeft) {
      mkTxt(cc, 'TXT_Label_Rapid',   'Rapid prototyping',  180, 310, 18, 'regular', C111);
      mkTxt(cc, 'TXT_Label_Latency', 'Latency response',   380, 310, 18, 'regular', C111);
      mkTxt(cc, 'TXT_Label_Interim', 'Interim dev stage',  180, 450, 18, 'regular', C111);
      mkTxt(cc, 'TXT_Label_Preview', 'Tagged as PREVIEW',  380, 450, 18, 'regular', C111);
    } else {
      mkTxt(cc, 'TXT_Label_Infra',  'Custom Infra\rDeployment',   180, 310, 18, 'regular', C111, 22);
      mkTxt(cc, 'TXT_Label_Metric', 'Metric-Based Scaling',       380, 310, 18, 'regular', C111);
      mkTxt(cc, 'TXT_Label_AI',     'Total AI Control',            180, 450, 18, 'regular', C111);
      mkTxt(cc, 'TXT_Label_Run',    'Run Anywhere\rPortability',   380, 450, 18, 'regular', C111, 22);
    }

    // Accent line: 5px wide, full card height (700), flush to left/right edge
    if (isLeft) {
      mkRectFill(cc, 'SHP_Accent_Left',  2.5,   350, 5, 700, 0, CGRN);
    } else {
      mkRectFill(cc, 'SHP_Accent_Right', 557.5, 350, 5, 700, 0, CBLU);
    }

    return cc;
  }

  var cardLeft  = buildCard('CARD_Left_HostedAPI',        true);
  var cardRight = buildCard('CARD_Right_DownloadableNIM', false);

  // ================================================================
  // LAYOUT PRECOMP (1920x1080)
  // Left card center: [620, 600], Right: [1300, 600] (120px gap)
  // ================================================================
  var layoutComp = newComp('PRECOMP_Cards_Layout', 1920, 1080);
  placeComp(layoutComp, cardLeft,   620,  600, 'CARD_Left_HostedAPI');
  placeComp(layoutComp, cardRight, 1300,  600, 'CARD_Right_DownloadableNIM');

  // ================================================================
  // MASTER COMP (created by createBlock(); 1920x1080 white bg solid)
  // Add in this order (each new layer → index 1 = top):
  //   1. LOGO_NVIDIA   -> ends at index 4
  //   2. PRECOMP_Cards -> ends at index 3
  //   3. TXT_Subtitle  -> ends at index 2
  //   4. TXT_Title     -> ends at index 1 (topmost)
  // Final stack top->bottom: Title, Subtitle, CardsLayout, Logo, BG
  // ================================================================

  // NVIDIA logo (text placeholder — script cannot import raster assets)
  var logoLyr = ebText(comp, 'NVIDIA', 1840, 1020, 22, 'bold', CGRN, 'center');
  logoLyr.name = 'LOGO_NVIDIA';

  // Cards layout precomp (overlays full master comp area 1:1)
  var layoutLyr = comp.layers.add(layoutComp);
  layoutLyr.name = 'PRECOMP_Cards_Layout';
  layoutLyr.position.setValue([960, 540]);

  // Subtitle (28px regular, green, centered)
  var subTxt = params.subtitle ||
    'Prototype using hosted API but deploy in production with downloadable NIM';
  var subLyr = ebText(comp, subTxt, 960, 175, 28, 'regular', CGRN, 'center');
  subLyr.name = 'TXT_Subtitle';

  // Title (56px bold, dark, centered) — added last = topmost
  var titTxt = params.title ||
    'Hosted API vs Downloadable NIM (build.nvidia.com)';
  var titLyr = ebText(comp, titTxt, 960, 120, 56, 'bold', C111, 'center');
  titLyr.name = 'TXT_Title';
}

// =============================================================
// CUSTOM BLOCK -- AI-generated freeform layout
// Claude analyzes a visual and returns a layers[] spec.
// Each spec is turned into a real, editable AE layer.
//
// Layer types:
//   "text"      -- single-line point text  (ebText)
//   "text-para" -- word-wrapped paragraph  (ebTextParagraph)
//   "rect"      -- rounded rectangle shape
//   "circle"    -- ellipse/circle shape
//   "line"      -- open path (rule / divider)
//   "arrow"     -- line with arrowhead
// =============================================================

// =============================================================
// FLOW DIAGRAM -- ICON CARDS (3 or 4 steps)
// White cards with NVIDIA icon at top, accent-colored title,
// animated horizontal rule, and body text. Arrows between cards.
// params.steps = [{ icon, label, body, _iconPng }, ...]
// =============================================================
function createFlowIconBlock(comp, params, stepCount) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var color  = ebColor(params.accentColor || '76B900');
  var colRGB = [color[0], color[1], color[2]];
  var L      = EB_LAYOUT;
  var icoDir = $.global._ebpIconDir || '';
  var doAnim = params.animateIn !== false;
  var n      = stepCount || 3;

  var nodeH = L.cardBottom - L.cardTop;
  var nodeY = L.cardTop + nodeH / 2;
  var nodeW, nodeGap;
  if (n === 4) { nodeW = 350; nodeGap = 44; }
  else          { nodeW = 480; nodeGap = 60; }
  var totalW = n * nodeW + (n - 1) * nodeGap;
  var startX = 960 - totalW / 2 + nodeW / 2;
  var nodeXs = [];
  for (var ni = 0; ni < n; ni++) nodeXs.push(startX + ni * (nodeW + nodeGap));

  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var steps = params.steps || [];
  for (var i = 0; i < n; i++) {
    var step      = steps[i] || {};
    var nodeX     = nodeXs[i];
    var nodeStart = sf + 28 + i * 8;
    var icoSize   = 72;
    var padTop    = 28;
    var padX      = 28;
    var tSize     = (n === 4) ? 26 : 28;
    var bSize     = (n === 4) ? 20 : 22;
    var cardTop_y = nodeY - nodeH / 2;
    var contentY  = cardTop_y + padTop;

    // Background (respects Fill Shapes / Card BG / Border / Shadow checkboxes)
    var nodeCard = { x: nodeX, y: nodeY, w: nodeW, h: nodeH };
    var _fiNoFill = (params.cardBg === false);
    var _fiFill   = (params.shapeFill === false) ? null : color;
    var bgLyr = ebCreateCardBg(comp, nodeCard, 'EB_FI_Node_' + (i + 1) + '_BG', null,
                               borderClr, showShadow, _fiNoFill, _fiFill);
    ebTextAnimatorFadeUp(bgLyr, nodeStart, fps, 32);

    // Icon at top (PNG preferred, SVG fallback)
    var icoName = step.icon || '';
    var icoPng  = step._iconPng || '';
    var icoPath = icoPng || (icoDir && icoName ? icoDir + '/' + icoName + '.svg' : '');
    if (icoPath) {
      try {
        var icoFile = new File(icoPath);
        if (icoFile.exists) {
          var icoOpts = new ImportOptions(icoFile);
          icoOpts.importAs = ImportAsType.FOOTAGE;
          var icoFtg = app.project.importFile(icoOpts);
          var icoLyr = comp.layers.add(icoFtg);
          icoLyr.name = 'EB_FI_Node_' + (i + 1) + '_Icon';
          var icoScl = (icoSize / (icoFtg.width || 48)) * 100;
          try { icoLyr.position.setValue([nodeX, contentY + icoSize / 2]); } catch(e) {}
          try { icoLyr.scale.setValue([icoScl, icoScl, 100]); } catch(e) {}
          if (doAnim) { try { ebAnimateFadeUp(icoLyr, nodeStart + 4, fps, 24); } catch(e) {} }
        }
      } catch(e) {}
    }
    contentY += icoSize + 16;

    // Title
    var tLabel    = step.label || ('Step ' + (i + 1));
    var tBaseline = Math.round(contentY + tSize);
    var tLyr      = ebText(comp, tLabel, nodeX, tBaseline, tSize, 'semibold', colRGB, 'center');
    tLyr.name = 'EB_FI_Node_' + (i + 1) + '_Title';
    if (doAnim) ebTextAnimatorFadeUp(tLyr, nodeStart + 6, fps, 18);
    contentY = tBaseline + 10;

    // Horizontal rule below title
    var tlY  = Math.round(contentY + 2);
    var tlLyr = comp.layers.addShape();
    tlLyr.name = 'EB_FI_Node_' + (i + 1) + '_Rule';
    tlLyr.position.setValue([nodeX, tlY]);
    var tlGc = tlLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tlPg = tlGc.addProperty('ADBE Vector Shape - Group');
    var tlHW = nodeW / 2 - padX;
    try { tlPg.property('ADBE Vector Shape').setValue(ebOpenPath([[-tlHW, 0], [tlHW, 0]])); } catch(e) {}
    var tlSt = tlGc.addProperty('ADBE Vector Graphic - Stroke');
    try { tlSt.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { tlSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    if (doAnim) {
      var tlTrim = tlGc.addProperty('ADBE Vector Filter - Trim');
      var tlEnd  = tlTrim.property('ADBE Vector Trim End');
      try { tlLyr.inPoint = nodeStart / fps; } catch(e) {}
      try { ebAnimateTrimDraw(tlEnd, nodeStart + 7, fps); } catch(e) {}
    }
    contentY = tlY + 14;

    // Body text
    var bodyTxt = step.body || '';
    if (bodyTxt) {
      var bBaseline = Math.round(contentY + bSize);
      var bLyr = ebTextParagraph(comp, bodyTxt,
                   nodeX - (nodeW / 2 - padX), bBaseline,
                   bSize, 'regular', [0.2, 0.2, 0.2], nodeW - padX * 2);
      bLyr.name = 'EB_FI_Node_' + (i + 1) + '_Body';
      if (doAnim) ebTextAnimatorFadeUp(bLyr, nodeStart + 9, fps, 18);
    }
  }

  // Connectors (drawn last = top of stack, visible over cards)
  var halfW    = nodeW / 2;
  var CONN_PAD = 16;
  for (var j = 0; j < n - 1; j++) {
    var cL = comp.layers.addShape();
    cL.name = 'EB_FI_Conn_' + (j + 1);
    cL.position.setValue([0, 0]);
    var cc = cL.property('Contents');

    var lGrp = cc.addProperty('ADBE Vector Group'); lGrp.name = 'Line';
    var lGC  = lGrp.property('Contents');
    var lPth = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[nodeXs[j]+halfW+CONN_PAD, nodeY],[nodeXs[j+1]-halfW-CONN_PAD, nodeY]])); } catch(e) {}
    var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}

    var aGrp = cc.addProperty('ADBE Vector Group'); aGrp.name = 'Arrow';
    var aGC  = aGrp.property('Contents');
    var aPth = aGC.addProperty('ADBE Vector Shape - Group');
    var aX   = nodeXs[j + 1] - halfW - CONN_PAD;
    try { aPth.property('ADBE Vector Shape').setValue(ebOpenPath([[aX-11, nodeY-8], [aX, nodeY], [aX-11, nodeY+8]])); } catch(e) {}
    var aStr = aGC.addProperty('ADBE Vector Graphic - Stroke');
    try { aStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
    ebFadeOnly(cL, sf + 28 + j * 8 + 5, fps);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// FLOW DIAGRAM -- NUMBERED BULLET CARDS (3 steps)
// Cards with accent-colored badge number, title, rule, bullet list.
// params.steps = [{ label, bullets: [...] }, ...]
// =============================================================
function createFlowBulletsBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var color  = ebColor(params.accentColor || '76B900');
  var colRGB = [color[0], color[1], color[2]];
  var L      = EB_LAYOUT;
  var doAnim = params.animateIn !== false;

  var nodeW = 480, nodeGap = 60;
  var nodeH = L.cardBottom - L.cardTop;
  var nodeY = L.cardTop + nodeH / 2;
  var totalW = 3 * nodeW + 2 * nodeGap;
  var startX = 960 - totalW / 2 + nodeW / 2;
  var nodeXs = [startX, startX + nodeW + nodeGap, startX + 2 * (nodeW + nodeGap)];

  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var steps = params.steps || [];
  for (var i = 0; i < 3; i++) {
    var step      = steps[i] || {};
    var nodeX     = nodeXs[i];
    var nodeStart = sf + 28 + i * 8;
    var tSize     = 28;
    var bSize     = 22;
    var padX      = 28;
    var padTop    = 28;
    var cardTop_y = nodeY - nodeH / 2;
    var contentY  = cardTop_y + padTop;

    // Background (respects Fill Shapes / Card BG / Border / Shadow checkboxes)
    var nodeCard = { x: nodeX, y: nodeY, w: nodeW, h: nodeH };
    var _fbNoFill = (params.cardBg === false);
    var _fbFill   = (params.shapeFill === false) ? null : color;
    var bgLyr = ebCreateCardBg(comp, nodeCard, 'EB_FB_Node_' + (i + 1) + '_BG', null,
                               borderClr, showShadow, _fbNoFill, _fbFill);
    ebTextAnimatorFadeUp(bgLyr, nodeStart, fps, 32);

    // Numbered badge (filled circle -- addSolid: always visible, ellipse fill unreliable in AE 2024+)
    var badgeR  = 20;
    var badgeSz = badgeR * 2;
    var badgeY  = contentY + badgeR;
    var badgeX  = nodeX - nodeW / 2 + padX + badgeR;
    var bdLyr   = comp.layers.addSolid([color[0], color[1], color[2]], 'EB_FB_Node_' + (i + 1) + '_Badge', badgeSz, badgeSz, 1);
    try { bdLyr.anchorPoint.setValue([badgeR, badgeR]); } catch(e) {}
    bdLyr.position.setValue([badgeX, badgeY]);
    ebTextAnimatorFadeUp(bdLyr, nodeStart + 2, fps, 20);

    var numLyr = ebText(comp, String(i + 1),
                   nodeX - nodeW / 2 + padX + badgeR, badgeY + 7,
                   18, 'bold', [1, 1, 1], 'center');
    numLyr.name = 'EB_FB_Node_' + (i + 1) + '_Num';
    if (doAnim) ebTextAnimatorFadeUp(numLyr, nodeStart + 3, fps, 18);
    contentY = badgeY + badgeR + 16;

    // Title (left-aligned)
    var tLabel    = step.label || ('Step ' + (i + 1));
    var tBaseline = Math.round(contentY + tSize);
    var tLyr      = ebText(comp, tLabel, nodeX - nodeW / 2 + padX, tBaseline, tSize,
                           'semibold', colRGB, 'left');
    tLyr.name = 'EB_FB_Node_' + (i + 1) + '_Title';
    if (doAnim) ebTextAnimatorFadeUp(tLyr, nodeStart + 5, fps, 18);
    contentY = tBaseline + 10;

    // Horizontal rule
    var tlY  = Math.round(contentY + 2);
    var tlLyr = comp.layers.addShape();
    tlLyr.name = 'EB_FB_Node_' + (i + 1) + '_Rule';
    tlLyr.position.setValue([nodeX, tlY]);
    var tlGc = tlLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tlPg = tlGc.addProperty('ADBE Vector Shape - Group');
    var tlHW = nodeW / 2 - padX;
    try { tlPg.property('ADBE Vector Shape').setValue(ebOpenPath([[-tlHW, 0], [tlHW, 0]])); } catch(e) {}
    var tlSt = tlGc.addProperty('ADBE Vector Graphic - Stroke');
    try { tlSt.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { tlSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    if (doAnim) {
      var tlTrim = tlGc.addProperty('ADBE Vector Filter - Trim');
      var tlEnd  = tlTrim.property('ADBE Vector Trim End');
      try { tlLyr.inPoint = nodeStart / fps; } catch(e) {}
      try { ebAnimateTrimDraw(tlEnd, nodeStart + 6, fps); } catch(e) {}
    }
    contentY = tlY + 14;

    // Bullet list
    var bullets = (step.bullets && step.bullets.length) ? step.bullets : [
      'Key point or feature here',
      'Supporting detail or benefit',
      'Additional information'
    ];
    for (var bi = 0; bi < bullets.length; bi++) {
      var bulBaseline = Math.round(contentY + bSize);
      var bulLyr = ebText(comp, '\u2022  ' + bullets[bi],
                     nodeX - nodeW / 2 + padX, bulBaseline,
                     bSize, 'regular', [0.2, 0.2, 0.2], 'left');
      bulLyr.name = 'EB_FB_Node_' + (i + 1) + '_Bul' + (bi + 1);
      if (doAnim) ebTextAnimatorFadeUp(bulLyr, nodeStart + 8 + bi * 3, fps, 16);
      contentY = bulBaseline + 10;
    }
  }

  // Connectors
  var halfW    = nodeW / 2;
  var CONN_PAD = 16;
  for (var j = 0; j < 2; j++) {
    var cL = comp.layers.addShape();
    cL.name = 'EB_FB_Conn_' + (j + 1);
    cL.position.setValue([0, 0]);
    var cc = cL.property('Contents');

    var lGrp = cc.addProperty('ADBE Vector Group'); lGrp.name = 'Line';
    var lGC  = lGrp.property('Contents');
    var lPth = lGC.addProperty('ADBE Vector Shape - Group');
    try { lPth.property('ADBE Vector Shape').setValue(ebOpenPath([[nodeXs[j]+halfW+CONN_PAD, nodeY],[nodeXs[j+1]-halfW-CONN_PAD, nodeY]])); } catch(e) {}
    var lStr = lGC.addProperty('ADBE Vector Graphic - Stroke');
    try { lStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Width').setValue(3); } catch(e) {}
    try { lStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}

    var aGrp = cc.addProperty('ADBE Vector Group'); aGrp.name = 'Arrow';
    var aGC  = aGrp.property('Contents');
    var aPth = aGC.addProperty('ADBE Vector Shape - Group');
    var aX   = nodeXs[j + 1] - halfW - CONN_PAD;
    try { aPth.property('ADBE Vector Shape').setValue(ebOpenPath([[aX-11, nodeY-8], [aX, nodeY], [aX-11, nodeY+8]])); } catch(e) {}
    var aStr = aGC.addProperty('ADBE Vector Graphic - Stroke');
    try { aStr.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Width').setValue(2.5); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { aStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
    ebFadeOnly(cL, sf + 28 + j * 8 + 5, fps);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// FEATURE CARDS -- ICON TOP (3 cards with icon + title + body)
// Like icon flow but no connectors. Cards spread across full width.
// params.cards = [{ icon, label, body, _iconPng }, ...]
// =============================================================
function createCardsIconBlock(comp, params, count) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var color  = ebColor(params.accentColor || '76B900');
  var colRGB = [color[0], color[1], color[2]];
  var L      = EB_LAYOUT;
  var icoDir = $.global._ebpIconDir || '';
  var doAnim = params.animateIn !== false;
  var n      = count || 3;

  var nodeH = L.cardBottom - L.cardTop;
  var nodeY = L.cardTop + nodeH / 2;
  var nodeW, nodeGap;
  if (n === 4) { nodeW = 350; nodeGap = 44; }
  else          { nodeW = 480; nodeGap = 60; }
  var totalW = n * nodeW + (n - 1) * nodeGap;
  var startX = 960 - totalW / 2 + nodeW / 2;
  var nodeXs = [];
  for (var ni = 0; ni < n; ni++) nodeXs.push(startX + ni * (nodeW + nodeGap));

  var borderClr  = params.cardBorder ? color : null;
  var showShadow = params.dropShadow !== false;

  var cards = params.cards || [];
  for (var i = 0; i < n; i++) {
    var card      = cards[i] || {};
    var nodeX     = nodeXs[i];
    var nodeStart = sf + 22 + i * 8;
    var icoSize   = 80;
    var padTop    = 32;
    var padX      = 28;
    var tSize     = 28;
    var bSize     = 22;
    var cardTop_y = nodeY - nodeH / 2;
    var contentY  = cardTop_y + padTop;

    // Background
    var nodeCard = { x: nodeX, y: nodeY, w: nodeW, h: nodeH };
    var bgLyr = ebCreateCardBg(comp, nodeCard, 'EB_CI_Card_' + (i + 1) + '_BG', null,
                               borderClr, showShadow, params.shapeFill === false, color);
    if (doAnim) { try { ebAnimateFadeUp(bgLyr, nodeStart, fps, 32); } catch(e) {} }

    // Icon
    var icoName = card.icon || '';
    var icoPng  = card._iconPng || '';
    var icoPath = icoPng || (icoDir && icoName ? icoDir + '/' + icoName + '.svg' : '');
    if (icoPath) {
      try {
        var icoFile = new File(icoPath);
        if (icoFile.exists) {
          var icoOpts = new ImportOptions(icoFile);
          icoOpts.importAs = ImportAsType.FOOTAGE;
          var icoFtg = app.project.importFile(icoOpts);
          var icoLyr = comp.layers.add(icoFtg);
          icoLyr.name = 'EB_CI_Card_' + (i + 1) + '_Icon';
          var icoScl = (icoSize / (icoFtg.width || 48)) * 100;
          try { icoLyr.position.setValue([nodeX, contentY + icoSize / 2]); } catch(e) {}
          try { icoLyr.scale.setValue([icoScl, icoScl, 100]); } catch(e) {}
          if (doAnim) { try { ebAnimateFadeUp(icoLyr, nodeStart + 4, fps, 24); } catch(e) {} }
        }
      } catch(e) {}
    }
    contentY += icoSize + 20;

    // Title (centered)
    var tLabel    = card.label || ('Feature ' + (i + 1));
    var tBaseline = Math.round(contentY + tSize);
    var tLyr      = ebText(comp, tLabel, nodeX, tBaseline, tSize, 'semibold', colRGB, 'center');
    tLyr.name = 'EB_CI_Card_' + (i + 1) + '_Title';
    if (doAnim) ebTextAnimatorFadeUp(tLyr, nodeStart + 6, fps, 18);
    contentY = tBaseline + 10;

    // Horizontal rule
    var tlY  = Math.round(contentY + 2);
    var tlLyr = comp.layers.addShape();
    tlLyr.name = 'EB_CI_Card_' + (i + 1) + '_Rule';
    tlLyr.position.setValue([nodeX, tlY]);
    var tlGc = tlLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var tlPg = tlGc.addProperty('ADBE Vector Shape - Group');
    var tlHW = nodeW / 2 - padX;
    try { tlPg.property('ADBE Vector Shape').setValue(ebOpenPath([[-tlHW, 0], [tlHW, 0]])); } catch(e) {}
    var tlSt = tlGc.addProperty('ADBE Vector Graphic - Stroke');
    try { tlSt.property('ADBE Vector Stroke Color').setValue(color); } catch(e) {}
    try { tlSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    if (doAnim) {
      var tlTrim = tlGc.addProperty('ADBE Vector Filter - Trim');
      var tlEnd  = tlTrim.property('ADBE Vector Trim End');
      try { tlLyr.inPoint = nodeStart / fps; } catch(e) {}
      try { ebAnimateTrimDraw(tlEnd, nodeStart + 7, fps); } catch(e) {}
    }
    contentY = tlY + 14;

    // Body text (centered paragraph)
    var bodyTxt = card.body || '';
    if (bodyTxt) {
      var bBaseline = Math.round(contentY + bSize);
      var bLyr = ebTextParagraph(comp, bodyTxt,
                   nodeX - (nodeW / 2 - padX), bBaseline,
                   bSize, 'regular', [0.2, 0.2, 0.2], nodeW - padX * 2);
      bLyr.name = 'EB_CI_Card_' + (i + 1) + '_Body';
      if (doAnim) ebTextAnimatorFadeUp(bLyr, nodeStart + 9, fps, 18);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// ============================================================
// Option B — Constrained Custom Layouts
// All positions derived from EB_LAYOUT. No freeform coordinates.
// ============================================================

// ── Layout 1: cbLayoutSplit ─────────────────────────────────
// Two-column layout. Left = stat | bullets | text. Right = stacked cards.
function cbLayoutSplit(comp, params, fps, doAnim) {
  var L = EB_LAYOUT;
  var contentW = L.compW - 2 * L.marginX;  // 1760
  var contentH = L.cardBottom - L.cardTop;  // 750
  var ratio     = (params.splitRatio && params.splitRatio >= 0.3 && params.splitRatio <= 0.6)
                  ? params.splitRatio : 0.42;
  var leftW     = Math.round(contentW * ratio / 8) * 8;
  var rightW    = contentW - leftW - L.cardGap;
  var leftCX    = L.marginX + Math.floor(leftW / 2);
  var rightCX   = L.marginX + leftW + L.cardGap + Math.floor(rightW / 2);
  var showDiv   = (params.divider !== false);
  var accent    = params.accentColor || '76B900';
  var lContent  = params.left  || {};
  var rCards    = (params.right && params.right.cards) ? params.right.cards : [];
  var padX      = 24;
  var padTop    = 28;

  // ── vertical divider ──────────────────────────────────────
  if (showDiv) {
    var divX  = L.marginX + leftW + Math.floor(L.cardGap / 2);
    var divY1 = L.cardTop  + 16;
    var divY2 = L.cardBottom - 16;
    var divShp = comp.layers.addShape();
    divShp.name = 'EB_Sp_Divider';
    divShp.position.setValue([0, 0]);
    var divTrimEnd = null;
    try {
      var divGc  = divShp.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var divPg  = divGc.addProperty('ADBE Vector Shape - Group');
      try { divPg.property('ADBE Vector Shape').setValue(ebOpenPath([[divX, divY1], [divX, divY2]])); } catch(e) {}
      var divSt  = divGc.addProperty('ADBE Vector Graphic - Stroke');
      try { divSt.property('ADBE Vector Stroke Color').setValue(ebColor('CDCDCD')); } catch(e) {}
      try { divSt.property('ADBE Vector Stroke Width').setValue(1); } catch(e) {}
      if (doAnim) {
        var divTrim = divGc.addProperty('ADBE Vector Filter - Trim');
        divTrimEnd  = divTrim.property('ADBE Vector Trim End');
      }
    } catch(e) {}
    if (doAnim && divTrimEnd) {
      try { ebAnimateTrimDraw(divTrimEnd, 20, fps); } catch(e) {}
    }
  }

  // ── LEFT CONTENT ──────────────────────────────────────────
  var lType  = lContent.type || 'text';
  var lFrame = 22;

  if (lType === 'stat') {
    var valColor = lContent.valueColor ? ebColorRGB(lContent.valueColor) : ebColorRGB(accent);
    var valLyr = ebText(comp, lContent.value || '', leftCX, L.cardTop + 90,
                        88, 'bold', valColor, 'center');
    valLyr.name = 'EB_Sp_StatValue';
    if (doAnim) ebTextAnimatorFadeUp(valLyr, lFrame, fps, 36);
    lFrame += 6;

    if (lContent.label) {
      var labLyr = ebText(comp, lContent.label, leftCX, L.cardTop + 90 + 76,
                          26, 'bold', [0.07, 0.07, 0.07], 'center');
      labLyr.name = 'EB_Sp_StatLabel';
      if (doAnim) ebTextAnimatorFadeUp(labLyr, lFrame, fps, 18);
      lFrame += 6;
    }

    if (lContent.sublabel) {
      var subLyr = ebText(comp, lContent.sublabel, leftCX, L.cardTop + 90 + 76 + 38,
                          22, 'regular', [0.37, 0.37, 0.37], 'center');
      subLyr.name = 'EB_Sp_StatSublabel';
      if (doAnim) ebTextAnimatorFadeUp(subLyr, lFrame, fps, 18);
      lFrame += 6;
    }

    var statBullets = lContent.bullets || [];
    var statBulletY = L.cardTop + 90 + 76 + 38 + 48;
    for (var sb = 0; sb < statBullets.length; sb++) {
      var sbLyr = ebTextParagraph(comp, statBullets[sb],
                    L.marginX + padX, statBulletY + 22, 22, 'regular',
                    [0.2, 0.2, 0.2], leftW - padX * 2);
      sbLyr.name = 'EB_Sp_StatBullet_' + sb;
      if (doAnim) ebTextAnimatorFadeUp(sbLyr, lFrame, fps, 16);
      lFrame += 6;
      statBulletY += 36;
    }

  } else if (lType === 'bullets') {
    var byY = L.cardTop + padTop;
    if (lContent.header) {
      var hdrLyr = ebText(comp, lContent.header, L.marginX + padX, byY + 24,
                          30, 'bold', [0.07, 0.07, 0.07], 'left');
      hdrLyr.name = 'EB_Sp_BullHeader';
      if (doAnim) ebTextAnimatorFadeUp(hdrLyr, lFrame, fps, 18);
      lFrame += 6;
      byY += 56;
    }
    var bItems = lContent.items || [];
    for (var bi = 0; bi < bItems.length; bi++) {
      // dot — use text bullet character to avoid shape layer property path issues
      var dotLyr = ebText(comp, '\u2022', L.marginX + padX + 4, byY + 22,
                          24, 'regular', ebColorRGB(accent), 'left');
      dotLyr.name = 'EB_Sp_BullDot_' + bi;
      if (doAnim) ebAnimateFadeUp(dotLyr, lFrame, fps, 14);
      // text
      var biLyr = ebTextParagraph(comp, bItems[bi],
                    L.marginX + padX + 16, byY + 22,
                    24, 'regular', [0.2, 0.2, 0.2], leftW - padX * 2 - 16);
      biLyr.name = 'EB_Sp_BullItem_' + bi;
      if (doAnim) ebTextAnimatorFadeUp(biLyr, lFrame, fps, 16);
      lFrame += 6;
      byY += 40;
    }

  } else {
    // type === 'text'
    var tyY = L.cardTop + padTop;
    if (lContent.header) {
      var thLyr = ebText(comp, lContent.header, L.marginX + padX, tyY + 24,
                         30, 'bold', [0.07, 0.07, 0.07], 'left');
      thLyr.name = 'EB_Sp_TextHeader';
      if (doAnim) ebTextAnimatorFadeUp(thLyr, lFrame, fps, 18);
      lFrame += 6;
      tyY += 56;
    }
    if (lContent.body) {
      var tbLyr = ebTextParagraph(comp, lContent.body,
                    L.marginX + padX, tyY + 24,
                    24, 'regular', [0.2, 0.2, 0.2], leftW - padX * 2);
      tbLyr.name = 'EB_Sp_TextBody';
      if (doAnim) ebTextAnimatorFadeUp(tbLyr, lFrame, fps, 16);
    }
  }

  // ── RIGHT STACKED CARDS ───────────────────────────────────
  var N = rCards.length;
  if (N > 0) {
    var cardH   = Math.floor((contentH - L.cardGap * (N - 1)) / N);
    var cardPadX2 = 20;
    var cardPadT  = 22;
    var rCardFrame = 30;

    for (var ci = 0; ci < N; ci++) {
      var rc   = rCards[ci];
      var cardY = L.cardTop + ci * (cardH + L.cardGap) + Math.floor(cardH / 2);
      var cardDef = { x: rightCX, y: cardY, w: rightW, h: cardH };
      var borderClr = rc.accent ? ebColor(rc.accent) : ebColor('CDCDCD');
      var fillClr   = rc.fill   ? ebColor(rc.fill)   : ebColor('f5f5f5');
      var cardBg = ebCreateCardBg(comp, cardDef, 'EB_Sp_RCard_' + ci + '_Bg', null,
                                  borderClr, false, false, fillClr);
      if (doAnim) ebAnimateFadeUp(cardBg, rCardFrame, fps, 20);

      var contentX = rightCX - Math.floor(rightW / 2) + cardPadX2;
      var contentMaxW = rightW - cardPadX2 * 2;
      var curY     = cardY - Math.floor(cardH / 2) + cardPadT;

      if (rc.title) {
        var tColor = rc.titleColor ? ebColorRGB(rc.titleColor) : [0.07, 0.07, 0.07];
        var rcTitleLyr = ebText(comp, rc.title, contentX, curY + 22,
                                26, 'bold', tColor, 'left');
        rcTitleLyr.name = 'EB_Sp_RCard_' + ci + '_Title';
        if (doAnim) ebTextAnimatorFadeUp(rcTitleLyr, rCardFrame + 4, fps, 14);
        curY += 34;
      }

      if (rc.body) {
        var rcBodyLyr = ebTextParagraph(comp, rc.body, contentX, curY + 20,
                                        22, 'regular', [0.2, 0.2, 0.2], contentMaxW);
        rcBodyLyr.name = 'EB_Sp_RCard_' + ci + '_Body';
        if (doAnim) ebTextAnimatorFadeUp(rcBodyLyr, rCardFrame + 6, fps, 12);
        curY += 32;
      }

      if (rc.bullets) {
        for (var rb = 0; rb < rc.bullets.length; rb++) {
          var rbLyr = ebTextParagraph(comp, '\u2022  ' + rc.bullets[rb],
                        contentX, curY + 20, 20, 'regular', [0.2, 0.2, 0.2], contentMaxW);
          rbLyr.name = 'EB_Sp_RCard_' + ci + '_Bul_' + rb;
          if (doAnim) ebTextAnimatorFadeUp(rbLyr, rCardFrame + 6, fps, 10);
          curY += 28;
        }
      }

      rCardFrame += 10;
    }
  }
}

// ── Layout 2: cbLayoutCardsRow ──────────────────────────────
// Horizontal row of 2–4 equal cards spanning full content height.
function cbLayoutCardsRow(comp, params, fps, doAnim) {
  var L       = EB_LAYOUT;
  var accent  = params.accentColor || '76B900';
  var cards   = params.cards || [];
  var N       = cards.length;
  if (N < 2) N = 2;
  if (N > 4) N = 4;

  var contentW = L.compW - 2 * L.marginX;  // 1760
  var cardW    = Math.floor((contentW - L.cardGap * (N - 1)) / N);
  var cardH    = 750;
  var cardCY   = L.cardTop + Math.floor(cardH / 2);  // 605
  var padX     = 28;
  var padTop   = 32;
  var baseFrame = 22;

  for (var ci = 0; ci < N; ci++) {
    var c     = cards[ci];
    var cardCX = L.marginX + ci * (cardW + L.cardGap) + Math.floor(cardW / 2);
    var cardDef = { x: cardCX, y: cardCY, w: cardW, h: cardH };
    var fillClr = c.fill ? ebColor(c.fill) : ebColor('f5f5f5');
    var accentClr = c.accent ? ebColor(c.accent) : ebColor(accent);
    var borderClr = accentClr;

    var cardBg = ebCreateCardBg(comp, cardDef, 'EB_CR_Card_' + ci + '_Bg', null,
                                borderClr, true, false, fillClr);
    if (doAnim) ebAnimateFadeUp(cardBg, baseFrame + ci * 12, fps, 24);

    var cardTop2 = cardCY - Math.floor(cardH / 2);
    var curY     = cardTop2 + padTop;
    var icoSize  = c.iconSize || 48;

    // Icon
    if (c.icon) {
      var icoDir = $.global._ebpIconDir || '';
      if (icoDir) {
        try {
          var icoFile = new File(icoDir + '/' + c.icon + '.png');
          if (icoFile.exists) {
            var icoItem = app.project.importFile(new ImportOptions(icoFile));
            var icoLyr  = comp.layers.add(icoItem);
            icoLyr.name = 'EB_CR_Card_' + ci + '_Icon';
            icoLyr.property('Position').setValue([cardCX, curY + Math.floor(icoSize / 2)]);
            var sc = icoSize / icoItem.width * 100;
            icoLyr.property('Scale').setValue([sc, sc]);
            icoLyr.property('Anchor Point').setValue([Math.floor(icoItem.width / 2), Math.floor(icoItem.height / 2)]);
            if (doAnim) ebAnimateFadeUp(icoLyr, baseFrame + ci * 12 + 4, fps, 16);
          }
        } catch(e) {}
      }
      curY += icoSize + 16;
    }

    // Title
    if (c.title) {
      var tColor = c.titleColor ? ebColorRGB(c.titleColor) : [0.07, 0.07, 0.07];
      var doCenter = !!(c.icon || c.textAlign === 'center');
      var tAlign   = doCenter ? 'center' : 'left';
      var tX       = doCenter ? cardCX : (cardCX - Math.floor(cardW / 2) + padX);
      var titleLyr = ebText(comp, c.title, tX, curY + 24, 28, 'bold', tColor, tAlign);
      titleLyr.name = 'EB_CR_Card_' + ci + '_Title';
      if (doAnim) ebTextAnimatorFadeUp(titleLyr, baseFrame + ci * 12 + 4, fps, 16);
      curY += 38;

      // Title line
      if (c.titleLine) {
        var tlX1 = cardCX - Math.floor(cardW / 2) + padX;
        var tlX2 = cardCX + Math.floor(cardW / 2) - padX;
        var tlY  = curY + 4;
        var tlShp = comp.layers.addShape();
        tlShp.name = 'EB_CR_Card_' + ci + '_TitleLine';
        var tlTrimEnd = null;
        try {
          var tlGC  = tlShp.property('Contents').addProperty('ADBE Vector Group').property('Contents');
          var tlPth = tlGC.addProperty('ADBE Vector Shape - Group');
          try { tlPth.property('ADBE Vector Shape').setValue(ebOpenPath([[tlX1, tlY], [tlX2, tlY]])); } catch(e) {}
          var tlStr = tlGC.addProperty('ADBE Vector Graphic - Stroke');
          try { tlStr.property('ADBE Vector Stroke Color').setValue(accentClr); } catch(e) {}
          try { tlStr.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
          if (doAnim) {
            var tlTrim = tlGC.addProperty('ADBE Vector Filter - Trim');
            tlTrimEnd  = tlTrim.property('ADBE Vector Trim End');
          }
        } catch(e) {}
        if (doAnim && tlTrimEnd) {
          try { ebAnimateTrimDraw(tlTrimEnd, baseFrame + ci * 12 + 6, fps); } catch(e) {}
        }
        curY += 16;
      }
    }

    // Body
    if (c.body) {
      var tAlign2  = (c.textAlign === 'center') ? 'center' : 'left';
      var bX       = (tAlign2 === 'center') ? cardCX : (cardCX - Math.floor(cardW / 2) + padX);
      var bodyLyr  = ebTextParagraph(comp, c.body, bX, curY + 20, 22, 'regular',
                                     [0.2, 0.2, 0.2], cardW - padX * 2, tAlign2);
      bodyLyr.name = 'EB_CR_Card_' + ci + '_Body';
      if (doAnim) ebTextAnimatorFadeUp(bodyLyr, baseFrame + ci * 12 + 6, fps, 14);
      curY += 32;
    }

    // Bullets
    if (c.bullets) {
      for (var bi = 0; bi < c.bullets.length; bi++) {
        var bLyrC = ebTextParagraph(comp, '\u2022  ' + c.bullets[bi],
                      cardCX - Math.floor(cardW / 2) + padX, curY + 18,
                      20, 'regular', [0.2, 0.2, 0.2], cardW - padX * 2);
        bLyrC.name = 'EB_CR_Card_' + ci + '_Bul_' + bi;
        if (doAnim) ebTextAnimatorFadeUp(bLyrC, baseFrame + ci * 12 + 8, fps, 12);
        curY += 28;
      }
    }
  }
}

// ── Layout 3: cbLayoutStatsGrid ─────────────────────────────
// 2-column grid of metric/stat boxes.
function cbLayoutStatsGrid(comp, params, fps, doAnim) {
  var L      = EB_LAYOUT;
  var accent = params.accentColor || '76B900';
  var stats  = params.stats || [];
  var N      = stats.length;
  if (N < 2) N = 2;
  if (N > 6) N = 6;

  var colW   = Math.floor((1760 - L.cardGap) / 2);  // 865
  var rows   = Math.ceil(N / 2);
  var rowH   = Math.floor((750 - L.cardGap * (rows - 1)) / rows);
  var padX   = 28;
  var padTop = 28;
  var baseFrame = 22;

  for (var si = 0; si < N; si++) {
    var st   = stats[si];
    var col  = si % 2;
    var row  = Math.floor(si / 2);
    var boxCX = L.marginX + col * (colW + L.cardGap) + Math.floor(colW / 2);
    var boxCY = L.cardTop + row * (rowH + L.cardGap) + Math.floor(rowH / 2);
    var boxDef = { x: boxCX, y: boxCY, w: colW, h: rowH };
    var accentClr = st.accent ? ebColor(st.accent) : ebColor(accent);
    var fillClr   = ebColor('f5f5f5');

    var boxBg = ebCreateCardBg(comp, boxDef, 'EB_SG_Box_' + si + '_Bg', null,
                               accentClr, false, false, fillClr);
    if (doAnim) ebAnimateFadeUp(boxBg, baseFrame + si * 8, fps, 20);

    var cx   = boxCX;
    var topY = boxCY - Math.floor(rowH / 2) + padTop;

    // Value
    var valColor = st.accent ? ebColorRGB(st.accent) : ebColorRGB(accent);
    var valLyr = ebText(comp, st.value || '', cx, topY + 48, 56, 'bold', valColor, 'center');
    valLyr.name = 'EB_SG_Box_' + si + '_Value';
    if (doAnim) ebTextAnimatorFadeUp(valLyr, baseFrame + si * 8 + 3, fps, 24);

    // Label
    if (st.label) {
      var labLyr = ebText(comp, st.label, cx, topY + 48 + 52, 24, 'regular',
                          [0.33, 0.33, 0.33], 'center');
      labLyr.name = 'EB_SG_Box_' + si + '_Label';
      if (doAnim) ebTextAnimatorFadeUp(labLyr, baseFrame + si * 8 + 5, fps, 14);
    }

    // Body
    if (st.body) {
      var sbLyr = ebTextParagraph(comp, st.body,
                    boxCX - Math.floor(colW / 2) + padX, topY + 48 + 52 + 36,
                    20, 'regular', [0.4, 0.4, 0.4], colW - padX * 2);
      sbLyr.name = 'EB_SG_Box_' + si + '_Body';
      if (doAnim) ebTextAnimatorFadeUp(sbLyr, baseFrame + si * 8 + 5, fps, 10);
    }
  }
}

// ── Layout 4: cbLayoutFlowSteps ─────────────────────────────
// Horizontal step flow with numbered circles and connecting arrows.
function cbLayoutFlowSteps(comp, params, fps, doAnim) {
  var L      = EB_LAYOUT;
  var accent = params.accentColor || '76B900';
  var steps  = params.steps || [];
  var N      = steps.length;
  if (N < 3) N = 3;
  if (N > 5) N = 5;
  steps = steps.slice(0, N);

  var gap    = 40;
  var nodeW  = Math.floor((1760 - gap * (N - 1)) / N);
  var nodeH  = 600;
  var nodeCY = L.cardTop + Math.floor(nodeH / 2);  // 530
  var accentClr = ebColor(accent);
  var baseFrame = 22;

  for (var si = 0; si < N; si++) {
    var st     = steps[si];
    var nodeX  = L.marginX + si * (nodeW + gap) + Math.floor(nodeW / 2);
    var nodeTop = nodeCY - Math.floor(nodeH / 2);
    var nodeDef = { x: nodeX, y: nodeCY, w: nodeW, h: nodeH };
    var stepFrame = baseFrame + si * 12;

    // Card background
    var nodeBg = ebCreateCardBg(comp, nodeDef, 'EB_FS_Node_' + si + '_Bg', null,
                                accentClr, true, false, ebColor('ffffff'));
    if (doAnim) ebAnimateFadeUp(nodeBg, stepFrame, fps, 24);

    var padX   = 20;
    var padTop = 24;
    var circleR = 26;
    var circleY = nodeTop + padTop + circleR;

    // Number circle (shape)
    var circShp = comp.layers.addShape();
    circShp.name = 'EB_FS_Node_' + si + '_Circle';
    circShp.position.setValue([nodeX, circleY]);
    try {
      var circGC  = circShp.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var circEl  = circGC.addProperty('ADBE Vector Shape - Ellipse');
      var circFil = circGC.addProperty('ADBE Vector Graphic - Fill');
      try { circEl.property('ADBE Vector Ellipse Size').setValue([circleR * 2, circleR * 2]); } catch(e) {}
      try { circFil.property('ADBE Vector Fill Color').setValue(accentClr); } catch(e) {}
    } catch(e) {}
    if (doAnim) ebAnimateFadeUp(circShp, stepFrame + 3, fps, 16);

    // Number / icon text inside circle
    var numTxt = st.number ? String(st.number) : String(si + 1);
    var numLyr = ebText(comp, numTxt, nodeX, circleY + 9,
                        26, 'bold', [1, 1, 1], 'center');
    numLyr.name = 'EB_FS_Node_' + si + '_Num';
    if (doAnim) ebTextAnimatorFadeUp(numLyr, stepFrame + 4, fps, 10);

    var titleY = circleY + circleR + 24;

    // Title
    if (st.title) {
      var tColor = st.color ? ebColorRGB(st.color) : [0.07, 0.07, 0.07];
      var titleLyr = ebText(comp, st.title, nodeX, titleY + 22, 26, 'bold', tColor, 'center');
      titleLyr.name = 'EB_FS_Node_' + si + '_Title';
      if (doAnim) ebTextAnimatorFadeUp(titleLyr, stepFrame + 5, fps, 14);
      titleY += 38;
    }

    // Body
    if (st.body) {
      var bodyLyr = ebTextParagraph(comp, st.body,
                      nodeX - Math.floor(nodeW / 2) + padX, titleY + 18,
                      22, 'regular', [0.2, 0.2, 0.2], nodeW - padX * 2, 'center');
      bodyLyr.name = 'EB_FS_Node_' + si + '_Body';
      if (doAnim) ebTextAnimatorFadeUp(bodyLyr, stepFrame + 6, fps, 12);
    }
  }

  // Connecting arrows between nodes
  for (var ai = 0; ai < N - 1; ai++) {
    var n1X  = L.marginX + ai * (nodeW + gap) + Math.floor(nodeW / 2);
    var n2X  = L.marginX + (ai + 1) * (nodeW + gap) + Math.floor(nodeW / 2);
    var arrX1 = n1X + Math.floor(nodeW / 2) + 6;
    var arrX2 = n2X - Math.floor(nodeW / 2) - 6;
    var arrY  = nodeCY;

    var arrShp = comp.layers.addShape();
    arrShp.name = 'EB_FS_Arrow_' + ai;
    try {
      var arrCt  = arrShp.property('Contents');
      // Shaft line
      var arrGC  = arrCt.addProperty('ADBE Vector Group').property('Contents');
      var arrPth = arrGC.addProperty('ADBE Vector Shape - Group');
      var arrStr = arrGC.addProperty('ADBE Vector Graphic - Stroke');
      try { arrPth.property('ADBE Vector Shape').setValue(ebOpenPath([[arrX1, arrY], [arrX2, arrY]])); } catch(e) {}
      try { arrStr.property('ADBE Vector Stroke Color').setValue(accentClr); } catch(e) {}
      try { arrStr.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
      try { arrStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    } catch(e) {}
    // Arrowhead triangle (closed filled shape)
    try {
      var ahGC  = arrShp.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var ahPth = ahGC.addProperty('ADBE Vector Shape - Group');
      var ahFil = ahGC.addProperty('ADBE Vector Graphic - Fill');
      var ahSize = 8;
      var ahShape = new Shape();
      ahShape.vertices    = [[arrX2, arrY - ahSize], [arrX2 + Math.round(ahSize * 1.4), arrY], [arrX2, arrY + ahSize]];
      ahShape.inTangents  = [[0,0],[0,0],[0,0]];
      ahShape.outTangents = [[0,0],[0,0],[0,0]];
      ahShape.closed      = true;
      try { ahPth.property('ADBE Vector Shape').setValue(ahShape); } catch(e) {}
      try { ahFil.property('ADBE Vector Fill Color').setValue(accentClr); } catch(e) {}
    } catch(e) {}
    var arrFrame = baseFrame + ai * 12 + 10;
    if (doAnim) ebAnimateFadeUp(arrShp, arrFrame, fps, 12);
  }
}

// ============================================================
// End Option B — Constrained Custom Layouts
// ============================================================

function createCustomBlock(comp, params) {
  var fps    = comp.frameRate;
  var specs  = params.layers || [];
  var doAnim = params.animateIn !== false;

  // Dispatch to constrained layout presets (Option B — content-only, no coordinates)
  if (params.layout) {
    var lay = params.layout;
    if      (lay === 'split')       cbLayoutSplit(comp, params, fps, doAnim);
    else if (lay === 'cards-row')   cbLayoutCardsRow(comp, params, fps, doAnim);
    else if (lay === 'stats-grid')  cbLayoutStatsGrid(comp, params, fps, doAnim);
    else if (lay === 'flow-steps')  cbLayoutFlowSteps(comp, params, fps, doAnim);
    ebCreateHeader(comp, params, 12);
    return;
  }

  for (var i = 0; i < specs.length; i++) {
    var s  = specs[i];
    var nm = s.name || ('EB_Custom_' + i);
    var sf = (s.anim && typeof s.anim.frame === 'number') ? s.anim.frame : (28 + i * 6);
    var sl = (s.anim && typeof s.anim.slide === 'number') ? s.anim.slide : 24;
    var doLayerAnim = doAnim && (s.anim !== false);

    // ── text (single-line point text) ──────────────────────
    if (s.type === 'text') {
      var clr = s.color ? ebColorRGB(s.color) : [0, 0, 0];
      var lyr = ebText(comp, s.text || '', s.x || 960, s.y || 540,
                       s.size || 32, s.weight || 'regular', clr, s.align || 'center');
      lyr.name = nm;
      if (doLayerAnim) ebTextAnimatorFadeUp(lyr, sf, fps, sl);
    }

    // ── text-para (word-wrapped paragraph) ─────────────────
    else if (s.type === 'text-para') {
      var clr = s.color ? ebColorRGB(s.color) : [0, 0, 0];
      var lyr = ebTextParagraph(comp, s.text || '', s.x || 100, s.y || 540,
                                s.size || 26, s.weight || 'regular', clr, s.w || 800);
      lyr.name = nm;
      if (doLayerAnim) ebTextAnimatorFadeUp(lyr, sf, fps, sl);
    }

    // ── icon (NVIDIA brand SVG imported as footage layer) ───────────────────
    // Requires AE 2026+ for native SVG vector import. Fails silently on older AE.
    // s.icon = filename without extension, e.g. "m48-gpu-chip"
    // s.size = display size in px (square, default 64). s.x,y = center.
    // s.color = optional hex tint applied via Fill effect.
    else if (s.type === 'icon') {
      var icoDir  = $.global._ebpIconDir || '';
      var icoName = s.icon || '';
      if (icoName) {
        try {
          // Use pre-converted PNG if available (set by panel), else fall back to SVG
          var icoPath = s._pngPath || (icoDir ? icoDir + '/' + icoName + '.svg' : '');
          var icoFile = icoPath ? new File(icoPath) : null;
          if (icoFile && icoFile.exists) {
            var icoOpts    = new ImportOptions(icoFile);
            icoOpts.importAs = ImportAsType.FOOTAGE;
            var icoFootage = app.project.importFile(icoOpts);
            var icoLayer   = comp.layers.add(icoFootage);
            icoLayer.name  = nm;
            var icoSz  = s.size || 64;
            var icoW   = icoFootage.width  || 48;
            var icoH   = icoFootage.height || 48;
            var icoScX = (icoSz / icoW) * 100;
            var icoScY = (icoSz / icoH) * 100;
            try { icoLayer.position.setValue([s.x || 960, s.y || 540]); } catch(e) {}
            try { icoLayer.scale.setValue([icoScX, icoScY, 100]); } catch(e) {}
            if (s.color) {
              try {
                var icoFx  = icoLayer.Effects.addProperty('ADBE Fill');
                var icoClr = ebColor(s.color);
                icoFx.property('ADBE Fill-0002').setValue([icoClr[0], icoClr[1], icoClr[2], 1]);
              } catch(e) {}
            }
            if (doLayerAnim) ebAnimateFadeUp(icoLayer, sf, fps, sl);
          }
        } catch(e) {}  // silently skip missing / unsupported icons
      }
    }

    // ── hbar (left-aligned horizontal bar + centered label + optional annotation) ──
    // Eliminates manual proportional-bar math for bar chart patterns.
    // x = LEFT EDGE of bar area. barW = maxW * (value/maxValue). rect center auto-computed.
    // If bar is too narrow for label, label moves to the right of the bar.
    // sectionLabel = small caption ABOVE the bar (auto-positioned at bar_top - gap).
    else if (s.type === 'hbar') {
      var hbMaxW  = s.maxW  || 960;
      var hbH     = s.h     || 80;
      var hbVal   = (typeof s.value    === 'number') ? s.value    : 1;
      var hbMax   = (typeof s.maxValue === 'number') ? s.maxValue : 1;
      var hbRatio = (hbMax > 0) ? Math.min(hbVal / hbMax, 1) : 0;
      var hbW     = Math.max(Math.round(hbMaxW * hbRatio), 4);
      var hbX     = s.x || 880;
      var hbY     = s.y || 400;
      var hbCx    = hbX + hbW / 2;

      // Section label above the bar (auto-positioned)
      if (s.sectionLabel) {
        var slSize = s.sectionLabelSize || 22;
        var slClr  = s.sectionLabelColor ? ebColorRGB(s.sectionLabelColor) : [0.37, 0.37, 0.37];
        // Place bottom of label 12px above bar top edge; baseline = bar_top - 12 + descender
        var slY    = Math.round((hbY - hbH / 2) - 12 - slSize * 0.25);
        var slLyr  = ebText(comp, s.sectionLabel, hbX, slY, slSize, 'regular', slClr, 'left');
        slLyr.name = nm + '_SLabel';
        if (doLayerAnim) ebTextAnimatorFadeUp(slLyr, sf, fps, sl);
      }

      // Bar rect
      if (hbW > 0) {
        var hbLyr = comp.layers.addShape();
        hbLyr.name = nm + '_Rect';
        hbLyr.position.setValue([hbCx, hbY]);
        var hbGc  = hbLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
        var hbR   = hbGc.addProperty('ADBE Vector Shape - Rect');
        try { hbR.property('ADBE Vector Rect Size').setValue([hbW, hbH]); } catch(e) {}
        try { hbR.property('ADBE Vector Rect Roundness').setValue(s.radius || 2); } catch(e) {}
        var hbFc  = ebColor(s.fill || '76B900');
        var hbF   = hbGc.addProperty('ADBE Vector Graphic - Fill');
        try { hbF.property('ADBE Vector Fill Color').setValue(hbFc); } catch(e) {}
        if (doLayerAnim) ebAnimateFadeUp(hbLyr, sf, fps, sl);
      }

      // Label: inside bar if bar is wide enough, otherwise to the right
      if (s.label) {
        var lbSize    = s.labelSize || 28;
        var lbClr     = s.labelColor ? ebColorRGB(s.labelColor) : [1, 1, 1];
        var lbBaseline = Math.round(hbY + lbSize * 0.35);
        var labelInside = hbW >= lbSize * 3; // rough min-width check
        var lbX, lbAlign;
        if (labelInside) {
          lbX = hbCx; lbAlign = 'center';
          lbClr = s.labelColor ? ebColorRGB(s.labelColor) : [1, 1, 1];
        } else {
          lbX = hbX + hbW + 16; lbAlign = 'left';
          lbClr = s.labelColor ? ebColorRGB(s.labelColor) : [0.07, 0.07, 0.07];
        }
        var lbLyr = ebText(comp, s.label, lbX, lbBaseline, lbSize,
                           s.labelWeight || 'bold', lbClr, lbAlign);
        lbLyr.name = nm + '_Label';
        if (doLayerAnim) ebTextAnimatorFadeUp(lbLyr, sf, fps, sl);
      }

      // Annotation: small text above the bar right edge
      if (s.annotation) {
        var anSize = s.annotationSize || 20;
        var anClr  = s.annotationColor ? ebColorRGB(s.annotationColor) : [0.35, 0.09, 0.51];
        // Sits just above bar top, right-aligned to bar right edge
        var anBarTop  = hbY - hbH / 2;
        var anY       = Math.round(anBarTop - 8 - anSize * 0.25);
        var anX       = hbX + hbW;
        var anLyr     = ebText(comp, s.annotation, anX, anY, anSize, 'regular', anClr, 'right');
        anLyr.name = nm + '_Annot';
        if (doLayerAnim) ebTextAnimatorFadeUp(anLyr, sf, fps, sl);
      }
    }

    // ── card (rect + auto-positioned content) ───────────────
    // Supports: title, body, bullets, titleLine, iconTop, iconBottom.
    // All y positions are computed from card geometry — no manual math needed.
    else if (s.type === 'card') {
      var cx         = s.x || 432;
      var cy         = s.y || 480;
      var cw         = s.w || 560;
      var ch         = s.h || 144;
      var padX       = s.padX   || 24;
      var padTop     = s.padTop || 24;
      var tSize      = s.titleSize || 28;
      var bSize      = s.bodySize  || 22;
      var icoSize    = s.iconSize  || 48;
      var icoName    = s.iconTop || s.iconBottom || '';
      var icoDir     = $.global._ebpIconDir || '';
      var cardTop_y  = cy - ch / 2;
      var cardLeft_x = cx - cw / 2;
      // Cards with iconTop default to center alignment; others default to left.
      var defaultCenter = !!(s.iconTop);
      var isCenter = (s.textAlign === 'center') || (s.textAlign !== 'left' && defaultCenter);
      var tX         = isCenter ? cx : (cardLeft_x + padX);
      var tAlign     = isCenter ? 'center' : 'left';

      // ① Background rect
      var bgLyr = comp.layers.addShape();
      bgLyr.name = nm + '_BG';
      bgLyr.position.setValue([cx, cy]);
      var bgGc = bgLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var bgR  = bgGc.addProperty('ADBE Vector Shape - Rect');
      try { bgR.property('ADBE Vector Rect Size').setValue([cw, ch]); } catch(e) {}
      try { bgR.property('ADBE Vector Rect Roundness').setValue(s.radius || 2); } catch(e) {}
      if (s.fill !== false) {
        var bgFc = ebColor(s.fill || 'ffffff');
        var bgF  = bgGc.addProperty('ADBE Vector Graphic - Fill');
        try { bgF.property('ADBE Vector Fill Color').setValue(bgFc); } catch(e) {}
      }
      if (s.stroke) {
        var bgSc = ebColor(s.stroke);
        var bgSt = bgGc.addProperty('ADBE Vector Graphic - Stroke');
        try { bgSt.property('ADBE Vector Stroke Color').setValue(bgSc); } catch(e) {}
        try { bgSt.property('ADBE Vector Stroke Width').setValue(s.strokeW || 2); } catch(e) {}
      }
      if (doLayerAnim) ebAnimateFadeUp(bgLyr, sf, fps, sl);

      // ② iconTop — rendered before title, pushes title down
      var contentY = cardTop_y + padTop; // running y cursor (visual tops)
      if (s.iconTop) {
        var itPath = s._iconTopPng || (icoDir ? icoDir + '/' + s.iconTop + '.svg' : '');
        try {
          var itFile = itPath ? new File(itPath) : null;
          if (itFile && itFile.exists) {
            var itOpts = new ImportOptions(itFile);
            itOpts.importAs = ImportAsType.FOOTAGE;
            var itFootage = app.project.importFile(itOpts);
            var itLyr = comp.layers.add(itFootage);
            itLyr.name = nm + '_IconTop';
            var itScl = (icoSize / (itFootage.width || 48)) * 100;
            try { itLyr.position.setValue([cx, contentY + icoSize / 2]); } catch(e) {}
            try { itLyr.scale.setValue([itScl, itScl, 100]); } catch(e) {}
            if (doLayerAnim) ebAnimateFadeUp(itLyr, sf, fps, sl);
          }
        } catch(e) {}
        contentY += icoSize + 16; // advance past icon + gap
      }

      // ③ Title text
      if (s.title) {
        var tClr      = s.titleColor ? ebColorRGB(s.titleColor) : [0.07, 0.07, 0.07];
        var tBaseline = Math.round(contentY + tSize);
        var tLyr      = ebText(comp, s.title, tX, tBaseline, tSize,
                               s.titleWeight || 'bold', tClr, tAlign);
        tLyr.name = nm + '_Title';
        if (doLayerAnim) ebTextAnimatorFadeUp(tLyr, sf, fps, sl);
        contentY = tBaseline + 10; // advance past title
      }

      // ④ titleLine — horizontal rule below title (like Abstractor diagram style)
      if (s.titleLine && s.title) {
        var tlLineY  = Math.round(contentY + 2);
        var tlClr    = s.titleColor ? ebColor(s.titleColor) : ebColor('CDCDCD');
        var tlLyr    = comp.layers.addShape();
        tlLyr.name   = nm + '_TitleLine';
        tlLyr.position.setValue([cx, tlLineY]);
        var tlGc     = tlLyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
        var tlPg     = tlGc.addProperty('ADBE Vector Shape - Group');
        var tlHalfW  = cw / 2 - padX;
        try { tlPg.property('ADBE Vector Shape').setValue(ebOpenPath([[-tlHalfW, 0], [tlHalfW, 0]])); } catch(e) {}
        var tlSt     = tlGc.addProperty('ADBE Vector Graphic - Stroke');
        try { tlSt.property('ADBE Vector Stroke Color').setValue(tlClr); } catch(e) {}
        try { tlSt.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
        if (doLayerAnim) {
          var tlTrim = tlGc.addProperty('ADBE Vector Filter - Trim');
          var tlEnd  = tlTrim.property('ADBE Vector Trim End');
          try { tlLyr.inPoint = sf / fps; } catch(e) {}
          ebAnimateTrimDraw(tlEnd, sf, fps);
        }
        contentY = tlLineY + 14; // advance past line + gap
      }

      // ⑤ Body text (paragraph — wraps at card inner width, never overflows)
      if (s.body) {
        var bClr      = s.bodyColor ? ebColorRGB(s.bodyColor) : [0.2, 0.2, 0.2];
        var bBaseline = Math.round(contentY + bSize);
        var bLyr      = ebTextParagraph(comp, s.body, cardLeft_x + padX, bBaseline, bSize,
                                        s.bodyWeight || 'regular', bClr, cw - padX * 2, tAlign);
        bLyr.name = nm + '_Body';
        if (doLayerAnim) ebTextAnimatorFadeUp(bLyr, sf, fps, sl);
        contentY = bBaseline + 10;
      }

      // ⑥ Bullets — array of short text items, each on its own line
      if (s.bullets && s.bullets.length) {
        var bulClr = s.bodyColor ? ebColorRGB(s.bodyColor) : [0.13, 0.13, 0.13];
        for (var bi = 0; bi < s.bullets.length; bi++) {
          var bulBaseline = Math.round(contentY + bSize);
          var bulTxt = '\u2022  ' + s.bullets[bi]; // bullet char + text
          var bulLyr = ebTextParagraph(comp, bulTxt, cardLeft_x + padX, bulBaseline, bSize,
                                       'regular', bulClr, cw - padX * 2);
          bulLyr.name = nm + '_Bul' + (bi + 1);
          if (doLayerAnim) ebTextAnimatorFadeUp(bulLyr, sf + bi * 4, fps, sl);
          contentY = bulBaseline + 10;
        }
      }

      // ⑦ iconBottom — rendered at bottom-center, independent of text layout
      if (s.iconBottom) {
        var ibPath = s._iconBottomPng || (icoDir ? icoDir + '/' + s.iconBottom + '.svg' : '');
        try {
          var ibFile = ibPath ? new File(ibPath) : null;
          if (ibFile && ibFile.exists) {
            var ibOpts = new ImportOptions(ibFile);
            ibOpts.importAs = ImportAsType.FOOTAGE;
            var ibFootage = app.project.importFile(ibOpts);
            var ibLyr = comp.layers.add(ibFootage);
            ibLyr.name = nm + '_IconBot';
            var ibScl = (icoSize / (ibFootage.width || 48)) * 100;
            var ibX = (s.iconBottomAlign === 'right')
              ? Math.round(cx + cw / 2 - padX - icoSize / 2)
              : cx;
            var ibY = Math.round(cy + ch / 2 - padTop - icoSize / 2);
            try { ibLyr.position.setValue([ibX, ibY]); } catch(e) {}
            try { ibLyr.scale.setValue([ibScl, ibScl, 100]); } catch(e) {}
            if (doLayerAnim) ebAnimateFadeUp(ibLyr, sf + 8, fps, sl);
          }
        } catch(e) {}
      }
    }

    // ── rect (rounded rectangle) ────────────────────────────
    else if (s.type === 'rect') {
      var lyr = comp.layers.addShape();
      lyr.name = nm;
      lyr.position.setValue([s.x || 960, s.y || 540]);
      var gc = lyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var r  = gc.addProperty('ADBE Vector Shape - Rect');
      try { r.property('ADBE Vector Rect Size').setValue([s.w || 200, s.h || 100]); } catch(e) {}
      try { r.property('ADBE Vector Rect Roundness').setValue(s.radius || 4); }      catch(e) {}
      if (s.fill) {
        var fc = ebColor(s.fill);
        var f  = gc.addProperty('ADBE Vector Graphic - Fill');
        try { f.property('ADBE Vector Fill Color').setValue(fc); } catch(e) {}
      }
      if (s.stroke) {
        var sc = ebColor(s.stroke);
        var st = gc.addProperty('ADBE Vector Graphic - Stroke');
        try { st.property('ADBE Vector Stroke Color').setValue(sc); } catch(e) {}
        try { st.property('ADBE Vector Stroke Width').setValue(s.strokeW || 2); } catch(e) {}
      }
      if (s.shadow) try { ebDropShadow(lyr, 30, 14, 40); } catch(e) {}
      if (doLayerAnim) ebAnimateFadeUp(lyr, sf, fps, sl);
    }

    // ── circle / ellipse ────────────────────────────────────
    else if (s.type === 'circle') {
      var lyr = comp.layers.addShape();
      lyr.name = nm;
      lyr.position.setValue([s.x || 960, s.y || 540]);
      var gc = lyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var el = gc.addProperty('ADBE Vector Shape - Ellipse');
      var r  = s.r || 40;
      try { el.property('ADBE Vector Ellipse Size').setValue([r * 2, r * 2]); } catch(e) {}
      if (s.fill) {
        var fc = ebColor(s.fill);
        var f  = gc.addProperty('ADBE Vector Graphic - Fill');
        try { f.property('ADBE Vector Fill Color').setValue(fc); } catch(e) {}
      }
      if (s.stroke) {
        var sc = ebColor(s.stroke);
        var st = gc.addProperty('ADBE Vector Graphic - Stroke');
        try { st.property('ADBE Vector Stroke Color').setValue(sc); } catch(e) {}
        try { st.property('ADBE Vector Stroke Width').setValue(s.strokeW || 2); } catch(e) {}
      }
      if (doLayerAnim) ebAnimateFadeUp(lyr, sf, fps, sl);
    }

    // ── line / rule ─────────────────────────────────────────
    else if (s.type === 'line') {
      var lyr = comp.layers.addShape();
      lyr.name = nm;
      lyr.position.setValue([0, 0]);
      var gc = lyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
      var pg = gc.addProperty('ADBE Vector Shape - Group');
      try { pg.property('ADBE Vector Shape').setValue(
        ebOpenPath([[s.x1 || 0, s.y1 || 540], [s.x2 || 1920, s.y2 || 540]])
      ); } catch(e) {}
      var sc = ebColor(s.stroke || '76B900');
      var st = gc.addProperty('ADBE Vector Graphic - Stroke');
      try { st.property('ADBE Vector Stroke Color').setValue(sc); } catch(e) {}
      try { st.property('ADBE Vector Stroke Width').setValue(s.strokeW || 2); } catch(e) {}
      if (doLayerAnim) {
        if (s.anim && s.anim.trim) {
          var trim = gc.addProperty('ADBE Vector Filter - Trim');
          var te   = trim.property('ADBE Vector Trim End');
          try { lyr.inPoint = sf / fps; } catch(e) {}
          ebAnimateTrimDraw(te, sf, fps);
        } else {
          ebAnimateFadeUp(lyr, sf, fps, sl);
        }
      }
    }

    // ── arrow (line + arrowhead triangle) ───────────────────
    else if (s.type === 'arrow') {
      var lyr = comp.layers.addShape();
      lyr.name = nm;
      lyr.position.setValue([0, 0]);
      var c = lyr.property('Contents');
      // Shaft
      var sg  = c.addProperty('ADBE Vector Group').property('Contents');
      var spg = sg.addProperty('ADBE Vector Shape - Group');
      try { spg.property('ADBE Vector Shape').setValue(
        ebOpenPath([[s.x1 || 0, s.y1 || 540], [s.x2 || 300, s.y2 || 540]])
      ); } catch(e) {}
      var sc = ebColor(s.stroke || '76B900');
      var sst = sg.addProperty('ADBE Vector Graphic - Stroke');
      try { sst.property('ADBE Vector Stroke Color').setValue(sc); } catch(e) {}
      try { sst.property('ADBE Vector Stroke Width').setValue(s.strokeW || 2); } catch(e) {}
      // Arrowhead (small triangle at x2,y2)
      var dx = (s.x2 || 300) - (s.x1 || 0);
      var dy = (s.y2 || 540) - (s.y1 || 540);
      var len = Math.sqrt(dx * dx + dy * dy) || 1;
      var ux = dx / len, uy = dy / len;
      var pw = 10, ph = 14;
      var ax = (s.x2 || 300), ay = (s.y2 || 540);
      var p0 = [ax, ay];
      var p1 = [ax - ux * ph - uy * pw, ay - uy * ph + ux * pw];
      var p2 = [ax - ux * ph + uy * pw, ay - uy * ph - ux * pw];
      var ag  = c.addProperty('ADBE Vector Group').property('Contents');
      var apg = ag.addProperty('ADBE Vector Shape - Group');
      try {
        var shape = new Shape();
        shape.vertices   = [p0, p1, p2];
        shape.inTangents = [[0,0],[0,0],[0,0]];
        shape.outTangents = [[0,0],[0,0],[0,0]];
        shape.closed = true;
        apg.property('ADBE Vector Shape').setValue(shape);
      } catch(e) {}
      var afc = ebColor(s.stroke || '76B900');
      var af  = ag.addProperty('ADBE Vector Graphic - Fill');
      try { af.property('ADBE Vector Fill Color').setValue(afc); } catch(e) {}
      if (doLayerAnim) ebAnimateFadeUp(lyr, sf, fps, sl);
    }
  }

  // Title + subtitle header (added after content so it renders on top)
  ebCreateHeader(comp, params, 12);
}

// =============================================================
// TIMELINE / ROADMAP  (diagram-timeline)
// =============================================================
// 4 milestone nodes on a horizontal line.
// Each node: diamond marker (addSolid rotated 45deg), date + label above,
// description below. Text uses LEFT_JUSTIFY + manual half-width offset
// — the only reliable centering method in AE 2024+ without sourceRectAtTime.
// =============================================================
function createTimelineBlock(comp, params) {
  var fps       = comp.frameRate;
  var sf        = 1;
  var color     = ebColor(params.accentColor);
  var colorRGB  = [color[0], color[1], color[2]];
  var colorArr  = [color[0], color[1], color[2], 1];
  var colorTick = [color[0], color[1], color[2], 0.4];
  var descClr   = [0.33, 0.33, 0.33];
  var L         = EB_LAYOUT;

  var N          = Math.min(Math.max(parseInt(params.timelineCount) || 4, 2), 10);
  var tlStyle    = params.timelineStyle || 'straight';  // 'straight' | 'alternate'
  var pointStyle = params.pointStyle    || 'diamond';   // 'diamond' | 'circle' | 'square'

  // Default milestone data
  var _defDates  = ['Q1 2024','Q2 2024','Q3 2024','Q4 2024',
                    'Q1 2025','Q2 2025','Q3 2025','Q4 2025','Q1 2026','Q2 2026'];
  var _defLabels = ['Foundation','Development','Beta','Launch',
                    'Growth','Scale','Optimize','Expand','Mature','Next'];
  var _defDescs  = ['Planning and setup','Core implementation','Partner testing','General release',
                    'User adoption','Infrastructure','Performance','New markets','Mature product','Future roadmap'];

  var items = [];
  for (var _k = 0; _k < N; _k++) {
    var _src = (params.milestones && params.milestones[_k]) ? params.milestones[_k] : {};
    items.push({
      date:  _src.date  || _defDates[_k],
      label: _src.label || _defLabels[_k],
      text:  _src.text  || _defDescs[_k]
    });
  }

  // Node X positions — evenly distributed
  var lineLeft  = 160;
  var lineRight = 1760;
  var nodeXs    = [];
  for (var _k2 = 0; _k2 < N; _k2++) {
    nodeXs.push(Math.round(lineLeft + (lineRight - lineLeft) * _k2 / (N > 1 ? N - 1 : 1)));
  }

  // Font sizes — scale down for dense layouts
  var dateFSz  = N <= 5 ? 22 : 18;
  var labelFSz = N <= 5 ? 28 : 22;
  var descFSz  = N <= 5 ? 24 : 20;

  // ── Y layout ─────────────────────────────────────────────────────────
  // straight: date + label above line, desc below
  // alternate: even events above, odd events below (zigzag)
  var lineY;
  // straight Y positions
  var st_dateY, st_labelY, st_tickT, st_tickB, st_descY;
  // alternate — above lane
  var al_aDateY, al_aLblY, al_aDescY, al_aTickT, al_aTickB;
  // alternate — below lane
  var al_bTickT, al_bTickB, al_bDescY, al_bLblY, al_bDateY;

  if (tlStyle === 'alternate') {
    lineY       = 605;
    al_aDateY   = 305;
    al_aLblY    = 362;
    al_aDescY   = 422;
    al_aTickT   = 448;
    al_aTickB   = lineY - 20;  // 585
    al_bTickT   = lineY + 20;  // 625
    al_bTickB   = 668;
    al_bDescY   = 702;
    al_bLblY    = 752;
    al_bDateY   = 808;
  } else {
    lineY       = 580;
    st_dateY    = 410;
    st_labelY   = 466;
    st_tickT    = 488;
    st_tickB    = lineY - 16;  // 564
    st_descY    = lineY + 84;  // 664
  }

  // ── Horizontal timeline line ──────────────────────────────────────────
  var lineLayer = comp.layers.addShape();
  lineLayer.name = 'EB_TL_Line';
  lineLayer.position.setValue([960, lineY]);
  var llg = lineLayer.property('Contents').addProperty('ADBE Vector Group');
  llg.name = 'Line';
  var llc = llg.property('Contents');
  var llp = llc.addProperty('ADBE Vector Shape - Group');
  try { llp.property('ADBE Vector Shape').setValue(
    ebOpenPath([[lineLeft - 960, 0], [lineRight - 960, 0]])
  ); } catch(e) {}
  var lls = llc.addProperty('ADBE Vector Graphic - Stroke');
  try { lls.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { lls.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  try { lls.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  var llt    = llc.addProperty('ADBE Vector Filter - Trim');
  var lltEnd = llt.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { lineLayer.inPoint = sf / fps; } catch(e) {}
    try { ebAnimateTrimDraw(lltEnd, sf, fps); } catch(e) {}
  } else {
    try { lltEnd.setValue(100); } catch(e) {}
  }

  // ── Per-node elements ─────────────────────────────────────────────────
  for (var i = 0; i < N; i++) {
    var nx      = nodeXs[i];
    var nodeSF  = sf + 20 + i * 8;
    var item    = items[i];
    var isAbove = (tlStyle === 'straight') || (i % 2 === 0);

    // ── Marker ──
    if (pointStyle === 'circle') {
      var R_C  = 9;
      var k_c  = 0.5523;
      var cirSol = comp.layers.addSolid(colorRGB, 'EB_TL_Dot_' + (i+1), R_C*2, R_C*2, 1);
      cirSol.position.setValue([nx, lineY]);
      var cirMask = cirSol.Masks.addProperty('ADBE Mask Atom');
      try { cirMask.maskMode = MaskMode.ADD; } catch(e) {}
      var cirShape = new Shape();
      cirShape.vertices    = [[R_C, 0], [R_C*2, R_C], [R_C, R_C*2], [0, R_C]];
      cirShape.inTangents  = [[-R_C*k_c, 0], [0, -R_C*k_c], [R_C*k_c, 0], [0, R_C*k_c]];
      cirShape.outTangents = [[R_C*k_c, 0], [0, R_C*k_c], [-R_C*k_c, 0], [0, -R_C*k_c]];
      cirShape.closed = true;
      try { cirMask.property('ADBE Mask Shape').setValue(cirShape); } catch(e) {}
      ebFadeOnly(cirSol, nodeSF, fps, 8);
    } else if (pointStyle === 'square') {
      var sqSol = comp.layers.addSolid(colorRGB, 'EB_TL_Dot_' + (i+1), 14, 14, 1);
      sqSol.position.setValue([nx, lineY]);
      ebFadeOnly(sqSol, nodeSF, fps, 8);
    } else {
      // diamond (default) — rotated square
      var diaSol = comp.layers.addSolid(colorRGB, 'EB_TL_Dot_' + (i+1), 14, 14, 1);
      diaSol.position.setValue([nx, lineY]);
      try { diaSol.rotation.setValue(45); } catch(e) {}
      ebFadeOnly(diaSol, nodeSF, fps, 8);
    }

    // ── Connector tick ──
    var myTickT = isAbove
      ? (tlStyle === 'straight' ? st_tickT : al_aTickT)
      : al_bTickT;
    var myTickB = isAbove
      ? (tlStyle === 'straight' ? st_tickB : al_aTickB)
      : al_bTickB;

    var tickLyr = comp.layers.addShape();
    tickLyr.name = 'EB_TL_Tick_' + (i+1);
    tickLyr.position.setValue([nx, lineY]);
    var tkg = tickLyr.property('Contents').addProperty('ADBE Vector Group');
    tkg.name = 'Tick';
    var tkc = tkg.property('Contents');
    var tkp = tkc.addProperty('ADBE Vector Shape - Group');
    try { tkp.property('ADBE Vector Shape').setValue(
      ebOpenPath([[0, myTickT - lineY], [0, myTickB - lineY]])
    ); } catch(e) {}
    var tks = tkc.addProperty('ADBE Vector Graphic - Stroke');
    try { tks.property('ADBE Vector Stroke Color').setValue(colorTick); } catch(e) {}
    try { tks.property('ADBE Vector Stroke Width').setValue(1.5); } catch(e) {}
    ebFadeOnly(tickLyr, nodeSF, fps, 8);

    // ── Text positions ──
    var myDateY, myLblY, myDescY;
    if (isAbove) {
      myDateY = tlStyle === 'straight' ? st_dateY  : al_aDateY;
      myLblY  = tlStyle === 'straight' ? st_labelY : al_aLblY;
      myDescY = tlStyle === 'straight' ? st_descY  : al_aDescY;
    } else {
      myDescY = al_bDescY;
      myLblY  = al_bLblY;
      myDateY = al_bDateY;
    }

    // Adaptive justify: left for first node, right for last, center for middle
    var txtJustify = (i === 0) ? 'left' : (i === N - 1) ? 'right' : 'center';

    var dateLyr = ebText(comp, item.date  || '', nx, myDateY,  dateFSz,  'bold',     colorRGB, txtJustify);
    dateLyr.name = 'EB_TL_Date_' + (i+1);
    ebTextAnimatorFadeUp(dateLyr, nodeSF,     fps, 18);

    var lblLyr  = ebText(comp, item.label || '', nx, myLblY,   labelFSz, 'semibold', colorRGB, txtJustify);
    lblLyr.name  = 'EB_TL_Label_' + (i+1);
    ebTextAnimatorFadeUp(lblLyr,  nodeSF + 2,  fps, 16);

    var descLyr = ebText(comp, item.text  || '', nx, myDescY,  descFSz,  'regular',  descClr,  txtJustify);
    descLyr.name = 'EB_TL_Desc_' + (i+1);
    ebTextAnimatorFadeUp(descLyr, nodeSF + 5,  fps, 16);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// FUNNEL  (diagram-funnel)
// =============================================================
// 4 horizontal bands decreasing in width (top = widest).
// Bands are stroke-only shape layers (no fill) on white bg.
// Label in accent color, description in grey.
// =============================================================
function createFunnelBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var colorRGB = [color[0], color[1], color[2]];
  var colorArr = [color[0], color[1], color[2], 1];
  var descClr  = [0.35, 0.35, 0.35];

  // Default funnel stages
  var defStages = [
    { label: 'Awareness',   text: 'Reach and initial impressions' },
    { label: 'Interest',    text: 'Active engagement and research' },
    { label: 'Evaluation',  text: 'Trials, demos, and proof of value' },
    { label: 'Conversion',  text: 'Customers acquired and onboarded' }
  ];
  var stages = (params.stages && params.stages.length >= 2)
    ? params.stages : defStages;
  var n = Math.min(stages.length, 6);

  // ── Layout constants ───────────────────────────────────────────────
  var bandH    = 130;
  var bandGap  = 8;
  var maxW     = 1360;
  var minW     = 430;
  var wStep    = (n > 1) ? Math.round((maxW - minW) / (n - 1)) : 0;
  var totalH   = n * bandH + (n - 1) * bandGap;
  var topY     = Math.round(605 - totalH / 2);
  var padLeft  = 48;

  // ── Bands + text ────────────────────────────────────────────────────
  for (var i = 0; i < n; i++) {
    var bandW       = maxW - i * wStep;
    var bandCenterY = topY + i * (bandH + bandGap) + Math.round(bandH / 2);
    var bandSF      = sf + i * 9;
    var hw = Math.round(bandW / 2);
    var hh = Math.round(bandH / 2);

    // Band — stroke-only closed rectangle shape layer, centered at x=960
    var bandLyr = comp.layers.addShape();
    bandLyr.name = 'EB_FN_Band_' + (i+1);
    bandLyr.position.setValue([960, bandCenterY]);
    var bGC  = bandLyr.property('Contents');
    var bGrp = bGC.addProperty('ADBE Vector Group');
    bGrp.name = 'Band';
    var bGCi = bGrp.property('Contents');
    var bPath = bGCi.addProperty('ADBE Vector Shape - Group');
    var rectShape = new Shape();
    rectShape.vertices    = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
    rectShape.inTangents  = [[0,0],[0,0],[0,0],[0,0]];
    rectShape.outTangents = [[0,0],[0,0],[0,0],[0,0]];
    rectShape.closed = true;
    try { bPath.property('ADBE Vector Shape').setValue(rectShape); } catch(e) {}
    var bStroke = bGCi.addProperty('ADBE Vector Graphic - Stroke');
    try { bStroke.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { bStroke.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    try { bStroke.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    ebTextAnimatorFadeUp(bandLyr, bandSF, fps, 16);

    // Text x: left edge of this band + padding
    var textX = Math.round(960 - hw) + padLeft;

    // Stage label — semibold, accent color, 30pt
    var lblStr = stages[i].label || '';
    var lblY   = bandCenterY - 10;
    var lblLyr = ebText(comp, lblStr, textX, lblY, 30, 'semibold', colorRGB, 'left');
    lblLyr.name = 'EB_FN_Label_' + (i+1);
    ebTextAnimatorFadeUp(lblLyr, bandSF + 2, fps, 14);

    // Description — regular, grey, 22pt
    var descStr = stages[i].text || '';
    var descY   = bandCenterY + 30;
    var descLyr = ebText(comp, descStr, textX, descY, 22, 'regular', descClr, 'left');
    descLyr.name = 'EB_FN_Desc_' + (i+1);
    ebTextAnimatorFadeUp(descLyr, bandSF + 4, fps, 14);
  }
}

// =============================================================
// 2x2 COMPARISON MATRIX  (diagram-matrix)
// =============================================================
// Two perpendicular axis lines (with V-stroke arrowheads) dividing
// the comp into 4 quadrants. Each quadrant has a bold title + description.
// HIGH/LOW endpoint labels + axis dimension labels.
// =============================================================
function createMatrixBlock(comp, params) {
  var fps      = comp.frameRate;
  var sf       = 1;
  var color    = ebColor(params.accentColor);
  var colorRGB = [color[0], color[1], color[2]];
  var colorArr = [color[0], color[1], color[2], 1];
  var dimClr   = [0.52, 0.52, 0.52];   // neutral grey for endpoint + axis labels
  var bodyClr  = [0.33, 0.33, 0.33];   // dark grey for descriptions

  // Default quadrant data — arranged [TL, TR, BL, BR]
  var defQ = [
    { title: 'Quick Wins',     text: 'High value, low effort — prioritize now' },
    { title: 'Strategic Bets', text: 'High value, high effort — plan carefully' },
    { title: 'Fill-Ins',       text: 'Low value, low effort — do if time permits' },
    { title: 'Time Sinks',     text: 'Low value, high effort — minimize or avoid' }
  ];
  var quads = (params.quadrants && params.quadrants.length === 4)
    ? params.quadrants : defQ;

  // Axis dimension labels (user-overridable)
  var xLabel = params.xLabel || 'EFFORT';
  var yLabel = params.yLabel || 'VALUE';

  // ── Axis geometry ─────────────────────────────────────────────────
  var axH  = 610;   // horizontal axis y
  var axV  = 960;   // vertical axis x
  var hx0  = 140;   // horizontal axis left x
  var hx1  = 1770;  // horizontal axis right x (arrowhead tip)
  var vy0  = 258;   // vertical axis top y (arrowhead tip)
  var vy1  = 968;   // vertical axis bottom y
  var arLen = 11;   // arrowhead arm length
  var arW  =  8;    // arrowhead half-width

  // ── Horizontal axis line ─────────────────────────────────────────
  var hLine = comp.layers.addShape();
  hLine.name = 'EB_MX_HLine';
  hLine.position.setValue([960, axH]);
  var hlg = hLine.property('Contents').addProperty('ADBE Vector Group');
  hlg.name = 'HLine';
  var hlc = hlg.property('Contents');
  var hlp = hlc.addProperty('ADBE Vector Shape - Group');
  try { hlp.property('ADBE Vector Shape').setValue(
    ebOpenPath([[hx0 - 960, 0], [hx1 - 960, 0]])
  ); } catch(e) {}
  var hls = hlc.addProperty('ADBE Vector Graphic - Stroke');
  try { hls.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { hls.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  try { hls.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  var hlt    = hlc.addProperty('ADBE Vector Filter - Trim');
  var hltEnd = hlt.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { hLine.inPoint = sf / fps; } catch(e) {}
    try { ebAnimateTrimDraw(hltEnd, sf, fps); } catch(e) {}
  } else {
    try { hltEnd.setValue(100); } catch(e) {}
  }

  // ── Vertical axis line ────────────────────────────────────────────
  var vLine = comp.layers.addShape();
  vLine.name = 'EB_MX_VLine';
  vLine.position.setValue([axV, 613]);  // layer origin at midpoint y for clean local math
  var vlg = vLine.property('Contents').addProperty('ADBE Vector Group');
  vlg.name = 'VLine';
  var vlc = vlg.property('Contents');
  var vlp = vlc.addProperty('ADBE Vector Shape - Group');
  try { vlp.property('ADBE Vector Shape').setValue(
    ebOpenPath([[0, vy0 - 613], [0, vy1 - 613]])
  ); } catch(e) {}
  var vls = vlc.addProperty('ADBE Vector Graphic - Stroke');
  try { vls.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { vls.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  try { vls.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  var vlt    = vlc.addProperty('ADBE Vector Filter - Trim');
  var vltEnd = vlt.property('ADBE Vector Trim End');
  if (params.animateIn) {
    try { vLine.inPoint = (sf + 8) / fps; } catch(e) {}
    try { ebAnimateTrimDraw(vltEnd, sf + 8, fps); } catch(e) {}
  } else {
    try { vltEnd.setValue(100); } catch(e) {}
  }

  // ── Arrowheads (V-stroke, separate layer — appear after lines finish drawing) ──
  var arrSF    = sf + 28;
  var arrLayer = comp.layers.addShape();
  arrLayer.name = 'EB_MX_Arrows';
  arrLayer.position.setValue([0, 0]);
  var aGC = arrLayer.property('Contents');

  // Right-pointing arrowhead at end of horizontal axis
  var rGrp = aGC.addProperty('ADBE Vector Group');
  rGrp.name = 'ArrowRight';
  var rGC  = rGrp.property('Contents');
  var rPth = rGC.addProperty('ADBE Vector Shape - Group');
  try { rPth.property('ADBE Vector Shape').setValue(
    ebOpenPath([[hx1 - arLen, axH - arW], [hx1, axH], [hx1 - arLen, axH + arW]])
  ); } catch(e) {}
  var rStr = rGC.addProperty('ADBE Vector Graphic - Stroke');
  try { rStr.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { rStr.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  try { rStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { rStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}

  // Up-pointing arrowhead at top of vertical axis
  var uGrp = aGC.addProperty('ADBE Vector Group');
  uGrp.name = 'ArrowUp';
  var uGC  = uGrp.property('Contents');
  var uPth = uGC.addProperty('ADBE Vector Shape - Group');
  try { uPth.property('ADBE Vector Shape').setValue(
    ebOpenPath([[axV - arW, vy0 + arLen], [axV, vy0], [axV + arW, vy0 + arLen]])
  ); } catch(e) {}
  var uStr = uGC.addProperty('ADBE Vector Graphic - Stroke');
  try { uStr.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
  try { uStr.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
  try { uStr.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
  try { uStr.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}

  ebFadeOnly(arrLayer, arrSF, fps, 8);

  // ── Axis endpoint labels (HIGH / LOW) ──────────────────────────────
  var lblSF = sf + 34;
  var lblFSz = 18;

  // X-axis: LOW at left, HIGH at right (below axis line)
  var xLowLyr  = ebText(comp, 'LOW',  80,       axH + 28, lblFSz, 'semibold', dimClr, 'left');
  xLowLyr.name = 'EB_MX_XLow';
  ebFadeOnly(xLowLyr, lblSF, fps, 8);

  var xHighLyr  = ebText(comp, 'HIGH', 1793,     axH + 28, lblFSz, 'semibold', dimClr, 'left');
  xHighLyr.name = 'EB_MX_XHigh';
  ebFadeOnly(xHighLyr, lblSF, fps, 8);

  // Y-axis: HIGH at top, LOW at bottom (right of axis line)
  var yHighLyr  = ebText(comp, 'HIGH', axV + 14, vy0 + 14, lblFSz, 'semibold', dimClr, 'left');
  yHighLyr.name = 'EB_MX_YHigh';
  ebFadeOnly(yHighLyr, lblSF, fps, 8);

  var yLowLyr   = ebText(comp, 'LOW',  axV + 14, vy1 + 14, lblFSz, 'semibold', dimClr, 'left');
  yLowLyr.name  = 'EB_MX_YLow';
  ebFadeOnly(yLowLyr, lblSF, fps, 8);

  // X-axis dimension label — centered below axis
  // "EFFORT" at 16pt: ~52px wide; half=26 → x=934
  var xDimLyr  = ebText(comp, xLabel, 960 - 26, axH + 50, 16, 'semibold', colorRGB, 'left');
  xDimLyr.name = 'EB_MX_XDim';
  ebFadeOnly(xDimLyr, lblSF, fps, 8);

  // Y-axis dimension label — rotated -90deg, left of vertical axis
  // Position is approximate; rotation pivots around anchor set by ebText.
  var yDimLyr  = ebText(comp, yLabel, axV - 80, (vy0 + vy1) / 2, 16, 'semibold', colorRGB, 'left');
  yDimLyr.name = 'EB_MX_YDim';
  try { yDimLyr.rotation.setValue(-90); } catch(e) {}
  ebFadeOnly(yDimLyr, lblSF, fps, 8);

  // ── Quadrant content [TL, TR, BL, BR] ─────────────────────────────
  // titleFSz=28pt semibold accent, descFSz=24pt regular dark grey
  // LEFT_JUSTIFY; positions chosen to sit in upper area of each quadrant.
  var qXs     = [180, 1000, 180, 1000];  // left x for each quadrant's text block
  var qTitleY = [388, 388, 750, 750];    // title baseline y
  var qDescY  = [430, 430, 792, 792];    // description baseline y

  for (var q = 0; q < 4; q++) {
    var qSF   = sf + 40 + q * 8;
    var qData = quads[q];

    var tLyr  = ebText(comp, qData.title || '', qXs[q], qTitleY[q], 28, 'semibold', colorRGB, 'left');
    tLyr.name = 'EB_MX_QTitle_' + (q+1);
    ebTextAnimatorFadeUp(tLyr, qSF, fps, 20);

    var dLyr  = ebText(comp, qData.text  || '', qXs[q], qDescY[q],  24, 'regular', bodyClr, 'left');
    dLyr.name = 'EB_MX_QDesc_' + (q+1);
    ebTextAnimatorFadeUp(dLyr, qSF + 3, fps, 18);
  }
}

// =============================================================
// STEPS ANIMATION  (diagram-steps)
// 10 chevron steps in 2 rows of 5.
// Each card: white addSolid fill + accent stroke chevron border
//            + step number (top-left) + step title (bottom).
// White solid makes each card opaque so sliding cards hide behind
// card 1 as they emerge — no overlapping stroke artefacts.
// Built in reverse order so step 1 is topmost in AE stack.
// Animation: step 1 fades in first; steps 2-10 slide out from
// the leftmost position of their row simultaneously.
// =============================================================
function createStepsBlock(comp, params) {
  var fps     = comp.frameRate;
  var sf      = 1;
  var color   = ebColor(params.accentColor);
  var colorRGB = [color[0], color[1], color[2]];
  var colorArr = [color[0], color[1], color[2], 1];
  var darkClr = [0.12, 0.12, 0.12];

  var N       = Math.min(Math.max(parseInt(params.stepCount)   || 10, 1), 10);
  var PER_ROW = Math.min(Math.max(parseInt(params.stepsPerRow) || 5,  3),  5);
  var numRows = Math.ceil(N / PER_ROW);

  // ── Card geometry — taller proportions, adapts to per-row count ──────
  var CARD_H  = numRows === 1 ? 340 : (numRows === 2 ? 265 : 220);
  var ROW_GAP = numRows === 3 ? 30 : 44;
  var NOTCH   = Math.round(CARD_H * 0.094);  // ~10% of height
  var GAP     = 6;
  var CARD_W  = Math.floor((1760 - (PER_ROW - 1) * GAP) / PER_ROW);
  var HW      = Math.round(CARD_W / 2);
  var HH      = Math.round(CARD_H / 2);

  // Row vertical centers
  var totalH  = numRows * CARD_H + (numRows - 1) * ROW_GAP;
  var topY    = Math.round(605 - totalH / 2);
  var rowCYs  = [];
  for (var _r = 0; _r < numRows; _r++) {
    rowCYs.push(topY + _r * (CARD_H + ROW_GAP) + HH);
  }

  var LEFT_M   = Math.round((1920 - (PER_ROW * CARD_W + (PER_ROW - 1) * GAP)) / 2);
  var STEP_X   = CARD_W + GAP;
  var STAGGER  = 4;   // frames between each step's animation start
  var SLIDE_D  = 16;  // frames for the slide motion

  // Default step data
  var defSteps = [];
  for (var _di = 0; _di < 10; _di++) { defSteps.push({ title: 'Step ' + (_di + 1) }); }
  var steps = (params.steps && params.steps.length >= N)
    ? params.steps.slice(0, N) : defSteps.slice(0, N);

  var numFSz = CARD_H >= 300 ? 54 : (CARD_H >= 240 ? 46 : 38);
  var titFSz = CARD_H >= 300 ? 24 : 22;

  ebCreateHeader(comp, params, sf);

  // ── Build in REVERSE so step 1 lands at top of AE layer stack ────────
  // Each new layer is inserted at index 1 (top), so last-added = topmost.
  // Reverse build → step 1's group ends up topmost, step N bottommost.
  // This is critical: sliding steps pass BEHIND earlier steps (correct z-order).
  var pcBefore, bgLyr, borderLyr, numLbl, titLbl;

  for (var i = N - 1; i >= 0; i--) {
    var iInRow   = i % PER_ROW;
    var rowIdx   = Math.floor(i / PER_ROW);
    var cx       = LEFT_M + iInRow * STEP_X + HW;
    var cy       = rowCYs[rowIdx];
    var cleft    = cx - HW;
    var ctop     = cy - HH;
    var animStart = sf + 1 + i * STAGGER;
    var t0_s     = animStart / fps;
    var t1_s     = (animStart + SLIDE_D) / fps;
    var rowAnchorX = LEFT_M + HW;  // first card X in any row (cascade start point)

    pcBefore = comp.numLayers;

    // ── White solid BG ──
    bgLyr = comp.layers.addSolid([1, 1, 1], 'EB_ST_BG_' + (i+1), CARD_W, CARD_H, 1);
    bgLyr.position.setValue([cx, cy]);

    // ── Chevron border (stroke only) ──
    borderLyr = comp.layers.addShape();
    borderLyr.name = 'EB_ST_Border_' + (i+1);
    borderLyr.position.setValue([cx, cy]);
    var bGC  = borderLyr.property('Contents');
    var bGrp = bGC.addProperty('ADBE Vector Group');
    bGrp.name = 'Chevron';
    var bGCi  = bGrp.property('Contents');
    var bPath = bGCi.addProperty('ADBE Vector Shape - Group');
    var chevShape = new Shape();
    chevShape.vertices    = [[-HW,-HH],[HW-NOTCH,-HH],[HW,0],[HW-NOTCH,HH],[-HW,HH]];
    chevShape.inTangents  = [[0,0],[0,0],[0,0],[0,0],[0,0]];
    chevShape.outTangents = [[0,0],[0,0],[0,0],[0,0],[0,0]];
    chevShape.closed = true;
    try { bPath.property('ADBE Vector Shape').setValue(chevShape); } catch(e) {}
    var bStroke = bGCi.addProperty('ADBE Vector Graphic - Stroke');
    try { bStroke.property('ADBE Vector Stroke Color').setValue(colorArr); } catch(e) {}
    try { bStroke.property('ADBE Vector Stroke Width').setValue(2); } catch(e) {}
    try { bStroke.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { bStroke.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}

    // ── Number ──
    numLbl = ebText(comp, '' + (i+1), cleft + 28, ctop + Math.round(CARD_H * 0.36), numFSz, 'bold', colorRGB, 'left');
    numLbl.name = 'EB_ST_Num_' + (i+1);

    // ── Title ──
    titLbl = ebText(comp, steps[i].title || '', cleft + 28, ctop + CARD_H - 28, titFSz, 'regular', darkClr, 'left');
    titLbl.name = 'EB_ST_Title_' + (i+1);

    // ── Animate ──────────────────────────────────────────────────────────
    if (i === 0) {
      // Step 1: simple fade-up (reference anchor for the cascade)
      ebTextAnimatorFadeUp(bgLyr,     sf + 1, fps, 20);
      ebTextAnimatorFadeUp(borderLyr, sf + 1, fps, 20);
      ebTextAnimatorFadeUp(numLbl,    sf + 3, fps, 14);
      ebTextAnimatorFadeUp(titLbl,    sf + 5, fps, 12);

    } else if (iInRow === 0) {
      // First card of rows 2, 3, etc.: fade in at its final position
      // (serves as anchor for its row's cascade — no slide needed)
      try {
        bgLyr.property('Opacity').setValueAtTime(t0_s, 0);
        bgLyr.property('Opacity').setValueAtTime((animStart + 8) / fps, 100);
        bgLyr.inPoint = t0_s;
      } catch(e) {}
      try {
        borderLyr.property('Opacity').setValueAtTime(t0_s, 0);
        borderLyr.property('Opacity').setValueAtTime((animStart + 8) / fps, 100);
        borderLyr.inPoint = t0_s;
      } catch(e) {}
      var numPY0 = numLbl.position.value[1];
      try {
        numLbl.property('Opacity').setValueAtTime(t0_s, 0);
        numLbl.property('Opacity').setValueAtTime((animStart + 10) / fps, 100);
        numLbl.property('Position').setValueAtTime(t0_s, [cleft + 28, numPY0 + 16]);
        numLbl.property('Position').setValueAtTime((animStart + 14) / fps, [cleft + 28, numPY0]);
        numLbl.inPoint = t0_s;
      } catch(e) {}
      var titPY0 = titLbl.position.value[1];
      try {
        titLbl.property('Opacity').setValueAtTime(t0_s, 0);
        titLbl.property('Opacity').setValueAtTime((animStart + 12) / fps, 100);
        titLbl.property('Position').setValueAtTime(t0_s, [cleft + 28, titPY0 + 14]);
        titLbl.property('Position').setValueAtTime((animStart + 16) / fps, [cleft + 28, titPY0]);
        titLbl.inPoint = t0_s;
      } catch(e) {}

    } else {
      // Remaining steps: slide from row anchor to final position.
      // BG and border: fully opaque from inPoint — NO opacity animation.
      // This ensures white BG always covers lower-z text as it passes over.
      try {
        bgLyr.position.setValueAtTime(t0_s, [rowAnchorX, cy]);
        bgLyr.position.setValueAtTime(t1_s, [cx, cy]);
        bgLyr.inPoint = t0_s;
      } catch(e) {}
      try {
        borderLyr.position.setValueAtTime(t0_s, [rowAnchorX, cy]);
        borderLyr.position.setValueAtTime(t1_s, [cx, cy]);
        borderLyr.inPoint = t0_s;
      } catch(e) {}

      var numFX = cleft + 28;
      var numSX = rowAnchorX - HW + 28;
      var numPY = numLbl.position.value[1];
      try {
        numLbl.property('Position').setValueAtTime(t0_s, [numSX, numPY]);
        numLbl.property('Position').setValueAtTime(t1_s, [numFX, numPY]);
        numLbl.property('Opacity').setValueAtTime(t0_s, 0);
        numLbl.property('Opacity').setValueAtTime((animStart + 8) / fps, 100);
        numLbl.inPoint = t0_s;
      } catch(e) {}

      var titFX = cleft + 28;
      var titSX = rowAnchorX - HW + 28;
      var titPY = titLbl.position.value[1];
      try {
        titLbl.property('Position').setValueAtTime(t0_s, [titSX, titPY]);
        titLbl.property('Position').setValueAtTime(t1_s, [titFX, titPY]);
        titLbl.property('Opacity').setValueAtTime(t0_s, 0);
        titLbl.property('Opacity').setValueAtTime((animStart + 10) / fps, 100);
        titLbl.inPoint = t0_s;
      } catch(e) {}
    }

    if (params.precomp) {
      _ebPrecompCard(comp, pcBefore, 'EB_Step_' + (i+1), animStart - sf, fps, cx, cy);
    }
  }
}

// =============================================================
// HUB-AND-SPOKE DIAGRAM  (diagram-hub-spoke)
// Central circle with n radial spoke nodes (3–12).
// Each spoke: line from center circle edge → junction node circle → stub → label.
// Horizontal stubs for left/right nodes; vertical stubs for top/bottom nodes.
// =============================================================
function createHubSpokeBlock(comp, params) {
  var fps  = comp.frameRate;
  var sf   = 1;
  var L    = EB_LAYOUT;
  var PI   = Math.PI;

  var color   = ebColor(params.accentColor || '76B900');
  var accArr  = [color[0], color[1], color[2], 1];
  var darkArr = [0.12, 0.12, 0.12, 1];
  var darkRGB = [0.12, 0.12, 0.12];
  var grayFill = [0.88, 0.88, 0.88, 1];
  var grayStr  = [0.18, 0.18, 0.18, 1];
  var lineArr  = [0.18, 0.18, 0.18, 1];

  var nodes    = params.nodes || ['GPU','NGC CLI','Docker-CE','NVIDIA GPU Drivers','Operating System','Networking','Storage','Memory','CPU'];
  var n        = Math.min(Math.max(nodes.length, 3), 12);
  var hubLabel = params.hub || '';

  // ── Layout ──────────────────────────────────────────────────
  var CX      = L.compW / 2;                              // 960
  var CY      = Math.round((L.cardTop + L.cardBottom) / 2) + 20; // ~625
  var R_C     = 195;   // center circle radius
  var R_EXT   = 130;   // diagonal extension beyond circle boundary
  var NODE_R  = 20;    // junction node circle radius
  var STUB_H  = 130;   // horizontal stub length (left/right nodes)
  var STUB_V  = 80;    // vertical stub length (top/bottom nodes)
  var FSZ     = 28;    // label font size
  var LINE_SW = 2.5;
  var THRESH  = 0.26;  // |cos(θ)| below this → classify as top/bottom node

  // ── Helpers ─────────────────────────────────────────────────
  function _circle(name, cx, cy, r, fillA, strokeA, sw) {
    var lyr = comp.layers.addShape(); lyr.name = name;
    lyr.position.setValue([cx, cy]);
    var gi = lyr.property('Contents').addProperty('ADBE Vector Group').property('Contents');
    var el = gi.addProperty('ADBE Vector Shape - Ellipse');
    try { el.property('ADBE Vector Ellipse Size').setValue([r*2, r*2]); } catch(e) {}
    if (fillA) {
      var f = gi.addProperty('ADBE Vector Graphic - Fill');
      try { f.property('ADBE Vector Fill Color').setValue(fillA); } catch(e) {}
    }
    if (strokeA) {
      var s = gi.addProperty('ADBE Vector Graphic - Stroke');
      try { s.property('ADBE Vector Stroke Color').setValue(strokeA); } catch(e) {}
      try { s.property('ADBE Vector Stroke Width').setValue(sw || 2); } catch(e) {}
    }
    return lyr;
  }

  function _scalePopIn(lyr, sfNum) {
    if ($.global._ebSkipAnimIn) return;
    var t0 = sfNum / fps;
    var t1 = (sfNum + 10) / fps;
    try {
      lyr.opacity.setValue(100);
      lyr.property('Transform').property('Scale').setValueAtTime(t0, [0, 0]);
      lyr.property('Transform').property('Scale').setValueAtTime(t1, [100, 100]);
      try { setEase(lyr.property('Transform').property('Scale'), 1, 33, 33); } catch(e) {}
      try { setEase(lyr.property('Transform').property('Scale'), 2, 33, 85); } catch(e) {}
      lyr.inPoint = t0;
    } catch(e) {}
  }

  function _line(name, x0, y0, x1, y1, colorA, sw, sfNum) {
    var lyr = comp.layers.addShape(); lyr.name = name;
    lyr.position.setValue([0, 0]);
    var gc  = lyr.property('Contents');
    var grp = gc.addProperty('ADBE Vector Group');
    var gi  = grp.property('Contents');
    var sp  = gi.addProperty('ADBE Vector Shape - Group');
    try { sp.property('ADBE Vector Shape').setValue(ebOpenPath([[x0,y0],[x1,y1]])); } catch(e) {}
    var str = gi.addProperty('ADBE Vector Graphic - Stroke');
    try { str.property('ADBE Vector Stroke Color').setValue(colorA); } catch(e) {}
    try { str.property('ADBE Vector Stroke Width').setValue(sw || 1.5); } catch(e) {}
    try { str.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    if (sfNum !== undefined) {
      try {
        var tr = gi.addProperty('ADBE Vector Filter - Trim');
        ebAnimateTrimDraw(tr.property('End'), sfNum, fps);
      } catch(e) { ebFadeOnly(lyr, sfNum, fps, 10); }
    }
    return lyr;
  }

  // ── 1. Center circle ────────────────────────────────────────
  // Fill: solid + circular mask (shape fill unreliable in AE 2024+)
  var cFill = comp.layers.addSolid(
    [grayFill[0], grayFill[1], grayFill[2]], 'EB_Hub_Center_Fill',
    comp.width, comp.height, 1
  );
  try {
    var _k  = 0.5523;
    var _msk = cFill.property('Masks').addProperty('Mask');
    var _msh = new Shape();
    _msh.vertices    = [[CX, CY-R_C],[CX+R_C, CY],[CX, CY+R_C],[CX-R_C, CY]];
    _msh.inTangents  = [[-_k*R_C,0],[0,-_k*R_C],[_k*R_C,0],[0,_k*R_C]];
    _msh.outTangents = [[_k*R_C,0],[0,_k*R_C],[-_k*R_C,0],[0,-_k*R_C]];
    _msh.closed = true;
    _msk.property('Mask Path').setValue(_msh);
  } catch(e) {}
  ebFadeOnly(cFill, sf + 1, fps, 12);
  // Stroke ring (no fill needed — fill handled above)
  var cCircle = _circle('EB_Hub_Center', CX, CY, R_C, null, grayStr, 3);
  ebFadeOnly(cCircle, sf + 1, fps, 12);

  // ── 2. Hub label ────────────────────────────────────────────
  if (hubLabel) {
    var hLines = hubLabel.split('\r');
    var hFSz   = 22;
    var hLineH = hFSz + 6;
    var hTotH  = hLines.length * hLineH;
    for (var hi = 0; hi < hLines.length; hi++) {
      var hY   = CY - Math.round(hTotH / 2) + hi * hLineH + hFSz;
      var hLyr = ebText(comp, hLines[hi], CX, hY, hFSz, 'regular', darkRGB, 'center');
      hLyr.name = 'EB_Hub_CLabel_' + hi;
      ebFadeOnly(hLyr, sf + 4, fps, 10);
    }
  }

  // ── 3. Spokes + junction nodes + stubs + labels ─────────────
  for (var i = 0; i < n; i++) {
    var theta   = -PI/2 + i * 2*PI / n;   // 0 = top, clockwise
    var cosT    = Math.cos(theta);
    var sinT    = Math.sin(theta);
    var nodeSF  = sf + 12 + i * 6;

    // Junction node sits ON the main circle boundary — no lines inside the circle
    var jx = Math.round(CX + R_C * cosT);
    var jy = Math.round(CY + R_C * sinT);

    // Extension line: from junction outward (diagonal away from center)
    var ex = Math.round(CX + (R_C + R_EXT) * cosT);
    var ey = Math.round(CY + (R_C + R_EXT) * sinT);
    var extLyr = _line('EB_Hub_Ext_' + i, jx, jy, ex, ey, lineArr, LINE_SW, nodeSF);

    // Junction node: small solid (NODE_R*2 sq) centered at jx,jy — anchor auto-centers, scales correctly
    var _nd = NODE_R * 2;
    var _nk = 0.5523;
    var _nFill = comp.layers.addSolid([1,1,1], 'EB_Hub_NodeFill_' + i, _nd, _nd, 1);
    _nFill.property('Transform').property('Position').setValue([jx, jy]);
    try {
      var _nm = _nFill.property('Masks').addProperty('Mask');
      var _ns = new Shape();
      // mask coords in layer space — center is [NODE_R, NODE_R]
      _ns.vertices    = [[NODE_R, 0],[_nd, NODE_R],[NODE_R, _nd],[0, NODE_R]];
      _ns.inTangents  = [[-_nk*NODE_R,0],[0,-_nk*NODE_R],[_nk*NODE_R,0],[0,_nk*NODE_R]];
      _ns.outTangents = [[_nk*NODE_R,0],[0,_nk*NODE_R],[-_nk*NODE_R,0],[0,-_nk*NODE_R]];
      _ns.closed = true;
      _nm.property('Mask Path').setValue(_ns);
    } catch(e) {}
    _scalePopIn(_nFill, nodeSF + 1);
    // Green stroke ring — position at jx,jy, anchor at [0,0] = layer center → scales correctly
    var nodeLyr = _circle('EB_Hub_Node_' + i, jx, jy, NODE_R, null, accArr, 2.5);
    _scalePopIn(nodeLyr, nodeSF + 1);

    // Classify: top / bottom / left / right
    var isTop   = (Math.abs(cosT) < THRESH) && (sinT < 0);
    var isBot   = (Math.abs(cosT) < THRESH) && (sinT >= 0);
    var isRight = (!isTop && !isBot) && (cosT > 0);
    // isLeft: everything else

    var stubX0, stubY0, stubX1, stubY1, labelX, labelY, justify;

    if (isTop) {
      stubX0 = ex;  stubY0 = ey;
      stubX1 = ex;  stubY1 = ey - STUB_V;
      labelX = ex;
      labelY = stubY1 - 8;
      justify = 'center';
    } else if (isBot) {
      stubX0 = ex;  stubY0 = ey;
      stubX1 = ex;  stubY1 = ey + STUB_V;
      labelX = ex;
      labelY = stubY1 + FSZ + 4;
      justify = 'center';
    } else if (isRight) {
      stubX0 = ex;  stubY0 = ey;
      stubX1 = ex + STUB_H;  stubY1 = ey;
      labelX = Math.round((ex + stubX1) / 2);
      labelY = ey - 10;
      justify = 'center';
    } else {
      // left
      stubX0 = ex;  stubY0 = ey;
      stubX1 = ex - STUB_H;  stubY1 = ey;
      labelX = Math.round((ex + stubX1) / 2);
      labelY = ey - 10;
      justify = 'center';
    }

    var stubLyr = _line('EB_Hub_Stub_' + i, stubX0, stubY0, stubX1, stubY1, lineArr, LINE_SW, nodeSF + 2);

    var lbl  = (typeof nodes[i] === 'string') ? nodes[i] : ('Node ' + (i+1));
    var lLyr = ebText(comp, lbl, labelX, labelY, FSZ, 'medium', darkRGB, justify);
    lLyr.name = 'EB_Hub_Label_' + i;
    ebFadeOnly(lLyr, nodeSF + 4, fps, 8);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// GH200 DUAL SUPERCHIP TOPOLOGY  (topology-gh200)
// Two chassis side-by-side, each with 4 stacked component boxes.
// External DPU / NVMe / SuperNIC on each side with connection lines.
// Middle: NVLink C2C (purple) + NVLink GPU (accent) arrows.
// All text is param-driven; reference content is default only.
// =============================================================
function createGH200PairBlock(comp, params) {
  var fps = comp.frameRate;
  var sf  = 1;

  // ── Colors ────────────────────────────────────────────────────
  var blueRGB  = [0.788, 0.878, 0.961];   // memory boxes fill
  var greenRGB = [0.839, 0.910, 0.831];   // CPU / GPU boxes fill
  var ylwRGB   = [1.000, 0.902, 0.800];   // DPU / SuperNIC fill
  var purpArr  = [0.54,  0.29,  0.76,  1];
  var purpRGB  = [0.54,  0.29,  0.76];
  var frameArr = [0.68,  0.68,  0.68,  1];  // chassis stroke
  var darkRGB  = [0.10,  0.10,  0.10];
  var subRGB   = [0.40,  0.40,  0.40];
  var lblRGB   = [0.44,  0.44,  0.44];
  var connArr  = [0.82,  0.62,  0.10,  1]; // external connection arrows (amber)
  var acc      = ebColor(params.accentColor);
  var accRGB   = [acc[0], acc[1], acc[2]];
  var accArr   = [acc[0], acc[1], acc[2], 1];

  // ── Layout ────────────────────────────────────────────────────
  var CH_TOP = 240;
  var CH_BOT = 850;
  var CH_H   = CH_BOT - CH_TOP;    // 610
  var CH_W   = 560;
  var CH1_L  = 330;  var CH1_R = CH1_L + CH_W;  var CH1_CX = CH1_L + Math.round(CH_W / 2);  // 610
  var CH2_L  = 1030; var CH2_R = CH2_L + CH_W;  var CH2_CX = CH2_L + Math.round(CH_W / 2); // 1310

  var BOX_PAD = 24;
  var BOX_W   = CH_W - 2 * BOX_PAD;   // 512
  var BOX_H   = 120;
  var BOX_GAP = 24;
  var b1T = CH_TOP + BOX_PAD;                       // 264
  var b2T = b1T + BOX_H + BOX_GAP;                 // 408
  var b3T = b2T + BOX_H + BOX_GAP;                 // 552
  var b4T = b3T + BOX_H + BOX_GAP;                 // 696
  var b1CY = b1T + Math.round(BOX_H / 2);          // 324
  var b2CY = b2T + Math.round(BOX_H / 2);          // 468
  var b3CY = b3T + Math.round(BOX_H / 2);          // 612
  var b4CY = b4T + Math.round(BOX_H / 2);          // 756
  var chMidY = Math.round((CH_TOP + CH_BOT) / 2);  // 545
  var chHW   = Math.round(CH_W / 2);               // 280
  var chHH   = Math.round(CH_H / 2);               // 305

  var EXT_W  = 140;  var EXT_H  = 54;
  var EXT_HW = Math.round(EXT_W / 2);
  var EXT_HH = Math.round(EXT_H / 2);
  var EXT_L_CX = 203;   var EXT_R_CX = 1717;
  var DPU_CY = 346;  var NVM_CY = b2CY;  var SNC_CY = 638;

  // ── Params / defaults ─────────────────────────────────────────
  var chassisLbl = params.chassisLabel || '';
  var b1n = (params.box1 && params.box1[0]) ? params.box1[0] : '';
  var b1s = (params.box1 && params.box1[1]) ? params.box1[1] : '';
  var b2n = (params.box2 && params.box2[0]) ? params.box2[0] : '';
  var b2s = (params.box2 && params.box2[1]) ? params.box2[1] : '';
  var b3n = (params.box3 && params.box3[0]) ? params.box3[0] : '';
  var b3s = (params.box3 && params.box3[1]) ? params.box3[1] : '';
  var b4n = (params.box4 && params.box4[0]) ? params.box4[0] : '';
  var b4s = (params.box4 && params.box4[1]) ? params.box4[1] : '';
  var eTN = (params.extTop && params.extTop[0]) ? params.extTop[0] : '';
  var eTS = (params.extTop && params.extTop[1]) ? params.extTop[1] : '';
  var eMN = (params.extMid && params.extMid[0]) ? params.extMid[0] : '';
  var eMS = (params.extMid && params.extMid[1]) ? params.extMid[1] : '';
  var eBN = (params.extBot && params.extBot[0]) ? params.extBot[0] : '';
  var eBS = (params.extBot && params.extBot[1]) ? params.extBot[1] : '';
  var eTL1 = (params.extTopLbl && params.extTopLbl[0]) ? params.extTopLbl[0] : '';
  var eTL2 = (params.extTopLbl && params.extTopLbl[1]) ? params.extTopLbl[1] : '';
  var eML1 = params.extMidLbl || '';
  var eBL1 = (params.extBotLbl && params.extBotLbl[0]) ? params.extBotLbl[0] : '';
  var eBL2 = (params.extBotLbl && params.extBotLbl[1]) ? params.extBotLbl[1] : '';
  var c2cLbl    = params.c2cLabel  || '';
  var nvlC2CLbl = params.nvlinkC2C || '';
  var nvlGPULbl = params.nvlinkGPU || '';

  ebCreateHeader(comp, params, sf);

  // ── Utility: add stroke-only closed rect shape layer ──────────
  // Positions layer center at [cx, cy]. Returns layer.
  function _addStrokeRect(name, cx, cy, w, h, colorA, sw) {
    var lyr = comp.layers.addShape();
    lyr.name = name;
    lyr.position.setValue([cx, cy]);
    var gc = lyr.property('Contents');
    var grp = gc.addProperty('ADBE Vector Group');
    grp.name = 'Rect';
    var gi = grp.property('Contents');
    var sp = gi.addProperty('ADBE Vector Shape - Group');
    var hw2 = Math.round(w / 2);  var hh2 = Math.round(h / 2);
    var sh = new Shape();
    sh.vertices    = [[-hw2,-hh2],[hw2,-hh2],[hw2,hh2],[-hw2,hh2]];
    sh.inTangents  = [[0,0],[0,0],[0,0],[0,0]];
    sh.outTangents = [[0,0],[0,0],[0,0],[0,0]];
    sh.closed = true;
    try { sp.property('ADBE Vector Shape').setValue(sh); } catch(e) {}
    var str = gi.addProperty('ADBE Vector Graphic - Stroke');
    try { str.property('ADBE Vector Stroke Color').setValue(colorA); } catch(e) {}
    try { str.property('ADBE Vector Stroke Width').setValue(sw || 1.5); } catch(e) {}
    try { str.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    return lyr;
  }

  // ── Utility: add open-path arrow layer (single group) ─────────
  // pts: [[x,y],...]. Returns layer.
  function _addArrow(name, pts, colorA, sw) {
    var lyr = comp.layers.addShape();
    lyr.name = name;
    lyr.position.setValue([0, 0]);
    var gc  = lyr.property('Contents');
    var grp = gc.addProperty('ADBE Vector Group');
    grp.name = 'Path';
    var gi  = grp.property('Contents');
    var sp  = gi.addProperty('ADBE Vector Shape - Group');
    try { sp.property('ADBE Vector Shape').setValue(ebOpenPath(pts)); } catch(e) {}
    var str = gi.addProperty('ADBE Vector Graphic - Stroke');
    try { str.property('ADBE Vector Stroke Color').setValue(colorA); } catch(e) {}
    try { str.property('ADBE Vector Stroke Width').setValue(sw || 1.5); } catch(e) {}
    try { str.property('ADBE Vector Stroke Line Cap').setValue(2); } catch(e) {}
    try { str.property('ADBE Vector Stroke Line Join').setValue(2); } catch(e) {}
    return lyr;
  }

  // ── Utility: add solid box + title [+ sub] text ───────────────
  // Returns nothing (layers created as side-effect).
  function _addBox(pfx, colorRGB, w, h, cx, cy, tname, tsub, tFSz, sFSz, sfNum) {
    var sol = comp.layers.addSolid(colorRGB, pfx + '_Fill', w, h, 1);
    sol.position.setValue([cx, cy]);
    ebTextAnimatorFadeUp(sol, sfNum, fps, 14);
    var nlen = (tname || '').length;
    var nx   = Math.round(cx - nlen * tFSz * 0.28);
    var ny   = cy + (tsub ? 4 : 8);
    var tLyr = ebText(comp, tname, nx, ny, tFSz, 'bold', darkRGB, 'left');
    tLyr.name = pfx + '_T';
    ebTextAnimatorFadeUp(tLyr, sfNum + 2, fps, 10);
    if (tsub) {
      var slen = (tsub || '').length;
      var sx   = Math.round(cx - slen * sFSz * 0.27);
      var sLyr = ebText(comp, tsub, sx, cy + 28, sFSz, 'regular', subRGB, 'left');
      sLyr.name = pfx + '_S';
      ebTextAnimatorFadeUp(sLyr, sfNum + 3, fps, 8);
    }
  }

  // ── 1. CHASSIS FRAMES ─────────────────────────────────────────
  var chFr1 = _addStrokeRect('EB_GH_Frame_1', CH1_CX, chMidY, CH_W, CH_H, frameArr, 1.5);
  var chFr2 = _addStrokeRect('EB_GH_Frame_2', CH2_CX, chMidY, CH_W, CH_H, frameArr, 1.5);
  ebTextAnimatorFadeUp(chFr1, sf + 1, fps, 14);
  ebTextAnimatorFadeUp(chFr2, sf + 1, fps, 14);

  // ── 2. COMPONENT BOXES ────────────────────────────────────────
  var bxSF = sf + 10;
  var ch, pfx;
  for (ch = 0; ch < 2; ch++) {
    pfx = 'EB_GH_' + (ch ? 'R' : 'L');
    var bcx = (ch === 0) ? CH1_CX : CH2_CX;
    _addBox(pfx + '_B1', blueRGB,  BOX_W, BOX_H, bcx, b1CY, b1n, b1s, 24, 18, bxSF);
    _addBox(pfx + '_B2', greenRGB, BOX_W, BOX_H, bcx, b2CY, b2n, b2s, 24, 18, bxSF + 5);
    _addBox(pfx + '_B3', greenRGB, BOX_W, BOX_H, bcx, b3CY, b3n, b3s, 24, 18, bxSF + 10);
    _addBox(pfx + '_B4', blueRGB,  BOX_W, BOX_H, bcx, b4CY, b4n, b4s, 24, 18, bxSF + 15);
  }

  // ── 4. MIDDLE NVLINK ARROWS ───────────────────────────────────
  var midSF  = sf + 42;
  var midX0  = CH1_R + 8;   // 898
  var midX1  = CH2_L - 8;   // 1022
  var midCX  = Math.round((midX0 + midX1) / 2);  // 960
  var ARM2   = 9;

  // NVLink C2C (between CPUs, at b2CY)
  var nC2CLine = _addArrow('EB_GH_NVL_C2C_Line', [[midX0, b2CY], [midX1, b2CY]], purpArr, 2);
  ebFadeOnly(nC2CLine, midSF, fps, 8);
  var nC2CAL = _addArrow('EB_GH_NVL_C2C_ArrL',
    [[midX0 + ARM2, b2CY - ARM2], [midX0, b2CY], [midX0 + ARM2, b2CY + ARM2]], purpArr, 2);
  ebFadeOnly(nC2CAL, midSF, fps, 8);
  var nC2CAR = _addArrow('EB_GH_NVL_C2C_ArrR',
    [[midX1 - ARM2, b2CY - ARM2], [midX1, b2CY], [midX1 - ARM2, b2CY + ARM2]], purpArr, 2);
  ebFadeOnly(nC2CAR, midSF, fps, 8);
  var nC2CLblLen = nvlC2CLbl.length;
  var nC2CLblLyr = ebText(comp, nvlC2CLbl,
    Math.round(midCX - nC2CLblLen * 13 * 0.27), b2CY - 14, 13, 'regular', purpRGB, 'left');
  nC2CLblLyr.name = 'EB_GH_NVL_C2C_Lbl';
  ebFadeOnly(nC2CLblLyr, midSF + 2, fps, 6);

  // NVLink GPU (between GPUs, at b3CY)
  var nGPULine = _addArrow('EB_GH_NVL_GPU_Line', [[midX0, b3CY], [midX1, b3CY]], accArr, 2);
  ebFadeOnly(nGPULine, midSF + 4, fps, 8);
  var nGPUAL = _addArrow('EB_GH_NVL_GPU_ArrL',
    [[midX0 + ARM2, b3CY - ARM2], [midX0, b3CY], [midX0 + ARM2, b3CY + ARM2]], accArr, 2);
  ebFadeOnly(nGPUAL, midSF + 4, fps, 8);
  var nGPUAR = _addArrow('EB_GH_NVL_GPU_ArrR',
    [[midX1 - ARM2, b3CY - ARM2], [midX1, b3CY], [midX1 - ARM2, b3CY + ARM2]], accArr, 2);
  ebFadeOnly(nGPUAR, midSF + 4, fps, 8);
  var nGPULblLen = nvlGPULbl.length;
  var nGPULblLyr = ebText(comp, nvlGPULbl,
    Math.round(midCX - nGPULblLen * 13 * 0.27), b3CY - 14, 13, 'regular', accRGB, 'left');
  nGPULblLyr.name = 'EB_GH_NVL_GPU_Lbl';
  ebFadeOnly(nGPULblLyr, midSF + 6, fps, 6);

  // ── 5. EXTERNAL COMPONENTS ────────────────────────────────────
  var extSF = sf + 50;
  var extDefs = [
    { n: eTN, s: eTS, cy: DPU_CY, clr: ylwRGB,  l1: eTL1, l2: eTL2, labAbove: true  },
    { n: eMN, s: eMS, cy: NVM_CY, clr: blueRGB, l1: eML1, l2: '',   labAbove: true  },
    { n: eBN, s: eBS, cy: SNC_CY, clr: ylwRGB,  l1: eBL1, l2: eBL2, labAbove: false }
  ];
  var ei, ed, ecx, ecy, eSF;
  for (ei = 0; ei < extDefs.length; ei++) {
    ed  = extDefs[ei];
    eSF = extSF + ei * 5;
    for (ch = 0; ch < 2; ch++) {
      ecx  = (ch === 0) ? EXT_L_CX : EXT_R_CX;
      ecy  = ed.cy;
      pfx  = 'EB_GH_E' + (ch ? 'R' : 'L') + '_' + (ei + 1);
      // Solid fill
      var eSol = comp.layers.addSolid(ed.clr, pfx + '_Fill', EXT_W, EXT_H, 1);
      eSol.position.setValue([ecx, ecy]);
      ebTextAnimatorFadeUp(eSol, eSF, fps, 12);
      // Name
      var enX = Math.round(ecx - (ed.n || '').length * 18 * 0.28);
      var enLyr = ebText(comp, ed.n, enX, ecy + (ed.s ? 2 : 7), 18, 'bold', darkRGB, 'left');
      enLyr.name = pfx + '_N';
      ebTextAnimatorFadeUp(enLyr, eSF + 2, fps, 8);
      // Sub
      if (ed.s) {
        var esX = Math.round(ecx - (ed.s || '').length * 14 * 0.27);
        var esLyr = ebText(comp, ed.s, esX, ecy + 22, 14, 'regular', subRGB, 'left');
        esLyr.name = pfx + '_S';
        ebTextAnimatorFadeUp(esLyr, eSF + 3, fps, 8);
      }
      // Labels (small text above or below box)
      var lblBaseX = ecx - EXT_HW;
      if (ed.labAbove) {
        if (ed.l1) {
          var el1 = ebText(comp, ed.l1, lblBaseX, ecy - EXT_HH - 16, 13, 'regular', lblRGB, 'left');
          el1.name = pfx + '_L1';  ebFadeOnly(el1, eSF + 2, fps, 6);
        }
        if (ed.l2) {
          var el2 = ebText(comp, ed.l2, lblBaseX, ecy - EXT_HH - 3, 13, 'regular', lblRGB, 'left');
          el2.name = pfx + '_L2';  ebFadeOnly(el2, eSF + 2, fps, 6);
        }
      } else {
        if (ed.l1) {
          var el3 = ebText(comp, ed.l1, lblBaseX, ecy + EXT_HH + 16, 13, 'regular', lblRGB, 'left');
          el3.name = pfx + '_L3';  ebFadeOnly(el3, eSF + 2, fps, 6);
        }
        if (ed.l2) {
          var el4 = ebText(comp, ed.l2, lblBaseX, ecy + EXT_HH + 30, 13, 'regular', lblRGB, 'left');
          el4.name = pfx + '_L4';  ebFadeOnly(el4, eSF + 2, fps, 6);
        }
      }
    }
  }

  // ── 6. EXTERNAL CONNECTION ARROWS ─────────────────────────────
  // Arrow from each external box to the chassis edge.
  // Left side: from [EXT_L_CX + EXT_HW + 4, ext_cy] to [CH1_L - 4, conn_cy]
  // Right side: mirrored.
  var arrSF    = sf + 58;
  var ARM3     = 8;
  var extConnY = [b1CY, b2CY, b3CY];  // chassis-edge connection y per component

  for (ei = 0; ei < 3; ei++) {
    var extCY   = extDefs[ei].cy;
    var connY   = extConnY[ei];
    for (ch = 0; ch < 2; ch++) {
      var arrSfx = (ch ? 'R' : 'L');
      var ax0, ay0, ax1, ay1;
      if (ch === 0) {
        ax0 = EXT_L_CX + EXT_HW + 4;  ay0 = extCY;
        ax1 = CH1_L - 4;               ay1 = connY;
      } else {
        ax0 = EXT_R_CX - EXT_HW - 4;  ay0 = extCY;
        ax1 = CH2_R + 4;               ay1 = connY;
      }
      var aLine = _addArrow('EB_GH_EL_' + arrSfx + '_' + (ei+1),
        [[ax0, ay0], [ax1, ay1]], connArr, 1.5);
      ebFadeOnly(aLine, arrSF + ei * 3, fps, 8);
      // Arrowhead at chassis end — computed from actual arrow direction so diagonals align correctly
      var _dx = ax1 - ax0, _dy = ay1 - ay0;
      var _len = Math.sqrt(_dx*_dx + _dy*_dy);
      if (_len > 0) {
        var _nx = _dx/_len, _ny = _dy/_len;  // unit forward
        var _px = -_ny,     _py = _nx;        // unit perpendicular
        var aHead = _addArrow('EB_GH_EH_' + arrSfx + '_' + (ei+1), [
          [Math.round(ax1 - _nx*ARM3 + _px*ARM3), Math.round(ay1 - _ny*ARM3 + _py*ARM3)],
          [ax1, ay1],
          [Math.round(ax1 - _nx*ARM3 - _px*ARM3), Math.round(ay1 - _ny*ARM3 - _py*ARM3)]
        ], connArr, 1.5);
        ebFadeOnly(aHead, arrSF + ei * 3, fps, 8);
      }
    }
  }

  // ── 7. CHASSIS LABELS ─────────────────────────────────────────
  var clSF  = sf + 40;
  var clFSz = 17;
  var clLen = (chassisLbl || '').length;
  var clY   = CH_BOT + 26;
  var cl1 = ebText(comp, chassisLbl,
    Math.round(CH1_CX - clLen * clFSz * 0.27), clY, clFSz, 'regular', subRGB, 'left');
  cl1.name = 'EB_GH_CLabel_1';  ebFadeOnly(cl1, clSF, fps, 8);
  var cl2 = ebText(comp, chassisLbl,
    Math.round(CH2_CX - clLen * clFSz * 0.27), clY, clFSz, 'regular', subRGB, 'left');
  cl2.name = 'EB_GH_CLabel_2';  ebFadeOnly(cl2, clSF, fps, 8);
}

// =============================================================
// Topology 2: NVLink Switch Fabric
// 8 GPUs (4 left, 4 right) connected to a central NVSwitch.
// No text. Solid colored fill boxes + accent stroke lines.
// =============================================================
function createNVLinkSwitchBlock(comp, params) {
  var fps = comp.frameRate, sf = 1;
  var acc     = ebColor(params.accentColor || '76B900');
  var accArr  = [acc[0], acc[1], acc[2], 1];
  var blueRGB = [0.788, 0.878, 0.961];
  var grnRGB  = [0.839, 0.910, 0.831];

  ebCreateHeader(comp, params, sf);

  var GPU_W = 200, GPU_H = 90;
  var GPU_CYS = [270, 390, 530, 650];
  var L_CX  = 340,  R_CX  = 1580;
  var SW_CX = 960,  SW_CY = 460, SW_W = 110, SW_H = 470;
  var SW_L  = SW_CX - Math.round(SW_W / 2);
  var SW_R  = SW_CX + Math.round(SW_W / 2);
  var L_RE  = L_CX  + Math.round(GPU_W / 2);
  var R_LE  = R_CX  - Math.round(GPU_W / 2);

  // NVSwitch frame
  var swLyr = ebStrokeRect(comp, 'EB_NVS_Switch', SW_CX, SW_CY, SW_W, SW_H, accArr, 2);
  ebTextAnimatorFadeUp(swLyr, sf + 1, fps, 14);

  var i, cy, lgpu, rgpu, ll, rl;
  for (i = 0; i < 4; i++) {
    cy = GPU_CYS[i];
    lgpu = comp.layers.addSolid(blueRGB, 'EB_NVS_LGPU_' + (i+1), GPU_W, GPU_H, 1);
    lgpu.position.setValue([L_CX, cy]);
    ebTextAnimatorFadeUp(lgpu, sf + 6 + i * 3, fps, 12);
    rgpu = comp.layers.addSolid(grnRGB, 'EB_NVS_RGPU_' + (i+1), GPU_W, GPU_H, 1);
    rgpu.position.setValue([R_CX, cy]);
    ebTextAnimatorFadeUp(rgpu, sf + 6 + i * 3, fps, 12);
    ll = ebStrokeLine(comp, 'EB_NVS_LL_' + (i+1),
      [[L_RE + 2, cy], [SW_L - 2, cy]], accArr, 1.5);
    ebFadeOnly(ll, sf + 20, fps, 8);
    rl = ebStrokeLine(comp, 'EB_NVS_RL_' + (i+1),
      [[SW_R + 2, cy], [R_LE - 2, cy]], accArr, 1.5);
    ebFadeOnly(rl, sf + 20, fps, 8);
  }
}

// =============================================================
// Topology 3: Spine-Leaf Network Fabric
// 2 spine switches + 4 leaf switches + 8 compute nodes.
// Dashed lines spine→leaf; solid lines leaf→node.
// =============================================================
function createSpineLeafBlock(comp, params) {
  var fps = comp.frameRate, sf = 1;
  var acc     = ebColor(params.accentColor || '76B900');
  var accArr  = [acc[0], acc[1], acc[2], 1];
  var blueRGB = [0.788, 0.878, 0.961];
  var grayArr = [0.55, 0.55, 0.55, 1];
  var darkArr = [0.38, 0.38, 0.38, 1];

  ebCreateHeader(comp, params, sf);

  var SP_W = 300, SP_H = 62, SP_Y = 250;
  var sp_xs = [530, 1390];

  var LF_W = 220, LF_H = 52, LF_Y = 490;
  var lf_xs = [260, 720, 1200, 1660];

  var ND_W = 180, ND_H = 85, ND_Y = 770;
  var nd_pairs = [[150, 370], [610, 830], [1090, 1310], [1550, 1770]];

  var SP_HH = Math.round(SP_H / 2);
  var LF_HH = Math.round(LF_H / 2);
  var ND_HH = Math.round(ND_H / 2);
  var i, j, nd, sp, lf, sl, ln;

  // Spine switches
  for (i = 0; i < 2; i++) {
    sp = ebStrokeRect(comp, 'EB_SL_Spine_' + (i+1), sp_xs[i], SP_Y, SP_W, SP_H, accArr, 2);
    ebTextAnimatorFadeUp(sp, sf + 1, fps, 14);
  }

  // Leaf switches
  for (j = 0; j < 4; j++) {
    lf = ebStrokeRect(comp, 'EB_SL_Leaf_' + (j+1), lf_xs[j], LF_Y, LF_W, LF_H, grayArr, 1.5);
    ebTextAnimatorFadeUp(lf, sf + 8, fps, 12);
  }

  // Spine → leaf dashed connections (all-to-all)
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 4; j++) {
      sl = ebStrokeLine(comp, 'EB_SL_SL_' + i + '_' + j,
        [[sp_xs[i], SP_Y + SP_HH + 2], [lf_xs[j], LF_Y - LF_HH - 2]],
        grayArr, 1.2, 8, 6);
      ebFadeOnly(sl, sf + 16, fps, 8);
    }
  }

  // Leaf → node solid connections + compute nodes
  for (j = 0; j < 4; j++) {
    for (var k = 0; k < 2; k++) {
      var nx = nd_pairs[j][k];
      ln = ebStrokeLine(comp, 'EB_SL_LN_' + j + '_' + k,
        [[lf_xs[j], LF_Y + LF_HH + 2], [nx, ND_Y - ND_HH - 2]], darkArr, 1.5);
      ebFadeOnly(ln, sf + 24, fps, 8);
      nd = comp.layers.addSolid(blueRGB, 'EB_SL_Node_' + j + '_' + k, ND_W, ND_H, 1);
      nd.position.setValue([nx, ND_Y]);
      ebTextAnimatorFadeUp(nd, sf + 28 + j * 2, fps, 10);
    }
  }
}

// =============================================================
// Topology 4: Single GPU Server Node
// CPU domain (left) + PCIe bus + 2x4 GPU grid (right).
// NVLink dashed lines between GPUs. Memory strips below CPUs.
// =============================================================
function createGPUNodeBlock(comp, params) {
  var fps = comp.frameRate, sf = 1;
  var acc     = ebColor(params.accentColor || '76B900');
  var accArr  = [acc[0], acc[1], acc[2], 1];
  var blueRGB = [0.788, 0.878, 0.961];
  var grnRGB  = [0.839, 0.910, 0.831];
  var grayArr = [0.55, 0.55, 0.55, 1];
  var dimArr  = [0.70, 0.70, 0.70, 1];

  ebCreateHeader(comp, params, sf);

  // CPU box
  var CPU_W = 210, CPU_H = 230, CPU_CX = 290, CPU_CY = 430;
  var cpu = comp.layers.addSolid([0.88, 0.88, 0.88], 'EB_GN_CPU', CPU_W, CPU_H, 1);
  cpu.position.setValue([CPU_CX, CPU_CY]);
  ebTextAnimatorFadeUp(cpu, sf + 1, fps, 14);

  // Memory strips below CPU
  var MEM_W = 185, MEM_H = 30, MEM_X = CPU_CX, MEM_Y0 = 585;
  var mi;
  for (mi = 0; mi < 3; mi++) {
    var ms = comp.layers.addSolid(blueRGB, 'EB_GN_MEM_' + (mi+1), MEM_W, MEM_H, 1);
    ms.position.setValue([MEM_X, MEM_Y0 + mi * 38]);
    ebTextAnimatorFadeUp(ms, sf + 4 + mi, fps, 10);
  }

  // PCIe bus line (horizontal, dashed)
  var BUS_Y  = CPU_CY;
  var BUS_X0 = CPU_CX + Math.round(CPU_W / 2) + 4;
  var BUS_X1 = 618;
  var bus = ebStrokeLine(comp, 'EB_GN_PCIe',
    [[BUS_X0, BUS_Y], [BUS_X1, BUS_Y]], dimArr, 2, 10, 6);
  ebFadeOnly(bus, sf + 8, fps, 8);

  // 2×4 GPU grid
  var GPU_W = 240, GPU_H = 155, GPU_GAP_X = 20, GPU_GAP_Y = 20;
  var GPU_COLS = 4, GPU_ROWS = 2;
  var GRID_L = 640;
  var GRID_T = 280;
  var gx, gy, col, row, gLyr;
  var gpu_cxs = [], gpu_cys = [];
  for (col = 0; col < GPU_COLS; col++) {
    gpu_cxs[col] = GRID_L + Math.round(GPU_W / 2) + col * (GPU_W + GPU_GAP_X);
  }
  for (row = 0; row < GPU_ROWS; row++) {
    gpu_cys[row] = GRID_T + Math.round(GPU_H / 2) + row * (GPU_H + GPU_GAP_Y);
  }
  for (row = 0; row < GPU_ROWS; row++) {
    for (col = 0; col < GPU_COLS; col++) {
      gLyr = comp.layers.addSolid(grnRGB, 'EB_GN_GPU_' + row + '_' + col, GPU_W, GPU_H, 1);
      gLyr.position.setValue([gpu_cxs[col], gpu_cys[row]]);
      ebTextAnimatorFadeUp(gLyr, sf + 12 + row * 4 + col, fps, 10);
    }
  }

  // NVLink dashed lines between adjacent GPUs (horizontal + vertical)
  var nvlArr = [acc[0], acc[1], acc[2], 0.7];
  for (row = 0; row < GPU_ROWS; row++) {
    for (col = 0; col < GPU_COLS - 1; col++) {
      var hLine = ebStrokeLine(comp, 'EB_GN_NVH_' + row + '_' + col,
        [[gpu_cxs[col] + Math.round(GPU_W/2) + 2, gpu_cys[row]],
         [gpu_cxs[col+1] - Math.round(GPU_W/2) - 2, gpu_cys[row]]],
        nvlArr, 1.5, 6, 5);
      ebFadeOnly(hLine, sf + 22, fps, 8);
    }
  }
  for (col = 0; col < GPU_COLS; col++) {
    var vLine = ebStrokeLine(comp, 'EB_GN_NVV_' + col,
      [[gpu_cxs[col], gpu_cys[0] + Math.round(GPU_H/2) + 2],
       [gpu_cxs[col], gpu_cys[1] - Math.round(GPU_H/2) - 2]],
      nvlArr, 1.5, 6, 5);
    ebFadeOnly(vLine, sf + 22, fps, 8);
  }

  // Chassis frame around GPU grid
  var FRAME_PAD = 20;
  var GRID_R = gpu_cxs[GPU_COLS-1] + Math.round(GPU_W/2);
  var GRID_B = gpu_cys[GPU_ROWS-1] + Math.round(GPU_H/2);
  var frCX = Math.round((GRID_L - FRAME_PAD + GRID_R + FRAME_PAD) / 2);
  var frCY = Math.round((GRID_T - FRAME_PAD + GRID_B + FRAME_PAD) / 2);
  var frW  = GRID_R - GRID_L + FRAME_PAD * 2;
  var frH  = GRID_B - GRID_T + FRAME_PAD * 2;
  var fr = ebStrokeRect(comp, 'EB_GN_Frame', frCX, frCY, frW, frH, grayArr, 1.2);
  ebTextAnimatorFadeUp(fr, sf + 1, fps, 14);
}

// =============================================================
// Topology 5: Multi-Rack Scale-Out Cluster
// Aggregation switch → 3 ToR switches → 3 racks of 4 servers.
// Dashed lines agg→ToR; solid lines ToR→servers.
// =============================================================
function createMultiRackBlock(comp, params) {
  var fps = comp.frameRate, sf = 1;
  var acc     = ebColor(params.accentColor || '76B900');
  var accArr  = [acc[0], acc[1], acc[2], 1];
  var blueRGB = [0.788, 0.878, 0.961];
  var grayArr = [0.50, 0.50, 0.50, 1];
  var dimArr  = [0.65, 0.65, 0.65, 1];

  ebCreateHeader(comp, params, sf);

  var RACK_XS  = [380, 960, 1540];
  var AGG_W    = 360, AGG_H = 58, AGG_CX = 960, AGG_CY = 175;
  var TOR_W    = 220, TOR_H = 50, TOR_Y  = 330;
  var RACK_W   = 250, RACK_H = 480, RACK_Y = 670;
  var SRV_W    = 200, SRV_H = 72, SRV_COUNT = 4;
  var AGG_HH   = Math.round(AGG_H / 2);
  var TOR_HH   = Math.round(TOR_H / 2);
  var RACK_HH  = Math.round(RACK_H / 2);
  var ri, si, rx, torY0, torY1, srvCY, srvLine;

  // Aggregation switch
  var agg = ebStrokeRect(comp, 'EB_MR_Agg', AGG_CX, AGG_CY, AGG_W, AGG_H, accArr, 2);
  ebTextAnimatorFadeUp(agg, sf + 1, fps, 14);

  for (ri = 0; ri < 3; ri++) {
    rx = RACK_XS[ri];

    // ToR switch
    var tor = ebStrokeRect(comp, 'EB_MR_TOR_' + (ri+1), rx, TOR_Y, TOR_W, TOR_H, accArr, 1.5);
    ebTextAnimatorFadeUp(tor, sf + 6, fps, 12);

    // Agg → ToR dashed line
    torY0 = AGG_CY + AGG_HH + 2;
    torY1 = TOR_Y  - TOR_HH - 2;
    var aggLine = ebStrokeLine(comp, 'EB_MR_AT_' + (ri+1),
      [[AGG_CX, torY0], [rx, torY1]], dimArr, 1.5, 8, 6);
    ebFadeOnly(aggLine, sf + 14, fps, 8);

    // Rack frame
    var rack = ebStrokeRect(comp, 'EB_MR_Rack_' + (ri+1), rx, RACK_Y, RACK_W, RACK_H, grayArr, 1.2);
    ebTextAnimatorFadeUp(rack, sf + 8, fps, 12);

    // ToR → rack (vertical solid line from ToR bottom to rack top)
    var rackTop = RACK_Y - RACK_HH;
    var torLine = ebStrokeLine(comp, 'EB_MR_TR_' + (ri+1),
      [[rx, TOR_Y + TOR_HH + 2], [rx, rackTop - 2]], grayArr, 1.5);
    ebFadeOnly(torLine, sf + 18, fps, 8);

    // Server nodes inside rack
    var srvGap   = 14;
    var srvTotalH = SRV_COUNT * SRV_H + (SRV_COUNT - 1) * srvGap;
    var srvStartY = RACK_Y - Math.round(srvTotalH / 2) + Math.round(SRV_H / 2);
    for (si = 0; si < SRV_COUNT; si++) {
      srvCY = srvStartY + si * (SRV_H + srvGap);
      var srv = comp.layers.addSolid(blueRGB, 'EB_MR_SRV_' + ri + '_' + si, SRV_W, SRV_H, 1);
      srv.position.setValue([rx, srvCY]);
      ebTextAnimatorFadeUp(srv, sf + 22 + ri * 3 + si, fps, 10);
    }
  }
}

// =============================================================
// COMPONENTS -- Standalone slide-level atomic blocks
// =============================================================

// Stat Callout -- giant centered number + label + optional desc
function createStatCalloutBlock(comp, params) {
  var fps = comp.frameRate;
  var sf  = 1;
  var acc = ebColor(params.accentColor);
  var number = params.statNumber || params.title || '0';
  var label  = (params.statLabel  || params.subtitle || '').toUpperCase();
  var desc   = params.statDesc   || '';

  // Accent line above number
  var lineY = 400;
  var lineL = ebStrokeLine(comp, 'EB_StatLine',
    [[760, lineY], [1160, lineY]], [acc[0], acc[1], acc[2], 1], 4);
  ebStrokeLineTrimDraw(lineL, sf, fps);

  // Giant number
  var numL = ebText(comp, number, 960, 560, 200, 'bold', [acc[0], acc[1], acc[2]], 'center');
  numL.name = 'EB_StatNum';
  ebAnimateFadeUp(numL, sf + 2, fps, 40);

  // Label
  if (label) {
    var lblL = ebText(comp, label, 960, 680, 32, 'regular', [0.35, 0.35, 0.35], 'center');
    lblL.name = 'EB_StatLbl';
    ebAnimateFadeUp(lblL, sf + 4, fps, 16);
  }

  // Optional description
  if (desc) {
    var descL = ebText(comp, desc, 960, 740, 24, 'light', [0.5, 0.5, 0.5], 'center');
    descL.name = 'EB_StatDesc';
    ebAnimateFadeUp(descL, sf + 6, fps, 12);
  }

  ebCreateHeader(comp, params, sf);
}

// KPI Row -- 2-5 key metrics side-by-side with accent lines
function createKPIRowBlock(comp, params) {
  var fps = comp.frameRate;
  var sf  = 1;
  var acc = ebColor(params.accentColor);
  var defaultKPIs = [
    {number: '99%',  label: 'Uptime',       desc: ''},
    {number: '2.4x', label: 'Performance',  desc: ''},
    {number: '50%',  label: 'Cost Savings', desc: ''}
  ];
  var kpis = (params.kpis && params.kpis.length >= 2)
    ? params.kpis.slice(0, 5) : defaultKPIs;
  var N    = kpis.length;
  var colW = Math.round(1760 / N);
  var lineY = 400;
  var numY  = 560;
  var lblY  = 650;
  var descY = 690;

  for (var i = 0; i < N; i++) {
    var cx = 80 + i * colW + Math.round(colW / 2);
    var kpi = kpis[i];

    // Accent line
    var lineW = Math.min(colW - 80, 220);
    var ln = ebStrokeLine(comp, 'EB_KPILine_' + (i + 1),
      [[cx - Math.round(lineW / 2), lineY], [cx + Math.round(lineW / 2), lineY]],
      [acc[0], acc[1], acc[2], 1], 3);
    ebStrokeLineTrimDraw(ln, sf + i, fps);

    // Number
    var numL = ebText(comp, kpi.number || '', cx, numY, 110, 'bold',
      [acc[0], acc[1], acc[2]], 'center');
    numL.name = 'EB_KPI_' + (i + 1);
    ebAnimateFadeUp(numL, sf + 2 + i, fps, 28);

    // Label
    if (kpi.label) {
      var lblL = ebText(comp, kpi.label.toUpperCase(), cx, lblY, 20, 'regular',
        [0.4, 0.4, 0.4], 'center');
      lblL.name = 'EB_KPILbl_' + (i + 1);
      ebAnimateFadeUp(lblL, sf + 3 + i, fps, 14);
    }

    // Sub-description
    if (kpi.desc) {
      var descL = ebText(comp, kpi.desc, cx, descY, 17, 'light',
        [0.55, 0.55, 0.55], 'center');
      descL.name = 'EB_KPIDesc_' + (i + 1);
      ebAnimateFadeUp(descL, sf + 4 + i, fps, 10);
    }

    // Vertical divider between columns (not after last)
    if (i < N - 1) {
      var dvX = 80 + (i + 1) * colW;
      var dvL = ebStrokeLine(comp, 'EB_KPIDiv_' + (i + 1),
        [[dvX, 340], [dvX, 720]], [0.18, 0.18, 0.18, 1], 1);
      ebFadeOnly(dvL, sf + 5, fps, 8);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// Pull Quote -- large quote text + attribution
function createPullQuoteBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var acc   = ebColor(params.accentColor);
  var quote = params.quote || params.bodyText || 'Your most impactful quote goes here.';
  var author = params.author || params.subtitle || '';

  // Opening quotation mark
  var qM = ebText(comp, '\u201C', 80, 440, 180, 'bold',
    [acc[0], acc[1], acc[2]], 'left');
  qM.name = 'EB_QuoteMark';
  ebAnimateFadeUp(qM, sf + 1, fps, 20);

  // Quote body
  var qTxt = ebText(comp, quote, 960, 580, 50, 'light', [0.1, 0.1, 0.1], 'center');
  qTxt.name = 'EB_QuoteText';
  ebTextAnimatorFadeUp(qTxt, sf + 2, fps, 18);

  // Accent bar
  var barY = 660;
  var bar  = comp.layers.addSolid([acc[0], acc[1], acc[2]], 'EB_QuoteBar', 80, 4, 1);
  bar.position.setValue([960, barY]);
  ebAnimateFadeUp(bar, sf + 4, fps, 10);

  // Author attribution
  if (author) {
    var authL = ebText(comp, '\u2014 ' + author, 960, barY + 40, 24, 'regular',
      [0.4, 0.4, 0.4], 'center');
    authL.name = 'EB_QuoteAuthor';
    ebAnimateFadeUp(authL, sf + 5, fps, 12);
  }

  ebCreateHeader(comp, params, sf);
}

// Section Divider -- full-width accent line + section number + title
function createSectionDividerBlock(comp, params) {
  var fps         = comp.frameRate;
  var sf          = 1;
  var acc         = ebColor(params.accentColor);
  var sectionNum  = params.sectionNum  || '';
  var sectionTitle = params.sectionTitle || params.title || 'Section Title';
  var sectionDesc  = params.sectionDesc  || params.subtitle || '';

  // Full-width horizontal accent line
  var lineY = 440;
  var lineL = ebStrokeLine(comp, 'EB_DivLine',
    [[80, lineY], [1840, lineY]], [acc[0], acc[1], acc[2], 1], 4);
  ebStrokeLineTrimDraw(lineL, sf, fps);

  // Section number (optional, large, left-aligned)
  var titleX = 80;
  if (sectionNum) {
    var numStr = String(sectionNum).length < 2
      ? '0' + String(sectionNum) : String(sectionNum);
    var numL = ebText(comp, numStr, 80, 570, 110, 'bold',
      [acc[0], acc[1], acc[2]], 'left');
    numL.name = 'EB_DivNum';
    ebAnimateFadeUp(numL, sf + 2, fps, 28);
    titleX = 240;
  }

  // Section title
  var titL = ebText(comp, sectionTitle, titleX, 570, 68, 'bold',
    [0.07, 0.07, 0.07], 'left');
  titL.name = 'EB_DivTitle';
  ebTextAnimatorFadeUp(titL, sf + 3, fps, 18);

  // Optional description
  if (sectionDesc) {
    var descL = ebText(comp, sectionDesc, titleX, 650, 28, 'light',
      [0.4, 0.4, 0.4], 'left');
    descL.name = 'EB_DivDesc';
    ebAnimateFadeUp(descL, sf + 5, fps, 14);
  }
}

// =============================================================
// INJECTABLE COMPONENTS -- Added to existing comps by the AI
// =============================================================

// Upper-right stat: large number + label next to the title area
function ebpAddInjStat(comp, inj) {
  var fps = comp.frameRate;
  var acc = ebColor(inj.accentColor || '76B900');
  var num = inj.number || '';
  var lbl = (inj.label || '').toUpperCase();
  // Right-aligned in the header zone; vertically centered between title rows
  var cx  = 1760;
  var numL = ebText(comp, num, cx, 110, 54, 'bold', [acc[0], acc[1], acc[2]], 'right');
  numL.name = 'EB_InjStatNum';
  ebAnimateFadeUp(numL, 4, fps, 14);
  if (lbl) {
    var lblL = ebText(comp, lbl, cx, 152, 14, 'semibold', [0.55, 0.55, 0.55], 'right');
    lblL.name = 'EB_InjStatLbl';
    ebAnimateFadeUp(lblL, 5, fps, 8);
  }
}

// Colored pill badge above title: "Step 2 of 4"
function ebpAddInjBadge(comp, inj) {
  var fps  = comp.frameRate;
  var acc  = ebColor(inj.accentColor || '76B900');
  var text = (inj.text || '').toUpperCase();
  if (!text) return;
  var charW = 9; var padX = 20; var h = 26;
  var w = Math.max(text.length * charW + padX * 2, 80);
  var cy = 68;
  var bg = comp.layers.addSolid([acc[0], acc[1], acc[2]], 'EB_InjBadgeBG', w, h, 1);
  bg.position.setValue([960, cy]);
  ebAnimateFadeUp(bg, 1, fps, 10);
  var txtL = ebText(comp, text, 960, cy + 5, 13, 'bold', [0, 0, 0], 'center');
  txtL.name = 'EB_InjBadgeTxt';
  ebAnimateFadeUp(txtL, 2, fps, 10);
}

// Small attribution text at very bottom of slide
function ebpAddInjSource(comp, inj) {
  var fps  = comp.frameRate;
  var text = inj.text || '';
  if (!text) return;
  var srcL = ebText(comp, text, 1840, 1055, 17, 'light', [0.5, 0.5, 0.5], 'right');
  srcL.name = 'EB_InjSource';
  ebAnimateFadeUp(srcL, 10, fps, 6);
}

// Three KPIs across the bottom strip of the card area
function ebpAddInjKPIStrip(comp, inj) {
  var fps  = comp.frameRate;
  var acc  = ebColor(inj.accentColor || '76B900');
  var kpis = (inj.kpis && inj.kpis.length >= 2) ? inj.kpis.slice(0, 3) : [];
  if (!kpis.length) return;
  var N    = kpis.length;
  var colW = Math.round(1760 / N);
  var numY = 920; var lblY = 960;
  for (var i = 0; i < N; i++) {
    var cx   = 80 + i * colW + Math.round(colW / 2);
    var kpi  = kpis[i];
    var numL = ebText(comp, kpi.number || '', cx, numY, 48, 'bold',
      [acc[0], acc[1], acc[2]], 'center');
    numL.name = 'EB_InjKPI_' + (i + 1);
    ebAnimateFadeUp(numL, 5 + i, fps, 14);
    if (kpi.label) {
      var lblL = ebText(comp, kpi.label.toUpperCase(), cx, lblY, 15, 'regular',
        [0.5, 0.5, 0.5], 'center');
      lblL.name = 'EB_InjKPILbl_' + (i + 1);
      ebAnimateFadeUp(lblL, 6 + i, fps, 8);
    }
  }
}

// =============================================================
// STORYTELLING BLOCKS
// =============================================================

// =============================================================
// TEXT STORYTELLING BLOCKS
// =============================================================

// text-agenda: Numbered agenda / table of contents.
// params: title, subtitle, accentColor, bullets (array of strings, up to 6)
function createTextAgendaBlock(comp, params) {
  var fps    = comp.frameRate;
  var sf     = 1;
  var acc    = ebColor(params.accentColor);
  var aRGB   = [acc[0], acc[1], acc[2]];
  var L      = EB_LAYOUT;

  var defItems = ['First agenda item', 'Second topic', 'Third section',
                  'Fourth point', 'Fifth item'];
  var items = (params.bullets && params.bullets.length)
    ? params.bullets.slice(0, 6) : defItems;
  var N = items.length;

  var card = {
    x: 960,
    y: L.cardTop + (L.cardBottom - L.cardTop) / 2,
    w: L.compW - L.marginX * 2,
    h: L.cardBottom - L.cardTop
  };
  var showShadow = params.dropShadow !== false;
  var borderClr  = params.cardBorder ? acc : null;
  var _noFill    = (params.cardBg === false);
  var bgL = ebCreateCardBg(comp, card, 'EB_AgBG', null, borderClr, showShadow, _noFill, null);
  ebAnimateFadeUp(bgL, sf + 36, fps, 40);

  // Content zone starts just below card header rule (no actual header used — title via ebCreateHeader)
  // Card inner top = card.y - card.h/2 = 230. After header label+rule = 230+76 = 306 (not used here).
  // We use full card zone: first item at zoneTop + first slot center.
  var zoneTop = card.y - card.h / 2 + 40;    // 270
  var zoneH   = card.h - 40;                  // 710
  var rowH    = Math.min(Math.round(zoneH / N), 126);
  var numFSz  = 30;
  var txtFSz  = 28;
  // Number x: left edge of card + cardPadX
  var numX    = card.x - card.w / 2 + L.cardPadX;       // 112
  var txtX    = numX + 68;                               // 180
  var sepClr  = [0.82, 0.82, 0.82, 1];

  for (var i = 0; i < N; i++) {
    // Baseline sits 0.72 into the row
    var itemY  = zoneTop + Math.round(rowH * (i + 0.68));
    var fr     = sf + 36 + i * 6;
    var numStr = (i + 1) < 10 ? '0' + (i + 1) : String(i + 1);
    var txt    = typeof items[i] === 'string' ? items[i]
               : (items[i].text || items[i].main || '');

    // Number
    var nL = ebText(comp, numStr, numX, itemY, numFSz, 'bold', aRGB, 'left');
    nL.name = 'EB_Ag_Num_' + i;
    ebTextAnimatorFadeUp(nL, fr, fps, 18);

    // Text
    var tL = ebText(comp, txt, txtX, itemY, txtFSz, 'regular', [0.05, 0.05, 0.05], 'left');
    tL.name = 'EB_Ag_Txt_' + i;
    ebTextAnimatorFadeUp(tL, fr + 2, fps, 18);

    // Separator line below each item except the last
    if (i < N - 1) {
      var sepY = zoneTop + Math.round(rowH * (i + 1));
      var sepL = ebStrokeLine(comp, 'EB_Ag_Sep_' + i,
        [[numX, sepY], [card.x + card.w / 2 - L.cardPadX, sepY]], sepClr, 1);
      ebFadeOnly(sepL, fr + 3, fps, 8);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// text-acronym: Letter-by-letter acronym breakdown (e.g. C-G-N-B).
// params: title, subtitle, accentColor,
//         letters: [{letter:'C', word:'CPUs', desc:'Processing units'}, ...]
function createTextAcronymBlock(comp, params) {
  var fps  = comp.frameRate;
  var sf   = 1;
  var acc  = ebColor(params.accentColor);
  var aRGB = [acc[0], acc[1], acc[2]];
  var L    = EB_LAYOUT;

  var defLetters = [
    {letter: 'C', word: 'CPUs',      desc: 'Processing units'},
    {letter: 'G', word: 'GPUs',      desc: 'Accelerators'},
    {letter: 'N', word: 'NICs',      desc: 'Network interface cards'},
    {letter: 'B', word: 'Bandwidth', desc: 'Network throughput'},
    {letter: 'S', word: 'Storage',   desc: 'Data persistence'},
    {letter: 'M', word: 'Memory',    desc: 'High-bandwidth memory'}
  ];
  var nTarget = Math.min(Math.max(parseInt(params.acronymCount) || 4, 2), 6);
  var letters = (params.letters && params.letters.length >= 2)
    ? params.letters.slice(0, nTarget) : defLetters.slice(0, nTarget);
  var N    = letters.length;
  var colW = Math.round(1760 / N);

  // Vertical positions — all fixed, no sourceRect
  var letFSz   = 130;
  var letY     = 572;           // baseline for large letter (visually centered ~540)
  var wordFSz  = 28;
  var wordY    = letY + 72;     // 644
  var descFSz  = 20;
  var descY    = wordY + 44;    // 688
  var divTop   = 430;
  var divBot   = 710;
  var divClr   = [0.78, 0.78, 0.78, 1];

  var acrLayersBefore;
  for (var i = 0; i < N; i++) {
    var item = letters[i];
    var cx   = L.marginX + i * colW + Math.round(colW / 2);
    var fr   = sf + 36 + i * 8;
    acrLayersBefore = comp.numLayers;

    // Large letter
    var letL = ebText(comp, item.letter || '', cx, letY, letFSz, 'bold', aRGB, 'center');
    letL.name = 'EB_Acr_Let_' + i;
    ebAnimateFadeUp(letL, fr, fps, 28);

    // Word (all-caps)
    if (item.word) {
      var wrd = typeof item.word === 'string' ? item.word.toUpperCase() : '';
      var wL = ebText(comp, wrd, cx, wordY, wordFSz, 'bold', [0.07, 0.07, 0.07], 'center');
      wL.name = 'EB_Acr_Word_' + i;
      ebAnimateFadeUp(wL, fr + 4, fps, 18);
    }

    // Description
    if (item.desc) {
      var dL = ebText(comp, item.desc, cx, descY, descFSz, 'light', [0.45, 0.45, 0.45], 'center');
      dL.name = 'EB_Acr_Desc_' + i;
      ebAnimateFadeUp(dL, fr + 6, fps, 14);
    }

    // Vertical divider between columns
    if (i < N - 1) {
      var dvX = L.marginX + (i + 1) * colW;
      var dvL = ebStrokeLine(comp, 'EB_Acr_Div_' + i,
        [[dvX, divTop], [dvX, divBot]], divClr, 1);
      ebFadeOnly(dvL, fr + 3, fps, 8);
    }

    if (params.precomp) {
      _ebPrecompCard(comp, acrLayersBefore, 'EB_Acr_Col_' + i, fr - sf, fps, cx, Math.round((letY + divTop) / 2));
    }
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// DIAGRAM BLOCKS
// =============================================================

// diagram-chal-sol: Challenges vs Solutions two-panel block.
// Uses ebCreateCardHeader (proven) — text positioning derived from card geometry.
// params: title, subtitle, accentColor, leftColor, rightColor, leftTitle, rightTitle,
//         cards: [{label:'Challenges',body:'Item1\rItem2\rItem3'},
//                 {label:'Solutions', body:'Sol1\rSol2\rSol3'}]
function createChalSolBlock(comp, params) {
  var fps  = comp.frameRate;
  var sf   = 1;

  var chalClr = ebColor(params.leftColor  || '890C58');
  var solClr  = ebColor(params.rightColor || (params.accentColor || '76B900'));
  var cards2  = ebCardLayout(2);
  var bChar   = String.fromCharCode(8226);
  var showShadow = params.dropShadow !== false;

  var sides = [
    { card:  cards2[0], clr: chalClr,
      label: (params.cards && params.cards[0] && params.cards[0].label)
             ? params.cards[0].label : (params.leftTitle  || 'Challenges'),
      items: (params.cards && params.cards[0] && params.cards[0].body)
             ? params.cards[0].body.split('\r')
             : ['First challenge here', 'Second concern', 'Third limitation'] },
    { card:  cards2[1], clr: solClr,
      label: (params.cards && params.cards[1] && params.cards[1].label)
             ? params.cards[1].label : (params.rightTitle || 'Solutions'),
      items: (params.cards && params.cards[1] && params.cards[1].body)
             ? params.cards[1].body.split('\r')
             : ['First solution', 'Second resolution', 'Third improvement'] }
  ];

  for (var s = 0; s < 2; s++) {
    var side     = sides[s];
    var card     = side.card;
    var clr      = side.clr;
    var cRGB     = [clr[0], clr[1], clr[2]];
    var fr0      = sf + 36 + s * 10;
    var _noFill  = (params.cardBg === false);
    var borderClr = params.cardBorder ? clr : null;

    var bgL = ebCreateCardBg(comp, card, 'EB_CS_BG_' + s, null, borderClr, showShadow, _noFill, null);
    ebAnimateFadeUp(bgL, fr0, fps, 40);

    // ebCreateCardHeader returns {header, rule, bottomY}
    // bottomY = (card.y - card.h/2) + cardPadTop + headerFontSize + 14
    //         = cardTop + 36 + 26 + 14 = cardTop + 76
    var hdr = ebCreateCardHeader(comp, card, side.label, clr, true, fr0 + 8, fps);

    // Body bullets — positioned from hdr.bottomY + gap
    // bodyY is the zone-top for bullets; each bullet baseline:
    //   zoneTop + k * lineAdv + bFSz * 0.78
    // (same pattern as createBulletListBlock body via ebCreateBullet, but direct)
    var items   = side.items.slice(0, 5);
    var bFSz    = 24;
    var lineAdv = bFSz + 28;
    var L       = EB_LAYOUT;
    var dotX    = card.x - card.w / 2 + L.cardPadX;   // left edge + padding
    var txtX    = dotX + 26;
    var zoneTop = hdr.bottomY + 20;

    for (var k = 0; k < items.length; k++) {
      // Baseline = zoneTop + k * lineAdv + cap-height offset
      var bY  = zoneTop + k * lineAdv + Math.round(bFSz * 0.78);
      var iFr = fr0 + 16 + k * 5;
      var txt = items[k].replace(/^\s+|\s+$/g, '');
      if (!txt) continue;

      var dotL = ebText(comp, bChar, dotX, bY, bFSz, 'regular', cRGB, 'left');
      dotL.name = 'EB_CS_Dot_' + s + '_' + k;
      ebTextAnimatorFadeUp(dotL, iFr, fps, 16);

      var txtL = ebText(comp, txt, txtX, bY, bFSz, 'regular', [0.07, 0.07, 0.07], 'left');
      txtL.name = 'EB_CS_Txt_' + s + '_' + k;
      ebTextAnimatorFadeUp(txtL, iFr + 2, fps, 16);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// CODE LAYOUT BLOCKS
// =============================================================

// text-code-quad: 2x2 grid of code cards.
// Each card: colored label + thin accent underline + monospaced code lines.
// ALL text positions derived from solid center — no sourceRectAtTime.
// params: title, subtitle, accentColor,
//         cards: [{label:'Init', code:'line1\rline2'}, ...] (4 items)
function createCodeQuadBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var acc   = ebColor(params.accentColor);
  var aRGB  = [acc[0], acc[1], acc[2]];
  var L     = EB_LAYOUT;

  var defCards = [
    {label: 'Initialize',  code: 'import client\rclient = Client(\r  cluster_url, token)'},
    {label: 'Submit Job',  code: 'job = client.submit(\r  name="train",\r  gpu=4)'},
    {label: 'Monitor',     code: 'status = client\r  .get(job.id)\r  .status'},
    {label: 'Collect',     code: 'logs = client\r  .logs(job.id)\rfor l in logs: print(l)'}
  ];
  var cards4 = (params.cards && params.cards.length >= 2)
    ? params.cards.slice(0, 4) : defCards;

  var gap  = 20;
  var zL   = L.marginX;               // 80   left edge
  var zT   = L.cardTop;               // 230  top edge
  var zW   = L.compW - 2 * L.marginX; // 1760 total width
  var zH   = L.cardBottom - zT;       // 750  total height
  var nCards = (params.cardCount === 2) ? 2 : 4;
  var nRows  = (nCards === 2) ? 1 : 2;
  var cW   = Math.round((zW - gap) / 2);
  var cH   = Math.round((zH - (nRows - 1) * gap) / nRows);
  var bgClr   = [0.96, 0.96, 0.96];
  var monoClr = [0.12, 0.12, 0.12];
  var lblFSz  = 20;
  var codeFSz = 22;
  var codeAdv = codeFSz + 8;  // line-height

  var layersBefore;
  for (var i = 0; i < nCards; i++) {
    layersBefore = comp.numLayers;
    var col  = i % 2;
    var row  = Math.floor(i / 2);
    // Card center: start at zL, step by cW+gap; offset to center of card
    var cx   = zL + col * (cW + gap) + Math.round(cW / 2);
    var cy   = zT + row * (cH + gap) + Math.round(cH / 2);
    // Card edges — derived from center, no sourceRect
    var left = cx - Math.round(cW / 2);
    var top  = cy - Math.round(cH / 2);
    var fr   = sf + 36 + i * 6;
    var dat  = cards4[i] || defCards[i % 4];
    var lbl  = dat.label || '';
    var code = dat.code  || dat.body || '';

    // Background solid — centered exactly at [cx, cy]
    var bgS = comp.layers.addSolid(bgClr, 'EB_CQ_BG_' + i, cW, cH, 1);
    bgS.position.setValue([cx, cy]);
    ebAnimateFadeUp(bgS, fr, fps, 28);

    // Label baseline = top + 42 (leaves ~18px clearance above for a 20px label)
    var lblY = top + 50;
    var lblL = ebText(comp, lbl, left + 24, lblY, lblFSz, 'semibold', aRGB, 'left');
    lblL.name = 'EB_CQ_Lbl_' + i;
    ebTextAnimatorFadeUp(lblL, fr + 2, fps, 12);

    // Accent underline: 1.5px line 10px below label baseline, fixed 160px wide
    var ulY = lblY + 10;
    var ulL = ebStrokeLine(comp, 'EB_CQ_UL_' + i,
      [[left + 24, ulY], [left + 184, ulY]], [aRGB[0], aRGB[1], aRGB[2], 1], 1.5);
    ebStrokeLineTrimDraw(ulL, fr + 3, fps);

    // Code lines — start 22px below underline
    var codeTop = ulY + 22;
    var lines   = code.split('\r');
    for (var li = 0; li < lines.length && li < 10; li++) {
      var lineBase = codeTop + li * codeAdv + codeFSz;
      // Stop if line would exceed card bottom (leave 14px margin)
      if (lineBase > top + cH - 14) break;
      var cL = ebText(comp, lines[li], left + 24, lineBase, codeFSz, 'mono', monoClr, 'left');
      cL.name = 'EB_CQ_Code_' + i + '_' + li;
      ebAnimateFadeUp(cL, fr + 4 + li, fps, 8);
    }

    if (params.precomp) {
      _ebPrecompCard(comp, layersBefore, 'EB_CodeCard_' + i, fr - sf, fps, cx, cy);
    }
  }

  ebCreateHeader(comp, params, sf);
}

// text-code-split: Left bullet list + right code block side by side.
// Right code area is a solid; ALL text positions fixed from solid geometry.
// params: title, subtitle, accentColor, codeLabel, code (string, \r-separated),
//         bullets (array of strings)
function createCodeSplitBlock(comp, params) {
  var fps   = comp.frameRate;
  var sf    = 1;
  var acc   = ebColor(params.accentColor);
  var aRGB  = [acc[0], acc[1], acc[2]];
  var L     = EB_LAYOUT;

  var gap    = 40;
  var leftW  = 740;
  var rightW = L.compW - L.marginX * 2 - leftW - gap;  // 900
  var zT     = L.cardTop;     // 230
  var zB     = L.cardBottom;  // 980
  var zH     = zB - zT;       // 750

  // Right code block — solid centered at [rightCX, rightCY]
  var rightCX  = L.marginX + leftW + gap + Math.round(rightW / 2);  // 80+740+40+450 = 1310
  var rightCY  = zT + Math.round(zH / 2);                           // 230+375 = 605
  var rightL   = rightCX - Math.round(rightW / 2);                  // left edge = 860
  var rightTop = rightCY - Math.round(zH / 2);                      // = zT = 230

  var codeBG = comp.layers.addSolid([0.95, 0.95, 0.95], 'EB_CSp_BG', rightW, zH, 1);
  codeBG.position.setValue([rightCX, rightCY]);
  ebAnimateFadeUp(codeBG, sf + 36, fps, 28);

  // Optional drop shadow on code block
  if (params.dropShadow !== false) {
    try {
      var ds = codeBG.Effects.addProperty('ADBE Drop Shadow');
      try { ds.property('Opacity').setValue(10); } catch(e) {}
      try { ds.property('Direction').setValue(135); } catch(e) {}
      try { ds.property('Distance').setValue(6); } catch(e) {}
      try { ds.property('Softness').setValue(18); } catch(e) {}
    } catch(e) {}
  }

  // Code section label — baseline = rightTop + 44
  var codeLabel = (params.codeLabel || 'Example').toUpperCase();
  var clblY     = rightTop + 44;
  var clblL = ebText(comp, codeLabel, rightL + 24, clblY, 16, 'semibold', aRGB, 'left');
  clblL.name = 'EB_CSp_Lbl';
  ebTextAnimatorFadeUp(clblL, sf + 38, fps, 12);

  // Label underline — 10px below label baseline, 160px wide
  var ulY = clblY + 10;
  var ulL = ebStrokeLine(comp, 'EB_CSp_UL',
    [[rightL + 24, ulY], [rightL + 184, ulY]], [aRGB[0], aRGB[1], aRGB[2], 1], 1.5);
  ebStrokeLineTrimDraw(ulL, sf + 39, fps);

  // Code lines — first baseline = label underline + 26
  var rawCode   = params.code || params.cliCommand || '// code here';
  var codeLines = rawCode.split('\r');
  var codeFSz   = 16;
  var codeAdv   = codeFSz + 8;
  var monoClr   = [0.1, 0.1, 0.1];
  var codeStartY = ulY + 26;
  for (var li = 0; li < codeLines.length && li < 24; li++) {
    var cBase = codeStartY + li * codeAdv + codeFSz;
    if (cBase > zB - 18) break;
    var cL = ebText(comp, codeLines[li], rightL + 24, cBase, codeFSz, 'mono', monoClr, 'left');
    cL.name = 'EB_CSp_Code_' + li;
    ebAnimateFadeUp(cL, sf + 40 + li, fps, 8);
  }

  // Left bullets
  var defBullets = ['First key point', 'Second important concept',
                    'Third detail', 'Fourth takeaway'];
  var bullets  = (params.bullets && params.bullets.length)
    ? params.bullets.slice(0, 5) : defBullets;
  var bChar    = String.fromCharCode(8226);
  var bFSz     = 26;
  var bLineAdv = bFSz + 32;
  var dotX     = L.marginX + 8;        // 88
  var bTxtX    = dotX + 26;            // 114
  // Spread bullets evenly across the content zone height
  var bAvailH  = zH - 60;             // 690px available
  var bSpacing = Math.min(Math.round(bAvailH / Math.max(bullets.length, 1)), bLineAdv + 18);
  var bZoneTop = zT + 40;             // 270

  for (var bi = 0; bi < bullets.length; bi++) {
    // Baseline = zone top + cap-height entry + per-item step
    var bY  = bZoneTop + Math.round(bFSz * 0.78) + bi * bSpacing;
    var bFr = sf + 36 + bi * 6;
    var btxt = typeof bullets[bi] === 'string' ? bullets[bi]
             : (bullets[bi].main || bullets[bi].text || '');

    var dL = ebText(comp, bChar, dotX, bY, bFSz, 'regular', aRGB, 'left');
    dL.name = 'EB_CSp_Dot_' + bi;
    ebTextAnimatorFadeUp(dL, bFr, fps, 18);

    var tL = ebText(comp, btxt, bTxtX, bY, bFSz, 'regular', [0.07, 0.07, 0.07], 'left');
    tL.name = 'EB_CSp_Txt_' + bi;
    ebTextAnimatorFadeUp(tL, bFr + 2, fps, 18);
  }

  ebCreateHeader(comp, params, sf);
}

// =============================================================
// MULTI-BLOCK LAYOUT
// Creates N sub-comps (one per slot), calls each block function
// with noHeader:true, then assembles them in the master comp
// scaled/positioned according to the chosen layout template.
// =============================================================

// Internal dispatch: maps blockType string → block function call on a given comp.
function _ebDispatch(comp, p) {
  var bt = p.blockType || '';
  if      (bt === 'slide-title')              { createSlideTitleBlock(comp, p); }
  else if (bt === 'cards-1')                  { createIconCardsBlock(comp, p, 1); }
  else if (bt === 'cards-2')                  { createIconCardsBlock(comp, p, 2); }
  else if (bt === 'cards-3')                  { createIconCardsBlock(comp, p, 3); }
  else if (bt === 'cards-4')                  { createIconCardsBlock(comp, p, 4); }
  else if (bt === 'cards-5')                  { createIconCardsBlock(comp, p, 5); }
  else if (bt === 'cards-icon-3')             { createCardsIconBlock(comp, p, 3); }
  else if (bt === 'cards-compare')            { createComparisonBlock(comp, p); }
  else if (bt === 'cards-media')              { createMediaCardsBlock(comp, p); }
  else if (bt === 'cards-corner')             { createCornerCardsBlock(comp, p); }
  else if (bt === 'cards-corner-sq')          { createCornerSquareBlock(comp, p); }
  else if (bt === 'cards-corner-slim')        { createCornerSlimBlock(comp, p); }
  else if (bt === 'cards-specs-a')            { createSpecsCardA(comp, p); }
  else if (bt === 'cards-specs-b')            { createSpecsCardB(comp, p); }
  else if (bt === 'cards-specs-c')            { createSpecsCardC(comp, p); }
  else if (bt === 'bullets')                  { createBulletListBlock(comp, p); }
  else if (bt === 'text-bullets')             { createTextBulletsBlock(comp, p); }
  else if (bt === 'bullet-list')              { createBulletDotListBlock(comp, p); }
  else if (bt === 'check-list')               { createCheckmarksListBlock(comp, p); }
  else if (bt === 'text-nested')              { createTextNestedBlock(comp, p); }
  else if (bt === 'text-2col')                { createText2ColBlock(comp, p); }
  else if (bt === 'text-numbered')            { createTextNumberedBlock(comp, p); }
  else if (bt === 'text-cli')                 { createTextCLIBlock(comp, p); }
  else if (bt === 'text-code-bullets')        { createTextCodeBulletsBlock(comp, p); }
  else if (bt === 'text-code-cli')            { createTextCodeCLIBlock(comp, p); }
  else if (bt === 'text-links')               { createTextLinksBlock(comp, p); }
  else if (bt === 'text-body-bullets')        { createTextBodyBulletsBlock(comp, p); }
  else if (bt === 'text-errors')              { createTextErrorsBlock(comp, p); }
  else if (bt === 'text-agenda')              { createTextAgendaBlock(comp, p); }
  else if (bt === 'text-acronym')             { createTextAcronymBlock(comp, p); }
  else if (bt === 'text-code-quad')           { createCodeQuadBlock(comp, p); }
  else if (bt === 'text-code-split')          { createCodeSplitBlock(comp, p); }
  else if (bt === 'diagram-flow')             { createFlowDiagramBlock(comp, p); }
  else if (bt === 'diagram-flow-4')           { createFlowDiagram4StepBlock(comp, p); }
  else if (bt === 'diagram-cycle')            { createFlowCycleBlock(comp, p); }
  else if (bt === 'diagram-process-2')        { createDiagramProcess2Block(comp, p); }
  else if (bt === 'diagram-chal-sol')         { createChalSolBlock(comp, p); }
  else if (bt === 'diagram-timeline')         { createTimelineBlock(comp, p); }
  else if (bt === 'diagram-funnel')           { createFunnelBlock(comp, p); }
  else if (bt === 'diagram-matrix')           { createMatrixBlock(comp, p); }
  else if (bt === 'diagram-steps')            { createStepsBlock(comp, p); }
  else if (bt === 'diagram-hub-spoke')        { createHubSpokeBlock(comp, p); }
  else if (bt === 'diagram-flow-bullets-3')   { createFlowBulletsBlock(comp, p); }
  else if (bt === 'diagram-parallel-split-ol'){ p.strokeOnly = true; createParallelSplitBlock(comp, p); }
  else if (bt === 'diagram-split-2-ol')       { p.strokeOnly = true; createSplitBlock(comp, p, 2); }
  else if (bt === 'diagram-split-3-ol')       { p.strokeOnly = true; createSplitBlock(comp, p, 3); }
  else if (bt === 'diagram-split-5-ol')       { p.strokeOnly = true; createSplitBlock(comp, p, 5); }
  else if (bt === 'diagram-split-mirror-ol')  { p.strokeOnly = true; createSplitMirrorBlock(comp, p); }
  else if (bt === 'tree-3')                   { createTree3Block(comp, p); }
  else if (bt === 'tree-2level')              { createTree2LevelBlock(comp, p); }
  else if (bt === 'tree-h3')                  { createTreeH3Block(comp, p); }
  else if (bt === 'tree-h5')                  { createTreeH5Block(comp, p); }
  else if (bt === 'chart-bar')                { createBarGraphBlock(comp, p); }
  else if (bt === 'chart-bar-v')              { createVerticalBarGraphBlock(comp, p); }
  else if (bt === 'chart-bar-stacked')        { createStackedBarChartBlock(comp, p); }
  else if (bt === 'chart-donut')              { createDonutChartBlock(comp, p); }
  else if (bt === 'chart-line')               { createLineChartBlock(comp, p); }
  else if (bt === 'chart-bar-grouped')        { createGroupedBarChartBlock(comp, p); }
  else if (bt === 'chart-area')               { createAreaChartBlock(comp, p); }
  else if (bt === 'chart-progress')           { createProgressChartBlock(comp, p); }
  else if (bt === 'chart-scatter')            { createScatterPlotBlock(comp, p); }
  else if (bt === 'chart-pie')                { createPieChartBlock(comp, p); }
  else if (bt === 'chart-waterfall')          { createWaterfallChartBlock(comp, p); }
  else if (bt === 'chart-radar')              { createRadarChartBlock(comp, p); }
  else if (bt === 'chart-bubble')             { createBubbleChartBlock(comp, p); }
  else if (bt === 'table-1col')               { createTableBlock(comp, p, 1); }
  else if (bt === 'table-2col')               { createTableBlock(comp, p, 2); }
  else if (bt === 'table-3col')               { createTableBlock(comp, p, 3); }
  else if (bt === 'table-4col')               { createTableBlock(comp, p, 4); }
  else if (bt === 'cards-device')             { createDeviceCardBlock(comp, p); }
  else if (bt === 'rack-callout')             { createRackBlock(comp, p); }
  else if (bt === 'comp-timeline')            { createCompTimelineBlock(comp, p); }
  else if (bt === 'comp-logo-strip')          { createLogoStripBlock(comp, p); }
  else if (bt === 'comp-compare')             { createCompareBlock(comp, p); }
  else if (bt === 'comp-tags')                { createTagsBlock(comp, p); }
  else if (bt === 'comp-callout')             { createCalloutBlock(comp, p); }
  else if (bt === 'comp-icon-grid')           { createIconGridBlock(comp, p); }
  else if (bt === 'topology-gh200')           { createGH200PairBlock(comp, p); }
  else if (bt === 'topology-nvlink-switch')   { createNVLinkSwitchBlock(comp, p); }
  else if (bt === 'topology-spine-leaf')      { createSpineLeafBlock(comp, p); }
  else if (bt === 'topology-gpu-node')        { createGPUNodeBlock(comp, p); }
  else if (bt === 'topology-multi-rack')      { createMultiRackBlock(comp, p); }
  else if (bt === 'comp-stat')                { createStatCalloutBlock(comp, p); }
  else if (bt === 'comp-kpi')                 { createKPIRowBlock(comp, p); }
  else if (bt === 'comp-quote')               { createPullQuoteBlock(comp, p); }
  else if (bt === 'comp-divider')             { createSectionDividerBlock(comp, p); }
}

// Layout region definitions — pixel coords in the 1920×1080 master comp.
// scale = min(region.w/1920, region.h/1080) * 100 (uniform, no crop)
function _ebMultiLayouts() {
  var G = 8; // gap between slots in px
  var W = 1920; var H = 1080;
  var hW = Math.floor((W - G) / 2);   // 956
  var hH = Math.floor((H - G) / 2);   // 536
  var tW = Math.floor((W - 2*G) / 3); // 634  (3-col)
  return {
    'split-h': {
      slots: 2,
      regions: [
        { l:0,        t:0, w:hW, h:H },
        { l:hW+G,     t:0, w:hW, h:H }
      ]
    },
    'split-v': {
      slots: 2,
      regions: [
        { l:0, t:0,    w:W, h:hH },
        { l:0, t:hH+G, w:W, h:hH }
      ]
    },
    'left-1-right-2': {
      slots: 3,
      regions: [
        { l:0,    t:0,    w:hW, h:H  },
        { l:hW+G, t:0,    w:hW, h:hH },
        { l:hW+G, t:hH+G, w:hW, h:hH }
      ]
    },
    'left-2-right-1': {
      slots: 3,
      regions: [
        { l:0,    t:0,    w:hW, h:hH },
        { l:0,    t:hH+G, w:hW, h:hH },
        { l:hW+G, t:0,    w:hW, h:H  }
      ]
    },
    'three-col': {
      slots: 3,
      regions: [
        { l:0,          t:0, w:tW, h:H },
        { l:tW+G,       t:0, w:tW, h:H },
        { l:2*(tW+G),   t:0, w:W-2*(tW+G), h:H }
      ]
    },
    '2x2': {
      slots: 4,
      regions: [
        { l:0,    t:0,    w:hW, h:hH },
        { l:hW+G, t:0,    w:hW, h:hH },
        { l:0,    t:hH+G, w:hW, h:hH },
        { l:hW+G, t:hH+G, w:hW, h:hH }
      ]
    }
  };
}

function createMultiBlockLayout(masterComp, params) {
  var fps    = masterComp.frameRate;
  var dur    = masterComp.duration;
  var W      = 1920; var H = 1080;
  var layouts = _ebMultiLayouts();
  var layout;
  // Custom AI-driven regions: when the AI supplies its own region rectangles,
  // build a layout on-the-fly. Each region is {l, t, w, h} in pixels (canvas
  // 1920x1080). We clamp every region inside the canvas and reject obviously
  // bad input so a malformed AI response can't render off-screen blocks.
  if (params.multiLayout === 'custom' && params.customRegions && params.customRegions.length) {
    var regions = [];
    for (var ri = 0; ri < params.customRegions.length; ri++) {
      var r = params.customRegions[ri] || {};
      var l = Math.max(0, Math.min(W - 40, parseInt(r.l, 10) || 0));
      var t = Math.max(0, Math.min(H - 40, parseInt(r.t, 10) || 0));
      var rw = Math.max(40, Math.min(W - l, parseInt(r.w, 10) || 0));
      var rh = Math.max(40, Math.min(H - t, parseInt(r.h, 10) || 0));
      regions.push({ l: l, t: t, w: rw, h: rh });
    }
    if (regions.length) {
      layout = { slots: regions.length, regions: regions };
    } else {
      layout = layouts['split-h'];
    }
  } else {
    layout = layouts[params.multiLayout] || layouts['split-h'];
  }
  var slots   = params.slots || [];
  var nSlots  = Math.min(slots.length, layout.slots);

  // Shared base params for every slot
  var baseParams = {
    title:       '',
    subtitle:    '',
    accentColor: params.accentColor || '76B900',
    animateIn:   params.animateIn !== false,
    posAnim:     params.posAnim    !== false,
    shapeFill:   false,
    cardBorder:  params.cardBorder || false,
    dropShadow:  params.dropShadow !== false,
    noHeader:    true
  };

  for (var i = 0; i < nSlots; i++) {
    var slot   = slots[i];
    if (!slot || !slot.blockType) continue;
    var region = layout.regions[i];

    // Build per-slot params: merge base + slot overrides
    var sp = {};
    for (var k in baseParams) { sp[k] = baseParams[k]; }
    for (var k2 in slot)      { sp[k2] = slot[k2]; }
    sp.noHeader = true;

    // Compute scale and center position in master comp
    var scale  = Math.min(region.w / W, region.h / H) * 100;
    var cx     = region.l + Math.round(region.w / 2);
    var cy     = region.t + Math.round(region.h / 2);

    // Create sub-comp
    var subComp;
    try {
      subComp = app.project.items.addComp(
        'EB_Slot' + (i+1) + '_' + slot.blockType,
        W, H, 1, dur, fps
      );
      subComp.bgColor = [1, 1, 1];
    } catch(e) { continue; }

    // White background solid
    try { subComp.layers.addSolid([1,1,1], 'EB_Background', W, H, 1); } catch(e) {}

    // Call the block function
    try { _ebDispatch(subComp, sp); } catch(e) {}

    // Apply easing to sub-comp
    try { ebApplyEaseToComp(subComp); } catch(e) {}

    // Add sub-comp to master as a layer
    var subLayer;
    try {
      subLayer = masterComp.layers.add(subComp);
      subLayer.position.setValue([cx, cy]);
      subLayer.property('Transform').property('Scale').setValue([scale, scale]);
    } catch(e) {}
  }

  // Title + subtitle on the master comp (centered at top, same as all other blocks)
  ebCreateHeader(masterComp, params, 1);
}

// Dispatcher: called by hostscript with existing comp + JSON array of inject objects
function ebpApplyInjectables(comp, injectsJSON) {
  try {
    var injects = JSON.parse(injectsJSON);
    for (var i = 0; i < injects.length; i++) {
      var inj = injects[i];
      if (!inj || !inj.type) continue;
      try {
        if      (inj.type === 'inj-stat')      { ebpAddInjStat(comp, inj); }
        else if (inj.type === 'inj-badge')     { ebpAddInjBadge(comp, inj); }
        else if (inj.type === 'inj-source')    { ebpAddInjSource(comp, inj); }
        else if (inj.type === 'inj-kpi-strip') { ebpAddInjKPIStrip(comp, inj); }
      } catch(e2) {}
    }
    ebApplyEaseToComp(comp);
    return 'ok';
  } catch(e) {
    return 'error: ' + e.message;
  }
}
