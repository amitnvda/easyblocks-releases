# EasyBlocks Pro — Installation Guide
**Version 1.1.0**

---

## What You Need

| Requirement | Details |
|---|---|
| **Adobe After Effects** | Version 2022 (22.0) or later |
| **Node.js LTS** | Required for AI Generate — [nodejs.org](https://nodejs.org) |
| **Claude CLI** | `npm install -g @anthropic-ai/claude-code` |
| **Python 3** | Required for PDF import — usually pre-installed on macOS |
| **PyMuPDF** | Required for PDF import — `pip3 install pymupdf` |
| **NVIDIA Sans font** | Included in the ZIP — install before opening AE |
| **ZXP Installer** | Free — [zxpinstaller.com](https://www.zxpinstaller.com) |

---

## macOS — Fresh Install

### Step 1 — Install Node.js
1. Go to [nodejs.org](https://nodejs.org) and download the **LTS** version
2. Run the `.pkg` installer
3. Verify — open **Terminal** and run:
   ```bash
   node --version
   ```
   You should see a version number (e.g. `v20.11.0`)

### Step 2 — Install Claude CLI
In Terminal:
```bash
npm install -g @anthropic-ai/claude-code
```
Verify:
```bash
claude --version
```

### Step 3 — Install PyMuPDF (for PDF import)
In Terminal:
```bash
pip3 install pymupdf
```
Verify:
```bash
python3 -c "import fitz; print(fitz.__version__)"
```
You should see a version number. If `pip3` is not found, install Python from [python.org](https://www.python.org) first.

> **Note:** This is only required if you plan to import PDF files in the Deck Import tab. PPTX import works without it.

### Step 4 — Install NVIDIA Sans Font
1. Open the `fonts/` folder from the ZIP
2. Select all `.ttf` / `.otf` files → right-click → **Open with Font Book**
3. Click **Install Font** for each file (or select all and install at once)

### Step 5 — Enable CEP Debug Mode
One-time setting that allows the extension to load in After Effects.

Open **Terminal** and paste all 4 lines, then press Enter:
```bash
defaults write com.adobe.CSXS.9  PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

### Step 6 — Install ZXP Installer
1. Go to [zxpinstaller.com](https://www.zxpinstaller.com) and download the free app
2. Open the `.dmg` and drag **ZXP Installer** to your Applications folder

### Step 7 — Install the Extension
1. Open **ZXP Installer**
2. Drag `EasyBlocksPro-1.1.0.zxp` onto the ZXP Installer window
3. Click **Install** when prompted and wait for the green checkmark

### Step 8 — Launch After Effects
1. **Fully quit and relaunch** Adobe After Effects (a full restart is required)
2. Go to **Window → Extensions → EasyBlocks Pro**
3. The panel opens — you're ready

---

## Windows — Fresh Install

### Step 1 — Install Node.js
1. Go to [nodejs.org](https://nodejs.org) and download the **LTS** version
2. Run the `.msi` installer, accept all defaults
3. Verify — open **Command Prompt** and run:
   ```
   node --version
   ```

### Step 2 — Install Claude CLI
In Command Prompt:
```
npm install -g @anthropic-ai/claude-code
```

### Step 3 — Install PyMuPDF (for PDF import)
In Command Prompt or PowerShell:
```
python -m pip install pymupdf
```
Verify:
```
python -c "import fitz; print(fitz.__version__)"
```
If `python` is not found, install Python from [python.org](https://www.python.org) — make sure to check **"Add Python to PATH"** during setup, then retry.

> **Note:** Only required for PDF import in the Deck Import tab. PPTX import works without it.

### Step 4 — Install NVIDIA Sans Font
1. Open the `fonts/` folder from the ZIP
2. Select all font files → right-click → **Install for all users**

### Step 5 — Enable CEP Debug Mode
1. Press `Win + R`, type `cmd`, press `Ctrl + Shift + Enter` to open as **Administrator**
2. Paste all 4 lines and press Enter:
   ```
   reg add "HKCU\Software\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f
   ```

### Step 6 — Install ZXP Installer
1. Go to [zxpinstaller.com](https://www.zxpinstaller.com) and download the Windows version
2. Run the installer

### Step 7 — Install the Extension
1. Open **ZXP Installer**
2. Drag `EasyBlocksPro-1.1.0.zxp` onto the ZXP Installer window
3. Click **Install** when prompted

### Step 8 — Launch After Effects
1. **Fully quit and relaunch** Adobe After Effects
2. Go to **Window → Extensions → EasyBlocks Pro**

---

## Verify the Installation

1. Open any AE project with an active composition
2. In the **Blocks** tab, select **3 Cards**, enter any title, click **Insert**
   → A new comp `EBP_3Cards_...` appears in your project ✓
3. Switch to the **AI Generate** tab, type `"GPU performance comparison"`, click **Generate**
   → Claude creates a block ✓

---

## Updating from a Previous Version

### Option A — ZXP Installer (recommended)
1. Open **ZXP Installer**
2. Click the **×** next to EasyBlocks Pro to uninstall the old version
3. Drag `EasyBlocksPro-1.1.0.zxp` onto ZXP Installer → **Install**
4. Fully restart After Effects

### Option B — Manual file replacement (macOS)
Use this if you received `EasyBlocksPro-1.1.0-update.zip` instead of the ZXP:
1. Quit After Effects
2. Unzip the file
3. Copy the contents of the unzipped folder into:
   ```
   ~/Library/Application Support/Adobe/CEP/extensions/com.nvidia.easyblockspr/
   ```
   Overwrite all files when prompted
4. Relaunch After Effects — no reinstall needed, no debug mode change needed

### Option B — Manual file replacement (Windows)
1. Quit After Effects
2. Unzip `EasyBlocksPro-1.1.0-update.zip`
3. Copy the contents into:
   ```
   C:\Users\<YourName>\AppData\Roaming\Adobe\CEP\extensions\com.nvidia.easyblockspr\
   ```
4. Relaunch After Effects

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Panel not visible in Window → Extensions | Debug mode not set — redo Step 4, then **fully restart** AE |
| Panel appears blank or white | Right-click the panel title → **Reload Extension** |
| Text renders in wrong font or shows boxes | NVIDIA Sans not installed — redo Step 3, restart AE |
| AI Generate does nothing | Run `claude --version` in Terminal — if missing, redo Step 2 |
| "No module named 'fitz'" error on PDF import | Run `pip3 install pymupdf` in Terminal, then retry |
| "Node not found" error in AI tab | Install Node.js and **fully restart** AE (panel refresh is not enough) |
| Blocks insert but look wrong | Make sure a composition is active and open in the viewer before clicking Insert |
| ZXP Installer says "already installed" | Uninstall first (click ×), then install the new version |
| Extension disappears after AE update | Reinstall the ZXP — AE updates sometimes clear extensions |

---

## Extension Location

For manual access or troubleshooting:

**macOS:**
```
~/Library/Application Support/Adobe/CEP/extensions/com.nvidia.easyblockspr/
```

**Windows:**
```
C:\Users\<YourName>\AppData\Roaming\Adobe\CEP\extensions\com.nvidia.easyblockspr\
```
