/**
 * EasyBlocks Pro — AI Generate Bridge
 * Spawned by the CEP panel as: node ai-generate.js --config /tmp/ebp_xxx.json
 *
 * Config JSON: { systemPrompt, userMessage, imagePath (optional), outputPath }
 * On success: writes result text to outputPath, exits 0
 * Progress/logs: written to stderr as plain text lines
 */
'use strict';

var fs   = require('fs');
var os   = require('os');
var path = require('path');
var spawn = require('child_process').spawn;

// ── Parse args ────────────────────────────────────────────────────────────
var args = process.argv.slice(2);
var configIdx = args.indexOf('--config');
if (configIdx === -1 || !args[configIdx + 1]) {
  process.stderr.write('Usage: node ai-generate.js --config <path>\n');
  process.exit(1);
}
var config;
try {
  config = JSON.parse(fs.readFileSync(args[configIdx + 1], 'utf8'));
} catch(e) {
  process.stderr.write('Could not read config: ' + e.message + '\n');
  process.exit(1);
}

var systemPrompt = config.systemPrompt || '';
var userMessage  = config.userMessage  || '';
var imagePath    = config.imagePath    || null;
var outputPath   = config.outputPath;
var model        = config.model        || 'sonnet';

if (!outputPath) {
  process.stderr.write('config.outputPath required\n');
  process.exit(1);
}

// ── Find claude binary ────────────────────────────────────────────────────
var homedir = os.homedir();
var claudeCandidates = [
  path.join(homedir, '.local', 'bin', 'claude'),
  '/usr/local/bin/claude',
  '/opt/homebrew/bin/claude',
  '/usr/bin/claude'
];
var claudeBin = 'claude';
for (var i = 0; i < claudeCandidates.length; i++) {
  try { if (fs.existsSync(claudeCandidates[i])) { claudeBin = claudeCandidates[i]; break; } } catch(e) {}
}
process.stderr.write('claude: ' + claudeBin + '\n');

// ── Build stream-json input ────────────────────────────────────────────────
var content = [];
if (imagePath) {
  process.stderr.write('Loading image: ' + imagePath + '\n');
  try {
    var imgBuf  = fs.readFileSync(imagePath);
    var b64     = imgBuf.toString('base64');
    var ext     = path.extname(imagePath).slice(1).toLowerCase();
    var mimeMap = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp' };
    var mime    = mimeMap[ext] || 'image/png';
    content.push({ type: 'image', source: { type: 'base64', media_type: mime, data: b64 } });
    process.stderr.write('Image loaded: ' + Math.round(b64.length / 1024) + ' KB base64\n');
  } catch(e) {
    process.stderr.write('Warning: could not read image (' + e.message + ') — continuing text-only\n');
  }
}
content.push({ type: 'text', text: userMessage });

var streamInput = JSON.stringify({
  type: 'user',
  message: { role: 'user', content: content }
}) + '\n';

// ── Spawn claude ───────────────────────────────────────────────────────────
var childEnv = Object.assign({}, process.env);
delete childEnv.CLAUDECODE; // allow nested invocation

var extraPaths = [
  homedir + '/.local/bin',
  '/usr/local/bin', '/opt/homebrew/bin',
  '/usr/bin', '/bin'
].join(':');
childEnv.PATH = extraPaths + (childEnv.PATH ? ':' + childEnv.PATH : '');

var claudeArgs = [
  '--print',
  '--verbose',
  '--input-format',  'stream-json',
  '--output-format', 'stream-json',
  '--system-prompt', systemPrompt,
  '--model', model,
  '--no-session-persistence',
  '--dangerously-skip-permissions'
];

process.stderr.write('Spawning claude…\n');

var child = spawn(claudeBin, claudeArgs, {
  stdio: ['pipe', 'pipe', 'pipe'],
  env: childEnv,
  cwd: os.tmpdir()
});

child.stdin.write(streamInput);
child.stdin.end();
process.stderr.write('Prompt sent (' + Math.round(streamInput.length / 1024) + ' KB)\n');

// ── Collect output ─────────────────────────────────────────────────────────
var stdout = '';
var stderr = '';
var gotDelta = false;

child.stdout.on('data', function(d) {
  var chunk = d.toString();
  stdout += chunk;
  // Forward streaming progress signals
  chunk.split('\n').forEach(function(line) {
    line = line.trim();
    if (!line) return;
    try {
      var evt = JSON.parse(line);
      if (evt.type === 'content_block_delta' && evt.delta && evt.delta.type === 'text_delta') {
        if (!gotDelta) {
          process.stderr.write('STREAMING\n'); // signal to panel that response has started
          gotDelta = true;
        }
      }
    } catch(e) {}
  });
});

child.stderr.on('data', function(d) {
  var t = d.toString().trim();
  if (t) { stderr += t + '\n'; process.stderr.write(t + '\n'); }
});

child.on('error', function(e) {
  process.stderr.write('spawn error: ' + e.message + '\n');
  process.exit(1);
});

child.on('close', function(code) {
  process.stderr.write('claude exited: ' + code + '\n');

  // Parse stream-json output
  var deltaText = '', lastAssistant = '', resultText = '';
  stdout.split('\n').forEach(function(line) {
    line = line.trim();
    if (!line) return;
    try {
      var evt = JSON.parse(line);
      if (evt.type === 'content_block_delta' && evt.delta && evt.delta.type === 'text_delta') {
        deltaText += evt.delta.text;
      }
      if (evt.type === 'assistant' && evt.message && Array.isArray(evt.message.content)) {
        var t = evt.message.content.filter(function(b) { return b.type === 'text'; }).map(function(b) { return b.text; }).join('');
        if (t) lastAssistant = t;
      }
      if (evt.type === 'result' && evt.result) {
        resultText = evt.result;
      }
    } catch(e) {}
  });

  var result = (resultText || lastAssistant || deltaText).trim();

  if (!result) {
    process.stderr.write('ERROR: no text in output (code=' + code + ')\nstdout: ' + stdout.slice(0, 300) + '\n');
    process.exit(code || 1);
  }

  try {
    fs.writeFileSync(outputPath, result, 'utf8');
    process.stderr.write('OK: result written to ' + outputPath + '\n');
    process.exit(0);
  } catch(e) {
    process.stderr.write('Could not write output: ' + e.message + '\n');
    process.exit(1);
  }
});
