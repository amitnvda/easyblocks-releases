# EasyBlocks Pro — Documentation
**Version 1.1.0**

EasyBlocks Pro is an Adobe After Effects CEP panel that lets you insert pre-built slide blocks and generate new ones using Claude AI. One click creates a fully animated, NVIDIA-branded composition — ready to render.

---

## Overview

- **74 blocks** across 9 categories: Cards, Text, Diagrams, Trees, Charts, Tables, Topologies, Lower Thirds, Components
- **AI Generate tab** — describe a slide or drop in a screenshot, get a block back
- **My Blocks** — save any AI-generated result as a reusable custom block
- **Deck Import** — drop a PPTX or PDF, convert every slide to a block automatically

---

## Panel Tabs

### Blocks Tab
Browse and insert blocks from the library. Controls at the bottom adapt to the selected block type.

**Bottom bar controls:**

| Control | What it does |
|---|---|
| Animate in | Layers fade/slide in from frame 1 |
| Pos anim | Position keyframes included |
| Card BG | Add dark background behind cards |
| Border | Stroke border on card edges |
| Shadow | Drop shadow on cards |
| BODY (Text / Bullets / Pipes) | Body content style for Cards 1–5 and Compare Cards |
| CARDS 1–5 | Number of cards for the Cards block |
| Count pickers | Block-specific count row (appears when relevant) |
| THEME Dark / Light | Compare Table only |

### AI Generate Tab
Type a prompt or drop a slide image. Claude generates the best-fit block for the content.

**Modes:**
- **Prompt** — describe what you want in plain text
- **Media** — drop a screenshot of an existing slide; Claude reads it and rebuilds it as a block

**After generation:**
- Preview appears in the tab
- Click **Insert** to create the comp in After Effects
- Click **Tweak** to refine with a follow-up instruction
- Click **Save to My Blocks** to keep the result for later reuse

### Deck Import Tab
Drop a full PPTX or PDF presentation. EasyBlocks Pro converts each slide to a block, creates one comp per slide, and optionally pre-comps everything into a master timeline.

---

## Block Reference

### Cards (10 blocks)

| Block | ID | Description |
|---|---|---|
| 1 Card | `cards-1` | Single icon card |
| 2 Cards | `cards-2` | Two icon cards side by side |
| 3 Cards | `cards-3` | Three icon cards (most common layout) |
| 4 Cards | `cards-4` | Four icon cards |
| 5 Cards | `cards-5` | Five icon cards |
| Compare Cards | `cards-compare` | Two-column feature comparison |
| Media Cards | `cards-media` | Cards with large image placeholder areas |
| Corner Cards | `cards-corner` | Rounded corner accent cards |
| Corner Square | `cards-corner-sq` | Corner cards with square icon accent |
| Corner Slim | `cards-corner-slim` | Compact single-line corner cards |
| Specs A | `cards-specs-a` | Feature spec card: title + bullets + chip tags |
| Specs B | `cards-specs-b` | Two-column spec card |
| Specs C | `cards-specs-c` | Dense spec card with numbered items |

**Controls:** BODY style (Text / Bullets / Pipes), CARDS count (1–5), Card BG, Border, Shadow

---

### Text (15 blocks)

| Block | ID | Description |
|---|---|---|
| Pipe List | `bullets` | Vertical bar–separated list items |
| Squares List | `text-bullets` | Accent square bullet points |
| Bullet List | `bullet-list` | Standard • bullet list |
| Checklist | `check-list` | Checkbox-style checklist |
| Nested | `text-nested` | 3 main items with 2 sub-bullets each |
| 2 Columns | `text-2col` | Side-by-side text columns |
| Numbered | `text-numbered` | Numbered list with accent numbers |
| Code + Log | `text-code-cli` | Code block with terminal output below |
| Code Bullets | `text-code-bullets` | Code snippet with labeled callouts |
| Code Quad | `text-code-quad` | 4 code panels in a 2×2 grid |
| Code Split | `text-code-split` | Side-by-side before/after code |
| Body + Bullets | `text-body-bullets` | Paragraph body with supporting bullets |
| Errors | `text-errors` | Error / warning message list |
| Links | `text-links` | URL list with descriptions |
| Agenda | `text-agenda` | Session agenda with time slots |
| Acronym | `text-acronym` | Term + definition pairs |

---

### Diagrams (14 blocks)

| Block | ID | Description |
|---|---|---|
| Flow | `diagram-flow` | Linear pipeline A→B→C, 2–5 stages |
| Flow Bullets | `diagram-flow-bullets-3` | 3 columns with numbered badges + bullets |
| Cycle | `diagram-cycle` | Circular 4-phase lifecycle |
| Process | `diagram-process-2` | 2-row process matrix |
| Timeline | `diagram-timeline` | Horizontal milestone roadmap, 2–10 events |
| Steps | `diagram-steps` | Numbered sequential steps, 3–8 items |
| Funnel | `diagram-funnel` | Narrowing conversion funnel |
| Matrix | `diagram-matrix` | 2×2 priority/effort quadrant |
| Hub + Spoke | `diagram-hub-spoke` | Central concept + 3–12 satellite nodes |
| Parallel Split | `diagram-parallel-split-ol` | One input → 2 parallel paths |
| Split 2 | `diagram-split-2-ol` | 1 source → 2 results |
| Split 3 | `diagram-split-3-ol` | 1 source → 3 results |
| Split 5 | `diagram-split-5-ol` | 1 source → 5 results |
| Split Mirror | `diagram-split-mirror-ol` | Mirrored split layout |

---

### Trees (4 blocks)

| Block | ID | Description |
|---|---|---|
| Tree 3 | `tree-3` | Root → 3 children |
| Tree 2-Level | `tree-2level` | Root → 2 parents → children |
| Tree H3 | `tree-h3` | Horizontal 3-branch tree |
| Tree H5 | `tree-h5` | Horizontal 5-branch tree |

---

### Charts (13 blocks)

| Block | ID | Best for |
|---|---|---|
| Bar (H) | `chart-bar` | Category comparisons, up to 8 items |
| Bar (V) | `chart-bar-v` | Category comparisons, vertical orientation |
| Stacked Bar | `chart-bar-stacked` | Part-to-whole across categories |
| Grouped Bar | `chart-bar-grouped` | Side-by-side series comparison |
| Donut | `chart-donut` | Proportions / shares, up to 8 segments |
| Pie | `chart-pie` | Proportions, up to 8 segments |
| Line | `chart-line` | Trends over time, 2–4 series |
| Area | `chart-area` | Trends + volume, 2–4 series |
| Progress | `chart-progress` | % completion bars, up to 5 items |
| Radar | `chart-radar` | Multi-axis capability comparison |
| Scatter | `chart-scatter` | X/Y distribution |
| Bubble | `chart-bubble` | 3-dimensional data (X / Y / size) |
| Waterfall | `chart-waterfall` | Cumulative gains and losses |

---

### Tables (4 blocks)

| Block | ID | Description |
|---|---|---|
| 1 Column | `table-1col` | Single-column data table |
| 2 Column | `table-2col` | Two-column table with header row |
| 3 Column | `table-3col` | Three-column table |
| 4 Column | `table-4col` | Four-column table |

---

### Topologies (5 blocks)

| Block | ID | Description |
|---|---|---|
| GH200 Pair | `topology-gh200` | GH200 NVLink pair diagram |
| NVLink Switch | `topology-nvlink-switch` | NVLink switch fabric topology |
| Spine–Leaf | `topology-spine-leaf` | Spine-leaf network topology |
| GPU Node | `topology-gpu-node` | Single GPU node layout |
| Multi-Rack | `topology-multi-rack` | Multi-rack cluster topology |

---

### Lower Thirds (1 block)

| Block | ID | Description |
|---|---|---|
| Insight Card | `comp-callout` | Highlight box: accent left bar + KEY INSIGHT label + headline + body |

---

### Components (10 blocks)

| Block | ID | Description |
|---|---|---|
| Timeline | `comp-timeline` | Horizontal roadmap, 3–5 milestones with date + title + desc |
| Logo Strip | `comp-logo-strip` | Row of logo placeholder boxes (3–6) |
| Compare Table | `comp-compare` | Feature table: Feature \| Traditional \| NVIDIA. 4/5/6 rows. Dark/Light theme toggle |
| Tags | `comp-tags` | Technology chip strip (4/6/8 chips) |
| Icon Grid | `comp-icon-grid` | Icon placeholder row (3–6) with label + description |
| Stat Callout | `comp-stat` | Single dominant metric (number + label) |
| KPI Row | `comp-kpi` | 2–5 KPI metrics side by side |
| Pull Quote | `comp-quote` | Impactful quote with attribution |
| Section Divider | `comp-divider` | Chapter title / section break |
| Rack + Callouts | `rack-callout` | Server rack diagram with callout annotations |

---

## AI Generate — How It Works

1. Panel spawns `claude -p "..."` as a child process
2. Claude receives a structured prompt with the full block inventory
3. Claude returns a JSON block plan (`{ blockType, title, ... }`)
4. Panel validates `blockType` against all 74 known block IDs
5. Panel calls `createBlock(params)` in After Effects via `cs.evalScript`
6. The resulting comp opens in the AE viewer

**Parameters Claude fills in:**

| Field | Type | Used by |
|---|---|---|
| `blockType` | string | All blocks |
| `title` / `subtitle` | string | All blocks |
| `bullets` | string[] | Text + list blocks |
| `cards` | `{label, text, icon}[]` | Card blocks |
| `accentColor` | hex string | All blocks |
| `count` | number | Timeline, Logo Strip, Compare, Tags, Icon Grid |
| `compareTheme` | `'dark'` \| `'light'` | Compare Table |
| `kpis` | `{number, label, desc}[]` | KPI Row |
| `statNumber` / `statLabel` | string | Stat Callout |
| `quote` / `author` | string | Pull Quote |
| Chart data arrays | varies | All chart blocks |

**Two-pass validation:** Claude first outputs a plan JSON. The panel validates `blockType` against the full inventory before calling AE. Unknown IDs are rejected without touching After Effects.

---

## My Blocks

AI-generated blocks can be saved to `~/.ebp_my_blocks/` as JSON files. They appear in the **My Blocks** accordion and can be re-inserted at any time with the same parameters.

---

## Accent Colors

The color swatches in the panel set `accentColor`. Default is NVIDIA Green (`76B900`). All blocks use this for header bars, icon squares, chart fills, chip borders, and category labels.

---

## Technical Notes

- **Requires:** Adobe After Effects 2022 (v22.0) or later
- **Font:** NVIDIA Sans (Bold, Medium, Regular, Light) — must be installed separately
- **Comp size:** All blocks create 1920×1080 @ 30fps, 10-second compositions
- **Background layer:** White solid (`EB_Background`) sits at the bottom of every comp — hide or replace for dark-background slides
- **Shape fills:** AE 2024+ silently ignores shape layer fill colors. All visible fills use `addSolid` layers
- **Animation start:** Frame 1 — frame 0 is a clean hold frame before the animation begins

---

## Folder Structure

```
com.nvidia.easyblockspr/
├── CSXS/
│   └── manifest.xml          — CEP manifest (version, host requirements)
├── panel/
│   ├── index.html            — Panel UI (all block buttons, count rows, bottom bar)
│   ├── app.js                — Panel logic, AI Generate, Deck Import
│   └── styles.css            — NVIDIA dark theme
├── jsx/
│   ├── hostscript.jsx        — AE entry point; hot-reloads blocks.jsx on every call
│   ├── blocks.jsx            — All 74 block creation functions
│   └── utils.jsx             — Shared helpers: ebText, ebAnimateFadeUp, ebColor, etc.
├── fonts/                    — NVIDIA Sans font files
└── scripts/
    ├── ai-generate.js        — Claude CLI bridge
    └── bridge.js             — Panel ↔ Node.js IPC
```

---

## Changelog

### 1.2.0
- Renamed "Callout Box" to "Insight Card" (`comp-callout`) and moved it to a new Lower Thirds category
- Total block count: 74

### 1.1.0
- Added 4 new Component blocks: Compare Table (dark/light theme), Tags, Callout Box, Icon Grid
- Added Timeline and Logo Strip component blocks
- Fixed duplicate `createTimelineBlock` function conflict (`comp-timeline` vs `diagram-timeline`)
- Added 9 missing chart types to AI Generate validation and prompt guidance
- Corrected total block count to 76
- Rack block rewritten to use `addSolid` for all fills (AE 2024+ shape fill bug)

### 1.0.0
- Initial release: 57 blocks across Cards, Text, Diagrams, Trees, Charts, Tables, Topologies
- AI Generate with Claude CLI
- My Blocks save/restore
- Deck Import (PPTX + PDF)
