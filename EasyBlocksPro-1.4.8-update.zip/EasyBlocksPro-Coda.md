# EasyBlocks Pro — Documentation

**Version:** 1.2.0 | **Platform:** Adobe After Effects (Mac & Windows)

---

EasyBlocks Pro is an internal After Effects panel built for the NVIDIA video production team. It lets you insert pre-built, fully animated slide blocks into any composition with a single click — and generate new ones using Claude AI from a text prompt or a slide screenshot.

---

## Table of Contents

1. [What is this?](#what-is-this)
2. [Requirements](#requirements)
3. [Installation](#installation)
4. [Inserting a Block](#inserting-a-block)
5. [AI Generate](#ai-generate)
6. [My Blocks](#my-blocks)
7. [Deck Import](#deck-import)
8. [Block Reference](#block-reference)
9. [Bottom Bar Controls](#bottom-bar-controls)
10. [Troubleshooting](#troubleshooting)
11. [Version History](#version-history)

---

## What is this?

EasyBlocks Pro gives you a library of 74 NVIDIA-branded slide blocks — cards, text layouts, charts, diagrams, tables, topologies, and more. Each block creates a new 1920×1080 composition with animated layers, NVIDIA Sans typography, and the correct green accent color.

The AI Generate tab lets you describe a slide in plain English (or drop a screenshot) and get a finished block back in seconds.

---

## Requirements

- Adobe After Effects 2022 (v22.0) or later
- Node.js LTS — [nodejs.org](https://nodejs.org)
- Claude CLI — `npm install -g @anthropic-ai/claude-code`
- NVIDIA Sans font — included in the ZIP, install before opening AE
- macOS or Windows 10/11

---

## Installation

### Mac

1. Unzip `EasyBlocksPro-1.2.0.zip`
2. Install the NVIDIA Sans fonts from the `fonts/` folder (select all → right-click → Open with Font Book → Install)
3. Enable CEP debug mode — open Terminal and run:
   ```bash
   defaults write com.adobe.CSXS.9  PlayerDebugMode 1
   defaults write com.adobe.CSXS.10 PlayerDebugMode 1
   defaults write com.adobe.CSXS.11 PlayerDebugMode 1
   defaults write com.adobe.CSXS.12 PlayerDebugMode 1
   ```
4. Install the extension using [ZXP Installer](https://www.zxpinstaller.com) — drag `EasyBlocksPro-1.2.0.zxp` onto the window
5. Fully quit and relaunch After Effects
6. Go to **Window → Extensions → EasyBlocks Pro**

### Windows

1. Unzip `EasyBlocksPro-1.2.0.zip`
2. Install the NVIDIA Sans fonts — select all font files → right-click → **Install for all users**
3. Enable CEP debug mode — open Command Prompt as Administrator and run:
   ```
   reg add "HKCU\Software\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f
   ```
4. Install via ZXP Installer
5. Fully restart After Effects
6. Go to **Window → Extensions → EasyBlocks Pro**

---

## Inserting a Block

1. Open a project with an active composition
2. In the **Blocks** tab, browse the categories and click a block thumbnail to select it
3. Fill in **Title** and **Subtitle** in the fields at the top
4. Adjust any block-specific options in the bottom bar (count, style, animation)
5. Click **Insert Block**

A new comp named `EBP_<BlockName>_<Title>` appears in your project, ready to drop into your master timeline.

---

## AI Generate

**Prompt mode** — describe the slide you need:
1. Switch to the **AI Generate** tab
2. Select **Prompt**
3. Type a description (e.g. *"GPU performance comparison: H100 vs A100 vs V100"*)
4. Click **Generate**

**Media mode** — rebuild from a screenshot:
1. Select **Media**
2. Drop a slide screenshot onto the drop zone
3. Click **Generate**

After generation:
- Click **Insert** to create the comp in After Effects
- Click **Tweak** to refine with a follow-up instruction
- Click **Save to My Blocks** to keep the result for reuse

---

## My Blocks

AI-generated blocks can be saved to `~/.ebp_my_blocks/` as JSON files. They appear in the **My Blocks** accordion at the bottom of the Blocks tab and can be re-inserted at any time with the same parameters.

---

## Deck Import

1. Switch to the **Deck Import** tab
2. Drop a PPTX or PDF onto the import area
3. EasyBlocks Pro converts each slide to the best-fit block type, creates one comp per slide, and optionally pre-comps everything into a master timeline

---

## Block Reference

### Cards (13 blocks)
Single to 5-card icon layouts, Compare Cards, Media Cards, Corner variants, and Specs cards (A/B/C).

### Text (17 blocks)
Pipe List, Squares List, Bullet List, Checklist, Nested, 2 Columns, Numbered, Agenda, Acronym, Code+Log, Code Bullets, Code Quad, Code Split, Body+Bullets, Errors, Links, Bullets+CLI.

### Diagrams (16 blocks)
Flow, Flow 4-Step, Flow Bullets, Cycle, Process, Challenge/Solution, Timeline, Steps, Funnel, Matrix, Hub+Spoke, Parallel Split, Split 2/3/5, Split Mirror.

### Trees (4 blocks)
Tree 3, Tree 2-Level, Tree H3, Tree H5.

### Charts (13 blocks)
Bar (H/V), Stacked Bar, Grouped Bar, Donut, Pie, Line, Area, Progress, Radar, Scatter, Bubble, Waterfall.

### Tables (4 blocks)
1–4 Column data tables.

### Topologies (5 blocks)
GH200 Pair, NVLink Switch, Spine-Leaf, GPU Node, Multi-Rack.

### Lower Thirds (1 block)
**Insight Card** (`comp-callout`) — accent left bar + KEY INSIGHT label + headline + body.

### Components (10 blocks)
Timeline, Logo Strip, Compare Table, Tags, Icon Grid, Stat Callout, KPI Row, Pull Quote, Section Divider, Rack + Callouts.

---

## Bottom Bar Controls

| Control | What it does |
|---|---|
| **Animate in** | Layers fade/slide in from frame 1 |
| **Pos anim** | Position keyframes included |
| **Card BG** | Dark background behind cards |
| **Border** | Stroke border on card edges |
| **Shadow** | Drop shadow on cards |
| **BODY** | Body content style for Cards 1–5 and Compare (Text / Bullets / Pipes) |
| **CARDS 1–5** | Number of cards |
| **Count pickers** | Block-specific row (appears when relevant) |
| **THEME Dark/Light** | Compare Table only |

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Panel not in Window → Extensions | CEP debug mode not set — redo Step 3, then **fully restart** AE |
| Panel appears blank | Right-click panel title → **Reload Extension** |
| Wrong font / boxes instead of text | NVIDIA Sans not installed — install fonts and restart AE |
| AI Generate does nothing | Run `claude --version` in Terminal — if missing, run `npm install -g @anthropic-ai/claude-code` |
| "Node not found" error | Install Node.js and **fully restart** AE (panel reload is not enough) |
| Block inserts but looks wrong | Make sure a composition is active and open before clicking Insert |
| Extension disappears after AE update | Reinstall the ZXP — AE updates sometimes clear extensions |

---

## Version History

| Version | Notes |
|---|---|
| **1.2.0** | Renamed "Callout Box" to "Insight Card", moved to new Lower Thirds category |
| **1.1.0** | Added Compare Table, Tags, Callout Box, Icon Grid, Timeline, Logo Strip components; 9 new chart types; total 76 blocks |
| **1.0.0** | Initial release: 57 blocks, AI Generate, My Blocks, Deck Import |

---

*EasyBlocks Pro is an internal tool developed for NVIDIA video production. For questions or to report issues, contact the video production team.*
